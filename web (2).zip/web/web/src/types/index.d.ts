/* eslint-disable */
declare module 'jquery';