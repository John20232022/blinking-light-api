import Vue from 'vue'
import Element from 'element-ui'
import '@/assets/styles/element-variables.scss'
import '@/assets/js/elementSetting' // element 全局样式配置
import '@/assets/styles/index.css' // global css

import App from './App'
import router from './router'
import plugins from './plugins' // plugins
import Axios from '@/utils/request'

import * as echarts from 'echarts'

// 文件下载全局挂载
import utils from '@/utils/common.js'
Vue.prototype.$utils = utils
Vue.prototype.$axios = Axios
Vue.prototype.$echarts = echarts

import '@/permission' // permission control

Vue.use(plugins)

Vue.use(Element, {
  size: 'medium' // set element-ui default size small
})

Vue.config.productionTip = false // 阻止你显示显示生产模式的消息

import i18n from '@/language'

new Vue({
  el: '#app',
  router,
  i18n,
  render: h => h(App)
})
