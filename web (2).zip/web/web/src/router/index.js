import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

// 这里配置路由
export const constantRoutes = [
  {
    path: '*',
    component: () => import('@/views/error/404')
  },
  {
    path: '/404',
    component: () => import('@/views/error/404')
  },
  {
    path: '/401',
    component: () => import('@/views/error/401')
  },
  {
    path: '',
    component: () => import('@/views/index')
  },
  {
    path: '/index',
    component: () => import('@/views/index')
  },
  /* 下面是IT开发的路由地址*/

  { path: '/DPMAuthority', component: () => import('@/views/MIDWAY/DPMAuthority') },
  { path: '/DPMBaseSetting', component: () => import('@/views/MIDWAY/DPMBaseSetting') },
  { path: '/DPMDashboard', component: () => import('@/views/MIDWAY/DPMDashboard') },
  { path: '/DPMDashboardArea', component: () => import('@/views/MIDWAY/DPMDashboardArea') },
  { path: '/DPMDashboardFactory', component: () => import('@/views/MIDWAY/DPMDashboardFactory') },
  { path: '/DPMDashboardLine', component: () => import('@/views/MIDWAY/DPMDashboardLine') },
  { path: '/DPMDashboardLineDetail', component: () => import('@/views/MIDWAY/DPMDashboardLineDetail') },
  { path: '/DPMDashboardTeam', component: () => import('@/views/MIDWAY/DPMDashboardTeam') },
  { path: '/DPMIssueReview', component: () => import('@/views/MIDWAY/DPMIssueReview') },
  { path: '/DPMLineStop', component: () => import('@/views/MIDWAY/DPMLineStop') },
  { path: '/DPMMyIssue', component: () => import('@/views/MIDWAY/DPMMyIssue') },
  { path: '/DPMOutputReview', component: () => import('@/views/MIDWAY/DPMOutputReview') },
  { path: '/DPMPCBAIssueLogReview', component: () => import('@/views/MIDWAY/DPMPCBAIssueLogReview') },
  // { path: '/DPMPlantView', name: 'DPMPlantView', component: () => import('@/views/dpm/DPMPlantView') },
  { path: '/DPMTeamKPI', component: () => import('@/views/MIDWAY/DPMTeamKPI') },
  { path: '/DPMTeamKPIHistory', component: () => import('@/views/MIDWAY/DPMTeamKPIHistory') },
  { path: '/DPMTeamKPIReview', component: () => import('@/views/MIDWAY/DPMTeamKPIReview') },
  { path: '/DPMSTDInputOutput', component: () => import('@/views/MIDWAY/DPMSTDInputOutput') },
  { path: '/DPMDailylReview', component: () => import('@/views/MIDWAY/DPMDailylReview') },
  { path: '/DPMGoalSetting', component: () => import('@/views/MIDWAY/DPMGoalSetting') },
  // add 20230227 fenglianlong  异常问题目标设定--------------
  { path: '/DPMIssueGoalSetting', component: () => import('@/views/MIDWAY/DPMIssueGoalSetting') },
  { path: '/DPMSummaryOfIssues', component: () => import('@/views/MIDWAY/DPMSummaryOfIssues') },

  { path: '/abnormalSummary', component: () => import('@/views/MIDWAY/abnormalSummary/index') },
  { path: '/abnormalRecords', component: () => import('@/views/MIDWAY/abnormalSummary/abnormalRecords') },
  { path: '/demoPage', component: () => import('@/views/demo/demoPage.vue') },
  // add by liwen at 20230831
  { path: '/DPMFatpHistoricalSummary', component: () => import('@/views/MIDWAY/DPMFatpHistoricalSummary/DPMFatpHistoricalSummary') },
  { path: '/DPMStageSetting', component: () => import('@/views/MIDWAY/DPMStageSetting') },
  { path: '/DPMTeamKPIReviewV2', component: () => import('@/views/MIDWAY/DPMTeamKPIReviewV2') },
  // add by Jingchang at 20240124
  { path: '/DPMIssueChecked', component: () => import('@/views/MIDWAY/DPMIssueChecked') },
  // add by Jingchang at 20240523
  { path: '/DPMReasonCodeSetting', component: () => import('@/views/MIDWAY/DPMReasonCodeSetting') },
  // add by zhujunjie at 2024-04-19
  { path: '/pcbaDashboard', component: () => import('@/views/MIDWAY/pcbaDashboard/index') }
]

// 防止连续点击多次路由报错
const routerPush = Router.prototype.push
Router.prototype.push = function push(location) {
  return routerPush.call(this, location).catch(err => err)
}

export default new Router({
  base: process.env.BASE_URL,
  mode: 'history', // 去掉url中的#
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})
