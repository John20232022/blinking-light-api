import { Message } from 'element-ui'
import axios from 'axios'
import cache from '@/plugins/cache'

axios.defaults.headers['Content-Type'] = 'application/json;charset=utf-8'

/*
  baseConfig 是全局變量，放在public/config.js 文件夾下面的
*/

// 创建axios实例
const service = axios.create({
  // axios中请求配置有baseURL选项，表示请求URL公共部分
  // eslint-disable-next-line no-undef
  baseURL: process.env.NODE_ENV === 'production' ? baseConfig.apiUrl : baseConfig.devApiUrl, // 数字工厂应用平台
  // 超时
  timeout: 300000
})

// request拦截器
service.interceptors.request.use(config => {
  // 是否需要防止数据重复提交
  const isRepeatSubmit = (config.headers || {}).repeatSubmit === false

  config.headers['Authorization'] = cache.session.get('Dfap-Token') // 让每个请求携带自定义token 请根据实际情况自行修改
  config.headers['Token'] = cache.session.get('Dfap-Token') // API Gateway重定向需要用到，这里添加进去
  config.headers.SystemName = 'dpm'
  config.headers.Site = cache.session.get('site')

  // config.headers['Authorization'] = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6IkNOMTAwODMwODEiLCJzaXRlX2lkIjoiOGFmMDQ2Njg4ODBjNDE0Njg0MmIyYmQ2N2IyOTY4NWYiLCJzaXRlIjoiQ04tR1oiLCJleHBpcmVUaW1lIjoiMjAyMy0wNy0wNSAwMTowNDo0NiIsImdlblRpbWUiOiIyMDIzLTA2LTA1IDAxOjA0OjQ2Ljc4MyIsImxvY2F0aW9uIjoiaW50cmFuZXQiLCJkZXZpY2UiOiJkZXNrdG9wIiwic3lzX3VzZXJpZCI6ImM0YjhiMDM5MTRhZTQzOTVhYTkzMzY4ZTc3NmY4NTJkIiwic3lzX3VzZXJuYW1lIjoi5Zas6bqX5paHIiwibGFuZyI6ImNuIn0.__rZUAYRdoKSXfWYXr-qnzXu_XdEtzzwS-OYZf98WrE' // cache.session.get('Dfap-Token') // 让每个请求携带自定义token 请根据实际情况自行修改
  // config.headers['Token'] = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6IkNOMTAwODMwODEiLCJzaXRlX2lkIjoiOGFmMDQ2Njg4ODBjNDE0Njg0MmIyYmQ2N2IyOTY4NWYiLCJzaXRlIjoiQ04tR1oiLCJleHBpcmVUaW1lIjoiMjAyMy0wNy0wNSAwMTowNDo0NiIsImdlblRpbWUiOiIyMDIzLTA2LTA1IDAxOjA0OjQ2Ljc4MyIsImxvY2F0aW9uIjoiaW50cmFuZXQiLCJkZXZpY2UiOiJkZXNrdG9wIiwic3lzX3VzZXJpZCI6ImM0YjhiMDM5MTRhZTQzOTVhYTkzMzY4ZTc3NmY4NTJkIiwic3lzX3VzZXJuYW1lIjoi5Zas6bqX5paHIiwibGFuZyI6ImNuIn0.__rZUAYRdoKSXfWYXr-qnzXu_XdEtzzwS-OYZf98WrE' // cache.session.get('Dfap-Token') // API Gateway 重定向需要用到，这里添加进去
  // config.headers.SystemName = 'dpm' // 注意这里面是需要修改的
  // config.headers.Site = 'CN-GZ'// cache.session.get('site');

  if (!isRepeatSubmit && (config.method === 'post' || config.method === 'put')) {
    const requestObj = {
      url: config.url,
      data: typeof config.data === 'object' ? JSON.stringify(config.data) : config.data,
      time: new Date().getTime()
    }
    const sessionObj = cache.session.getJSON('sessionObj')
    if (sessionObj === undefined || sessionObj === null || sessionObj === '') {
      cache.session.setJSON('sessionObj', requestObj)
    } else {
      const s_url = sessionObj.url // 请求地址
      const s_data = sessionObj.data // 请求数据
      const s_time = sessionObj.time // 请求时间
      const interval = 1000 // 间隔时间(ms)，小于此时间视为重复提交
      if (s_data === requestObj.data && requestObj.time - s_time < interval && s_url === requestObj.url) {
        const message = '数据正在处理，请勿重复提交'
        Message.warning(message)
        console.warn(`[${s_url}]: ` + message)
        return Promise.reject(new Error(message))
      } else {
        cache.session.setJSON('sessionObj', requestObj)
      }
    }
  }
  return config
}, error => {
  Promise.reject(error)
})

// 相应拦截去除

export default service
