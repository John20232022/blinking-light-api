
/**
 * 通用js方法封装处理
 * Copyright (c) 2022 zhujunjie
 */

// 导入请求实例
import service from './request'

var downloadFile = (url, fileName) => {
  const tempArray = url.split('?')
  let controllerAndAction = ''
  let downloadQueryString = ''
  if (tempArray.length > 1) {
    controllerAndAction = tempArray[0]
    downloadQueryString = tempArray[1]
  } else {
    controllerAndAction = url
  }
  let tempUrl = ''
  const tempArrayTow = controllerAndAction.split('/')
  if (tempArrayTow.length < 3) {
    tempUrl = '/HttpUtility/Download?controller=&action='
  } else {
    tempUrl = '/HttpUtility/Download?controller=' + tempArrayTow[1] + '&action=' + tempArrayTow[2]
    // tempUrl = '/HttpUtility/Download?controller=' + tempArrayTow[1] + '&action=' + tempArrayTow[2]
  }

  tempUrl = tempUrl + '&' + downloadQueryString
  service({
    method: 'get',
    url: tempUrl, // url,
    responseType: 'blob'
  })
    .then((res) => {
      const content = res.data
      const blob = new Blob([content])
      if ('download' in document.createElement('a')) { // 非IE下载
        const elink = document.createElement('a')
        elink.download = fileName
        elink.style.display = 'none'
        elink.href = URL.createObjectURL(blob)
        document.body.appendChild(elink)
        elink.click()
        URL.revokeObjectURL(elink.href) // 释放URL 对象
        document.body.removeChild(elink)
      } else { // IE10+下载
        navigator.msSaveBlob(blob, fileName)
      }
    })
    .catch(function(response) {
      alert('Error:' + response)
    })
}

function GetDateTimeString(date) {
  console.log(date, '----date')
  var year = date.getFullYear()
  var month = (date.getMonth() + 1).toString()
  var day = (date.getDate()).toString()
  var hour = (date.getHours()).toString()
  var min = (date.getMinutes()).toString()
  var sec = (date.getSeconds()).toString()
  if (month.length === 1) {
    month = '0' + month
  }
  if (day.length === 1) {
    day = '0' + day
  }
  if (hour.length === 1) {
    hour = '0' + hour
  }
  if (min.length === 1) {
    min = '0' + min
  }
  if (sec.length === 1) {
    sec = '0' + sec
  }
  var dateTime = year + '-' + month + '-' + day + ' ' + hour + ':' + min + ':' + sec
  return dateTime
}

function GetDateString(date) {
  var year = date.getFullYear()
  var month = (date.getMonth() + 1).toString()
  var day = (date.getDate()).toString()
  if (month.length === 1) {
    month = '0' + month
  }
  if (day.length === 1) {
    day = '0' + day
  }
  var dateTime = year + '-' + month + '-' + day
  return dateTime
}

function ReplacePlaceHolder(str, valueArray) {
  for (let i = 0; i < valueArray.length; i++) {
    const regex = '/``' + i + '``/g'
    console.log(regex)
    // eslint-disable-next-line no-eval
    str = str.replace(eval(regex), valueArray[i])
  }
  return str
}

export default {
  downloadFile,
  GetDateTimeString,
  GetDateString,
  ReplacePlaceHolder
}

