import Element from 'element-ui'

// 给表格统一加上边框
Element.Table.props.border = {
  type: Boolean,
  default: true
}
