<template>
  <el-dialog :title="dialogTitle" :visible.sync="visible" :before-close="handleCancel" :close-on-click-modal="false" :close-on-press-escape="false" append-to-body width="500px">
    <el-form ref="ruleForm" :model="ruleForm" label-width="140px">
      <el-form-item label="线体">
        <el-input v-model="ruleForm.pdline" disabled />
      </el-form-item>
      <el-form-item label="选择时间段">
        <el-select v-model="ruleForm.time" style="width:100%">
          <el-option v-for="item in timeList" :key="item.time" :label="item.time" :value="item.time" />
        </el-select>
      </el-form-item>
      <el-form-item label="手动输入(工单)">
        <el-input v-model="ruleForm.work_order" />
      </el-form-item>
      <el-form-item label="选择异常信息">
        <el-select v-model="ruleForm.reason_code" style="width:100%">
          <el-option v-for="item in informationOptions" :key="item.id" :label="item.reason_code" :value="item.reason_code" />
        </el-select>
      </el-form-item>
    </el-form>

    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">{{ $t('common.btnCancel') }}</el-button>
      <el-button :disabled="!ruleForm.time || !ruleForm.work_order || !ruleForm.reason_code" type="primary" @click="handleSave">{{ $t('common.btnSave') }}</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { GetReasonCodeAndTimeData_API, SaveLossTimeWithoutWorkOrderInfo_API } from '@/api/kpiSetting'
export default {
  name: 'DialogAbnormalRecordsIdea',
  props: {
    value: {
      type: Boolean,
      default: true
    },
    dialogTitle: {
      type: String,
      default: '无工单损失时间填写'
    }
  },
  data() {
    return {
      visible: this.value, // 是否顯示彈出層,
      ruleForm: this.initFormData(), // 初始化数据,
      timeList: [],
      informationOptions: []
    }
  },
  watch: {
    value(val) {
      this.visible = val
    },
    visible(val) {
      this.$emit('input', val)
    }
  },
  methods: {
    setUp(params) {
      const data = {
        pdline_name: params.pdline,
        factory: params.factory
      }
      GetReasonCodeAndTimeData_API(data).then((res) => {
        if (res.data.QueryResult === 'OK') {
          const ReturnObject = res.data.ReturnObject
          const arr = ReturnObject[0]
          arr.forEach((item) => {
            item.time = item.start_time + '~' + item.end_time
          })
          this.timeList = arr
          this.informationOptions = ReturnObject[1]
        }
      })
      this.ruleForm.pdline = params.pdline
      this.ruleForm.factory = params.factory
      this.ruleForm.team = params.team
      this.ruleForm.work_date = params.work_date
    },
    initFormData() {
      return {
        pdline: '',
        time: '', // 工作区段
        work_order: '', // 工单
        reason_code: '' // 异常信息
      }
    },
    // 取消
    handleCancel() {
      this.visible = false
      this.ruleForm = this.initFormData()
    },
    handleSave() {
      console.log(this.ruleForm)
      SaveLossTimeWithoutWorkOrderInfo_API(this.ruleForm).then(res => {
        if (res.data.QueryResult === 'OK') {
          this.$message({
            message: 'save success',
            type: 'success'
          })
          this.handleCancel()
        }
      })
    }
  }
}
</script>

<style scoped lang="less">
</style>
