<template>
  <el-dialog
    :title="dialogTitle"
    :visible.sync="visible"
    :before-close="handleCancel"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    append-to-body
    width="960px"
  >
    <el-form ref="ruleForm" label-width="110px" :model="ruleForm" :rules="rules">
      <el-row>
        <el-col :span="8">
          <el-form-item :label="$t('common.colFactory')" prop="factory">
            <el-select v-model="ruleForm.factory" :placeholder="$t('common.phdSelectFactory')" style="width: 200px" @change="changeFactory">
              <el-option v-for="item in factoryTypeList" :key="item.data" :label="item.data" :value="item.data" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item :label="$t('common.colArea')" prop="area">
            <el-select v-model="ruleForm.area" :disabled="!ruleForm.factory" :placeholder="$t('common.phdSelectArea')" style="width: 200px" @change="changeArea">
              <el-option v-for="item in areaList" :key="item.data" :label="item.data" :value="item.data" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="Team" prop="team">
            <el-select v-model="ruleForm.team" :disabled="!ruleForm.area" :placeholder="$t('common.phdSelectTeam')" style="width: 200px">
              <el-option v-for="item in teamList" :key="item.data" :label="item.data" :value="item.data" />
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>

      <el-row>
        <el-col :span="8">
          <el-form-item label="loss_time" prop="loss_time_value">
            <el-input-number v-model="ruleForm.loss_time_value" :precision="2" :step="0.1" :min="0" :max="100" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="down_time" prop="down_time_value">
            <el-input-number v-model="ruleForm.down_time_value" :precision="2" :step="0.1" :min="0" :max="100" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="yield_loss" prop="yield_loss_value">
            <el-input-number v-model="ruleForm.yield_loss_value" :precision="2" :step="0.1" :min="0" :max="100" />
          </el-form-item>
        </el-col>
      </el-row>

      <el-row>
        <el-col :span="8">
          <el-form-item label="unknow" prop="unknow_value">
            <el-input-number v-model="ruleForm.unknow_value" :precision="2" :step="0.1" :min="0" :max="100" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="oee2" prop="oee2_value">
            <el-input-number v-model="ruleForm.oee2_value" :precision="2" :step="0.1" :min="0" :max="100" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="total" prop="total_value">
            <el-input-number v-model="ruleForm.total_value" :precision="2" :step="0.1" :min="0" :max="100" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="平均换线时间" prop="average_change_line_time">
            <el-input-number v-model="ruleForm.average_change_line_time" :precision="2" :step="0.1" :min="0" :max="100" />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">{{ $t('common.btnCancel') }}</el-button>
      <el-button :disabled="loading" type="primary" @click="submitForm()">{{ $t('common.btnSave') }}</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { GetDPMQueryKeyValue_API, ModifyKpiTeamSetting_API, AddKpiTeamSetting_API } from '@/api/kpiSetting'

export default {
  name: 'DialogKpiTeamSetting',
  props: {
    value: {
      type: Boolean,
      default: true
    },
    dialogTitle: {
      type: String,
      default: 'TeamSetting'
    }
  },
  data() {
    return {
      visible: this.value, // 是否顯示彈出層,
      loading: false,
      factoryTypeList: [],
      areaList: [],
      teamList: [],
      ruleForm: this.initFormData(), // 初始化数据,
      rules: {
        factory: [{ required: true, message: this.$t('kpiTeamSet.phdPleaseSelect'), trigger: 'change' }],
        area: [{ required: true, message: this.$t('kpiTeamSet.phdPleaseSelect'), trigger: 'change' }],
        team: [{ required: true, message: this.$t('kpiTeamSet.phdPleaseSelect'), trigger: 'change' }],
        loss_time_value: [{ required: true, message: this.$t('kpiTeamSet.phdPleaseKeyin'), trigger: 'blur' }],
        down_time_value: [{ required: true, message: this.$t('kpiTeamSet.phdPleaseKeyin'), trigger: 'blur' }],
        yield_loss_value: [{ required: true, message: this.$t('kpiTeamSet.phdPleaseKeyin'), trigger: 'blur' }],
        unknow_value: [{ required: true, message: this.$t('kpiTeamSet.phdPleaseKeyin'), trigger: 'blur' }],
        oee2_value: [{ required: true, message: this.$t('kpiTeamSet.phdPleaseKeyin'), trigger: 'blur' }],
        total_value: [{ required: true, message: this.$t('kpiTeamSet.phdPleaseKeyin'), trigger: 'blur' }],
        average_change_line_time: [{ required: true, message: '平均换线时间', trigger: 'blur' }]
      }
    }
  },
  watch: {
    value(val) {
      this.visible = val
    },
    visible(val) {
      this.$emit('input', val)
    }
  },
  methods: {
    initFormData() {
      return {
        id: undefined,
        factory: undefined,
        area: undefined,
        team: undefined,
        loss_time_value: 0,
        down_time_value: 0,
        yield_loss_value: 0,
        unknow_value: 0,
        oee2_value: 0,
        total_value: 0,
        average_change_line_time: 0
      }
    },
    init() {
      this.getFactoryTypeList()
    },
    editTemp(obj, factoryTypeList, areaList, teamList) {
      this.ruleForm = obj
      this.factoryTypeList = factoryTypeList
      this.areaList = areaList
      this.teamList = teamList
    },
    getFactoryTypeList() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.factoryTypeList = res.data.ReturnObject
      })
    },
    changeFactory(val) {
      this.ruleForm.area = undefined
      this.ruleForm.team = undefined

      this.areaList = []
      this.teamList = []

      const obj = this.factoryTypeList.filter((item) => item.data === val)[0]
      const data = {
        type: 'userarea',
        key: obj.key
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        const arr = res.data.ReturnObject
        this.areaList = arr.filter((item) => {
          return item.data === 'PCBA'
        })
        if (this.areaList.length === 0) {
          this.loading = true
          this.$message({
            message: this.$t('kpiTeamSet.altMsgNotPCBA'),
            type: 'warning'
          })
        } else {
          this.loading = false
          this.ruleForm.area = this.areaList[0].data
          this.changeArea(this.ruleForm.area)
        }
      })
    },
    changeArea(val) {
      this.ruleForm.team = undefined

      this.teamList = []
      const obj = this.areaList.filter((item) => item.data === val)[0]
      const data = {
        type: 'userteam',
        key: obj.key
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.teamList = res.data.ReturnObject
      })
    },
    // 取消
    handleCancel() {
      this.visible = false
      this.loading = false
      this.factoryTypeList = []
      this.areaList = []
      this.teamList = []
      this.ruleForm = this.initFormData()
      this.$refs['ruleForm'].resetFields()
    },
    // 提交
    submitForm() {
      this.$confirm(this.$t('kpiTeamSet.altConfirmSubmit'), this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        cancelButtonText: this.$t('common.altMsgBtnCancel'),
        type: 'warning'
      }).then(() => {
        this.$refs['ruleForm'].validate((valid) => {
          if (valid) {
            this.loading = true
            // 修改
            if (this.ruleForm.id) {
              ModifyKpiTeamSetting_API(this.ruleForm).then((res) => {
                if (res.data.QueryResult === 'OK') {
                  this.$message({
                    message: this.$t('common.altMsgOptSuccess'),
                    type: 'success'
                  })
                  this.$emit('closeView')
                  this.handleCancel()
                } else {
                  this.$message.error(res.data.QueryResult)
                  this.loading = false
                }
              })
            } else {
              AddKpiTeamSetting_API(this.ruleForm).then((res) => {
                if (res.data.QueryResult === 'OK') {
                  this.$message({
                    message: this.$t('common.altMsgOptSuccess'),
                    type: 'success'
                  })
                  this.loading = false
                } else {
                  this.$message.error(res.data.QueryResult)
                  this.loading = false
                }
              })
            }
          }
        })
      })
    }
  }
}
</script>

<style scoped lang="less">
</style>
