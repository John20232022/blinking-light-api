<template>
  <el-dialog
    :title="dialogTitle"
    :visible.sync="visible"
    :before-close="handleCancel"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    append-to-body
    width="660px"
  >
    <el-form ref="ruleForm" label-width="104px" :model="ruleForm" :rules="rules">
      <el-row>
        <el-col :span="12">
          <el-form-item :label="$t('common.phdSelectFactory')" prop="factory">
            <el-select v-model="ruleForm.factory" :placeholder="$t('common.phdSelectFactory')" style="width: 200px" @change="changeFactory">
              <el-option v-for="item in factoryTypeList" :key="item.data" :label="item.data" :value="item.data" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col
          :span="12"
        ><el-form-item :label="$t('common.phdSelectArea')" prop="area">
          <el-select v-model="ruleForm.area" disabled :placeholder="$t('common.phdSelectArea')" style="width: 200px" @change="changeArea">
            <el-option v-for="item in areaList" :key="item.data" :label="item.data" :value="item.data" />
          </el-select>
        </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="Team" prop="team">
            <el-select v-model="ruleForm.team" :disabled="!ruleForm.factory" :placeholder="$t('common.phdSelectTeam')" style="width: 200px">
              <el-option v-for="item in teamList" :key="item.data" :label="item.data" :value="item.data" />
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="12">
          <el-form-item label="reason_code" prop="reason_code">
            <el-select
              v-model="ruleForm.reason_code"
              :disabled="!ruleForm.factory"
              :placeholder="$t('kpiReasonSet.phdPleaseSelect')"
              style="width: 200px"
              @change="changeReasonCode"
            >
              <el-option v-for="item in reason_code_list" :key="item.reason_code" :label="item.reason_code" :value="item.reason_code" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="type" prop="type">
            <el-input v-model="ruleForm.type" disabled :placeholder="$t('kpiReasonSet.phdPleaseKeyin')" style="width: 200px" />
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="value" prop="value">
            <el-input-number v-model="ruleForm.value" :precision="2" :step="0.1" :min="0" :max="100" />
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="type_num" prop="type_num">
            <el-select v-model="ruleForm.type_num" placeholder="type_num" style="width: 200px">
              <el-option v-for="item in type_num_list" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">{{ $t('common.btnCancel') }}</el-button>
      <el-button :disabled="loading" type="primary" @click="submitForm()">{{ $t('common.btnSave') }}</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { GetDPMQueryKeyValue_API, GetDPMPCBAReasonCode_API, ModifyKpiReasonSetting_API, AddKpiReasonSetting_API } from '@/api/kpiSetting'

export default {
  name: 'DialogKpiReasonSetting',
  props: {
    value: {
      type: Boolean,
      default: true
    },
    dialogTitle: {
      type: String,
      default: 'ReasonSetting'
    }
  },
  data() {
    return {
      visible: this.value, // 是否顯示彈出層,
      loading: false,
      factoryTypeList: [],
      areaList: [],
      teamList: [],
      reason_code_list: [],
      ruleForm: this.initFormData(), // 初始化数据,
      type_num_list: [
        {
          label: 'Loss Time',
          value: 'Loss Time'
        },
        {
          label: 'Down Time',
          value: 'Down Time'
        },
        {
          label: 'Idle Time',
          value: 'Idle Time'
        },
        {
          label: 'Yield Loss',
          value: 'Yield Loss'
        }
      ],
      rules: {
        factory: [{ required: true, message: this.$t('kpiReasonSet.phdPleaseSelect'), trigger: 'change' }],
        team: [{ required: true, message: this.$t('kpiReasonSet.phdPleaseSelect'), trigger: 'change' }],
        type: [{ required: true, message: this.$t('kpiReasonSet.phdPleaseSelect'), trigger: 'change' }],
        reason_code: [{ required: true, message: this.$t('kpiReasonSet.phdPleaseSelect'), trigger: 'change' }],
        value: [{ required: true, message: this.$t('kpiReasonSet.phdPleaseKeyin'), trigger: 'blur' }],
        type_num: [{ required: true, message: this.$t('kpiReasonSet.phdPleaseSelect'), trigger: 'change' }]
      }
    }
  },
  watch: {
    value(val) {
      this.visible = val
    },
    visible(val) {
      this.$emit('input', val)
    }
  },
  methods: {
    initFormData() {
      return {
        id: undefined,
        factory: undefined,
        area: undefined,
        team: undefined,
        reason_code: undefined,
        type: undefined,
        value: 0,
        type_num: undefined,
        type_nums: undefined,
        reason_code_num: undefined
      }
    },
    init() {
      this.getFactoryTypeList()
    },
    editTemp(obj, factoryTypeList, areaList, teamList) {
      this.ruleForm = obj
      this.getReasonCodeList()
      this.factoryTypeList = factoryTypeList
      this.areaList = areaList
      this.teamList = teamList
    },
    changeReasonCode(val) {
      const obj = this.reason_code_list.filter((item) => item.reason_code === val)[0]
      this.ruleForm.type = obj.type
      this.ruleForm.type_nums = obj.type_num
      this.ruleForm.reason_code_num = obj.reason_code_num
    },
    getFactoryTypeList() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.factoryTypeList = res.data.ReturnObject
      })
    },
    changeFactory(val) {
      this.ruleForm.area = undefined
      this.ruleForm.team = undefined

      this.areaList = []
      this.teamList = []

      const obj = this.factoryTypeList.filter((item) => item.data === val)[0]
      const data = {
        type: 'userarea',
        key: obj.key
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        if (res.data.QueryResult === 'OK') {
          const arr = res.data.ReturnObject
          this.areaList = arr.filter((item) => {
            return item.data === 'PCBA'
          })
          if (this.areaList.length === 0) {
            this.loading = true
            this.$message({
              message: this.$t('kpiReasonSet.altMsgNotPCBA'),
              type: 'warning'
            })
          } else {
            this.loading = false
            this.ruleForm.area = this.areaList[0].data
            this.changeArea(this.ruleForm.area)
          }
        }
      })

      this.getReasonCodeList()
      this.ruleForm.reason_code = undefined
      this.ruleForm.type = undefined
      this.ruleForm.type_nums = undefined
      this.ruleForm.reason_code_num = undefined
    },
    getReasonCodeList() {
      const param = {
        factory: this.ruleForm.factory
      }
      GetDPMPCBAReasonCode_API(param).then((res) => {
        if (res.data.QueryResult === 'OK') {
          const arr = res.data.ReturnObject
          this.reason_code_list = arr.map((item) => {
            return {
              type: item.type,
              type_num: item.type_num,
              reason_code: item.reason_code,
              reason_code_num: item.reason_code_num
            }
          })
          if (this.reason_code_list.length === 0) {
            this.$message({
              message: this.$t('kpiReasonSet.altMsgNoReasonCode'),
              type: 'warning'
            })
          }
        }
      })
    },
    changeArea(val) {
      this.ruleForm.team = undefined

      this.teamList = []
      const obj = this.areaList.filter((item) => item.data === val)[0]
      const data = {
        type: 'userteam',
        key: obj.key
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.teamList = res.data.ReturnObject
      })
    },
    // 取消
    handleCancel() {
      this.visible = false
      this.loading = false
      this.factoryTypeList = []
      this.areaList = []
      this.teamList = []
      this.ruleForm = this.initFormData()
      this.$refs['ruleForm'].resetFields()
    },
    // 提交
    submitForm() {
      this.$confirm(this.$t('kpiReasonSet.altConfirmSubmit'), this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        cancelButtonText: this.$t('common.altMsgBtnCancel'),
        type: 'warning'
      }).then(() => {
        this.$refs['ruleForm'].validate((valid) => {
          if (valid) {
            this.loading = true
            // 修改
            if (this.ruleForm.id) {
              ModifyKpiReasonSetting_API(this.ruleForm).then((res) => {
                if (res.data.QueryResult === 'OK') {
                  this.$message({
                    message: this.$t('common.altMsgOptSuccess'),
                    type: 'success'
                  })
                  this.$emit('closeView')
                  this.handleCancel()
                } else {
                  this.$message.error(res.data.QueryResult)
                  this.loading = false
                }
              })
            } else {
              AddKpiReasonSetting_API(this.ruleForm).then((res) => {
                if (res.data.QueryResult === 'OK') {
                  this.$message({
                    message: this.$t('common.altMsgOptSuccess'),
                    type: 'success'
                  })
                  this.loading = false
                } else {
                  this.$message.error(res.data.QueryResult)
                  this.loading = false
                }
              })
            }
          }
        })
      })
    }
  }
}
</script>

<style scoped lang="less">
</style>
