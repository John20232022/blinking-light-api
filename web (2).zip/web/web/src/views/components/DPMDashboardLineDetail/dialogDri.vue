<template>
  <el-dialog
    :title="dialogTitle"
    :visible.sync="visible"
    :before-close="handleCancel"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    append-to-body
    width="500px"
  >
    <div class="list-line">
      <div class="line">
        <span class="span01">{{ $t('dpmDashboardLineDetail.lblStage') }}:</span>
        <span class="span02">{{ formData.stage }}</span>
      </div>
      <div class="line">
        <span class="span01">{{ $t('dpmDashboardLineDetail.lblType') }}:</span>
        <span class="span02">{{ formData.type }}</span>
      </div>
      <div class="line">
        <span class="span01">{{ $t('dpmDashboardLineDetail.lblReasonCode') }}:</span>
        <span class="span02">{{ formData.reason_code }}</span>
      </div>
      <div class="line">
        <span class="span01">{{ $t('dpmDashboardLineDetail.lblReturnMark') }}:</span>
        <span class="span02">{{ formData.dri }}</span>
        <span class="span02">{{ formData.dri_name }}</span>
      </div>
      <div class="line">
        <span class="span01">{{ $t('dpmDashboardLineDetail.lblReason') }}:</span>
        <span class="span02">{{ formData.return_remark }}</span>
      </div>
    </div>
    <el-table :data="formData.loss_data" style="width: 100%">
      <el-table-column :label="$t('dpmDashboardLineDetail.colTime')">
        <template slot-scope="scope">
          <span>{{ scope.row.start_time }}</span>~
          <span>{{ scope.row.end_time }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="loss" label="loss qty" />
    </el-table>

    <div class="employee-title">{{ $t('dpmDashboardLineDetail.lblTitleDRIEmpId') }}：{{ staff.dri }}</div>
    <div class="flex justify-between">
      <el-button type="primary" @click="handleEmployee">{{ $t('dpmDashboardLineDetail.btnDispatchDRI') }}</el-button>
      <el-button type="success" @click="handleSubmit">{{ $t('dpmDashboardLineDetail.btnSaveDispatch') }}</el-button>
    </div>

    <DialogEmployee v-model="dialogVisible" @getStaff="getStaff" />
  </el-dialog>
</template>

<script>
import { SaveRedistributionLog_API, QueryIssueData_API } from '@/api/midway.js'
import DialogEmployee from '@/views/components/DPMDashboardLineDetail/dialogEmployee'
export default {
  name: 'DialogDri',
  components: {
    DialogEmployee
  },
  props: {
    value: {
      type: Boolean,
      default: true
    },
    dialogTitle: {
      type: String,
      default: '重新指派'
    }
  },
  data() {
    return {
      visible: this.value, // 是否顯示彈出層,
      dialogVisible: false,
      formData: {
        stage: '',
        type: '',
        reason_code: '',
        return_remark: '',
        dri: '',
        dri_name: '',
        loss_data: []
      },
      rowId: undefined,
      staff: {
        dri: undefined
      }
    }
  },
  watch: {
    value(val) {
      this.visible = val
    },
    visible(val) {
      this.$emit('input', val)
    }
  },
  methods: {
    init(rowId) {
      this.rowId = rowId
      const param = { rowId: rowId }
      QueryIssueData_API(param).then((res) => {
        if (res.data.QueryResult === 'OK') {
          this.formData = res.data.ReturnObject
        } else {
          this.$message({
            message: res.data.QueryResult,
            type: 'warning'
          })
        }
      })
    },
    handleCancel() {
      this.visible = false
      this.rowId = undefined
      this.staff = {
        dri: undefined
      }
      this.formData = {
        stage: '',
        type: '',
        reason_code: '',
        loss_data: []
      }
    },
    handleEmployee() {
      this.dialogVisible = true
    },
    handleSubmit() {
      if (this.staff.dri) {
        const param = {
          dri: this.staff.dri,
          rowId: this.rowId
        }
        const loading = this.$loading({
          lock: true,
          text: 'Loading',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        })
        SaveRedistributionLog_API(param).then((res) => {
          if (res.data.QueryResult === 'OK') {
            this.$message({
              message: this.$t('dpmDashboardLineDetail.lblDispatchOK'),
              type: 'success'
            })
            this.$emit('closeView')
            this.handleCancel()
            loading.close()
          } else {
            this.$message({
              type: 'warning',
              message: res.data.QueryResult
            })
            loading.close()
          }
        })
      } else {
        this.$message({
          message: this.$t('dpmDashboardLineDetail.altMsgNotDispatchDRI'),
          type: 'warning'
        })
      }
    },
    getStaff(staff) {
      this.staff.dri = staff.employee_id
    }
  }
}
</script>

<style scoped lang="less">
.list-line {
  font-size: 16px;
  .line {
    margin-bottom: 10px;
    .span01 {
      display: inline-block;
      width: 80px;
    }
  }
}
.employee-title {
  line-height: 30px;
  margin-top: 20px;
  margin-bottom: 20px;
  font-size: 16px;
}
</style>
