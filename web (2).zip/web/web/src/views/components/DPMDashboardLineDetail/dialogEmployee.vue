<template>
  <el-dialog
    :title="$t('dpmDashboardLineDetail.lblTileDRIFilter')"
    :visible.sync="visible"
    :before-close="handleCancel"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    append-to-body
    width="800px"
  >
    <div style="height: 520px">
      <el-input v-model="driFilterString" :placeholder="$t('dpmDashboardLineDetail.phdEmpIDAD')" size="small" style="width: 100%; margin: 10px 0">
        <el-button slot="append" icon="el-icon-search" @click="queryEmpList" />
      </el-input>
      <el-table v-loading="loading" :data="tableDRIFilter" stripe size="small" height="400px" style="width: 100%">
        <el-table-column label="" width="50">
          <template slot-scope="scope">
            <el-button type="text" size="small" style="color: blue" @click="chooseDRI(scope.row)">{{ $t('common.btnSelect') }}</el-button>
          </template>
        </el-table-column>
        <el-table-column prop="bu" label="BU" width="75" />
        <el-table-column prop="name" :label="$t('common.colEmpName')" width="75" show-overflow-tooltip />
        <el-table-column prop="employee_id" :label="$t('common.colEmpId')" width="90" show-overflow-tooltip />
        <el-table-column prop="dept_id" :label="$t('common.colCostCenter')" width="90" show-overflow-tooltip />
        <el-table-column prop="department" :label="$t('common.colDept')" show-overflow-tooltip />
        <el-table-column prop="email" :label="$t('common.colEMail')" width="180" show-overflow-tooltip />
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">{{ $t('common.btnCancel') }}</el-button>
    </div>
  </el-dialog>
</template>

<script>
import { GetEmpInfoList } from '@/api/midway.js'
export default {
  name: 'DialogEmployee',
  props: {
    value: {
      type: Boolean,
      default: true
    },
    dialogTitle: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      visible: this.value, // 是否顯示彈出層,
      tableDRIFilter: [],
      driFilterString: '',
      loading: false
    }
  },
  watch: {
    value(val) {
      this.visible = val
    },
    visible(val) {
      this.$emit('input', val)
    }
  },
  methods: {
    init() {},
    handleCancel() {
      this.visible = false
      this.tableDRIFilter = []
      this.driFilterString = ''
    },
    async queryEmpList() {
      if (this.driFilterString === null || this.driFilterString === '') {
        this.$message({
          message: this.$t('dpmDashboardLineDetail.altMsgFilterEmpty'),
          type: 'warning'
        })
        return
      }
      this.loading = true
      const data = {
        filter: this.driFilterString
      }
      const response = await GetEmpInfoList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.tableDRIFilter = response.data.ReturnObject
        this.loading = false
      } else {
        this.$message({
          message: queryResult,
          type: 'warning'
        })
        this.loading = false
      }
    },
    chooseDRI(row) {
      console.log(row)
      this.$emit('getStaff', row)
      this.handleCancel()
    }
  }
}
</script>

<style scoped lang="less">
</style>
