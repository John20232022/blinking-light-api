<template>
  <el-dialog :title="dialogTitle" :visible.sync="visible" :before-close="handleCancel" :close-on-click-modal="false" :close-on-press-escape="false" append-to-body width="1200px">
    <div class="model-station">
      <span>Model:</span><b>{{ queryParams.model }}</b> <span>Station:</span><b>{{ queryParams.processName }}</b>
    </div>
    <div ref="chart" :style="{ width, height }" />
  </el-dialog>
</template>

<script>
import { GetOATLLossKeyInfo_API } from '@/api/midway'
import * as echarts from 'echarts'
export default {
  name: 'DialogRTY',
  props: {
    height: {
      type: String,
      default: '300px'
    },
    width: {
      type: String,
      default: '100%'
    },
    value: {
      type: Boolean,
      default: true
    },
    dialogTitle: {
      type: String,
      default: '不良Key位柏拉图'
    }
  },
  data() {
    return {
      chart: null,
      visible: this.value, // 是否顯示彈出層,
      queryParams: {
        model: undefined,
        processName: undefined
      }
    }
  },
  watch: {
    value(val) {
      this.visible = val
    },
    visible(val) {
      this.$emit('input', val)
    }
  },
  methods: {
    setUp(params) {
      this.queryParams = params
      this.$nextTick(() => {
        this.chart = echarts.init(this.$refs.chart)
        GetOATLLossKeyInfo_API(params).then((res) => {
          console.log(res)
          const QueryResult = res.data.QueryResult
          const arr = res.data.ReturnObject
          if (arr.length === 0) {
            this.$message({
              message: 'No Data',
              type: 'warning',
              showClose: true
            })
          }
          if (QueryResult === 'OK') {
            console.log(arr)
            const xData = []
            const leftData = []
            const rightData = []
            arr.forEach((item) => {
              xData.push(item.value)
              leftData.push(item.num)
              rightData.push(item.cumulative_sum)
            })
            this.resetOption(xData, leftData, rightData)
          }
        })
      })
    },
    resetOption(xData, leftData, rightData) {
      const option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        legend: {
          data: ['num', 'per']
        },
        grid: {
          left: '0px',
          top: '40px',
          right: '0px',
          bottom: '0px',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            data: xData,
            /*             splitLine: {
              show: true
            }, */
            axisPointer: {
              type: 'shadow'
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            axisLabel: {
              formatter: '{value} 个'
            },
            splitLine: {
              show: false
            }
          },
          {
            type: 'value',
            axisLabel: {
              formatter: '{value} %'
            },
            max: (value) => {
              return value.max
            },
            // max: 100,
            splitLine: {
              show: false
            }
          }
        ],
        series: [
          {
            name: 'num',
            type: 'bar',
            tooltip: {
              valueFormatter: function(value) {
                return value + '个'
              }
            },
            label: {
              show: true,
              position: 'inside'
            },
            data: leftData
          },
          {
            name: 'per',
            type: 'line',
            yAxisIndex: 1,
            tooltip: {
              valueFormatter: function(value) {
                return value + '%'
              }
            },
            data: rightData
          }
        ]
      }
      this.chart.setOption(option)
    },
    handleCancel() {
      this.visible = false
      this.chart = null
      this.queryParams = {
        model: undefined,
        processName: undefined
      }
    }
  }
}
</script>

<style scoped lang="less">
::v-deep .el-dialog__body {
  padding: 10px 20px 20px 20px;
}
.model-station {
  font-size: 18px;
  span {
    display: inline-block;
    margin-left: 10px;
    margin-right: 4px;
  }
}
</style>
