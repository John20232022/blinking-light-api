<template>
  <el-dialog :title="dialogTitle" :visible.sync="visible" :before-close="handleCancel" :close-on-click-modal="false" :close-on-press-escape="false" append-to-body width="820px">
    <el-table :data="tableData" border :height="400">
      <el-table-column prop="factory_code" label="厂别" align="center" />
      <el-table-column prop="area" label="区域" align="center" />
      <el-table-column prop="issue_start_time" label="开始时间" align="center" />
      <el-table-column prop="issue_end_time" label="结束时间" align="center" />
      <el-table-column prop="shift_code" label="班别" align="center" />
      <el-table-column prop="status" label="状态" align="center" />
      <el-table-column prop="work_date" label="工作日期" align="center" />
    </el-table>
  </el-dialog>
</template>

<script>
export default {
  name: 'Dialogissue',
  props: {
    value: {
      type: Boolean,
      default: true
    },
    dialogTitle: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      visible: this.value,
      tableData: []
    }
  },
  watch: {
    value(val) {
      this.visible = val
    },
    visible(val) {
      this.$emit('input', val)
    }
  },
  methods: {
    setUp(arr) {
      this.tableData = arr
    },
    handleCancel() {
      this.visible = false
      this.tableData = []
    }
  }
}
</script>

<style scoped lang="less">

</style>
