<template>
  <div>
    <div ref="chart" :class="className" :style="{ width, height }" />
    <el-table :data="newTableData" border :height="200">
      <el-table-column prop="EQUCODE" label="設備標準編碼" align="center" />
      <el-table-column prop="DEFECTDESC" label="Top 5故障原因" width="120" align="center" />
      <el-table-column prop="FAILCAUSE" label="維修部位" width="120" align="center" />
      <el-table-column prop="REPAIRCONTENT" label="維修方式" width="120" align="center" />
    </el-table>
  </div>
</template>

<script>
import { GetEmsRepaireData_API } from '@/api/midway'
import * as echarts from 'echarts'
export default {
  name: 'Page01',
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '540px'
    },
    height: {
      type: String,
      default: '200px'
    }
  },
  data() {
    return {
      chart: null,
      seriesData: [],
      tableData: [],
      newTableData: []
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.chart = echarts.init(this.$refs.chart)
      this.chart.on('click', (params) => {
        const name = params.name
        this.newTableData = this.tableData.filter((item) => item.EQUDESC === name)
        console.log(this.newTableData)
      })
    })
  },
  methods: {
    reset() {
      this.seriesData = []
      this.tableData = []
      this.newTableData = []
    },
    setUp(params) {
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      GetEmsRepaireData_API(params).then((res) => {
        this.newTableData = []
        if (res.data.QueryResult === 'OK') {
          const arr = res.data.ReturnObject[0]
          const seriesData = arr.map((item) => {
            return {
              name: item.EQUDESC,
              value: item.TOTAL_TIME
            }
          })
          this.seriesData = seriesData
          this.tableData = res.data.ReturnObject[1]
          this.resetOption(seriesData)
          loading.close()
        } else {
          loading.close()
        }
      })
    },
    resetOption(seriesData) {
      const option = {
        tooltip: {
          trigger: 'item'
        },
        legend: {
          orient: 'vertical',
          left: 'left'
        },
        series: [
          {
            name: '分類',
            type: 'pie',
            radius: '80%',
            data: seriesData,
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      }
      this.chart.setOption(option)
    }
  }
}
</script>

<style scoped lang="scss">
</style>
