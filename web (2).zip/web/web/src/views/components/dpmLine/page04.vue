<template>
  <div>
    <el-form :inline="true" :model="queryParams">
      <el-form-item>
        <el-select v-model="queryParams.key" style="width: 110px">
          <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="handleSearch">查询</el-button>
      </el-form-item>
    </el-form>
    <el-table :data="tableData" border :height="400">
      <el-table-column v-for="(item, index) in lableArr" :key="index" :prop="item" :label="item" align="center" width="140" />
    </el-table>
  </div>
</template>

<script>
import { GetDqmDetail_API } from '@/api/midway'
export default {
  name: 'Page04',
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '548px'
    },
    height: {
      type: String,
      default: '200px'
    }
  },
  data() {
    return {
      lableArr: [],
      tableData: [],
      options: [
        {
          value: 'REWORK',
          label: 'REWORK'
        },
        {
          value: 'CCAR',
          label: 'CCAR'
        },
        {
          value: 'PCAR',
          label: 'PCAR'
        }
      ],
      queryParams: {
        factory: undefined,
        line: undefined,
        model: undefined,
        begin: undefined,
        end: undefined,
        key: 'CCAR',
        partNo: undefined,
        processName: undefined
      }
    }
  },
  methods: {
    reset() {
      this.tableData = []
      this.lableArr = []
      this.queryParams = {
        factory: undefined,
        line: undefined,
        model: undefined,
        begin: undefined,
        end: undefined,
        key: 'CCAR'
      }
    },
    setUp(params) {
      this.queryParams.factory = params.factory
      this.queryParams.line = params.line
      this.queryParams.partNo = params.partNo
      this.queryParams.begin = params.begin
      this.queryParams.end = params.end
      this.queryParams.model = params.model ? params.model : ''
      this.GetDqmDetail()
    },
    handleSearch() {
      this.GetDqmDetail()
    },
    GetDqmDetail() {
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      GetDqmDetail_API(this.queryParams).then((res) => {
        if (res.data.QueryResult === 'OK') {
          this.tableData = res.data.ReturnObject
          if (this.tableData.length > 0) {
            const lableArr = []
            const obj = this.tableData[0]
            for (const key in obj) {
              lableArr.push(key)
            }
            this.lableArr = lableArr
          }
          loading.close()
        } else {
          loading.close()
        }
      })
    }
  }
}
</script>

<style scoped lang="scss">
.isClick {
  cursor: pointer;
  color: #409eff;
}
</style>
