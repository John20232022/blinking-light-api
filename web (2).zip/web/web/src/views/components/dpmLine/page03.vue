<template>
  <div>
    <el-form :inline="true" :model="queryParams">
      <el-form-item>
        <el-select v-model="queryParams.key" style="width: 100px">
          <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="handleSearch">查询</el-button>
      </el-form-item>
    </el-form>
    <el-table :data="tableData" border>
      <el-table-column prop="line" label="线体" align="center" />
      <el-table-column prop="part_no" label="机种" align="center" />
      <el-table-column prop="process_name" label="PROCESS" align="center">
        <template slot-scope="scope">
          <span class="isClick" @click="handleprocess_name(scope.row)">{{ scope.row.process_name }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="count" label="数量" align="center" />
      <el-table-column prop="per" label="占比" align="center" />
    </el-table>

    <el-dialog :visible.sync="dialogVisible" :before-close="handleCancel" :close-on-click-modal="false" :close-on-press-escape="false" append-to-body width="1300px">
      <el-table :data="newTableData" border :height="400">
        <el-table-column type="index" width="50" align="center" />
        <el-table-column prop="PART_NO" label="PART_NO" align="center" />
        <el-table-column prop="PROCESS_NAME" label="PROCESS_NAME" align="center" />
        <el-table-column prop="DYTU_DESC" label="DYTU_DESC" align="center" />
        <el-table-column prop="REASON_DESC" label="REASON_DESC" align="center" />
        <el-table-column prop="DEFECT_DESC" label="DEFECT_DESC" align="center" />
        <el-table-column prop="DEFECT_DESC2" label="DEFECT_DESC2" align="center" />
        <el-table-column prop="REPAIR_CODE" label="REPAIR_CODE" align="center" />
        <el-table-column prop="REPAIR_DESC" label="REPAIR_DESC" align="center" />
        <el-table-column prop="LOCATION" label="LOCATION" align="center" />
      </el-table>

      <Pagination :total="total" :page.sync="queryParams.pageIndex" :limit.sync="queryParams.pageSize" @pagination="getList" />
    </el-dialog>
  </div>
</template>

<script>
import { GetDashBoardByPart_API, GetDashBoardDetail_API } from '@/api/midway'
import Pagination from '@/components/Pagination'

export default {
  name: 'Page03',
  components: {
    Pagination
  },
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '548px'
    },
    height: {
      type: String,
      default: '200px'
    }
  },
  data() {
    return {
      dialogVisible: false,
      tableData: [],
      newTableData: [],
      total: 0,
      options: [
        {
          value: 'ndf',
          label: 'NDF'
        },
        {
          value: 'oatl',
          label: 'OATL'
        },
        {
          value: 'oail',
          label: 'OAIL'
        }
      ],
      queryParams: {
        factory: undefined,
        line: undefined,
        model: undefined,
        begin: undefined,
        end: undefined,
        key: 'oatl',
        partNo: undefined,
        processName: undefined,
        pageIndex: 1,
        pageSize: 20
      }
    }
  },
  methods: {
    handleCancel() {
      this.dialogVisible = false
      this.total = 0
      this.newTableData = []
    },
    handleprocess_name(obj) {
      this.queryParams.partNo = obj.part_no
      this.queryParams.processName = obj.process_name
      this.getList()
    },
    getList() {
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      GetDashBoardDetail_API(this.queryParams).then((res) => {
        if (res.data.QueryResult === 'OK') {
          this.newTableData = res.data.ReturnObject.queryData
          this.total = res.data.ReturnObject.total
          this.dialogVisible = true
          loading.close()
        } else {
          loading.close()
        }
      })
    },
    reset() {
      this.dialogVisible = false
      this.tableData = []
      this.queryParams = {
        factory: undefined,
        line: undefined,
        model: undefined,
        begin: undefined,
        end: undefined,
        key: 'oatl'
      }
    },
    setUp(params) {
      this.queryParams.factory = params.factory
      this.queryParams.line = params.line
      this.queryParams.partNo = params.partNo
      this.queryParams.begin = params.begin
      this.queryParams.end = params.end
      this.queryParams.model = params.model ? params.model : ''
      this.GetDashBoardByPart()
    },
    handleSearch() {
      this.GetDashBoardByPart()
    },
    GetDashBoardByPart() {
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      GetDashBoardByPart_API(this.queryParams).then((res) => {
        if (res.data.QueryResult === 'OK') {
          this.tableData = res.data.ReturnObject
          loading.close()
        } else {
          loading.close()
        }
      })
    }
  }
}
</script>

<style scoped lang="scss">
.isClick {
  cursor: pointer;
  color: #409eff;
}
</style>
