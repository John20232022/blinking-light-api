<template>
  <div>
    <div class="flex justify-between" style="margin-bottom: 10px">
      <div ref="chart" :class="className" :style="{ width, height }" />
      <el-table :data="newTableData" border :height="200">
        <el-table-column prop="REASON_CODE" label="錯誤代碼" align="center">
          <template slot-scope="scope">
            <span class="isClick" @click="handleREASON_CODE(scope.row.REASON_CODE)">{{ scope.row.REASON_CODE }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="LOSS_PER" label="占比(%)" width="80" align="center" />
      </el-table>
    </div>
    <el-table :data="new_LOSS_TIME_Data" border :height="221" size="mini">
      <el-table-column prop="AREA" label="区域" align="center" />
      <el-table-column prop="PDLINE_NAME" label="线体名称" align="center" />
      <el-table-column prop="TYPE" label="Type" align="center" />
      <el-table-column prop="REASON_CODE" label="错误代码" align="center" />
      <el-table-column prop="LOSS_TIME" label="损失时间" align="center" />
      <el-table-column prop="REASON_DESC" label="异常信息" align="center" />
      <el-table-column prop="SOLUTION" label="解决方案" align="center" />
    </el-table>
  </div>
</template>

<script>
import { GetLossByPart_API } from '@/api/midway'
import * as echarts from 'echarts'
export default {
  name: 'Page01',
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '350px'
    },
    height: {
      type: String,
      default: '200px'
    }
  },
  data() {
    return {
      chart: null,
      seriesData: [],
      tableData: [],
      newTableData: [],
      LOSS_TIME_Data: [],
      new_LOSS_TIME_Data: []
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.chart = echarts.init(this.$refs.chart)
      this.chart.on('click', (params) => {
        const name = params.name
        this.newTableData = this.tableData.filter((item) => item.TYPE === name)
        this.new_LOSS_TIME_Data = []
      })
    })
  },
  methods: {
    reset() {
      this.seriesData = []
      this.tableData = []
      this.newTableData = []
      this.LOSS_TIME_Data = []
      this.new_LOSS_TIME_Data = []
    },
    handleREASON_CODE(REASON_CODE) {
      // eslint-disable-next-line eqeqeq
      this.new_LOSS_TIME_Data = this.LOSS_TIME_Data.filter((item) => item.REASON_CODE == REASON_CODE)
    },
    setUp(params) {
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      GetLossByPart_API(params).then((res) => {
        this.newTableData = []
        if (res.data.QueryResult === 'OK') {
          const arr = res.data.ReturnObject[1]
          const seriesData = arr.map((item) => {
            return {
              name: item.TYPE,
              value: item.TotalLossTime
            }
          })
          this.seriesData = seriesData
          this.tableData = res.data.ReturnObject[0]
          this.resetOption(seriesData)

          this.LOSS_TIME_Data = res.data.ReturnObject[2]
          loading.close()
        } else {
          loading.close()
        }
      })
    },
    resetOption(seriesData) {
      const option = {
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
          orient: 'vertical',
          left: 'left'
        },
        series: [
          {
            name: '分類',
            type: 'pie',
            radius: '80%',
            data: seriesData,
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      }
      this.chart.setOption(option)
    }
  }
}
</script>

<style scoped lang="scss">
.isClick {
  cursor: pointer;
  color: #409eff;
}
</style>
