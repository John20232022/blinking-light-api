<template>
  <el-dialog :title="dialogTitle" :visible.sync="visible" :before-close="handleCancel" :close-on-click-modal="false" :close-on-press-escape="false" append-to-body width="1200px">
    <div class="header-top">
      <div class="line">
        <span class="title">当前工单生产机种</span>
        <span class="content">
          <b v-for="(item, index) in PART_NO_ARR" :key="index" :class="{ isActive: partNoActive === index }" @click="handlePartNo(item, index)">{{ item.partNo }}</b>
        </span>
      </div>
      <div class="line">
        <span class="title">下个工单生产机种</span>
        <span class="content">
          <b v-for="(item, index) in PART_NO_ARR_NEXT" :key="index">{{ item.partNo }}</b>
        </span>
      </div>
    </div>

    <div class="flex justify-between">
      <div class="line-state">
        <div class="line-state-box flex items-center" style="cursor: pointer;" @click="handleOpenISSUE">
          <i class="el-icon-s-opportunity" :class="filterColor(countObj.issue_count)" />
          <span>Issue close</span>
        </div>
        <div class="line-state-box flex items-center" style="cursor: pointer;" @click="handleOpenM2S">
          <i class="el-icon-s-opportunity" :class="filterColor(countObj.m2s_connet_status)" />
          <span>M2S 连线</span>
        </div>
        <!-- <div class="line-state-box flex items-center">
          <i class="el-icon-s-opportunity" :class="filterColor(countObj.check_status)" />
          <span>仪校状态</span>
        </div> -->
        <div class="line-state-box flex items-center">
          <i class="el-icon-s-opportunity" :class="filterColor(countObj.equ_check)" />
          <span>设备点检、保养</span>
        </div>
        <div class="line-state-box flex items-center">
          <i class="el-icon-s-opportunity" :class="filterColor(countObj.equ_failure)" />
          <span>设备故障</span>
        </div>
      </div>

      <div style="border: 1px solid #DCDFE6;padding:10px">
        <div class="dateRange-list flex justify-end items-center">
          <el-date-picker
            v-model="queryTime"
            style="width: 250px"
            type="daterange"
            range-separator="-"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="yyyyMMdd"
            :clearable="false"
            :picker-options="pickerOptions"
            @change="changeTime"
          />
        </div>
        <div class="flex justify-between items-center">
          <el-tabs v-model="activeName" style="width: 950px" :stretch="true">
            <el-tab-pane label="Process KM" name="1">
              <Page01 ref="Page01" />
            </el-tab-pane>
            <el-tab-pane label="EMS" name="2">
              <Page02 ref="Page02" />
            </el-tab-pane>
            <el-tab-pane label="Repair Data" name="3">
              <Page03 ref="Page03" />
            </el-tab-pane>
            <el-tab-pane label="DQM" name="4">
              <Page04 ref="Page04" />
            </el-tab-pane>
            <!-- <el-tab-pane label="(参数控制)" name="5">参数控制</el-tab-pane> -->
          </el-tabs>
        </div>
      </div>
    </div>

    <Dialogissue ref="Dialogissue" v-model="dialogVisibleISSUE" />
    <Dialogm2s ref="Dialogm2s" v-model="dialogVisibleM2S" />
  </el-dialog>
</template>

<script>
import { GetWorkOrderAndPartData_API, GetLineQuality_API } from '@/api/midway'
import moment from 'moment'
import Page01 from '@/views/components/dpmLine/page01'
import Page02 from '@/views/components/dpmLine/page02'
import Page03 from '@/views/components/dpmLine/page03'
import Page04 from '@/views/components/dpmLine/page04'
import Dialogissue from '@/views/components/dpmLine/dialogissue'
import Dialogm2s from '@/views/components/dpmLine/dialogm2s'
export default {
  name: 'DialogDpmLine',
  components: {
    Page01,
    Page02,
    Page03,
    Page04,
    Dialogissue,
    Dialogm2s
  },
  props: {
    value: {
      type: Boolean,
      default: true
    },
    dialogTitle: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      dialogVisibleISSUE: false,
      dialogVisibleM2S: false,
      visible: this.value,
      partNoActive: 0,
      activeName: '1',
      PART_NO_ARR: [],
      PART_NO_ARR_NEXT: [],
      m2s_connet_arr: [],
      issue_data_arr: [],
      countObj: {
        issue_count: undefined,
        m2s_connet_status: undefined,
        check_status: undefined,
        equ_check: undefined,
        equ_failure: undefined
      },
      queryTime: [],
      queryParams: {
        line: undefined,
        workDay: undefined,
        begin: undefined,
        end: undefined,
        factory: undefined,
        area: undefined
      },
      pickerOptions: {
        disabledDate(date) {
          return date.getTime() > Date.now()
        }
      }
    }
  },
  watch: {
    value(val) {
      this.visible = val
    },
    visible(val) {
      this.$emit('input', val)
    }
  },
  created() {
    const now = moment()
    const endMonth = now.subtract(0, 'months').format('YYYYMMDD')
    const beginMonth = now.subtract(3, 'months').format('YYYYMMDD')
    this.queryParams.begin = beginMonth
    this.queryParams.end = endMonth
    this.queryTime = [beginMonth, endMonth]
  },
  methods: {
    handleOpenISSUE() {
      this.dialogVisibleISSUE = true
      this.$nextTick(() => {
        this.$refs['Dialogissue'].setUp(this.issue_data_arr)
      })
    },
    handleOpenM2S() {
      this.dialogVisibleM2S = true
      this.$nextTick(() => {
        this.$refs['Dialogm2s'].setUp(this.m2s_connet_arr)
      })
    },
    changeTime(time) {
      this.queryParams.begin = time[0]
      this.queryParams.end = time[1]

      this.handlePartNo(this.PART_NO_ARR[this.partNoActive], this.partNoActive)
    },
    handlePartNo(item, index) {
      this.partNoActive = index
      const params = {
        factory: this.queryParams.factory,
        line: this.queryParams.line,
        workDay: this.queryParams.workDay,
        begin: this.queryParams.begin,
        end: this.queryParams.end,
        partNo: item.partNo,
        model: item.model
      }
      this.$nextTick(() => {
        this.$refs['Page01'].setUp({ ...params })
        this.$refs['Page02'].setUp({ ...params })
        this.$refs['Page03'].setUp({ ...params })
        this.$refs['Page04'].setUp({ ...params })
      })
    },
    setUp(params) {
      // this.queryParams.line = 'PCBA-SMT-007'
      this.queryParams.line = params.line
      this.queryParams.workDay = params.workday
      this.queryParams.factory = params.factory
      this.queryParams.area = params.area

      this.GetWorkOrderAndPartData()
      this.GetLineQuality()
    },
    GetWorkOrderAndPartData() {
      GetWorkOrderAndPartData_API(this.queryParams).then((res) => {
        if (res.data.QueryResult === 'OK') {
          const arr = res.data.ReturnObject.now_part_no
          this.PART_NO_ARR = arr.map((item) => {
            return {
              partNo: item.partNo,
              model: item.model
            }
          })

          if (this.PART_NO_ARR.length > 0) {
            this.handlePartNo(this.PART_NO_ARR[0], 0)
          }

          const arr_next = res.data.ReturnObject.next_part_no
          this.PART_NO_ARR_NEXT = arr_next.map((item) => {
            return {
              partNo: item.partNo,
              model: item.model
            }
          })
        }
      })
    },
    GetLineQuality() {
      GetLineQuality_API(this.queryParams).then((res) => {
        if (res.data.QueryResult === 'OK') {
          this.countObj = res.data.ReturnObject.quality
          this.m2s_connet_arr = res.data.ReturnObject.quality.m2s_connet
          this.issue_data_arr = res.data.ReturnObject.issue_data
        }
      })
    },
    handleCancel() {
      const now = moment()
      const endMonth = now.subtract(0, 'months').format('YYYYMMDD')
      const beginMonth = now.subtract(3, 'months').format('YYYYMMDD')
      this.queryParams.begin = beginMonth
      this.queryParams.end = endMonth
      this.queryTime = [beginMonth, endMonth]
      this.countObj = {
        issue_count: undefined,
        m2s_connet: undefined,
        m2s_connet_status: undefined,
        equ_check: undefined,
        equ_failure: undefined
      }

      this.visible = false
      this.queryParams = {
        line: undefined,
        workDay: undefined,
        factory: undefined,
        area: undefined,
        begin: beginMonth,
        end: endMonth
      }
      this.PART_NO_ARR = []
      this.PART_NO_ARR_NEXT = []
      this.partNoActive = 0
      this.activeName = '1'

      this.$nextTick(() => {
        this.$refs['Page01'].reset()
        this.$refs['Page02'].reset()
        this.$refs['Page03'].reset()
        this.$refs['Page04'].reset()
      })
    },
    filterColor(num) {
      if (num === false) {
        return 'red'
      } else if (num === true) {
        return 'green'
      } else {
        const count = Number(num)
        if (count === 0) {
          return 'green'
        } else if (count > 0) {
          return 'red'
        } else {
          return 'gray'
        }
      }
    }
  }
}
</script>

<style scoped lang="less">
::v-deep .el-dialog__body {
  padding: 10px 20px 20px 20px;
}
.header-top {
  background-color: #0d68b7;
  color: #ffffff;
  padding: 10px;
  border-radius: 2px;
  margin-bottom: 10px;
  .line {
    font-size: 16px;
    line-height: 30px;
    .title {
      display: inline-block;
      padding-right: 10px;
    }
    .content {
      b {
        display: inline-block;
        margin-right: 10px;
        cursor: pointer;
      }
      b.isActive {
        color: #e6a23c;
      }
    }
  }
}
.line-state {
  padding: 42px 10px;
  border: 1px solid #DCDFE6;
  font-size: 16px;
  margin-right:0px;
  .line-state-box {
    padding: 8px 0;
    .el-icon-s-opportunity {
      font-size: 36px;
    }
    .el-icon-s-opportunity.green {
      color: #67c23a;
    }
    .el-icon-s-opportunity.yellow {
      color: #e6a23c;
    }
    .el-icon-s-opportunity.red {
      color: #f56c6c;
    }
    .el-icon-s-opportunity.gray {
      color: #909399;
    }
  }
}
.dateRange-list {
  margin-bottom: 10px;
}
</style>
