<template>
  <el-dialog
    v-loading="loading"
    :title="dialogTitle"
    :visible.sync="detailDialog"
    :before-close="handleCancel"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    append-to-body
    width="720px"
  >
    <el-form ref="emsForm" label-width="104px" :model="emsForm">
      <el-row>
        <el-col :span="12">
          <el-form-item :label="$t('dpmIssueReview.lblLine')" prop="line">
            <el-input v-model="emsForm.line" readonly style="width: 200px" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item :label="$t('dpmIssueReview.lblCallNo')" prop="callno">
            <el-input v-model="emsForm.callno" readonly style="width: 200px" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item :label="$t('dpmIssueReview.colIssueStart')" prop="call_repair_datetime">
            <el-date-picker
              v-model="emsForm.call_repair_datetime"
              type="datetime"
              readonly
              style="width: 200px"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item :label="$t('dpmIssueReview.colIssueEnd')" prop="confirm_datetime">
            <el-date-picker
              v-model="emsForm.confirm_datetime"
              type="datetime"
              readonly
              style="width: 200px"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item :label="$t('dpmIssueReview.colReasonDesc')" prop="reason_desc">
            <el-input v-model="emsForm.reason_desc" readonly style="width: 200px" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item :label="$t('dpmIssueReview.lblSolution')" prop="solution">
            <el-input v-model="emsForm.solution" readonly style="width: 200px" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item :label="$t('dpmIssueReview.lblEquipmentId')" prop="equipment_id">
            <el-input v-model="emsForm.equipment_id" readonly style="width: 200px" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item :label="$t('dpmIssueReview.colImpactPersons')" prop="people_num">
            <el-input v-model="emsForm.people_num" readonly style="width: 200px" />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="handleCancel">{{ $t('common.btnClose') }}</el-button>
    </span>
  </el-dialog>
</template>

<script>

export default {
  name: 'DialogEmsMaintenance',
  props: {
    detailDialog: {
      type: Boolean,
      required: false,
      default: false
    },
    emsData: {
      type: Object,
      required: true
    },
    dialogTitle: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      loading: false,
      emsForm: this.initFormData() // 初始化数据,
    }
  },
  watch: {
    emsData: function(val) {
      this.emsForm = this.emsData
    }
  },
  created() {

  },
  methods: {
    initFormData() {
      return {
        line: '',
        callno: '',
        call_repair_datetime: '',
        confirm_datetime: '',
        reason_desc: '',
        solution: '',
        equipment_id: '',
        people_num: ''
      }
    },
    handleCancel() {
      this.$emit('detail-close', false)
      this.emsForm = this.initFormData()
      this.$refs['emsForm'].resetFields()
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    }
  }
}
</script>

  <style scoped lang="less">
  </style>
