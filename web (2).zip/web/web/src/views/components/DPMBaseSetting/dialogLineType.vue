<template>
  <el-dialog
    :title="$t('dpmBaseSetting.lblQueryLineType')"
    :visible.sync="visible"
    :before-close="handleCancel"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    append-to-body
    width="800px"
  >
    <el-form ref="queryLineTypeFrom" :model="queryLineTypeFrom" :inline="true" size="small">
      <el-form-item prop="lineType">
        <el-input
          v-model="queryLineTypeFrom.lineType"
          :placeholder="$t('dpmBaseSetting.lblLineType')"
          prefix-icon="el-icon-search"
          clearable
          size="small"
          style="width:250px;margin-right:20px"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="small" @click="queryByLineType()">{{ $t('common.btnQuery') }}</el-button>
        <el-button type="primary" icon="el-icon-plus" plain size="small" style="margin-left:15px" @click="addLineTypeBtn()">{{ $t('common.btnAdd') }}</el-button>
      </el-form-item>
    </el-form>
    <div class="allLineTypeDiv">
      <el-table
        ref="LineTypeList"
        v-loading="loading"
        size="small"
        stripe
        fit
        highlight-current-row
        :data="LineTypeList"
        height="480px"
      >
        <el-table-column type="index" :label="$t('common.colSeq')" width="60" align="center" />
        <el-table-column label="Site" prop="SITE" align="center" />
        <el-table-column :label="$t('common.colFactory')" prop="FACTORY" align="center" />
        <el-table-column :label="$t('dpmBaseSetting.phdLineType')" prop="LINE_TYPE" align="center" />
        <el-table-column :label="$t('dpmBaseSetting.lblUpdateTime')" prop="UPDATE_TIME" align="center" />
      </el-table>
    </div>
    <el-dialog
      :title="$t('dpmBaseSetting.lblAddLineType')"
      :close-on-press-escape="false"
      :visible.sync="addLineTypeDialogVisible"
      width="400px"
      :close-on-click-modal="false"
      append-to-body
    >
      <el-form ref="AddLineTypeForm" :model="AddLineTypeForm" label-width="80px">
        <el-form-item :label="$t('common.colFactory')">
          <el-input v-model="AddLineTypeForm.factory" style="width:250px" :disabled="true" />
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.phdLineType')">
          <el-input v-model="AddLineTypeForm.lineType" style="width:250px" />
        </el-form-item>
        <el-form-item>
          <el-button type="danger" size="small" @click="closeAddLineTypeDialog">{{ $t('common.btnQuit') }}</el-button>
          <el-button type="success" size="small" style="margin-left:30px" @click="submitNewLineType">{{ $t('common.btnSubmit') }}</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </el-dialog>
</template>

<script>
import { GetLineTypeData, AddNewLineType } from '@/api/midway.js'
export default {
  name: 'DialogLineType',
  props: {
    value: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      loading: false,
      visible: this.value,
      LineTypeList: [],
      factory: '',
      queryLineTypeFrom: {
        lineType: ''
      },
      AddLineTypeForm: {
        factory: '',
        lineType: ''
      },
      addLineTypeDialogVisible: false
    }
  },
  watch: {
    value(val) {
      this.visible = val
    },
    visible(val) {
      this.$emit('input', val)
    }
  },
  methods: {
    init(factory) {
      this.factory = factory
      const param = { factory: factory, lineType: 'ALL' }
      this.loading = true
      GetLineTypeData(param).then((res) => {
        if (res.data.QueryResult === 'OK') {
          this.LineTypeList = res.data.ReturnObject[0]
        } else {
          this.$message({
            message: res.data.QueryResult,
            type: 'warning'
          })
        }
      })
      this.loading = false
    },
    handleCancel() {
      this.visible = false
      this.queryLineTypeFrom.lineType = ''
      this.factory = ''
      this.LineTypeList = []
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    closeAddLineTypeDialog() {
      this.AddLineTypeForm.factory = ''
      this.AddLineTypeForm.lineType = ''
      this.addLineTypeDialogVisible = false
    },
    addLineTypeBtn() {
      this.AddLineTypeForm.factory = this.factory
      this.AddLineTypeForm.lineType = ''
      this.addLineTypeDialogVisible = true
    },
    submitNewLineType() {
      if (this.AddLineTypeForm.lineType === '') {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgPleaseKeyinLineType'))
        return
      }
      const param = { factory: this.AddLineTypeForm.factory, lineType: this.AddLineTypeForm.lineType }
      this.$confirm(this.$t('common.altMsgConfirmSubmit'), this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        cancelButtonText: this.$t('common.altMsgBtnCancel'),
        type: 'warning'
      }).then(() => {
        AddNewLineType(param).then((res) => {
          if (res.data.QueryResult === 'OK') {
            this.$message({
              message: this.$t('common.altMsgOptSuccess'),
              type: 'success'
            })
            this.closeAddLineTypeDialog()
            this.init(this.factory)
          } else {
            this.$message.error(res.data.QueryResult)
          }
        })
      })
    },
    async queryByLineType() {
      if (this.queryLineTypeFrom.lineType === '') {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgMustKeyinLineType'))
        this.init(this.factory)
        return
      }
      const param = { factory: this.factory, lineType: this.queryLineTypeFrom.lineType }
      this.loading = true
      await GetLineTypeData(param).then((res) => {
        if (res.data.QueryResult === 'OK') {
          this.LineTypeList = res.data.ReturnObject[0]
        } else {
          this.$message({
            message: res.data.QueryResult,
            type: 'warning'
          })
        }
      })
      this.loading = false
    }
  }
}
</script>

<style lang="less" scoped>

.allLineTypeDiv{
  height: 500px !important;

  ::v-deep .el-table__body-wrapper::-webkit-scrollbar {
    width: 10px;
  }

  ::v-deep .el-table__body-wrapper::-webkit-scrollbar-thumb {
    background-color: #d1d1d4;border-radius: 5px;
  }

  ::v-deep .el-table__body-wrapper::-webkit-scrollbar-thumb:hover {
    background-color: #a8a8a8;
  }

  ::v-deep .el-table{
  height: 100%;
  }
}
</style>
