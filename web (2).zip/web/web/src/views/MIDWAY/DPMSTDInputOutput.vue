<template>
  <div style="height:100%;width:100%">
    <el-container style="height:100%">
      <el-header style="padding:0;height:40px">
        <el-select v-model="queryPlant" size="small" style="width:100px;margin-right:5px" :placeholder="$t('common.phdSelectFactory')">
          <el-option
            v-for="item in plantList"
            :key="item.plant"
            :label="item.plant"
            :value="item.plant"
          />
        </el-select>
        <el-date-picker v-model="queryYearMonth" size="small" style="width:120px;margin-right:5px" type="month" :placeholder="$t('dpmSTDInputOutput.phdYear')" />
        <el-input v-model="queryString" :placeholder="$t('dpmSTDInputOutput.phdLineOption')" size="small" style="width:150px;margin-right:5px" />
        <el-button type="primary" icon="el-icon-search" size="small" @click="querySTDData(true)">{{ $t('common.btnQuery') }}</el-button>
        <el-button type="primary" icon="el-icon-download" size="small" @click="downloadData('N')">{{ $t('common.btnDownload') }}</el-button>
        <el-button type="primary" icon="el-icon-download" style="margin-left:50px" size="small" @click="downloadData('Y')">{{ $t('common.btnDownloadTemplate') }}</el-button>
        <el-button type="primary" icon="el-icon-upload" size="small" @click="uploadFile">{{ $t('common.btnUpload') }}</el-button>
      </el-header>
      <el-main style="padding:0;height:1px">
        <div id="tableContainer" style="height:100%;">
          <el-table
            ref="tbData"
            v-loading="loading"
            :data="tableData"
            size="small"
            :height="tableHeight"
            style="width: 100%;"
          >
            <el-table-column prop="Line" :label="$t('common.colLine')" width="100" align="center" fixed />
            <el-table-column prop="Shift" :label="$t('common.colShift')" width="60" align="center" fixed />
            <el-table-column
              v-for="o in colSetting"
              :key="o.label"
              :label="o.label"
              :width="150"
              align="center"
            >
              <el-table-column
                v-for="child in o.children"
                :key="child.label"
                :prop="child.prop"
                :label="child.label"
                :width="75"
                align="center"
              />
            </el-table-column>
          </el-table>
        </div>
      </el-main>
    </el-container>

    <el-dialog
      :center="true"
      :title="$t('dpmSTDInputOutput.lblMsgUploadSTD')"
      :close-on-press-escape="false"
      :visible.sync="uploadDialogVisible"
      width="500px"
      :close-on-click-modal="false"
      top="5vh"
    >
      <el-upload
        ref="uploadDialog"
        class="upload-demo"
        action="#"
        :headers="headers"
        :limit="1"
        :http-request="uploadExcelFile"
        :on-remove="handleRemoveFile"
        :file-list="uploadFileList"
        :auto-upload="true"
        :on-exceed="selectOverLimit"
        :on-change="handleFileChange"
        :accept="'.xlsx'"
        list-type="text"
      >
        <el-button size="mini">{{ $t('dpmSTDInputOutput.lblUploadExcel') }}</el-button>
        <div slot="tip" class="el-upload__tip">{{ $t('dpmSTDInputOutput.lblForamtWarning') }}</div>
      </el-upload>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="closeUploadDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import { downloadSTDInputOutputGoal_API } from '@/api/upload_download'
import { UploadSTDDataFromExcel_API } from '@/api/upload_download'
import {
  getUserMenuPlantList, GetSTDInputOutputGoalData
} from '@/api/midway.js'
export default {
  data() {
    return {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      loading: false,
      loadingData: null,
      tableHeight: null,
      queryPlant: '',
      queryString: '',
      colSetting: [],
      tableData: [],
      plantList: [],
      uploadDialogVisible: false,
      uploadFileList: [],
      queryMonth: '',
      queryYearMonth: ''
    }
  },
  mounted() {
    this.getDefaultDate()
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
    }
    this.queryPlantList()
  },
  methods: {
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    getDefaultDate() {
      const curDate = new Date()
      this.queryMonth = curDate
      this.queryYearMonth = curDate
    },
    async queryPlantList() {
      // start update 20230222 fenglianlong 修改获取menuId来源于主框架值
      // const data = { menu: '', menuId: '62' }
      const data = { menuId: this.$route.query.menuId }
      this.plantList = []
      const response = await getUserMenuPlantList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.plantList = response.data.ReturnObject
        // end update 20230222 fenglianlong ---------------------
      } else {
        this.alertMsg(queryResult)
      }
    },
    async querySTDData() {
      if (this.queryPlant === '') {
        this.alertMsg(this.$t('dpmSTDInputOutput.altMsgFactoryEmpty'))
        return
      }
      this.colSetting = []
      this.tableData = []
      const yM = this.$utils.GetDateString(this.queryYearMonth)
      const data = {
        factory: this.queryPlant,
        line: this.queryString,
        yearMonth: yM.substr(0, 7),
        isTemplate: 'N'
      }
      this.loading = true
      const response = await GetSTDInputOutputGoalData(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        if (obj.length > 0) {
          for (const key in obj[0]) {
            if (key.toLowerCase() !== 'line' && key.toLowerCase() !== 'shift') {
              const temp = key.split('_')
              let mainLabel = null
              if (this.colSetting.filter(x => x.label === temp[0]).length > 0) {
                mainLabel = this.colSetting.filter(x => x.label === temp[0])[0]
              }
              if (mainLabel === null) {
                this.colSetting.push({
                  label: temp[0],
                  children: [{
                    prop: key,
                    label: temp[1]
                  }]
                })
              } else {
                mainLabel.children.push({
                  prop: key,
                  label: temp[1]
                })
              }
            }
          }
        }
        this.tableData = obj
        this.$nextTick(() => {
          this.$refs.tbData.doLayout()
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    downloadData: function(isTemplate) {
      if (this.queryPlant === '') {
        this.alertMsg(this.$t('dpmSTDInputOutput.altMsgFactoryEmpty'))
        return
      }
      this.$alert(this.$t('dpmSTDInputOutput.altMsgWaiting'), this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'warning'
      })
      const yM = this.$utils.GetDateString(this.queryYearMonth)
      // const fileName = isTemplate === 'N' ? this.queryPlant + '_InputOutputGoal(' + yM + ').xlsx' : this.queryPlant + '_InputOutputGoal_Template.xlsx'

      const params = {
        factory: encodeURIComponent(this.queryPlant),
        isTemplate: isTemplate,
        line: encodeURIComponent(this.queryString),
        yearMonth: encodeURIComponent(yM.substr(0, 7))
      }
      const fileName = isTemplate === 'N' ? this.queryPlant + '_InputOutputGoal(' + yM + ').xlsx' : this.queryPlant + '_InputOutputGoal_Template.xlsx'
      downloadSTDInputOutputGoal_API(params, fileName)
      // var url = '/MIDWAY/downloadSTDInputOutputGoal'
      // url = url + '?factory=' + encodeURIComponent(this.queryPlant) + '&isTemplate=' + isTemplate +
      // '&line=' + encodeURIComponent(this.queryString) + '&yearMonth=' + encodeURIComponent(yM.substr(0, 7)) + '&lang=cn'
      // this.$utils.downloadFile(url, fileName)
    },
    uploadFile() {
      // this.$refs.uploadDialog.uploadFiles = []
      if (this.queryPlant === '') {
        this.alertMsg(this.$t('dpmSTDInputOutput.altMsgFactoryEmpty'))
        return
      }
      this.uploadFileList = []
      this.uploadDialogVisible = true
    },
    closeUploadDialog() {
      this.uploadDialogVisible = false
    },
    selectOverLimit(file, fileList) {
      alert(this.$t('dpmSTDInputOutput.altMsgOnlyOneFile'))
    },
    handleFileChange(file, fileList) {
      this.uploadFileList = fileList
    },
    handleRemoveFile(file, fileList) {
      this.uploadFileList = fileList
    },
    uploadExcelFile: async function(params) {
      if (this.queryPlant === '') {
        this.alertMsg(this.$t('dpmSTDInputOutput.altMsgFactoryEmpty'))
        return
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoadingSubmit'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      var formData = new FormData()
      formData.append('file', params.file)
      formData.append('factory', this.queryPlant)
      const that = this
      const response = await UploadSTDDataFromExcel_API(formData)
      that.loadingData.close()
      if (response.data.QueryResult === 'OK') {
        // debugger
        if (response.data.ReturnObject !== null) {
          this.OprateImportData(response.data.ReturnObject)
          this.importDetaillDialog = true
        } else {
          that.$alert(this.$t('common.altUploadSuccessPlsRefresData'), this.$t('common.altMsgTitle'), {
            confirmButtonText: this.$t('common.altMsgTitle'),
            type: 'success'
          })
        }
        that.closeUploadDialog()
      } else {
        that.$refs.uploadDialog.uploadFiles = []
        that.uploadFileList = []
        alert(response.data.QueryResult)
      }
      // this.$axios.post('/HttpUtility/Upload?controller=MIDWAY&action=UploadSTDInputOutputFromExcel', formData, { headers: this.headers }).then(
      //   (response) => {
      //     that.loadingData.close()
      //     if (response.data.QueryResult === 'OK') {
      //       that.$alert(this.$t('dpmSTDInputOutput.altMsgUploadSuccess'), this.$t('common.altMsgTitle'), {
      //         confirmButtonText: this.$t('common.altMsgBtn'),
      //         type: 'success'
      //       })
      //       that.closeUploadDialog()
      //     } else {
      //       that.$refs.uploadDialog.uploadFiles = []
      //       that.uploadFileList = []
      //       alert(response.data.QueryResult)
      //     }
      //   }
      // ).catch(function(response) {
      //   that.loadingData.close()
      //   that.$refs.uploadDialog.uploadFiles = []
      //   alert(response)
      // })
    },
    resizeTable: function() {
      this.$nextTick(function() {
        const divHeight = $('#tableContainer').height()
        this.tableHeight = divHeight
      })
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep .el-divider--horizontal{
  margin:0
}
::v-deep .specialtotalcolumn{
  background-color: oldlace;
}
::v-deep .totalcolumn{
  background: #f0f9eb
}
</style>
