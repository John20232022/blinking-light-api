<template>
  <div style="height:100%;width:100%;">
    <el-tabs v-model="activetabName" type="card">
      <el-tab-pane label="MT" name="MT">
        <el-row>
          <el-col :span="4">
            <el-date-picker
              v-model="MTselectDate"
              type="date"
              value-format="yyyy-MM-dd"
              :placeholder="$t('dpmIssueReview.altMsgWorkDayEmpty')"
            />
          </el-col>
          <el-col :span="4">
            <el-select v-model="MTselectFacroty" multiple :placeholder="$t('common.phdSelectFactory')">
              <el-option
                v-for="item in MTFacrotyList"
                :key="item.factory"
                :label="item.factory"
                :value="item.factory"
              />
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-select v-model="MTselectLine" multiple filterable :placeholder="$t('dpmPCBAIssue.phdSelectLineOption')">
              <el-option
                v-for="item in MTLineList"
                :key="item.Line"
                :label="item.Line"
                :value="item.Line"
              />
            </el-select>
          </el-col>
          <el-col :span="7">
            <el-input
              v-model="MTselectedEmpNo"
              :placeholder="$t('common.colEmpId')"
            />
          </el-col>
          <el-col :span="2" style="margin-left: 15px;">
            <el-button type="primary" @click="searchingData('MT')">{{ $t('common.btnQuery') }}</el-button>
          </el-col>
        </el-row>
        <!--MT表格内容-->
        <el-table
          :data="MTDataInfo"
          height="600px"
          style="overflow:scroll"
          :header-cell-style="getHeaderCellColor"
          :row-style="tableRowStyle"
        >
          <el-table-column
            v-for="item1 in MTDatacolsel"
            :key="item1.name"
            :prop="item1.name"
            :label="item1.label"
            :width="item1.width"
          >
            <template #default="scoped">
              <div style="height: 20px;font-size:16px;padding: 0; font-weight: 300;">{{ scoped.row[item1.name] }}</div>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="過站數據" name="PassData">
        <el-row>
          <el-col :span="4">
            <el-date-picker
              v-model="Pass_selectDate"
              type="date"
              value-format="yyyy-MM-dd"
              :placeholder="$t('dpmIssueReview.altMsgWorkDayEmpty')"
            />
          </el-col>
          <el-col :span="4" style="margin-left: 15px;">
            <el-select v-model="Pass_selectFacroty" multiple :placeholder="$t('common.phdSelectFactory')">
              <el-option
                v-for="item in MTFacrotyList"
                :key="item.factory"
                :label="item.factory"
                :value="item.factory"
              />
            </el-select>
          </el-col>
          <el-col :span="4" style="margin-left: 15px;">
            <el-select v-model="Pass_LineSelected" multiple filterable :placeholder="$t('dpmPCBAIssue.phdSelectLineOption')">
              <el-option
                v-for="item in Pass_LineList"
                :key="item.Line"
                :label="item.Line"
                :value="item.Line"
              />
            </el-select>
          </el-col>
          <el-col :span="2" style="margin-left: 15px;">
            <el-select v-model="Pass_ShiftSelected" multiple filterable :placeholder="$t('common.colShift')">
              <el-option
                v-for="item in Pass_ShiftList"
                :key="item.Name"
                :label="item.Name"
                :value="item.Name"
              />
            </el-select>
          </el-col>
          <el-col :span="2" style="margin-left: 15px;">
            <el-input
              v-model="Pass_StageSelected"
              :placeholder="$t('common.phdSelectStage')"
            />
          </el-col>
          <el-col :span="2" style="margin-left: 15px;">
            <el-input
              v-model="Pass_ProcessSelected"
              :placeholder="$t('common.phdSelectProcess')"
            />
          </el-col>
          <el-col :span="2" style="margin-left: 15px;">
            <el-button type="primary" @click="searchingData('Pass_Data')">{{ $t('common.btnQuery') }}</el-button>
          </el-col>
        </el-row>
        <!--MT表格内容-->
        <el-table
          :data="Pass_Datainfo"
          height="600px"
          style="overflow:scroll"
          :header-cell-style="getHeaderCellColor"
          :row-style="tableRowStyle"
        >
          <el-table-column
            v-for="item1 in Pass_DataCol"
            :key="item1.name"
            :prop="item1.name"
            :label="item1.label"
            :width="item1.width"
          >
            <template #default="scoped">
              <div style="height: 20px;font-size:16px;padding: 0; font-weight: 300;">{{ scoped.row[item1.name] }}</div>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
// import $ from 'jquery'
import { GetIssueCheckSearchingComBox, GetIssueCheckSearchingInfo } from '@/api/midway.js'
export default {
  data() {
    return {
      Pass_ShiftList: [{ 'Name': 'D' }, { 'Name': 'M' }, { 'Name': 'N' }],
      Pass_ShiftSelected: ['D'],
      tableDataLineChange: [],
      tableDataChangeList: [],
      Pass_StageSelected: '',
      Pass_LineSelected: [],
      Pass_selectDate: '',
      Pass_ProcessSelected: '',
      Pass_selectFacroty: [],
      activeNames: '',
      activeNames2: '',
      activetabName: 'MT',
      MTselectDate: '',
      MTFacrotyList: [],
      MTselectFacroty: [],
      MTLineList: [],
      Pass_LineList: [],
      MTselectLine: [],
      loadingData: null,
      MTselectedEmpNo: '',
      MTDatacolsel: [],
      MTDataInfo: [],
      Pass_DataCol: [],
      Pass_Datainfo: []
    }
  },
  watch: {
    MTselectFacroty: {
      handler(newVal, oldVal) {
        if (this.MTselectFacroty.length === 0 || this.MTselectFacroty.length === 0) {
          this.MTLineList = []
          this.MTselectLine = []
        } else {
          this.getComboxlist('MT', 'MTLineList', this.MTselectFacroty)
          this.MTselectLine = []
        }
      }
    },
    Pass_selectFacroty: {
      handler(newVal, oldVal) {
        if (this.Pass_selectFacroty.length === 0 || this.Pass_selectFacroty.length === 0) {
          this.Pass_LineList = []
          this.Pass_LineSelected = []
        } else {
          this.getComboxlist('MT', 'Pass_LineList', this.Pass_selectFacroty)
          this.Pass_LineSelected = []
        }
      }
    }
  },
  mounted() {
    var currentDate = new Date() // 创建一个表示当前时间的Date对象
    this.MTselectDate = currentDate.getFullYear() + '-' + (currentDate.getMonth() + 1) + '-' + currentDate.getDate()
    this.Pass_selectDate = this.MTselectDate
    this.getPastOneYearMonth()
    this.getComboxlist('MT', 'MTFacrotyList', '')
  },
  methods: {
    getTabDivHeight() {
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    tableRowStyle({ row, rowIndex }) {
      if (row.WORK_TYPE === '') {
        return {
          'background-color': '#FFE4E1',
          padding: '0',
          height: '18px'
        }
      } else {
        return {
          padding: '0',
          height: '18px'
        }
      }
    },
    getHeaderCellColor() {
      const style = {
        'background-color': 'rgb(32,55,100)',
        color: 'white',
        padding: '0',
        height: '20px'
      }
      return style
    },
    getInfoData(className) {
      var tempresult = this.ProblemInfo.filter((item, index) => {
        if (item.class === className) {
          return true
        }
      })
      return tempresult
    },
    async getComboxlist(page, target, conditon) {
      const data = {
        page: page,
        target: target,
        MTselectDate: this.MTselectDate,
        conditon: conditon
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoading'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await GetIssueCheckSearchingComBox(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this[target] = response.data.ReturnObject[0]
        this.loadingData.close()
      } else {
        this.loadingData.close()
        this.alertMsg(queryResult)
      }
    },
    getPastOneYearMonth() {
      this.yearMonth_items = []
      var my = new Date()
      var currentYear = my.getFullYear() // 获取当前年份
      // var NextYear = my.getFullYear() + 1 // 获取当前年份
      var currentMonth = my.getMonth() + 1 // 获取当前月份
      // var NextcurrentYearMonth = NextYear + '-' + (currentMonth === 12 ? currentMonth : currentMonth + 1)
      var currentYearMonth = currentYear + '-' + (currentMonth === 12 ? currentMonth : currentMonth + 1)
      var pastOneYearMont = (currentYear - 1) + '-' + (currentMonth === 12 ? currentMonth : currentMonth + 1)
      var tempYearMonth = this.getArrtime(pastOneYearMont, currentYearMonth)
      tempYearMonth.forEach((i) => {
        i = i.replace('-', '')
        var obj = {}
        obj.Month = i
        this.yearMonth_items.push(obj)
      })
      this.yearMonth_items = this.yearMonth_items.reverse()
    },
    getArrtime: function(stime, etime) {
      var diffdate = []
      var year = stime.split('-')[0]
      var month = stime.split('-')[1]
      if (month < 10)stime = year + '-0' + month
      let i = 0
      while (i >= 0) {
        diffdate[i] = stime
        // 获取开始日期时间戳
        var stimets = new Date(stime).getTime()
        // console.log('当前日期：'+stime   +'当前时间戳：'+stime_ts);
        // 增加一个月时间戳后的日期
        var nextdate = stimets + (24 * 60 * 60 * 1000 * 31)
        // 拼接年月日，这里的月份会返回（0-11），所以要+1
        var nextdatesy = new Date(nextdate).getFullYear() + '-'
        var nextdatesm = (new Date(nextdate).getMonth() + 1 < 10) ? '0' + (new Date(nextdate).getMonth() + 1) : (new Date(nextdate).getMonth() + 1)
        stime = nextdatesy + nextdatesm
        if (new Date(stime) > +new Date(etime)) {
          break
        }
        i++
      }
      return diffdate
    },
    async searchingData(searchingType) {
      if (searchingType === 'MT') {
        const data = {
          searchingType: searchingType,
          Date: this.MTselectDate,
          factory: this.MTselectFacroty,
          Line: this.MTselectLine,
          empNo: this.MTselectedEmpNo
        }
        this.loadingData = this.$loading({
          lock: true,
          text: this.$t('common.altMsgLoading'),
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        })
        const response = await GetIssueCheckSearchingInfo(data)
        const queryResult = response.data.QueryResult
        if (queryResult === 'OK') {
          this.MTDatacolsel = response.data.ReturnObject[1]
          this.MTDataInfo = response.data.ReturnObject[0]
          this.loadingData.close()
        } else {
          this.loadingData.close()
          this.alertMsg(queryResult)
        }
      } else if (searchingType === 'Pass_Data') {
        if (this.Pass_selectDate === '' || this.Pass_selectFacroty.length === 0) {
          var mes = this.$t('common.phdSelectFactory') + ' and ' + this.$t('dpmIssueReview.altMsgWorkDayEmpty') + ' are not allow be Empty ,'
          alert(mes)
          return
        }
        const data = {
          searchingType: searchingType,
          Date: this.Pass_selectDate,
          factory: this.Pass_selectFacroty,
          Line: this.Pass_LineSelected,
          Stage: this.Pass_StageSelected,
          Process: this.Pass_ProcessSelected,

          Shift: this.Pass_ShiftSelected
        }
        this.loadingData = this.$loading({
          lock: true,
          text: this.$t('common.altMsgLoading'),
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        })
        const response = await GetIssueCheckSearchingInfo(data)
        const queryResult = response.data.QueryResult
        if (queryResult === 'OK') {
          this.Pass_DataCol = response.data.ReturnObject[1]
          this.Pass_Datainfo = response.data.ReturnObject[0]
          this.loadingData.close()
        } else {
          this.loadingData.close()
          this.alertMsg(queryResult)
        }
      }
    }
  }
}
</script>
<style lang="less" scoped>
  .el-table {
  /deep/ .el-table__body-wrapper::-webkit-scrollbar {
    width: 15px; /*滚动条宽度*/
    height: 15px; /*滚动条高度*/
  }
  /*定义滚动条轨道 内阴影+圆角*/
  /deep/ .el-table__body-wrapper::-webkit-scrollbar-track {
    box-shadow: 0px 1px 3px rgba(red, green, blue, 0) inset; /*滚动条的背景区域的内阴影*/
    border-radius: 12px; /*滚动条的背景区域的圆角*/
    background-color: rgba(red, green, blue, 0); /*滚动条的背景颜色*/
    width: 200px;
  }
  /*定义滑块 内阴影+圆角*/
  /deep/ .el-table__body-wrapper::-webkit-scrollbar-thumb {
    box-shadow: 0px 1px 3px rgba(red, green, blue, 0) inset; /*滚动条的内阴影*/
    border-radius: 12px; /*滚动条的圆角*/
    background-color: rgb(27, 117, 219); /*滚动条的背景颜色*/
    width: 200px;
  }
}
</style>
<style>
.el-table .el-table__fixed {
  height:auto ;
  bottom:auto
}
.el-table__body-wrapper {
  z-index:1
}
  .el-collapse .el-collapse-item__header {
    color: white;
    font-size: 18px;
    background-color: cornflowerblue;
    border-radius: 10px;
}
  .el-collapse-item__content {
    font-size: 18px;
    border-color: cornflowerblue;
    border-width: 5px;
    border-radius: 5px;
}
</style>
