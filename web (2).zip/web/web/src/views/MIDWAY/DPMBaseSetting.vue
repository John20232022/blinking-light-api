<template>
  <div style="height:100%;width:100%">
    <el-container style="height:100%">
      <el-header style="padding:0;height:40px">
        <el-select v-model="queryPlant" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectFactory')" @change="getQueryAreaList">
          <el-option
            v-for="item in plantList"
            :key="item.plant"
            :label="item.plant"
            :value="item.plant"
          />
        </el-select>
        <el-button type="primary" icon="el-icon-search" size="small" style="margin-left:5px" @click="getChangeList">{{ $t('dpmBaseSetting.btnRefreshTaskList') }}</el-button>
        <el-button type="primary" icon="el-icon-setting" plain size="small" style="margin-left:15px" @click="handleLineType()">{{ $t('dpmBaseSetting.btnLineTypeSetting') }}</el-button>
      </el-header>
      <el-main style="padding:0;height:1px">
        <div class="mainDiv">
          <div class="AreaDiv">
            <div class="fieldTitleDiv">
              Area
            </div>
            <ul v-for="(item, index) in areaList" :key="index" :style="{'background-color': getBgColor('area', item.key)}">
              <el-link :underline="false" @click="getQueryTeamList(item.key)">
                <span class="liDataSpan">{{ item.data }}</span>
              </el-link>
              <i class="el-icon-plus optIcon icon2" :title="$t('dpmBaseSetting.lblAddTeam')" @click="showAddNewTeamDialog(item.key)" />
              <i class="el-icon-document optIcon icon1" :title="$t('dpmBaseSetting.lblDetailData')" @click="getBaseViewList(item.key)" />
            </ul>
          </div>
          <div class="fieldDiv">
            <div class="fieldTitleDiv">
              Team
            </div>
            <ul v-for="(item, index) in teamList" :key="index" :style="{'background-color': getBgColor('team', item.key)}">
              <el-link :underline="false" @click="getQueryLineList(item.key)">
                <span class="liDataSpan">{{ item.data }}</span>
              </el-link>
              <i class="el-icon-plus optIcon icon2" :title="$t('dpmBaseSetting.lblAddLine')" @click="showAddNewLineDialog(item.key)" />
              <i class="el-icon-edit optIcon icon1" :title="$t('dpmBaseSetting.lblModifyTeam')" @click="showChangeTeamDialog(item.key, item.data)" />
            </ul>
          </div>
          <div class="fieldDiv">
            <div class="fieldTitleDiv">
              Line
            </div>
            <ul v-for="(item, index) in lineList" :key="index" :style="{'background-color': getBgColor('line', item.key)}">
              <el-link :underline="false">
                <span class="liDataSpan">{{ item.data }}</span>
              </el-link>
              <i class="el-icon-connection optIcon icon2" :title="$t('dpmBaseSetting.lblModifyLineStage')" @click="showChangeLineStageDialog(item.key, item.data)" />
              <i class="el-icon-edit optIcon icon1" :title="$t('dpmBaseSetting.lblModifyLine')" @click="showChangeLineDialog(item.key, item.data, item.block)" />
            </ul>
          </div>
          <div id="tableChangeDiv" class="fieldDiv" style="width:calc(100% - 660px)">
            <el-table
              v-loading="loading"
              :data="tableChangeList"
              size="small"
              stripe
              :height="tableHeight"
              style="width: 100%;"
            >
              <el-table-column prop="line" label="" width="60" align="center">
                <template slot-scope="scope">
                  <el-link :underline="false" style="color:red" @click="cancelChange(scope.row.id)">{{ $t('common.btnCancel') }}</el-link>
                </template>
              </el-table-column>
              <el-table-column prop="eff_work_date" :label="$t('dpmBaseSetting.colEffDay')" width="100" align="center" />
              <el-table-column prop="eff_shift" :label="$t('dpmBaseSetting.colEffShift')" width="90" align="center" />
              <el-table-column prop="change_type" :label="$t('dpmBaseSetting.colChangeType')" align="center" width="140" show-overflow-tooltip />
              <el-table-column prop="opt_value" :label="$t('dpmBaseSetting.colOptType')" align="center" width="110" show-overflow-tooltip />
              <el-table-column prop="old_value" :label="$t('dpmBaseSetting.colOldValue')" align="center" width="110" show-overflow-tooltip />
              <el-table-column prop="new_value" :label="$t('dpmBaseSetting.colNewValue')" align="center" width="110" show-overflow-tooltip />
              <el-table-column prop="submit_user" :label="$t('dpmBaseSetting.colSubmitUser')" align="center" width="100" />
              <el-table-column prop="submit_time" :label="$t('dpmBaseSetting.colSubmitTime')" align="center" width="150" />
            </el-table>
          </div>
        </div>
      </el-main>
    </el-container>
    <DialogLineType ref="DialogLineType" v-model="dialogVisibleLineType" />
    <!-- 新增team Kay-->
    <el-dialog
      :title="$t('dpmBaseSetting.lblAddTeam')"
      :close-on-press-escape="false"
      :visible.sync="addNewTeamDialogVisible"
      width="400px"
      :close-on-click-modal="false"
    >
      <el-form ref="AddTeamform" :model="AddTeamform" label-width="80px">
        <el-form-item :label="$t('dpmBaseSetting.colTeam')">
          <el-input v-model="AddTeamform.team" />
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.colOCS')">
          <el-input v-model="AddTeamform.ocs" />
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.colOPU')">
          <el-input v-model="AddTeamform.opu" />
        </el-form-item>
        <el-form-item>
          <el-button type="danger" size="small" @click="closeAddNewTeamDialog">{{ $t('common.btnQuit') }}</el-button>
          <el-button type="success" size="small" @click="submitNewTeam">{{ $t('common.btnSubmit') }}</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 新增line Kay-->
    <el-dialog
      :title="$t('dpmBaseSetting.lblAddLine')"
      :close-on-press-escape="false"
      :visible.sync="addNewLineDialogVisible"
      width="600px"
      :close-on-click-modal="false"
    >
      <el-form ref="AddLineform" :model="AddLineform" label-width="120px">
        <el-form-item :label="$t('dpmBaseSetting.lblLineName')">
          <el-input v-model="AddLineform.line" />
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.lblBlockName')">
          <el-input v-model="AddLineform.block_name" />
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.lblLineType')">
          <el-select v-model="AddLineform.line_type" size="small" class="selectMidSize" :placeholder="$t('dpmBaseSetting.phdLineType')">
            <el-option
              v-for="item in lineTypeList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.colOPU2')">
          <el-input v-model="AddLineform.OPU2" />
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.colCPH')">
          <el-input v-model="AddLineform.CPH" oninput="value=value.replace(/[^\d]/g,'')" />
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.phdNewCategory')">
          <el-select v-model="AddLineform.line_category" size="small" class="selectMidSize" :placeholder="$t('dpmBaseSetting.phdNewCategory')">
            <el-option
              v-for="item in lineCategoryList"
              :key="item.config_value3"
              :label="item.config_value3"
              :value="item.config_value3"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="danger" size="small" @click="closeAddNewLineDialog">{{ $t('common.btnQuit') }}</el-button>
          <el-button type="success" size="small" @click="submitNewLine">{{ $t('common.btnSubmit') }}</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 調整 Team Tab-->
    <el-dialog
      :title="$t('dpmBaseSetting.lblModifyTeamInfo')"
      :close-on-press-escape="false"
      :visible.sync="changeTeamDialogVisible"
      width="1000px"
      :close-on-click-modal="false"
    >
      <div style="margin-bottom:5px;">{{ $t('dpmBaseSetting.lblCurrentTeamName') }} {{ HiddenTeamName }}</div>
      <el-input v-show="false" v-model="HiddenTeamName" />
      <el-input v-show="false" v-model="HiddenTeam" />
      <el-tabs v-model="activeTeamOpt" type="card" @tab-click="TeamhandleClick">
        <!-- 調整team name Kay-->
        <el-tab-pane :label="$t('dpmBaseSetting.lblModifyTeam')" name="TeamName">
          <div>{{ $t('dpmBaseSetting.lblCurrentTeamName') }} {{ currentTeamName }}</div>
          <el-input v-model="newTeamName" size="small" style="width:200px" :placeholder="$t('dpmBaseSetting.phdNewTeamName')" />
          <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" :placeholder="$t('dpmBaseSetting.phdEffDay')" />
          <el-select v-model="newDataShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
            <el-option
              v-for="item in workshiftList"
              :key="item.shift_code"
              :label="item.shift_name"
              :value="item.shift_code"
            />
          </el-select>
          <div style="margin-top:5px;">
            <el-button type="danger" size="small" @click="closeChangeTeamDialog">{{ $t('common.btnQuit') }}</el-button>
            <el-button type="success" size="small" @click="submitChangeTeamName">{{ $t('common.btnSubmit') }}</el-button>
          </div>
        </el-tab-pane>
        <!-- 調整Team OPU Kay-->
        <el-tab-pane :label="$t('dpmBaseSetting.lblModifyOPU')" name="TeamOpu">
          <div> {{ $t('dpmBaseSetting.lblCurrentOPU') }}  {{ currentTeamOpu }}</div>
          <el-input v-model="newTeamOpu" size="small" style="width:200px" :placeholder="$t('dpmBaseSetting.phdNewOPU')" />
          <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" :placeholder="$t('dpmBaseSetting.phdEffDay')" />
          <el-select v-model="newDataShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
            <el-option
              v-for="item in workshiftList"
              :key="item.shift_code"
              :label="item.shift_name"
              :value="item.shift_code"
            />
          </el-select>
          <div style="margin-top:5px;">
            <el-button type="danger" size="small" @click="closeChangeTeamDialog">{{ $t('common.btnQuit') }}</el-button>
            <el-button type="success" size="small" @click="submitChangeTeamOpu">{{ $t('common.btnSubmit') }}</el-button>
          </div>
        </el-tab-pane>
        <!-- 調整team OCS Kay-->
        <el-tab-pane :label="$t('dpmBaseSetting.lblModifyOCS')" name="TeamOCS">
          <div>{{ $t('dpmBaseSetting.lblCurrentOCS') }} {{ currentTeamOCS }}</div>
          <el-input v-model="newTeamOCS" size="small" style="width:200px" :placeholder="$t('dpmBaseSetting.phdNewOCS')" />
          <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" :placeholder="$t('dpmBaseSetting.phdEffDay')" />
          <el-select v-model="newDataShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
            <el-option
              v-for="item in workshiftList"
              :key="item.shift_code"
              :label="item.shift_name"
              :value="item.shift_code"
            />
          </el-select>
          <div style="margin-top:5px;">
            <el-button type="danger" size="small" @click="closeChangeTeamDialog">{{ $t('common.btnQuit') }}</el-button>
            <el-button type="success" size="small" @click="submitChangeTeamOCS">{{ $t('common.btnSubmit') }}</el-button>
          </div>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>
    <!-- 調整 Line Tab-->
    <el-dialog
      :title="$t('dpmBaseSetting.lblModifyLineInfo')"
      :close-on-press-escape="false"
      :visible.sync="changeLineDialogVisible"
      width="1000px"
      :close-on-click-modal="false"
    >
      <div style="margin-bottom:5px;">{{ $t('dpmBaseSetting.lblCurrentLineName') }} {{ HiddenLineName }}</div>
      <el-input v-show="false" v-model="HiddenLineName" />
      <el-input v-show="false" v-model="HiddenLine" />
      <el-input v-show="false" v-model="HiddenLineBlock" />
      <el-tabs v-model="activeLineOpt" type="card" @tab-click="LinehandleClick">
        <el-tab-pane :label="$t('dpmBaseSetting.lblModifyLine')" name="LineName">
          <div>{{ $t('dpmBaseSetting.lblCurrentLineName') }} {{ currentLineName }}</div>
          <el-input v-model="newLineName" size="small" style="width:200px" :placeholder="$t('dpmBaseSetting.phdNewLineName')" />
          <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" :placeholder="$t('dpmBaseSetting.phdEffDay')" />
          <el-select v-model="newDataShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
            <el-option
              v-for="item in workshiftList"
              :key="item.shift_code"
              :label="item.shift_name"
              :value="item.shift_code"
            />
          </el-select>
          <div style="margin-top:5px;">
            <el-button type="danger" size="small" @click="closeChangeLineDialog">{{ $t('common.btnQuit') }}</el-button>
            <el-button type="success" size="small" @click="submitChangeLineName">{{ $t('common.btnSubmit') }}</el-button>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmBaseSetting.lblTitleMoveToOtherTeam')" name="LineMoveOtherTeam">
          <div>{{ $t('dpmBaseSetting.lblMsgMoveToOtherTeam') }}</div>
          <el-select v-model="moveTeam" size="small" class="selectMidSize" placeholder="Team">
            <el-option
              v-for="item in moveTeamList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" :placeholder="$t('dpmBaseSetting.phdEffDay')" />
          <el-select v-model="newDataShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
            <el-option
              v-for="item in workshiftList"
              :key="item.shift_code"
              :label="item.shift_name"
              :value="item.shift_code"
            />
          </el-select>
          <div style="margin-top:5px;">
            <el-button type="danger" size="small" @click="closeChangeLineDialog">{{ $t('common.btnQuit') }}</el-button>
            <el-button type="success" size="small" @click="submitMoveTeam">{{ $t('common.btnSubmit') }}</el-button>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmBaseSetting.lblModifyLineType')" name="LineType">
          <div>{{ $t('dpmBaseSetting.lblCurrentLineType') }} {{ currentLineType }}</div>
          <el-select v-model="newLineType" size="small" class="selectMidSize" :placeholder="$t('dpmBaseSetting.phdLineType')">
            <el-option
              v-for="item in lineTypeList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" :placeholder="$t('dpmBaseSetting.phdEffDay')" />
          <el-select v-model="newDataShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
            <el-option
              v-for="item in workshiftList"
              :key="item.shift_code"
              :label="item.shift_name"
              :value="item.shift_code"
            />
          </el-select>
          <div style="margin-top:5px;">
            <el-button type="danger" size="small" @click="closeChangeLineDialog">{{ $t('common.btnQuit') }}</el-button>
            <el-button type="success" size="small" @click="submitChangeLineType">{{ $t('common.btnSubmit') }}</el-button>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmBaseSetting.lblModifyLineGroup')" name="LineBlock">
          <div>{{ $t('dpmBaseSetting.lblCurrentBlockName') }} {{ currentBlockName }}</div>
          <el-input v-model="newBlockName" size="small" style="width:150px;margin-right:5px" :placeholder="$t('dpmBaseSetting.phdNewBlockName')" />
          <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" :placeholder="$t('dpmBaseSetting.phdEffDay')" />
          <el-select v-model="newDataShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
            <el-option
              v-for="item in workshiftList"
              :key="item.shift_code"
              :label="item.shift_name"
              :value="item.shift_code"
            />
          </el-select>
          <div style="margin-top:5px;">
            <el-button type="danger" size="small" @click="closeChangeLineDialog">{{ $t('common.btnQuit') }}</el-button>
            <el-button type="success" size="small" @click="submitChangeLineGroup">{{ $t('common.btnSubmit') }}</el-button>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmBaseSetting.lblModifyCPH')" name="LineCPH">
          <div> {{ $t('dpmBaseSetting.lblCurrentCPH') }}  {{ currentLineCPH }}</div>
          <el-input v-model="newLineCPH" size="small" style="width:200px" :placeholder="$t('dpmBaseSetting.phdNewCPH')" oninput="value=value.replace(/[^\d]/g,'')" />
          <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" :placeholder="$t('dpmBaseSetting.phdEffDay')" />
          <el-select v-model="newDataShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
            <el-option
              v-for="item in workshiftList"
              :key="item.shift_code"
              :label="item.shift_name"
              :value="item.shift_code"
            />
          </el-select>
          <div style="margin-top:5px;">
            <el-button type="danger" size="small" @click="closeChangeLineDialog">{{ $t('common.btnQuit') }}</el-button>
            <el-button type="success" size="small" @click="submitChangeLineCPH">{{ $t('common.btnSubmit') }}</el-button>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmBaseSetting.lblModifyOPU2')" name="LineOpu2">
          <div> {{ $t('dpmBaseSetting.lblCurrentOPU2') }}  {{ currentLineOpu2 }}</div>
          <el-input v-model="newLineOpu2" size="small" style="width:200px" :placeholder="$t('dpmBaseSetting.phdNewOPU2')" />
          <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" :placeholder="$t('dpmBaseSetting.phdEffDay')" />
          <el-select v-model="newDataShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
            <el-option
              v-for="item in workshiftList"
              :key="item.shift_code"
              :label="item.shift_name"
              :value="item.shift_code"
            />
          </el-select>
          <div style="margin-top:5px;">
            <el-button type="danger" size="small" @click="closeChangeLineDialog">{{ $t('common.btnQuit') }}</el-button>
            <el-button type="success" size="small" @click="submitChangeLineOpu2">{{ $t('common.btnSubmit') }}</el-button>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmBaseSetting.lblClearBlock')" name="ClearLineBlock">
          <div>{{ $t('dpmBaseSetting.lblCurrentBlockName') }} {{ currentBlockName }}</div>
          <el-input v-show="false" v-model="newBlockName" size="small" style="width:150px;margin-right:5px" :placeholder="$t('dpmBaseSetting.phdNewBlockName')" />
          <span>{{ $t('dpmBaseSetting.lblClearBlock') }} </span>
          <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" :placeholder="$t('dpmBaseSetting.phdEffDay')" />
          <el-select v-model="newDataShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
            <el-option
              v-for="item in workshiftList"
              :key="item.shift_code"
              :label="item.shift_name"
              :value="item.shift_code"
            />
          </el-select>
          <div style="margin-top:5px;">
            <el-button type="danger" size="small" @click="closeChangeLineDialog">{{ $t('common.btnQuit') }}</el-button>
            <el-button type="success" size="small" @click="submitClearLineGroup">{{ $t('common.btnSubmit') }}</el-button>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmBaseSetting.lblModifyCategory')" name="LineCategory">
          <div> {{ $t('dpmBaseSetting.lblCurrentCategory') }} {{ currentLineCategory }}</div>
          <el-select v-model="newLineCategory" size="small" class="selectMidSize" :placeholder="$t('dpmBaseSetting.phdNewCategory')">
            <el-option
              v-for="item in lineCategoryList"
              :key="item.config_value3"
              :label="item.config_value3"
              :value="item.config_value3"
            />
          </el-select>
          <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" :placeholder="$t('dpmBaseSetting.phdEffDay')" />
          <el-select v-model="newDataShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
            <el-option
              v-for="item in workshiftList"
              :key="item.shift_code"
              :label="item.shift_name"
              :value="item.shift_code"
            />
          </el-select>
          <div style="margin-top:5px;">
            <el-button type="danger" size="small" @click="closeChangeLineDialog">{{ $t('common.btnQuit') }}</el-button>
            <el-button type="success" size="small" @click="submitChangeLineCategory">{{ $t('common.btnSubmit') }}</el-button>
          </div>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>
    <!-- 新增調整linestage Kay-->
    <el-dialog
      :title="$t('dpmBaseSetting.lblModifyLineStage')"
      :close-on-press-escape="false"
      :visible.sync="changeLineStageDialogVisible"
      width="1000px"
      :close-on-click-modal="false"
    >
      <el-input v-show="false" v-model="HiddenLineName" />
      <el-input v-show="false" v-model="HiddenLine" />
      <el-form ref="AddLineStageform" :model="AddLineStageform" label-width="150px">
        <el-form-item :label="$t('dpmBaseSetting.lblLineName')">
          {{ HiddenLineName }}
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.colStage')">
          <!--  <el-select v-model="AddLineStageform.stage" size="small" class="selectMidSize" placeholder="Stage">
            <el-option
              v-for="item in stageList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select> -->
          <el-autocomplete
            v-model="AddLineStageform.stage"
            class="inline-input"
            :fetch-suggestions="querySearch"
            placeholder="Stage"
          />
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.colOperation')">
          <!-- <el-select v-model="AddLineStageform.stage_operation" size="small" class="selectMidSize" placeholder="Operation Code" :disabled="true">
            <el-option
              v-for="item in operationList"
              :key="item.key"
              :label="item.data"
              :value="item.data"
            />
          </el-select> -->
          <el-input v-model="AddLineStageform.stage_operation" placeholder="Operation Code" style="width:205px" />
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.colStageGroup')">
          <el-select v-model="AddLineStageform.stage_group" size="small" class="selectMidSize" placeholder="Stage Group">
            <el-option label="main" value="main" />
            <el-option label="sub" value="sub" />
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.colStageGroupInput')">
          <el-select v-model="AddLineStageform.stage_group_input" size="small" class="selectMidSize" placeholder="Stage Group Input">
            <el-option label="Y" value="Y" />
            <el-option label="N" value="N" />
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('dpmBaseSetting.colWorkCenter')">
          <el-input v-model="AddLineStageform.work_center" placeholder="Work Center" style="width:205px" />
          <el-button type="primary" style="margin-left: 10px;" @click="addData"> + </el-button>
        </el-form-item>
      </el-form>
      <el-table
        :data="StagetableData"
        style="width: 100%"
        max-height="450"
      >
        <el-table-column
          fixed="left"
          :label="$t('common.btnOpt')"
          width="120"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              size="small"
              @click.native.prevent="deleteRow(scope.$index, StagetableData)"
            >
              {{ $t('common.btnRemove') }}
            </el-button>
          </template>
        </el-table-column>
        <el-table-column
          v-if="false"
          prop="line_id"
          label="line_id"
        />
        <el-table-column
          prop="stage"
          :label="$t('dpmBaseSetting.colStage')"
          width="120"
        />
        <el-table-column
          prop="operation"
          :label="$t('dpmBaseSetting.colOperation')"
          width="120"
        />
        <el-table-column
          prop="stage_group"
          :label="$t('dpmBaseSetting.colStageGroup')"
          width="120"
        />
        <el-table-column
          prop="stage_group_input"
          :label="$t('dpmBaseSetting.colStageGroupInput')"
          width="150"
        />
        <el-table-column
          prop="work_center"
          :label="$t('dpmBaseSetting.colWorkCenter')"
          width="120"
        />
      </el-table>
      <div style="margin-top:5px;">
        <el-button type="danger" size="small" @click="closeLineStageDialog">{{ $t('common.btnQuit') }}</el-button>
        <el-button type="success" size="small" @click="submitLineStageOperation">{{ $t('common.btnSubmit') }}</el-button>
      </div>
    </el-dialog>
    <!-- 查看全部資料 Kay-->
    <el-dialog :title="$t('dpmBaseSetting.lblDetailData')" :visible.sync="ShowDataListDialog" :close-on-click-modal="false" width="80%">
      <div class="alldata_div">
        <el-table ref="AllDataList" size="small" stripe fit highlight-current-row :data="AllDataList" height="500px;">
          <el-table-column label="Area" prop="area" align="center" />
          <el-table-column label="Team" prop="team" align="center" />
          <el-table-column label="OCS" prop="OCS" align="center" />
          <el-table-column label="OPU" prop="OPU" align="center" />
          <el-table-column label="Line" prop="line" align="center" />
          <el-table-column label="Block Name" prop="block_name" align="center" />
          <el-table-column label="Line Type" prop="line_type" align="center" />
          <el-table-column label="OPU2" prop="OPU2" align="center" />
          <el-table-column label="CPH" prop="CPH" align="center" />
          <el-table-column label="Category" prop="category" align="center" />
        </el-table>
      </div>
    </el-dialog>

  </div>
</template>
<script>
import $ from 'jquery'
import {
  getUserMenuPlantList, GetCurrentBaseData, AddNewBaseData, AddBaseDataChangeRequest, GetBaseDataChangeList, CancelBaseDataChangeListItem, GetWorkshiftList, GetConfigList, GetStageOperationOption, SaveLineStageData, GetLineStageData
} from '@/api/midway.js'
import DialogLineType from '@/views/components/DPMBaseSetting/dialogLineType'
export default {
  components: {
    DialogLineType
  },
  data() {
    return {
      dialogVisibleLineType: false,
      tableHeight: 1,
      effDate: '',
      loading: false,
      loadingData: null,
      plantList: [],
      queryPlant: '',
      areaList: [],
      queryArea: '',
      teamList: [],
      queryTeam: '',
      lineList: [],
      queryLine: '',
      stageList: [],
      queryStage: '',
      addNewItemDialogVisible: false,
      addNewItemTitle: this.$t('dpmBaseSetting.lblTitleAddNewItem'),
      moveLineTeamDialogVisible: false,
      moveTeam: '',
      moveTeamList: [],
      newLineType: '',
      currentLineType: '',
      lineTypeList: [],
      currentLineName: '',
      currentBlockName: '',
      newLineName: '',
      newBlockName: '',
      currentTeamName: '',
      newTeamName: '',
      addNewTeamDialogVisible: false,
      addNewLineDialogVisible: false,
      tableChangeList: [],
      currentLineCPH: '',
      newLineCPH: '',
      currentLineOpu2: '',
      newLineOpu2: '',
      currentTeamOpu: '',
      newTeamOpu: '',
      ShowDataListDialog: false,
      AllDataList: [],
      AddTeamform: {
        team: '',
        ocs: '',
        opu: ''
      },
      AddLineform: {
        line: '',
        block_name: '',
        line_type: '',
        OPU2: '',
        CPH: '',
        line_category: ''
      },
      HiddenTeamName: '',
      HiddenTeam: '',
      currentTeamOCS: '',
      newTeamOCS: '',
      HiddenLine: '',
      HiddenLineName: '',
      HiddenLineBlock: '',
      activeTeamOpt: '',
      activeLineOpt: '',
      changeLineDialogVisible: false,
      changeTeamDialogVisible: false,
      workshiftList: [],
      newDataShift: '',
      lineCategoryList: [],
      newLineCategory: '',
      currentLineCategory: '',
      changeLineStageDialogVisible: false,
      stageoperationList: [],
      operationList: [],
      AddLineStageform: {
        stage: '',
        stage_operation: '',
        stage_group: '',
        stage_group_input: '',
        work_center: ''
      },
      StagetableData: []
    }
  },
  watch: {
    'AddLineStageform.stage'(newStage) {
      this.getOperationsByStage(newStage)
    }
  },
  mounted() {
    // MX與KH有三班制
    if (global.baseConfig.baseSite === 'MX-GDLA' ||
        global.baseConfig.baseSite === 'TW-KH') {
      // this.show_M = true
    }
    this.getDefaultDate()
    this.queryPlantList()
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
    }
  },
  methods: {
    handleLineType() {
      if (this.queryPlant === '') {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgPleaseSelectFactory'))
        return
      }
      this.dialogVisibleLineType = true
      this.$nextTick(() => {
        this.$refs['DialogLineType'].init(this.queryPlant)
      })
    },
    querySearch(queryString, cb) {
      var stageList = this.stageList
      var results = queryString ? stageList.filter(this.createFilter(queryString)) : stageList
      cb(results)
    },
    createFilter(queryString) {
      return (stagedata) => {
        return (stagedata.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    async GetLineStageData() {
      this.StagetableData = []
      const data = {
        lineId: this.HiddenLine
      }
      const response = await GetLineStageData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.StagetableData = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async submitLineStageOperation() {
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmBaseSetting.altMsgConfirmStageChange'), [this.HiddenLineName])
      if (!confirm(msg)) {
        return
      }
      const data = {
        lineId: this.HiddenLine,
        List: this.StagetableData
      }
      const response = await SaveLineStageData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeLineStageDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    addData() {
      const exists = this.StagetableData.some(item => item.stage === this.AddLineStageform.stage)
      if (exists) {
        this.alertMsg(this.$t('dpmBaseSetting.lblMsgExistSatge'))
      }
      if (this.AddLineStageform.stage && this.AddLineStageform.stage_operation && this.AddLineStageform.stage_group && this.AddLineStageform.stage_group_input) {
        this.StagetableData.push(
          {
            line_id: this.HiddenLine,
            stage: this.AddLineStageform.stage,
            operation: this.AddLineStageform.stage_operation,
            stage_group: this.AddLineStageform.stage_group,
            stage_group_input: this.AddLineStageform.stage_group_input,
            work_center: this.AddLineStageform.work_center
          })
      } else {
        this.alertMsg(this.$t('dpmBaseSetting.lblMsgCannotnull'))
      }
    },
    deleteRow(index, rows) {
      rows.splice(index, 1)
    },
    getOperationsByStage(stage) {
      this.AddLineStageform.stage_operation = ''
      this.operationList.filter(item => item.key === stage).forEach(item => {
        this.AddLineStageform.stage_operation = item.data
      })
    },
    async GetStageOperationOption() {
      this.operationList = []
      this.stageList = []
      const response = await GetStageOperationOption()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.stageoperationList = response.data.ReturnObject
        this.stageoperationList.forEach(item => {
          this.operationList.push({ key: item.STAGE_NAME, data: item.OPERATION })
          this.stageList.push({ value: item.STAGE_NAME, data: item.STAGE_NAME })
        })
      } else {
        this.alertMsg(
          this.$utils.ReplacePlaceHolder(
            this.$t('dpmBaseSetting.lblMsgStageOptionError'),
            [queryResult]
          )
        )
      }
    },
    closeLineStageDialog() {
      this.StagetableData = []
      this.stageoperationList = []
      this.operationList = []
      this.AddLineStageform = {
        stage: '',
        stage_operation: '',
        stage_group: '',
        stage_group_input: '',
        work_center: ''
      }
      this.changeLineStageDialogVisible = false
    },
    async GetConfigList() {
      this.lineCategoryList = []
      const data = {
        config_type: 'line_category'
      }
      const response = await GetConfigList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.lineCategoryList = response.data.ReturnObject
      } else {
        this.alertMsg(
          this.$utils.ReplacePlaceHolder(
            this.$t('dpmDashboardLineDetail.altMsgCannotGetShift'),
            [queryResult]
          )
        )
      }
    },
    async getWorkDayWorkshift() {
      this.workshiftList = []
      const data = {
        factory: this.queryPlant,
        hasALL: 'N'
      }
      const response = await GetWorkshiftList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.workshiftList = response.data.ReturnObject
      } else {
        this.alertMsg(
          this.$utils.ReplacePlaceHolder(
            this.$t('dpmDashboardLineDetail.altMsgCannotGetShift'),
            [queryResult]
          )
        )
      }
    },
    LinehandleClick(tab, event) {
      this.newDataShift = ''
      if (tab.name === 'LineName') {
        this.showChangeLineNameDialog(this.HiddenLine, this.HiddenLineName, this.HiddenLineBlock)
      } else if (tab.name === 'LineMoveOtherTeam') {
        this.showMoveTeamDialog(this.HiddenLine)
      } else if (tab.name === 'LineType') {
        this.showChangeLineTypeDialog(this.HiddenLine)
      } else if (tab.name === 'LineBlock') {
        this.showChangeLineGroupDialog(this.HiddenLine, this.HiddenLineBlock)
      } else if (tab.name === 'LineCPH') {
        this.showChangeLineCPHDialog(this.HiddenLine)
      } else if (tab.name === 'LineOpu2') {
        this.showChangeLineOpu2Dialog(this.HiddenLine)
      } else if (tab.name === 'ClearLineBlock') {
        this.showChangeLineGroupDialog(this.HiddenLine, this.HiddenLineBlock)
      } else if (tab.name === 'LineCategory') {
        this.showChangeLineCategoryDialog(this.HiddenLine)
      }
    },
    TeamhandleClick(tab, event) {
      this.newDataShift = ''
      if (tab.name === 'TeamName') {
        this.showChangeTeamNameDialog(this.HiddenTeam, this.HiddenTeamName)
      } else if (tab.name === 'TeamOpu') {
        this.showChangeTeamOpuDialog(this.HiddenTeam)
      } else if (tab.name === 'TeamOCS') {
        this.showChangeTeamOCSDialog(this.HiddenTeam)
      }
    },
    getDefaultDate() {
      const curDate = new Date()
      this.effDate = new Date(curDate.getTime() + 24 * 60 * 60 * 1000)
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    getBgColor(type, data) {
      if (type === 'area') {
        return data === this.queryArea ? 'lightblue' : 'white'
      } else if (type === 'team') {
        return data === this.queryTeam ? 'lightblue' : 'white'
      } else if (type === 'line') {
        return data === this.queryLine ? 'lightblue' : 'white'
      } else if (type === 'stage') {
        return data === this.queryStage ? 'lightblue' : 'white'
      }
    },
    async queryPlantList() {
    // start update 20230222 fenglianlong 修改获取menuId来源于主框架值
      // const data = { menu: '', menuId: '79' }
      const data = { menuId: this.$route.query.menuId }

      this.plantList = []
      const response = await getUserMenuPlantList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.plantList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryAreaList() {
      this.GetConfigList()
      this.getWorkDayWorkshift()
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = ''
      this.lineList = []
      this.queryLine = ''
      this.stageList = []
      this.queryStage = ''
      const data = {
        type: 'area',
        key: this.queryPlant
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject[0]
      } else {
        this.alertMsg(queryResult)
      }
      this.getChangeList()
    },
    async getQueryTeamList(key) {
      this.queryArea = key
      this.teamList = []
      this.queryTeam = ''
      this.lineList = []
      this.queryLine = ''
      this.stageList = []
      this.queryStage = ''
      const data = {
        type: 'team',
        key: this.queryArea
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.teamList = response.data.ReturnObject[0]
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryLineList(key) {
      this.queryTeam = key
      this.lineList = []
      this.queryLine = ''
      this.stageList = []
      this.queryStage = ''
      const data = {
        type: 'line',
        key: this.queryTeam
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.lineList = response.data.ReturnObject[0]
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getChangeList() {
      if (this.queryPlant === '') {
        return
      }
      this.tableChangeList = []
      const data = {
        factory: this.queryPlant
      }
      const response = await GetBaseDataChangeList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.tableChangeList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    setSelectedStage(key) {
      this.queryStage = key
    },
    openAddItemDialog() {
      this.addNewItemDialogVisible = true
    },
    closeAddItemDialog() {
      this.addNewItemDialogVisible = false
    },
    async showMoveTeamDialog(line) {
      this.queryLine = line
      this.moveTeam = ''
      const data = {
        type: 'moveteam',
        key: line
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.moveTeamList = response.data.ReturnObject[0]
      } else {
        this.alertMsg(queryResult)
      }
      this.moveLineTeamDialogVisible = true
    },
    async submitMoveTeam() {
      if (this.newDataShift === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgShiftEmpty'))
        return
      }
      const day = this.$utils.GetDateString(this.effDate)
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmBaseSetting.altMsgConfirmChange'), [day, this.newDataShift])
      if (!confirm(msg)) {
        return
      }
      const data = {
        type: 'changeteam',
        factory: this.queryPlant,
        optKey: this.queryLine,
        oldKey: this.queryTeam,
        oldValue: '',
        newKey: this.moveTeam,
        newValue: '',
        parentKey: this.queryTeam,
        effWorkDay: day,
        effShift: this.newDataShift
      }
      const response = await AddBaseDataChangeRequest(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgModifyTeamSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeChangeLineDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async showChangeLineTypeDialog(line) {
      this.queryLine = line
      this.currentLineType = ''
      this.newLineType = ''
      const data = {
        type: 'changelinetype',
        key: line
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.currentLineType = response.data.ReturnObject[0][0].line_type
        this.lineTypeList = response.data.ReturnObject[1]
      } else {
        this.alertMsg(queryResult)
      }
      this.changeLineTypeDialogVisible = true
    },
    async submitChangeLineType() {
      if (this.newLineType === '') {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgChooseNewLineType'))
        return
      }
      if (this.newDataShift === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgShiftEmpty'))
        return
      }
      const day = this.$utils.GetDateString(this.effDate)
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmBaseSetting.altMsgConfirmChange'), [day, this.newDataShift])
      if (!confirm(msg)) {
        return
      }
      const data = {
        type: 'changelinetype',
        factory: this.queryPlant,
        optKey: this.queryLine,
        oldKey: '',
        oldValue: this.currentLineType,
        newKey: '',
        newValue: this.newLineType,
        parentKey: this.queryTeam,
        effWorkDay: day,
        effShift: this.newDataShift
      }
      const response = await AddBaseDataChangeRequest(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgModifyLineTypeSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeChangeLineDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    showChangeLineGroupDialog(line, blockName) {
      this.queryLine = line
      this.currentBlockName = blockName
      this.newBlockName = ''
      this.changeLineGroupDialogVisible = true
    },
    showChangeLineDialog(line, lineName, lineBlock) {
      this.HiddenLine = line
      this.HiddenLineName = lineName
      this.HiddenLineBlock = lineBlock
      this.changeLineDialogVisible = true
      this.activeLineOpt = ''
    },
    showChangeLineStageDialog(line, lineName) {
      this.HiddenLine = line
      this.HiddenLineName = lineName
      this.GetStageOperationOption()
      this.GetLineStageData()
      this.changeLineStageDialogVisible = true
      // this.activeLineOpt = ''
    },
    showChangeLineNameDialog(line, lineName, lineBlock) {
      this.queryLine = line
      this.currentLineName = lineName
      this.newLineName = ''
    },
    async showChangeLineCPHDialog(line) {
      this.queryLine = line
      this.currentLineCPH = ''
      this.newLineCPH = ''
      const data = {
        type: 'changelinecph',
        key: line
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.currentLineCPH = response.data.ReturnObject[0][0].CPH
      } else {
        this.alertMsg(queryResult)
      }
      this.changeLineCPHDialogVisible = true
    },
    async submitChangeLineCPH() {
      if (this.newLineCPH === '') {
        this.alertMsg(this.$t('dpmBaseSetting.xx'))
        return
      }
      if (this.newDataShift === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgShiftEmpty'))
        return
      }
      const day = this.$utils.GetDateString(this.effDate)
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmBaseSetting.altMsgConfirmChange'), [day, this.newDataShift])
      if (!confirm(msg)) {
        return
      }
      const data = {
        type: 'changelinecph',
        factory: this.queryPlant,
        optKey: this.queryLine,
        oldKey: '',
        oldValue: this.currentLineCPH,
        newKey: '',
        newValue: this.newLineCPH,
        parentKey: this.queryTeam,
        effWorkDay: day,
        effShift: this.newDataShift
      }
      const response = await AddBaseDataChangeRequest(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgModifyCPHSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeChangeLineDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async showChangeLineOpu2Dialog(line) {
      this.queryLine = line
      this.currentLineOpu2 = ''
      this.newLineOpu2 = ''
      const data = {
        type: 'changelineopu2',
        key: line
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.currentLineOpu2 = response.data.ReturnObject[0][0].OPU2
      } else {
        this.alertMsg(queryResult)
      }
      this.changeLineOpu2DialogVisible = true
    },
    async submitChangeLineOpu2() {
      if (this.newLineOpu2 === '') {
        this.alertMsg(this.$t('dpmBaseSetting.xxx'))
        return
      }
      if (this.newDataShift === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgShiftEmpty'))
        return
      }
      const day = this.$utils.GetDateString(this.effDate)
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmBaseSetting.altMsgConfirmChange'), [day, this.newDataShift])
      if (!confirm(msg)) {
        return
      }
      const data = {
        type: 'changelineopu2',
        factory: this.queryPlant,
        optKey: this.queryLine,
        oldKey: '',
        oldValue: this.currentLineOpu2,
        newKey: '',
        newValue: this.newLineOpu2,
        parentKey: this.queryTeam,
        effWorkDay: day,
        effShift: this.newDataShift
      }
      const response = await AddBaseDataChangeRequest(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgModifyOPU2Success'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeChangeLineDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async showChangeTeamOpuDialog(team) {
      this.queryTeam = team
      this.currentTeamOpu = ''
      this.newTeamOpu = ''
      const data = {
        type: 'changeteamopu',
        key: team
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.currentTeamOpu = response.data.ReturnObject[0][0].OPU
      } else {
        this.alertMsg(queryResult)
      }
    },
    async submitChangeTeamOpu() {
      if (this.newTeamOpu === '') {
        this.alertMsg(this.$t('dpmBaseSetting.xxx'))
        return
      }
      if (this.newDataShift === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgShiftEmpty'))
        return
      }
      const day = this.$utils.GetDateString(this.effDate)
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmBaseSetting.altMsgConfirmChange'), [day, this.newDataShift])
      if (!confirm(msg)) {
        return
      }
      const data = {
        type: 'changeteamopu',
        factory: this.queryPlant,
        optKey: this.queryTeam,
        oldKey: '',
        oldValue: this.currentTeamOpu,
        newKey: '',
        newValue: this.newTeamOpu,
        parentKey: this.queryArea,
        effWorkDay: day,
        effShift: this.newDataShift
      }
      const response = await AddBaseDataChangeRequest(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgModifyOPUSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeChangeTeamDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async showChangeTeamOCSDialog(team) {
      this.queryTeam = team
      this.currentTeamOCS = ''
      this.newTeamOCS = ''
      const data = {
        type: 'changeteamocs',
        key: team
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.currentTeamOCS = response.data.ReturnObject[0][0].OCS
      } else {
        this.alertMsg(queryResult)
      }
    },
    async submitChangeTeamOCS() {
      if (this.newTeamOCS === '') {
        this.alertMsg(this.$t('dpmBaseSetting.xxx'))
        return
      }
      if (this.newDataShift === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgShiftEmpty'))
        return
      }
      const day = this.$utils.GetDateString(this.effDate)
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmBaseSetting.altMsgConfirmChange'), [day, this.newDataShift])
      if (!confirm(msg)) {
        return
      }
      const data = {
        type: 'changeteamocs',
        factory: this.queryPlant,
        optKey: this.queryTeam,
        oldKey: '',
        oldValue: this.currentTeamOCS,
        newKey: '',
        newValue: this.newTeamOCS,
        parentKey: this.queryArea,
        effWorkDay: day,
        effShift: this.newDataShift
      }
      const response = await AddBaseDataChangeRequest(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgModifyOCSSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeChangeTeamDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeChangeLineDialog() {
      this.newDataShift = ''
      this.newLineName = ''
      this.currentLineName = ''
      this.moveTeam = ''
      this.moveTeamList = []
      this.newLineType = ''
      this.currentLineType = ''
      this.lineTypeList = []
      this.newBlockName = ''
      this.currentBlockName = ''
      this.newLineCPH = ''
      this.currentLineCPH = ''
      this.newLineOpu2 = ''
      this.currentLineOpu2 = ''
      this.changeLineDialogVisible = false
      this.getChangeList()
    },
    async submitChangeLineName() {
      if (this.newLineName === '') {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgMustKeyinNewLine'))
        return
      }
      if (this.newLineName === this.currentLineName) {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgOldAndNewNameSame'))
        return
      }
      if (this.newDataShift === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgShiftEmpty'))
        return
      }
      const day = this.$utils.GetDateString(this.effDate)
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmBaseSetting.altMsgConfirmChange'), [day, this.newDataShift])
      if (!confirm(msg)) {
        return
      }
      const data = {
        type: 'changelinename',
        factory: this.queryPlant,
        optKey: this.queryLine,
        oldKey: '',
        oldValue: '',
        newKey: '',
        newValue: this.newLineName,
        parentKey: this.queryTeam,
        effWorkDay: day,
        effShift: this.newDataShift
      }
      const response = await AddBaseDataChangeRequest(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgModifyLineSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeChangeLineDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async submitChangeLineGroup() {
      if (this.newBlockName === this.currentBlockName) {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgOldAndNewNameSame'))
        return
      }
      if (this.newDataShift === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgShiftEmpty'))
        return
      }
      const day = this.$utils.GetDateString(this.effDate)
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmBaseSetting.altMsgConfirmChange'), [day, this.newDataShift])
      if (!confirm(msg)) {
        return
      }
      const data = {
        type: 'changelineblockname',
        factory: this.queryPlant,
        optKey: this.queryLine,
        oldKey: '',
        oldValue: '',
        newKey: '',
        newValue: this.newBlockName,
        parentKey: this.queryTeam,
        effWorkDay: day,
        effShift: this.newDataShift
      }
      const response = await AddBaseDataChangeRequest(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgModifyLineGroupSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeChangeLineDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async submitClearLineGroup() {
      if (this.newDataShift === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgShiftEmpty'))
        return
      }
      const day = this.$utils.GetDateString(this.effDate)
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmBaseSetting.altMsgConfirmChange'), [day, this.newDataShift])
      if (!confirm(msg)) {
        return
      }
      const data = {
        type: 'clearlineblockname',
        factory: this.queryPlant,
        optKey: this.queryLine,
        oldKey: '',
        oldValue: this.HiddenLineBlock,
        newKey: '',
        newValue: this.newBlockName,
        parentKey: this.queryTeam,
        effWorkDay: day,
        effShift: this.newDataShift
      }
      const response = await AddBaseDataChangeRequest(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgModifyLineGroupSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeChangeLineDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async showChangeLineCategoryDialog(line) {
      this.queryLine = line
      this.currentLineCategory = ''
      this.newLineCategory = ''
      const data = {
        type: 'changelinecategory',
        key: line
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.currentLineCategory = response.data.ReturnObject[0][0].category
      } else {
        this.alertMsg(queryResult)
      }
    },
    async submitChangeLineCategory() {
      if (this.newLineCategory === '') {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgMustKeyinNewCategory'))
        return
      }
      if (this.newDataShift === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgShiftEmpty'))
        return
      }
      const day = this.$utils.GetDateString(this.effDate)
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmBaseSetting.altMsgConfirmChange'), [day, this.newDataShift])
      if (!confirm(msg)) {
        return
      }
      const data = {
        type: 'changelinecategory',
        factory: this.queryPlant,
        optKey: this.queryLine,
        oldKey: '',
        oldValue: this.currentLineCategory,
        newKey: '',
        newValue: this.newLineCategory,
        parentKey: this.queryTeam,
        effWorkDay: day,
        effShift: this.newDataShift
      }
      const response = await AddBaseDataChangeRequest(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgModifyCategorySuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeChangeLineDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    showChangeTeamDialog(team, teamName) {
      this.HiddenTeamName = teamName
      this.HiddenTeam = team
      this.changeTeamDialogVisible = true
      this.activeTeamOpt = ''
    },
    showChangeTeamNameDialog(team, teamName) {
      this.queryTeam = team
      this.currentTeamName = teamName
      this.newTeamName = ''
    },
    closeChangeTeamDialog() {
      this.newDataShift = ''
      this.newTeamName = ''
      this.currentTeamName = ''
      this.newTeamOpu = ''
      this.currentTeamOpu = ''
      this.newTeamOCS = ''
      this.currentTeamOCS = ''
      this.changeTeamDialogVisible = false
      this.getChangeList()
    },
    async submitChangeTeamName() {
      if (this.newTeamName === '') {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgMustKeyinNewTeam'))
        return
      }
      if (this.newTeamName === this.currentTeamName) {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgOldAndNewNameSame'))
        return
      }
      if (this.newDataShift === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgShiftEmpty'))
        return
      }
      const day = this.$utils.GetDateString(this.effDate)
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmBaseSetting.altMsgConfirmChange'), [day, this.newDataShift])
      if (!confirm(msg)) {
        return
      }
      const data = {
        type: 'changeteamname',
        factory: this.queryPlant,
        optKey: this.queryTeam,
        oldKey: '',
        oldValue: '',
        newKey: '',
        newValue: this.newTeamName,
        parentKey: this.queryArea,
        effWorkDay: day,
        effShift: this.newDataShift
      }
      const response = await AddBaseDataChangeRequest(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgModifyTeamSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeChangeTeamDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    showAddNewTeamDialog(area) {
      this.queryArea = area
      this.newTeamName = ''
      this.addNewTeamDialogVisible = true
    },
    closeAddNewTeamDialog() {
      this.newTeamName = ''
      this.addNewTeamDialogVisible = false
      this.getChangeList()
    },
    async submitNewTeam() {
      if (this.AddTeamform.team === '') {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgMustKeyinNewTeam'))
        return
      }
      if (!confirm(this.$t('dpmBaseSetting.altMsgConfirmAddNewTeam'))) {
        return
      }
      const data = {
        type: 'addteam',
        factory: this.queryPlant,
        parentKey: this.queryArea,
        value: this.AddTeamform.team,
        value2: this.AddTeamform.opu,
        value3: this.AddTeamform.ocs
      }
      const response = await AddNewBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgAddTeamSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeAddNewTeamDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async showAddNewLineDialog(team) {
      this.queryTeam = team
      this.newLineName = ''
      this.newLineType = ''
      this.lineTypeList = []
      const data = {
        type: 'teamalllinetype',
        key: this.queryTeam
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.lineTypeList = response.data.ReturnObject[0]
      } else {
        this.alertMsg(queryResult)
      }
      this.addNewLineDialogVisible = true
    },
    closeAddNewLineDialog() {
      this.newLineName = ''
      this.newLineType = ''
      this.lineTypeList = []
      this.addNewLineDialogVisible = false
      this.getChangeList()
    },
    async submitNewLine() {
      if (this.AddLineform.line === '') {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgMustKeyinNewLine'))
        return
      }
      if (this.AddLineform.line_type === '') {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgChooseNewLineType'))
        return
      }
      if (this.AddLineform.line_category === '') {
        this.alertMsg(this.$t('dpmBaseSetting.altMsgMustKeyinLineType'))
        return
      }
      if (!confirm(this.$t('dpmBaseSetting.altMsgConfirmAddNewLine'))) {
        return
      }
      const data = {
        type: 'addline',
        factory: this.queryPlant,
        parentKey: this.queryTeam,
        value: this.AddLineform.line,
        value2: this.AddLineform.line_type,
        value3: this.AddLineform.block_name,
        value4: this.AddLineform.OPU2,
        value5: this.AddLineform.CPH,
        value6: this.AddLineform.line_category
      }
      const response = await AddNewBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmBaseSetting.altMsgAddLineSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeAddNewLineDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async cancelChange(id) {
      if (!confirm(this.$t('dpmBaseSetting.altMsggConfirmCancel'))) {
        return
      }
      const data = {
        id: id
      }
      const response = await CancelBaseDataChangeListItem(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.getChangeList()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getBaseViewList(Area) {
      if (this.queryPlant === '') {
        return
      }
      const data = {
        type: 'alldata',
        key: Area
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.AllDataList = response.data.ReturnObject[0]
      } else {
        this.alertMsg(queryResult)
      }
      this.ShowDataListDialog = true
    },
    resizeTable: function() {
      this.$nextTick(function() {
        const divHeight = $('#tableChangeDiv').height()
        this.tableHeight = divHeight
      })
    }
  }
}
</script>
<style lang="less" scoped>
.mainDiv{
width:100%;
height:100%;
display: flex;
}
.fieldDiv{
position: relative;
width:255px;
height:700px;
margin-right:5px;
border:1px solid rgb(1,173,187);
overflow: auto;
background-color: white;
}
.AreaDiv{
position: relative;
width:180px;
height:700px;
margin-right:5px;
border:1px solid rgb(1,173,187);
overflow: auto;
background-color: white;
}
.fieldTitleDiv{
width:100%;
font-size: 16px;
color:white;
height:25px;
line-height: 25px;
text-align: center;
background-color:rgb(1,173,187);
}
li {
list-style-type: none;
}
.liDataSpan{
font-size:14px;
color: rgb(23,102,173);
padding-left:0px;
}
.optIcon{
// right:20px;
position:absolute;
padding-top:5px;
cursor: pointer;
}
.icon3{
right:50px;
}
.icon2{
right:30px;
}
.icon1{
right:10px;
}
.icon4{
right:70px;
}
.icon5{
right:90px;
}
.icon6{
right:110px;
}
.alldata_div{
  height: 500px;
  overflow: auto;
}
</style>
