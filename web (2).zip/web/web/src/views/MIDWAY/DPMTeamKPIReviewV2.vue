<template>
  <div style="height:100%;width:100%;">
    <el-container style="height:100%;">
      <el-header class="header">
        <el-button v-show="showTypeBtnMsg==='YOY' || showTypeBtnMsg===$t('dpmTeamKPIReview.lblSummaryTable')" type="primary" round style="margin-right:20px;" size="small" @click="changePage">{{ showTypeBtnMsg }}</el-button>
        <div v-show="showTypeBtnMsg==='YOY'" style="display:inline">
          <el-select v-model="queryFactory" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectFactory')" @change="getQueryAreaList">
            <el-option
              v-for="item in factoryList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-select v-model="queryArea" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectArea')" @change="getQueryTeamList">
            <el-option
              v-for="item in areaList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-select v-model="queryTeam" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectTeam')" multiple collapse-tags style="width:230px;margin:0 5px">
            <el-option
              v-for="item in teamList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <span class="topLineSpan">{{ $t('dpmTeamKPIReview.lblTimeGranularity') }}>></span>
          <el-button :type="queryType==='year'?'success':'warning'" size="small" @click="queryData('year')">{{ $t('dpmSummaryOfissues.btnByYear') }}</el-button><!--dpmTeamKPIReview.btnByYearQuarter-->
          <el-button :type="queryType==='month'?'success':'warning'" size="small" @click="queryData('month')">{{ $t('dpmTeamKPIReview.btnByMonth') }}</el-button>
          <el-button :type="queryType==='week'?'success':'warning'" size="small" @click="queryData('week')">{{ $t('dpmTeamKPIReview.btnByWeek') }}</el-button>
          <el-button :type="queryType==='day'?'success':'warning'" size="small" @click="queryData('day')">{{ $t('dpmTeamKPIReview.btnByDay') }}</el-button>
        </div>
        <div v-show="showTypeBtnMsg==='HISTORY'" style="display:inline">
          <el-button v-show="showTypeBtnMsg==='HISTORY'" type="primary" round style="margin-right:20px;" size="small" @click="closeHistory">{{ $t('common.btnReturn') }}</el-button>
          <span class="topLineSpan">{{ $t('dpmTeamKPIReview.lblKPIHis') }}</span>
          <el-select v-model="queryFactoryHistory" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectFactory')" @change="getQueryAreaListHistory">
            <el-option
              v-for="item in factoryListHistory"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-select v-model="queryAreaHistory" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectArea')" @change="getQueryTeamListHistory">
            <el-option
              v-for="item in areaListHistory"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-select v-model="queryTeamHistory" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectTeam')" multiple collapse-tags style="width:230px;margin:0 5px">
            <el-option
              v-for="item in teamListHistory"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-date-picker v-model="queryMonth" size="small" style="width:120px;margin-right:5px" type="month" :placeholder="$t('dpmTeamKPIReview.phdMonth')" />
          <el-select v-model="queryShift" :placeholder="$t('common.phdShift')" style="width:100px;margin-right:5px" size="small">
            <el-option
              v-for="item in workshiftList"
              :key="item.shift_code"
              :label="item.shift_name"
              :value="item.shift_code"
            />
          </el-select>
          <el-select v-model="queryKpi" size="small" class="selectMidSize" placeholder="KPI">
            <el-option
              v-for="item in kpiList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-button type="primary" size="small" @click="queryKPIData">{{ $t('common.btnQuery') }}</el-button>
          <el-button type="primary" size="small" @click="downloadData()">{{ $t('common.btnDownload') }}</el-button>
        </div>
      </el-header>
      <el-main style="padding:0;">
        <div v-show="showTypeBtnMsg==='YOY'" style="height:100%;width: auto;">
          <div class="mainTopDiv">
            <div class="mainLeftDiv">
              <el-table
                v-loading="loading"
                :data="tableData"
                size="small"
                stripe
                :header-cell-style="getHeaderCellColor"
                :cell-style="getCellColor"
                style="width: 100%;border-style: none;"
              >
                <el-table-column
                  v-for="(o, index) in colSetting"
                  :key="index"
                  :prop="o.prop"
                  :label="o.label"
                  :width="o.width"
                  align="center"
                >
                  <template slot-scope="scope">
                    <el-link v-if="o.prop==='kpi' && scope.row[o.prop].split('(')[0]!=='RTY' && scope.row[o.prop].split('(')[0]!=='ONLINE UPPH'" :underline="false" @click="showIndexDialog(scope.row[o.prop].split('(')[0])"><span class="defTableCell">{{ scope.row[o.prop] }}</span></el-link>
                    <span v-else><span class="defTableCell" :style="getColumnColor(scope.row,o.prop)">{{ scope.row[o.prop] }}</span></span>
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div class="mainRightDiv">
              <div id="radarChart" class="radarChartDiv" />
              <div class="radarButton">
                <el-button-group>
                  <el-button v-show="isHidden" type="primary" icon="el-icon-caret-left" @click="perDate" />
                  <el-button v-show="isHidden" type="primary" style="margin-right:10px;float: left" icon="el-icon-caret-right el-icon--right" @click="nextDate" />
                </el-button-group>
                <!-- <span>{{ selectDate }}</span> -->
              </div>
            </div>
          </div>
          <div class="mainBottomDiv">
            <span class="chartHeadSpan">KPI>></span>
            <el-button v-for="(o, index) in kpiChartList" :key="index" :type="mainChartKPI===o?'success':'warning'" size="small" @click="setChart(o)">{{ o }}</el-button>
            <div id="elChart" class="chartDiv" />
          </div>
        </div>
        <div v-show="showTypeBtnMsg===$t('dpmTeamKPIReview.lblSummaryTable')" style="height:100%">
          <div class="YOYMainDiv">
            <div class="YOYLeftDiv">
              <el-form label-width="90px" :model="formYOY" size="small" style="padding-top:20px">
                <el-form-item :label="$t('common.colFactory')">
                  <el-select v-model="formYOY.factory" size="small" multiple collapse-tags :placeholder="$t('common.phdRequire')" style="width:240px" @change="getYOYAreaList">
                    <el-option
                      v-for="item in yoyFactoryList"
                      :key="item.key"
                      :label="item.data"
                      :value="item.key"
                    />
                  </el-select>
                </el-form-item>
                <el-form-item :label="$t('common.colArea')">
                  <el-select v-model="formYOY.area" size="small" multiple collapse-tags :placeholder="$t('common.phdOption')" style="width:240px" @change="getYOYTeamList">
                    <el-option-group
                      v-for="group in yoyAreaList"
                      :key="group.label"
                      :label="group.label"
                    >
                      <el-option
                        v-for="item in group.options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      />
                    </el-option-group>
                  </el-select>
                </el-form-item>
                <el-form-item label="Team">
                  <el-select v-model="formYOY.team" size="small" multiple collapse-tags :placeholder="$t('common.phdOption')" style="width:240px" @change="getYOYLineList">
                    <el-option-group
                      v-for="group in yoyTeamList"
                      :key="group.label"
                      :label="group.label"
                    >
                      <el-option
                        v-for="item in group.options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      />
                    </el-option-group>
                  </el-select>
                </el-form-item>
                <el-form-item :label="$t('common.colLine')">
                  <el-select v-model="formYOY.line" size="small" multiple collapse-tags :placeholder="$t('common.phdOption')" style="width:240px">
                    <el-option-group
                      v-for="group in yoyLineList"
                      :key="group.label"
                      :label="group.label"
                    >
                      <el-option
                        v-for="item in group.options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      />
                    </el-option-group>
                  </el-select>
                </el-form-item>
                <el-form-item label="KPI">
                  <el-select v-model="yoyKPI" size="small" class="selectMidSize" placeholder="KPI" style="width:240px">
                    <el-option
                      v-for="(item,index) in yoyKPIList"
                      :key="index"
                      :label="item"
                      :value="item"
                    />
                  </el-select>
                </el-form-item>
                <el-form-item :label="$t('dpmTeamKPIReview.lblPointQty')">
                  <el-select v-model="formYOY.qty" size="small" :placeholder="$t('dpmTeamKPIReview.phdPointQty')" style="width:240px">
                    <el-option label="2" value="2" />
                    <el-option label="3" value="3" />
                    <el-option label="4" value="4" />
                    <el-option label="5" value="5" />
                    <el-option label="6" value="6" />
                    <el-option label="7" value="7" />
                    <el-option label="8" value="7" />
                    <el-option label="9" value="9" />
                    <el-option label="10" value="10" />
                  </el-select>
                </el-form-item>
              </el-form>
              <el-button type="primary" size="small" style="margin-left:20px;width:calc(100% - 45px)" @click="queryYOYData">{{ $t('common.btnQuery') }}</el-button>
              <br>
              <br>
              <span style="display:inline-block;font-weight:blod;padding-left:20px;padding-right:10px">{{ $t('dpmTeamKPIReview.lblShowType') }}：</span>
              <el-radio-group v-model="showTypeRadio" @change="setShowData">
                <el-radio :label="1">{{ $t('dpmTeamKPIReview.lblByNum') }}</el-radio>
                <el-radio :label="2">{{ $t('dpmTeamKPIReview.lblByRate') }}</el-radio>
              </el-radio-group>
            </div>
            <div class="YOYRightDiv">
              <div class="YOYContentDiv">
                <div id="yoyTable" class="YOYContentTable">
                  <el-table
                    v-loading="loading"
                    :data="tableYOYYear"
                    size="small"
                    stripe
                    :height="yoyTableHeight"
                    :header-cell-style="getHeaderCellColor"
                    style="width: 100%;"
                  >
                    <el-table-column
                      v-for="(o, index) in colYOYYearSetting"
                      :key="index"
                      :prop="o.prop"
                      :label="o.label"
                      :width="o.width"
                      align="center"
                    />
                  </el-table>
                </div>
                <div id="elYOYChartYear" class="YOYChart" />
              </div>
              <div class="YOYContentDiv">
                <div class="YOYContentTable">
                  <el-table
                    v-loading="loading"
                    :data="tableYOYQuarter"
                    size="small"
                    stripe
                    :height="yoyTableHeight"
                    :header-cell-style="getHeaderCellColor"
                    style="width: 100%;"
                  >
                    <el-table-column
                      v-for="(o, index) in colYOYQuarterSetting"
                      :key="index"
                      :prop="o.prop"
                      :label="o.label"
                      :width="o.width"
                      align="center"
                    />
                  </el-table>
                </div>
                <div id="elYOYChartQuarter" class="YOYChart" />
              </div>
              <div class="YOYContentDiv">
                <div class="YOYContentTable">
                  <el-table
                    v-loading="loading"
                    :data="tableYOYMonth"
                    size="small"
                    stripe
                    :height="yoyTableHeight"
                    :header-cell-style="getHeaderCellColor"
                    style="width: 100%;"
                  >
                    <el-table-column
                      v-for="(o, index) in colYOYMonthSetting"
                      :key="index"
                      :prop="o.prop"
                      :label="o.label"
                      :width="o.width"
                      align="center"
                    />
                  </el-table>
                </div>
                <div id="elYOYChartMonth" class="YOYChart" />
              </div>
            </div>
          </div>
        </div>
        <div v-show="showTypeBtnMsg==='HISTORY'" style="height:100%;">
          <div id="elChartKPI" class="chartKPIDiv" />
          <div id="tableDetailContainer" class="detailDiv">
            <el-table
              ref="tbMainTableData"
              :data="mainTableData"
              style="width: 100%;"
              row-key="KPI"
              :height="170"
              size="mini"
              :header-cell-style="getHeaderCellColor"
            >
              <el-table-column
                prop="KPI"
                label="KPI"
                width="150"
                style="text-align: center;"
                fixed
              />
              <el-table-column
                prop="MTD"
                label="MTD"
                width="100"
                style="text-align: center;"
                fixed
              />

              <el-table-column
                v-for="(value, key) in tableColumns[0]"
                :key="key"
                :prop="key"
                :label="value"
                width="90"
                style="text-align: center;"
              />
            </el-table>
          </div>
          <div id="tableLinelContainer" class="lineDiv">
            <el-table
              ref="dataTreeList"
              class="el-table__body-wrapper"
              :data="tableHistoryData"
              style="width: 100%;"
              row-key="id"
              size="mini"
              :height="tableHistoryHeight"
              :header-cell-style="getHeaderCellColor"
              :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
              onload
              @sort-change="handleSortChange"
            >
              <el-table-column
                prop="PDLINE_NAME"
                label="綫體%"
                width="150"
                style="text-align: left;"
                :render-header="renderHeader"
                sortable
                fixed
              />
              <el-table-column
                prop="MTD"
                label="MTD"
                width="100"
                style="text-align: right;"
                sortable
                fixed
              />
              <el-table-column
                v-for="(value, index) in tableColumns[0]"
                :key="index"
                :prop="index"
                :label="value"
                width="90"
                sortable="custom"
                style="text-align: center;"
              />
            </el-table>
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import $ from 'jquery'
import { downloadDPMTeamKPIHistoryDataV2_API } from '@/api/upload_download'
import {
  GetDPMQueryKeyValue, GetDPMTeamKPIReviewMainData, GetWorkshiftList, GetDPMTeamKPIHistoryDataV2, GetDPMTeamKPIReviewYOYData
} from '@/api/midway.js'
export default {
  components: {
  },
  data() {
    return {
      showTypeBtnMsg: 'YOY',
      queryDay: '',
      queryFactory: '',
      factoryList: [],
      queryArea: '',
      areaList: [],
      queryTeam: '',
      teamList: [],
      tableHeight: 1,
      loadingData: null,
      loading: false,
      chart: null,
      radChart: null,
      queryType: '',
      mainChartKPI: '',
      colSetting: [],
      tableData: [],
      kpiRateData: [],
      mainObject: null,
      formYOY: {
        factory: [],
        area: [],
        team: [],
        line: [],
        qty: 2
      },
      yoyTableHeight: 1,
      yoyFactory: [],
      yoyArea: [],
      yoyLine: [],
      yoyFactoryList: [],
      yoyAreaList: [],
      yoyTeamList: [],
      yoyLineList: [],
      yoyKPI: 'Output',
      yoyKPIList: [], // YOYKPI list
      chartYOYYear: null,
      chartYOYQuarter: null,
      chartYOYMonth: null,
      tableYOYYear: [],
      colYOYYearSetting: [],
      tableYOYQuarter: [],
      colYOYQuarterSetting: [],
      tableYOYMonth: [],
      colYOYMonthSetting: [],
      yoyObjectData: null,
      showTypeRadio: 1,
      indexDialogTitle: '',
      indexDialogVisible: false,
      factoryListHistory: [],
      areaListHistory: [],
      teamListHistory: [],
      queryFactoryHistory: '',
      queryAreaHistory: '',
      queryTeamHistory: '',
      queryMonth: '',
      queryShift: 'ALL',
      workshiftList: [],
      queryKpi: '',
      kpiList: [],
      kpiChartList: [],
      kpiChartData: [],
      mainTableData: [],
      tableColumns: [],
      tableHistoryData: [],
      tableHistoryHeight: 500,
      selectDate: '',
      isHidden: false,
      isHistoryDataExpansion: false
    }
  },
  computed: {
  },
  mounted() {
    this.resizeTable()
    this.getDefaultDate()
    this.getQueryFactoryList()
    // this.initialData()
    window.onresize = () => {
      this.resizeTable()
      if (this.chart !== null) {
        this.chart.resize()
      }
      if (this.radChart !== null) {
        this.radChart.resize()
      }
    }
  },
  beforeDestroy() {
  },
  methods: {
    getDefaultDate() {
      const curDate = new Date()
      this.queryDay = new Date(curDate.getTime() - 24 * 60 * 60 * 1000)
      this.queryMonth = new Date(curDate.getTime() - 24 * 60 * 60 * 1000)
    },
    changePage() {
      if (this.showTypeBtnMsg === 'YOY') {
        this.showTypeBtnMsg = this.$t('dpmTeamKPIReview.lblSummaryTable')
        this.$nextTick(function() {
        })
      } else {
        this.showTypeBtnMsg = 'YOY'
      }
      this.resizeTable()
    },
    closeHistory() {
      this.showTypeBtnMsg = 'YOY'
      this.resizeTable()
    },
    async getWorkDayWorkshift() {
      this.workshiftList = []
      const data = {
        factory: this.factoryList.filter(x => x.key === this.queryFactory)[0].data,
        hasALL: 'Y'
      }
      const response = await GetWorkshiftList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.workshiftList = response.data.ReturnObject
      } else {
        this.alertMsg(
          this.$utils.ReplacePlaceHolder(
            this.$t('dpmDashboardLineDetail.altMsgCannotGetShift'),
            [queryResult]
          )
        )
      }
    },
    async getQueryFactoryList() {
      this.destroyChart()
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.factoryList = []
      // this.yoyFactoryList = []
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.factoryList = response.data.ReturnObject
        this.yoyFactoryList = response.data.ReturnObject
        this.factoryListHistory = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryAreaList() {
      this.getWorkDayWorkshift()
      this.destroyChart()
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.kpiList = [] // 20230111 Kimi Factory选择时，清空kpi下拉框
      this.queryTeam = ''
      const data = {
        type: 'userarea',
        key: this.queryFactory
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryTeamList() {
      this.destroyChart()
      this.teamList = []
      this.kpiList = [] // 20230111 Kimi Factory选择时，清空kpi下拉框
      this.queryTeam = ''
      const data = {
        type: 'userteam',
        key: this.queryArea
      }
      this.teamList.push({
        key: 0,
        data: 'ALL'
      })
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        for (let i = 0; i < obj.length; i++) {
          this.teamList.push({
            key: obj[i].key,
            data: obj[i].data
          })
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getYOYAreaList() {
      if (this.formYOY.factory.length === 0) {
        this.alertMsg(this.$t('dpmTeamKPIReview.altMsgFactoryEmpty'))
        return
      }
      this.yoyAreaList = []
      this.yoyTeamList = []
      this.yoyLineList = []
      this.formYOY.area = []
      this.formYOY.team = []
      this.formYOY.line = []
      // 区域一共有哪些
      const yoyArea = []

      for (let i = 0; i < this.formYOY.factory.length; i++) {
        const factoryName = this.yoyFactoryList.filter(x => x.key === this.formYOY.factory[i])[0].data
        const data = {
          type: 'userarea',
          key: this.formYOY.factory[i]
        }
        const response = await GetDPMQueryKeyValue(data)
        const queryResult = response.data.QueryResult
        const options = []
        if (queryResult === 'OK') {
          response.data.ReturnObject.forEach(x => {
            if (yoyArea.indexOf(x.data) < 0) {
              yoyArea.push(x.data)
            }
            options.push({
              value: x.key,
              label: x.data
            })
          })
        } else {
          this.alertMsg(queryResult)
          return
        }
        this.yoyAreaList.push({
          label: factoryName,
          options: options
        })
      }
      this.getYOYKpiList(yoyArea)
    },

    async getYOYKpiList(yoyArea) {
      // 判断选择的厂别有几个area
      let area = ''
      if (yoyArea.length <= 0) {
        area = ''
      } else if (yoyArea.length > 0 && yoyArea.indexOf('FATP') >= 0 && yoyArea.indexOf('PCBA') >= 0) {
        area = ''
      } else if (yoyArea.length > 0 && yoyArea.indexOf('FATP') >= 0 && yoyArea.indexOf('PCBA') < 0) {
        area = 'FATP'
      } else if (yoyArea.length > 0 && yoyArea.indexOf('FATP') < 0 && yoyArea.indexOf('PCBA') >= 0) {
        area = 'PCBA'
      }
      let kpiList = []
      this.yoyKPIList = []
      // this.yoyKPI=''
      for (let i = 0; i < this.formYOY.factory.length; i++) {
        let key = this.formYOY.factory[i]
        if (area.length > 0) {
          key = this.formYOY.factory[i] + ',' + area
        }
        const data = {
          type: 'dpmkpi',
          key: key
        }
        const response = await GetDPMQueryKeyValue(data)
        const queryResult = response.data.QueryResult
        if (queryResult === 'OK') {
          kpiList = response.data.ReturnObject
          kpiList.forEach(p => {
            if (this.yoyKPIList.indexOf(p.key) < 0) {
              this.yoyKPIList.push(p.key)
            }
          })
        } else {
          this.alertMsg(queryResult)
        }
      }
    },

    async getYOYTeamList() {
      //  区域一共有哪些
      const yoyArea = []
      if (this.formYOY.area.length === 0) {
        this.alertMsg(this.$t('dpmTeamKPIReview.altMsgAreaEmpty'))
        return
      }
      this.yoyTeamList = []
      this.yoyLineList = []
      this.formYOY.team = []
      this.formYOY.line = []

      for (let i = 0; i < this.formYOY.area.length; i++) {
        const areaId = this.formYOY.area[i]
        let factoryName = ''
        let areaName = ''
        for (let j = 0; j < this.yoyAreaList.length; j++) {
          factoryName = this.yoyAreaList[j].label
          const obj = this.yoyAreaList[j].options
          for (let k = 0; k < obj.length; k++) {
            if (obj[k].value === areaId) {
              areaName = obj[k].label
              const data = {
                type: 'userteam',
                key: areaId
              }
              const response = await GetDPMQueryKeyValue(data)
              const queryResult = response.data.QueryResult
              const options = []
              if (queryResult === 'OK') {
                response.data.ReturnObject.forEach(x => {
                  options.push({
                    value: x.key,
                    label: x.data
                  })
                })
              } else {
                this.alertMsg(queryResult)
                return
              }
              if (yoyArea.indexOf(areaName) < 0) {
                yoyArea.push(areaName)
              }
              this.yoyTeamList.push({
                label: factoryName + ' ' + areaName,
                options: options
              })
              break
            }
          }
        }
      }
      this.getYOYKpiList(yoyArea)
    },
    async getYOYLineList() {
      if (this.formYOY.team.length === 0) {
        this.alertMsg(this.$t('dpmTeamKPIReview.altMsgTeamEmpty'))
        return
      }
      this.yoyLineList = []
      this.formYOY.line = []

      for (let i = 0; i < this.formYOY.team.length; i++) {
        const teamId = this.formYOY.team[i]
        let factoryAndAreaName = ''
        let teamName = ''
        for (let j = 0; j < this.yoyTeamList.length; j++) {
          factoryAndAreaName = this.yoyTeamList[j].label
          const obj = this.yoyTeamList[j].options
          for (let k = 0; k < obj.length; k++) {
            if (obj[k].value === teamId) {
              teamName = obj[k].label
              const data = {
                type: 'userline',
                key: teamId
              }
              const response = await GetDPMQueryKeyValue(data)
              const queryResult = response.data.QueryResult
              const options = []
              if (queryResult === 'OK') {
                response.data.ReturnObject.forEach(x => {
                  options.push({
                    value: x.key,
                    label: x.data
                  })
                })
              } else {
                this.alertMsg(queryResult)
                return
              }
              this.yoyLineList.push({
                label: factoryAndAreaName + ' ' + teamName,
                options: options
              })
              break
            }
          }
        }
      }
    },
    async getYOYList() {
      if (this.formYOY.factory.length === 0) {
        this.alertMsg(this.$t('dpmTeamKPIReview.altMsgFactoryEmpty'))
        return
      }
      this.yoyAreaList = []
      this.yoyLineList = []
      this.formYOY.area = []
      this.formYOY.line = []

      for (let i = 0; i < this.formYOY.factory.length; i++) {
        const factoryName = this.yoyFactoryList.filter(x => x.key === this.formYOY.factory[i])[0].data
        const data = {
          type: 'userarea',
          key: this.formYOY.factory[i]
        }
        const response = await GetDPMQueryKeyValue(data)
        const queryResult = response.data.QueryResult
        const options = []
        if (queryResult === 'OK') {
          response.data.ReturnObject.forEach(x => {
            options.push({
              value: x.key,
              label: x.data
            })
          })
        } else {
          this.alertMsg(queryResult)
          return
        }
        this.yoyAreaList.push({
          label: factoryName,
          options: options
        })
      }
    },
    async getQueryAreaListHistory() {
      this.getKpiList()
      this.areaListHistory = []
      this.queryAreaHistory = ''
      this.teamListHistory = []
      this.queryTeamHistory = ''
      const data = {
        type: 'userarea',
        key: this.queryFactoryHistory
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaListHistory = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryTeamListHistory() {
      this.getKpiList()
      this.teamListHistory = []
      this.queryTeamHistory = ''
      const data = {
        type: 'userteam',
        key: this.queryAreaHistory
      }
      this.teamListHistory.push({
        key: 0,
        data: 'ALL'
      })
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        for (let i = 0; i < obj.length; i++) {
          this.teamListHistory.push({
            key: obj[i].key,
            data: obj[i].data
          })
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getKpiList() {
      this.kpiList = []
      let area
      if (this.showTypeBtnMsg === 'HISTORY') {
        area = this.areaListHistory.filter(x => x.key === this.queryAreaHistory)[0].data
      } else {
        area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      }
      // try {
      // area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      // } catch {
      // area = this.areaListHistory.filter(x => x.key === this.queryAreaHistory)[0].data
      // }
      this.queryKpi = ''
      const data = {
        type: 'dpmkpi',
        key: this.queryFactoryHistory + ',' + area
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.kpiList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    getHeaderCellColor() {
      const style = {
        'background-color': 'rgb(32,55,100)',
        color: 'white'
      }
      return style
    },
    getCellColor({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        return 'color: black; background: rgb(221, 235, 247);'
      } else {
        return 'color: black'
      }
    },
    getColumnColor(row, prop) {
      // eff,oee2,rty 直接对比达成率，其它需要除以目标值再进行goal值对比
      const kpiGoal = this.mainObject.kpiGoalTable.filter(p => p.kpi === row.kpi)[0][prop]
      const kpiRate = this.kpiRateData.filter(p => p.kpi === row.kpi)[0]['goal']
      const actvalue = row[prop]
      if (row.kpi.split('(')[0] === 'Efficiency' || row.kpi.split('(')[0] === 'RTY' || row.kpi.split('(')[0] === 'OEE2' || row.kpi.split('(')[0] === 'OEE1') {
        if (kpiRate > actvalue) {
          return 'color: red'
        } else if (kpiRate * 1.2 < actvalue) {
          return 'color: blue'
        } else {
          return 'color: black'
        }
      } else {
        if (kpiRate > actvalue / kpiGoal * 100) {
          return 'color: red'
        } else if (kpiRate * 1.2 < actvalue / kpiGoal * 100) {
          return 'color: blue'
        } else {
          return 'color: black'
        }
      }
    },
    async queryData(type) {
      this.queryType = type
      if (this.queryFactory === '') {
        this.alertMsg(this.$t('dpmTeamKPIReview.altMsgFactoryEmpty'))
        return
      }
      if (this.queryArea === '') {
        this.alertMsg(this.$t('dpmTeamKPIReview.altMsgAreaEmpty'))
        return
      }
      if (this.queryTeam === '') {
        this.queryTeam = 0
      }
      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      let team = ''
      this.queryTeam.forEach(p => {
        team = team + this.teamList.filter(x => x.key === p)[0].data + ','
      })
      team = team.substring(0, team.length - 1)
      const data = {
        factory: factory,
        area: area,
        team: team, // team,
        range: this.queryType
      }
      this.loading = true
      const response = await GetDPMTeamKPIReviewMainData(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.mainObject = response.data.ReturnObject
        this.colSetting = this.mainObject.columns
        this.tableData = this.mainObject.kpiActTable
        // add by liwen at 20240206 增加KPI GOAL值，拿来对比对列数字的赋值颜色
        this.kpiRateData = this.mainObject.kpiRate
        // start add by liwen at 20240123 指标写成取数据库数据返回的查询KPI不在代码中写死，方便后期KPI增加或者删除
        this.kpiChartList = []
        this.tableData.forEach(item => {
          this.kpiChartList.push(item.kpi)
        })
        // 初始化开始日期
        if (this.colSetting.length > 2) {
          this.selectDate = this.colSetting[this.colSetting.length - 1].label
        }
        // 根据日期显示雷达图
        this.setRadarChart(this.selectDate)
        // 显示雷达图下面的两个按钮
        this.isHidden = true
      } else {
        this.alertMsg(queryResult)
      }
      this.$nextTick(() => {
        this.$refs.dataTreeList.doLayout()
        // this.actreport_1ke.y = ''
      })
    },
    renderHeader(h, { column }) {
      let iconType = 'el-icon-arrow-right'
      if (this.isHistoryDataExpansion) {
        iconType = 'el-icon-arrow-down'
      } else {
        iconType = 'el-icon-arrow-right'
      }
      return h('span', [
        column.label,
        h('i', {
          class: iconType,
          style: 'margin-left: 5px; cursor: pointer;',
          on: {
            click: this.handleHeaderClick
          }
        })
      ])
    },
    handleHeaderClick() {
      // 如果当前是false，点击事件就是展开子节点，如果是true，点击事件就是关闭子节点
      if (this.isHistoryDataExpansion) {
        this.isHistoryDataExpansion = false
      } else {
        this.isHistoryDataExpansion = true
      }
      this.toggleRowExpansion(this.isHistoryDataExpansion)
    },
    toggleRowExpansion(isExpansion) {
      this.toggleRowExpansion_forAll(this.tableHistoryData, isExpansion)
    },
    toggleRowExpansion_forAll(dataTable, isExpansion) {
      dataTable.forEach(item => {
        this.$refs.dataTreeList.toggleRowExpansion(item, isExpansion)
        if (item.children !== undefined && item.children != null) {
          this.toggleRowExpansion_forAll(item.children, isExpansion)
        }
      })
    },
    destroyChart() {
      if (this.chart !== null && this.chart !== '' && this.chart !== undefined) {
        this.chart.dispose()
      }
      if (this.radChart !== null && this.radChart !== '' && this.radChart !== undefined) {
        this.radChart.dispose()
      }
    },
    destroyYOYChart(type) {
      if (type === 'year') {
        if (this.chartYOYYear !== null && this.chartYOYYear !== '' && this.chartYOYYear !== undefined) {
          this.chartYOYYear.dispose()
        }
      } else if (type === 'quarter') {
        if (this.chartYOYQuarter !== null && this.chartYOYQuarter !== '' && this.chartYOYQuarter !== undefined) {
          this.chartYOYQuarter.dispose()
        }
      } else if (type === 'month') {
        if (this.chartYOYMonth !== null && this.chartYOYMonth !== '' && this.chartYOYMonth !== undefined) {
          this.chartYOYMonth.dispose()
        }
      }
    },
    setChart(kpi) {
      this.mainChartKPI = kpi
      this.destoryChart(this.chart)
      // this.destroyChart()
      if (this.mainObject === null) {
        return
      }
      const dataXAxis = []
      const dataAct = []
      const dataGoal = []
      const objAct = this.mainObject.kpiActTable.filter(x => x.kpi === kpi)
      const objGoal = this.mainObject.kpiGoalTable.filter(x => x.kpi === kpi)
      if (objAct.length > 0 && objGoal.length > 0) {
        this.colSetting.forEach(x => {
          const prop = x.prop
          if (prop !== 'kpi') {
            dataXAxis.push(x.label)
            dataAct.push(objAct[0][prop])
            dataGoal.push(objGoal[0][prop])
          }
        })
      }
      const option = {
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: [kpi, 'Goal']
        },
        xAxis: {
          type: 'category',
          data: dataXAxis
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: kpi,
            data: dataAct,
            type: 'line'
          },
          {
            name: 'Goal',
            data: dataGoal,
            type: 'line'
          }
        ]
      }
      const chartDom = document.getElementById('elChart')
      this.chart = this.$echarts.init(chartDom)
      this.chart.clear()
      this.chart.setOption(option)
    },
    // 雷达图
    setRadarChart(selectDate) {
      this.destoryChart(this.radChart)
      if (this.mainObject === null) {
        return
      }
      const indicatorKPI = []
      const dataActRate = []
      const dataGoalRate = []
      // 通过selectdate找到日期对应的列
      const dateIndex = this.colSetting.findIndex(p => p.label === this.selectDate)
      const datecol = this.colSetting[dateIndex].prop
      let i = 0// 给第一个KPI刻度
      this.kpiRateData.forEach(x => {
        const kpi = x.kpi
        // 实际值
        const objActValue = this.mainObject.kpiActTable.filter(p => p.kpi === kpi)[0][datecol]
        // 目标值
        const objGoalValue = this.mainObject.kpiGoalTable.filter(p => p.kpi === kpi)[0][datecol]
        // Efficiency,OEE2,RTY,OEE1不需要算rate，其它都需要算
        let actRate = objActValue
        if (objActValue === '' || objActValue === '0' || objActValue === '0.00') {
          actRate = 0
        } else if (objGoalValue === '' || objGoalValue === '0' || objGoalValue === '0.00') {
          if ((kpi.split('(')[0] !== 'Efficiency' && kpi.split('(')[0] !== 'OEE2' && kpi.split('(')[0] !== 'OEE1' && kpi.split('(')[0] !== 'RTY')) {
            actRate = 0
          }
        } else if (kpi.split('(')[0] !== 'Efficiency' && kpi.split('(')[0] !== 'OEE2' && kpi.split('(')[0] !== 'OEE1' && kpi.split('(')[0] !== 'RTY') {
          actRate = parseFloat(objActValue / objGoalValue * 100).toFixed(2)
        }
        dataActRate.push(actRate)
        dataGoalRate.push(x.goal)
        if (i === 0) {
          indicatorKPI.push({ name: kpi, max: 150, axisLabel: { show: true, formatter: function(value) { return value + '%' }, inside: true, fontSize: 10 }})
        } else {
          indicatorKPI.push({ name: kpi, max: 150, axisLabel: { show: false }})
        }
        i = i + 1
      })
      const option = {
        title: {
          text: this.selectDate
        },
        tooltip: {
          trigger: 'axis'
          // axisPointer:{
          //   type:'shadow'
          // },
          // show : true,
          // showContent: true,
          // backgroundColor:'#fff',
          // textStyle:{
          //   color: "#333333",
          //   fontSize:12
          // }
        },
        toolbox: {
          show: true,
          feature: {
            mark: { show: true },
            dataView: { show: true, readOnly: false },
            restore: { show: true },
            saveAsImage: { show: true }
          }
        },
        legend: {
          orient: 'horizontal',
          x: 'right',
          y: 'bottom',
          data: ['Actual', 'Goal']
        },
        radar: {
          axisName: {
            color: '#428BD4'
          },
          splitNumber: 6,
          indicator: indicatorKPI
        },
        series: [
          {
            name: 'Actual vs Goal',
            type: 'radar',
            tooltip: {
              trigger: 'item'
            },
            data: [
              {
                value: dataActRate,
                name: 'Actual'
              },
              {
                value: dataGoalRate,
                name: 'Goal'
              }
            ]
          }
        ]
      }
      const chartDom = document.getElementById('radarChart')
      this.radChart = this.$echarts.init(chartDom)
      this.radChart.clear()
      this.radChart.setOption(option)
    },
    perDate() {
      // 找到日期对应的所有日期的索引
      const dateIndex = this.colSetting.findIndex(p => p.label === this.selectDate)
      if (dateIndex > 1) {
        this.selectDate = this.colSetting[dateIndex - 1].label
      }
      this.setRadarChart(this.selectDate)
    },
    nextDate() {
      // 找到日期对应的所有日期的索引
      const dateIndex = this.colSetting.findIndex(p => p.label === this.selectDate)
      if (dateIndex < this.colSetting.length - 1) {
        this.selectDate = this.colSetting[dateIndex + 1].label
      }
      this.setRadarChart(this.selectDate)
    },
    setYOYKPI(kpi) {
      this.yoyKPI = kpi
    },
    async queryYOYData() {
      if (this.yoyKPI === '') {
        this.alertMsg(this.$t('dpmTeamKPIReview.altMsgKPIEmpty'))
        return
      }
      // if (this.yoyKPI === 'OEE2') {
      //   this.alertMsg(this.$t('dpmTeamKPIReview.altMsgOEE2Diabled'))
      //   return
      // }
      let factoryList = ''
      let areaList = ''
      let teamList = ''
      let lineList = ''
      this.formYOY.factory.forEach(x => {
        factoryList = factoryList + x + ','
      })
      if (factoryList.length > 0) {
        factoryList = factoryList.substr(0, factoryList.length - 1)
      }
      if (factoryList === '') {
        this.alertMsg(this.$t('dpmTeamKPIReview.altMsgAtleastSelectFactory'))
        return
      }
      this.formYOY.area.forEach(x => {
        areaList = areaList + x + ','
      })
      if (areaList.length > 0) {
        areaList = areaList.substr(0, areaList.length - 1)
      }
      this.formYOY.team.forEach(x => {
        teamList = teamList + x + ','
      })
      if (teamList.length > 0) {
        teamList = teamList.substr(0, teamList.length - 1)
      }
      this.formYOY.line.forEach(x => {
        lineList = lineList + x + ','
      })
      if (lineList.length > 0) {
        lineList = lineList.substr(0, lineList.length - 1)
      }
      if (this.yoyKPI === 'EFF') {
        if (areaList === '') {
          this.alertMsg(this.$t('dpmTeamKPIReview.altMsgEffNotSupportFactory'))
          return
        }
      }
      this.yoyObjectData = null
      const data = {
        factoryList: factoryList,
        areaList: areaList,
        teamList: teamList,
        lineList: lineList,
        kpi: this.yoyKPI,
        qty: this.formYOY.qty
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoading'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await GetDPMTeamKPIReviewYOYData(data)
      const queryResult = response.data.QueryResult
      this.loadingData.close()
      if (queryResult === 'OK') {
        this.yoyObjectData = response.data.ReturnObject
        this.colYOYYearSetting = this.yoyObjectData.columnsYear
        this.colYOYQuarterSetting = this.yoyObjectData.columnsQuarter
        this.colYOYMonthSetting = this.yoyObjectData.columnsMonth
        this.setShowData()
      } else {
        this.alertMsg(queryResult)
      }
    },
    setShowData() {
      if (this.yoyObjectData !== null) {
        if (this.showTypeRadio === 1) {
          this.tableYOYYear = this.yoyObjectData.yoyYearTable
          this.tableYOYQuarter = this.yoyObjectData.yoyQuarterTable
          this.tableYOYMonth = this.yoyObjectData.yoyMonthTable
        } else {
          this.tableYOYYear = this.yoyObjectData.yoyRateYearTable
          this.tableYOYQuarter = this.yoyObjectData.yoyRateQuarterTable
          this.tableYOYMonth = this.yoyObjectData.yoyRateMonthTable
        }
        this.setYOYChartYear()
        this.setYOYChartQuarter()
        this.setYOYChartMonth()
      }
    },
    setYOYChartYear() {
      this.destroyYOYChart('year')
      const legend = []
      const xAxis = []
      const series = []
      this.colYOYYearSetting.forEach(x => {
        if (x.prop !== 'item') {
          xAxis.push(x.label)
        }
      })
      this.tableYOYYear.forEach(x => {
        const data = []
        for (let i = 0; i < this.colYOYYearSetting.length; i++) {
          const prop = this.colYOYYearSetting[i].prop
          if (prop !== 'item') {
            data.push(x[prop])
          }
        }
        legend.push(x.item)
        series.push({
          name: x.item,
          data: data,
          type: 'line'
        })
      })
      const option = {
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        title: {
          text: this.yoyKPI + ' YOY By Year' + (this.showTypeRadio === 2 ? ' [%]' : '')
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: legend
        },
        xAxis: {
          type: 'category',
          data: xAxis
        },
        yAxis: {
          type: 'value'
        },
        series: series
      }
      const chartDom = document.getElementById('elYOYChartYear')
      this.chartYOYYear = this.$echarts.init(chartDom)
      this.chartYOYYear.clear()
      this.chartYOYYear.setOption(option)
    },
    setYOYChartQuarter() {
      this.destroyYOYChart('quarter')
      const legend = []
      const xAxis = []
      const series = []
      this.colYOYQuarterSetting.forEach(x => {
        if (x.prop !== 'item') {
          xAxis.push(x.label)
        }
      })
      this.tableYOYQuarter.forEach(x => {
        const data = []
        for (let i = 0; i < this.colYOYQuarterSetting.length; i++) {
          const prop = this.colYOYQuarterSetting[i].prop
          if (prop !== 'item') {
            data.push(x[prop])
          }
        }
        legend.push(x.item)
        series.push({
          name: x.item,
          data: data,
          type: 'line'
        })
      })
      const option = {
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        title: {
          text: this.yoyKPI + ' YOY By Quarter' + (this.showTypeRadio === 2 ? ' [%]' : '')
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: legend
        },
        xAxis: {
          type: 'category',
          data: xAxis
        },
        yAxis: {
          type: 'value'
        },
        series: series
      }
      const chartDom = document.getElementById('elYOYChartQuarter')
      this.chartYOYQuarter = this.$echarts.init(chartDom)
      this.chartYOYQuarter.clear()
      this.chartYOYQuarter.setOption(option)
    },
    setYOYChartMonth() {
      this.destroyYOYChart('month')
      const legend = []
      const xAxis = []
      const series = []
      this.colYOYMonthSetting.forEach(x => {
        if (x.prop !== 'item') {
          xAxis.push(x.label)
        }
      })
      this.tableYOYMonth.forEach(x => {
        const data = []
        for (let i = 0; i < this.colYOYMonthSetting.length; i++) {
          const prop = this.colYOYMonthSetting[i].prop
          if (prop !== 'item') {
            data.push(x[prop])
          }
        }
        legend.push(x.item)
        series.push({
          name: x.item,
          data: data,
          type: 'line'
        })
      })
      const option = {
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        title: {
          text: this.yoyKPI + ' YOY By Month' + (this.showTypeRadio === 2 ? ' [%]' : '')
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: legend
        },
        xAxis: {
          type: 'category',
          data: xAxis
        },
        yAxis: {
          type: 'value'
        },
        series: series
      }
      const chartDom = document.getElementById('elYOYChartMonth')
      this.chartYOYMonth = this.$echarts.init(chartDom)
      this.chartYOYMonth.clear()
      this.chartYOYMonth.setOption(option)
    },
    setKPIChart(obj) {
      const series = []
      const legendData = []
      obj.series.forEach(s => {
        series.push(s)
        legendData.push(s.name)
      })
      const option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          }
        },
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        legend: {
          data: legendData
        },
        xAxis: [
          {
            type: 'category',
            data: obj.xAxisData,
            axisPointer: {
              type: 'shadow'
            }
          }
        ],
        yAxis: [
          {
            type: 'value'
            // name: obj.yAxisName
          },
          {
            type: 'value',
            axisLabel: {
              formatter: '{value} %'
            }
          }
        ],
        series: series
      }
      this.destoryChart(this.chart)
      const chartDom = document.getElementById('elChartKPI')
      this.chart = this.$echarts.init(chartDom)
      this.chart.clear()
      this.chart.setOption(option)
    },

    destoryChart(chart) {
      if (chart !== null && chart !== '' && chart !== undefined) {
        chart.dispose()
      }
    },
    async showIndexDialog(kpi) {
      this.queryFactoryHistory = this.queryFactory
      const data = {
        type: 'userarea',
        key: this.queryFactoryHistory
      }
      this.getKpiList()
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaListHistory = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
        return
      }
      this.queryAreaHistory = this.queryArea
      const data2 = {
        type: 'userteam',
        key: this.queryAreaHistory
      }
      this.teamListHistory = []
      this.teamListHistory.push({
        key: 0,
        data: 'ALL'
      })
      const response2 = await GetDPMQueryKeyValue(data2)
      const queryResult2 = response.data.QueryResult
      if (queryResult2 === 'OK') {
        const obj = response2.data.ReturnObject
        for (let i = 0; i < obj.length; i++) {
          this.teamListHistory.push({
            key: obj[i].key,
            data: obj[i].data
          })
        }
      } else {
        this.alertMsg(queryResult2)
        return
      }
      this.queryTeamHistory = this.queryTeam
      this.queryKpi = kpi
      this.queryShift = 'ALL'
      this.queryKPIData()
    },
    async queryKPIData() {
      this.showTypeBtnMsg = 'HISTORY'
      const area = this.areaListHistory.filter(x => x.key === this.queryAreaHistory)[0].data
      const factory = this.factoryListHistory.filter(x => x.key === this.queryFactoryHistory)[0].data
      let team = ''
      this.queryTeamHistory.forEach(p => {
        team = team + this.teamListHistory.filter(x => x.key === p)[0].data + ','
      })
      team = team.substring(0, team.length - 1)
      // const team = this.teamListHistory.filter(x => x.key === this.queryTeamHistory)[0].data
      const yM = this.$utils.GetDateString(this.queryMonth).substr(0, 7).replace('-', '')
      const data = {
        factory: factory,
        area: area,
        team: team,
        yearMonth: yM,
        shift: this.queryShift,
        kpi: this.queryKpi
      }
      this.loading = true
      const response = await GetDPMTeamKPIHistoryDataV2(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const queryResponse = response.data.ReturnObject
        this.kpiChartData = queryResponse.chartData
        this.tableColumns = queryResponse.columnsData
        this.mainTableData = queryResponse.mainData
        this.$nextTick(() => {
          this.$refs.tbMainTableData.doLayout()
        })
        this.tableHistoryData = queryResponse.historyData[0]['tableData']
        this.$nextTick(() => {
          this.$refs.dataTreeList.doLayout()
        })
      } else {
        this.alertMsg(queryResult)
      }
      this.resizeTableHistoryHegiht()
      this.setKPIChart(this.kpiChartData[0])
      debugger
    },
    sortMethod(a, b, column) {
      if (a[column] === '') {
        return -10000
      }
      if (this.currentSort.order === 'ascending') {
        if (a > b) {
          return -1
        }
      } else {
        if (a > b) {
          return 1
        }
      }
      return 0
    },
    handleSortChange({ column, prop, order }) {
      const arr1 = this.tableHistoryData.filter(x => x[prop] === '' || x[prop] === '0' || x[prop] === null || x[prop] === 'null')
      var arr2 = this.tableHistoryData.filter(x => x[prop] !== '' && x[prop] !== '0' && x[prop] !== null && x[prop] !== 'null')
      const len = arr2.length
      for (let i = 0; i < len - 1; i++) {
        for (let j = 0; j < len - 1 - i; j++) {
          const _a = isNaN(parseFloat(arr2[j][prop])) ? 0 : parseFloat(arr2[j][prop])
          const _b = isNaN(parseFloat(arr2[j + 1][prop])) ? 0 : parseFloat(arr2[j + 1][prop])
          if (order === 'ascending') {
            if (_a > _b) {
              [arr2[j], arr2[j + 1]] = [arr2[j + 1], arr2[j]]
            }
          } else {
            if (_b > _a) {
              [arr2[j], arr2[j + 1]] = [arr2[j + 1], arr2[j]]
            }
          }
        }
      }
      this.tableHistoryData = [...arr2, ...arr1]
    },
    downloadData: function() {
      if (this.queryFactoryHistory === '') {
        this.alertMsg(this.$t('dpmTeamKPIReview.altMsgFactoryEmpty'))
        return
      }
      if (this.queryAreaHistory === '') {
        this.alertMsg(this.$t('dpmTeamKPIReview.altMsgAreaEmpty'))
        return
      }
      if (this.queryKpi === '') {
        this.alertMsg(this.$t('dpmTeamKPIReview.altMsgKPIEmpty'))
        return
      }
      if (this.queryTeamHistory === '') {
        this.queryTeamHistory = 0
      }
      if (this.queryShift === '') {
        this.queryShift = 'ALL'
        return
      }
      const kpi = this.queryKpi
      // switch (this.queryKpi.toUpperCase()) {
      //   case 'UPPH':
      //     kpi = 'UPPH_v2'
      //     break
      // }

      const factory = this.factoryListHistory.filter(x => x.key === this.queryFactoryHistory)[0].data
      const area = this.areaListHistory.filter(x => x.key === this.queryAreaHistory)[0].data
      // const team = this.teamListHistory.filter(x => x.key === this.queryTeamHistory)[0].data$nextTick
      let team = ''
      this.queryTeamHistory.forEach(p => {
        team = team + this.teamListHistory.filter(x => x.key === p)[0].data + ','
      })
      team = team.substring(0, team.length - 1)
      // let yM = this.$utils.GetDateString(this.queryMonth)
      // yM = yM.substr(0, 7)
      const yM = this.$utils.GetDateString(this.queryMonth).substr(0, 7).replace('-', '')
      const params = {
        factory: factory,
        area: area,
        team: team,
        yearMonth: encodeURIComponent(yM),
        shift: this.queryShift,
        kpi: encodeURIComponent(this.queryKpi)
      }
      const fileName = factory + '_' + area + '_' + team + '_' + kpi + '(' + yM + ').xlsx'
      downloadDPMTeamKPIHistoryDataV2_API(params, fileName)
      // var url = '/midway/downloadDPMTeamKPIHistoryData'
      // url = url + '?lang=cn&factory=' + encodeURIComponent(factory) + '&area=' + encodeURIComponent(area) +
      // '&team=' + encodeURIComponent(team) + '&yearMonth=' + encodeURIComponent(yM) +
      // '&shift=' + this.queryShift + '&kpi=' + encodeURIComponent(kpi)
      // this.$utils.downloadFile(url, fileName)
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    resizeTable: function() {
      this.$nextTick(function() {
        try {
          this.yoyTableHeight = $('#yoyTable').height()
          // eslint-disable-next-line no-empty
        } catch {}
      })
    },
    resizeTableHistoryHegiht() {
      var wh = window.innerHeight - 70
      this.tableDetailHeight = wh - $('#tableDetailContainer').height()
    }
  }
}
</script>
  <style lang="less" scoped>
  ::v-deep main.el-main{
    padding: 0
  }
  ::v-deep .el-divider--horizontal{
    margin:0
  }
  .selectMidSize{
    width:120px;
    margin-right:5px;
  }
  .topLineSpan{
    display: inline-block;
    margin:0 10px;
    color: blue;
  }
  .chartHeadSpan{
    display: inline-block;
    color: blue;
    margin:20px 20px 20px 20px;
  }
  section{
    padding-bottom: 0;
  }
  .el-header{
      padding:0 5px
  }
  .header{
    height:40px !important;
    // background-color:#1f4e7c;
    background-color:rgba(0,0,0,0);
  }
  ::v-deep .el-table td div{
    font-size: 16px;
  }
  .defTableCell{
    font-size: 16px;
    color: black;
  }
  // ::v-deep .el-table .cell {
  //     white-space: pre-line;
  // }
  ::v-deep .el-table td {
    border:1px solid lightgray;
  }
  ::v-deep #txtIssueContent {
    color: blue
  }
  // .el-table_body-wrapper {
  //   &::-webkit-scrollbar{
  //     width: 10px;
  //     height: 10px;
  //   }
  //   &::-webkit-scrollbar-track{
  //     //box-shadow: 0px 1px #999 inset;
  //     //border-radius: 10px;
  //     background-color: #fff;
  //   }
  //   &::-webkit-scrollbar-thumb{
  //     //box-shadow: 0px 1px 3px hsl(214, 88%, 44%) inset;
  //     //border-radius: 10px;
  //     background-color: deepskyblue;
  //   }
  // }
  .el-table__body-wrapper::-webkit-scrollbar {
    width: 10px; /* 设置滚动条的宽度 */
    height: 10px; /* 设置滚动条的高度 */
  }

.el-table__body-wrapper::-webkit-scrollbar-thumb {
  background-color: hsl(212, 71%, 50%); /* 滚动条的颜色 */
  border-radius: 5px; /* 滚动条的圆角 */
}

.el-table__body-wrapper::-webkit-scrollbar-track {
  background-color: #f0f2f5; /* 滚动条的轨道颜色 */
}
  .chartDiv{
    height:100%;
    min-height: 200px;
    width:100%;
    background-color: white;
  }
  .radarChartDiv{
    width:100%;
    height: 90%;
    background-color: white;
    display: flex;
  }
  .radarButton{
    width:100%;
    height: 10%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .mainTopDiv{
    height:470px;
    width:100%;
    border-style: none;
    display: flex;
  }
  .mainLeftDiv{
    height:100%;
    width:1220px;
    //float: left;
    border-style:  none;
    //display: flex;
    // flex-direction: column;
    // justify-content: space-between;
  }
  .mainRightDiv{
    height:100%;
    width:calc(100% - 1220px);
    background-color: white;
    float: left;
    //margin-left: 10PX;
    //display: flex;
    // flex-direction: column;
    // justify-content: space-between;
  }
  .mainBottomDiv{
    height:calc(100% - 470px);
    width:100%;
  }
  .YOYMainDiv{
  width:100%;
  height:100%;
  display: flex;
  }
  .YOYLeftDiv{
    height:100%;
    width:350px;
  }
  .YOYRightDiv{
    height:100%;
    width:calc(100% - 350px);
    background-color: white;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }
  .YOYContentDiv{
    width:100%;
    height:33%;
    display: flex;
  }
  .YOYContentTable{
    height: 100%;
    width: 30%;
  }
  .YOYChart{
    height: 100%;
    width: 70%;
  }
  .modDiv{
    width:100%;
    height:100%;
  }
  .chartKPIDiv {
  height:350px;
  width:100%;
  background-color: white;
}
  .detailDiv{
  margin-top:10px;
  width:100%;
}
.lineDiv{
  margin-top:10px;
  width:100%;
}
.lineDiv .scrollbar-thumb::before {
    background-color: #ff0000; // 设置滑块（Thumb）的颜色为红色
}

.lineDiv .el-scrollbar__wrap {
  //background-color:deepskyblue; // 设置滚动条轨道（Track）的颜色为白色
  overflow-x: scroll; /* 显示水平滚动条 */
}
  </style>

