<template>
  <div style="height:100%;width:100%">
    <el-container style="height:100%">
      <el-header style="padding:0;height:40px">
        <el-select v-model="queryPlant" size="small" class="selectMidSize" placeholder="廠別" @change="getQueryAreaList">
          <el-option
            v-for="item in plantList"
                          :key="item.plant"
                          :label="item.plant"
            :value="item.plant"
          />
          </el-select>
        <el-button type="primary" icon="el-icon-search" size="small" style="margin-left:5px" @click="getChangeList">刷新待辦清單</el-button>
      </el-header>
      <el-main style="padding:0;height:1px">
        <div class="mainDiv">
          <div class="fieldDiv">
            <div class="fieldTitleDiv">
              Area
            </div>
            <ul v-for="(item, index) in areaList" :key="index" :style="{'background-color': getBgColor('area', item.key)}">
              <el-link :underline="false" @click="getQueryTeamList(item.key)">
                <span class="liDataSpan">{{ item.data }}</span>
              </el-link>
              <i class="el-icon-plus optIcon icon1" title="增加Team" @click="showAddNewTeamDialog(item.key)" />
              <!-- <i class="el-icon-edit optIcon icon2" title="修改Area名稱"></i>
              <i class="el-icon-close optIcon icon1" title="刪除Area"></i> -->
            </ul>
          </div>
          <div class="fieldDiv">
            <div class="fieldTitleDiv">
              Team
            </div>
            <ul v-for="(item, index) in teamList" :key="index" :style="{'background-color': getBgColor('team', item.key)}">
              <el-link :underline="false" @click="getQueryLineList(item.key)">
                <span class="liDataSpan">{{ item.data }}</span>
              </el-link>
              <i class="el-icon-plus optIcon icon2" title="增加Line" @click="showAddNewLineDialog(item.key)" />
              <i class="el-icon-edit optIcon icon1" title="修改Team名稱" @click="showChangeTeamNameDialog(item.key, item.data)" />
              <!-- <i class="el-icon-close optIcon icon1" title="刪除Team"></i> -->
            </ul>
          </div>
          <div class="fieldDiv" style="width:250px">
            <div class="fieldTitleDiv">
              Line
            </div>
            <ul v-for="(item, index) in lineList" :key="index" :style="{'background-color': getBgColor('line', item.key)}">
              <el-link :underline="false" @click="getQueryStageList(item.key)">
                <span class="liDataSpan">{{ item.data }}</span>
              </el-link>
              <i class="el-icon-guide optIcon icon3" title="更改掛靠Team" @click="showMoveTeamDialog(item.key)" />
              <i class="el-icon-collection-tag optIcon icon2" title="更改線體類型" @click="showChangeLineTypeDialog(item.key)" />
              <!-- <i class="el-icon-plus optIcon icon2" title="增加LineStage"></i> -->
              <i class="el-icon-edit optIcon icon1" title="修改Line名稱" @click="showChangeLineNameDialog(item.key, item.data)" />
              <!-- <i class="el-icon-close optIcon icon1" title="刪除Line"></i> -->
            </ul>
          </div>
          <!-- <div class="fieldDiv">
            <div class="fieldTitleDiv">
              Line stage
            </div>
            <ul v-for="(item, index) in stageList" :key="index" :style="{'background-color': getBgColor('stage', item.key)}">
              <el-link :underline="false" @click="setSelectedStage(item.key)">
                <span class="liDataSpan">{{item.data}}</span>
              </el-link>
              <i class="el-icon-edit optIcon icon2" title="修改LineStage名稱"></i>
              <i class="el-icon-close optIcon icon1" title="刪除LineStage"></i>
            </ul>
          </div> -->
          <div id="tableChangeDiv" class="fieldDiv" style="width:calc(100% - 660px)">
            <el-table
              v-loading="loading"
              :data="tableChangeList"
                size="small"
                stripe
                :height="tableHeight"
              style="width: 100%;"
            >
                <el-table-column prop="line" label="" width="60" align="center">
                  <template scope="scope">
                  <el-link :underline="false" style="color:red" @click="cancelChange(scope.row.id)">撤銷</el-link>
                  </template>
                </el-table-column>
              <el-table-column prop="eff_work_date" label="生效日期" width="100" align="center" />
              <el-table-column prop="eff_shift" label="生效班别" width="90" align="center" /> <!-- 20230304 Kimi 增加班别-->
              <el-table-column prop="change_type" label="類別" align="center" width="130" show-overflow-tooltip />
              <el-table-column prop="opt_value" label="操作對象" align="center" width="110" show-overflow-tooltip />
              <el-table-column prop="old_value" label="原始值" align="center" width="110" show-overflow-tooltip />
              <el-table-column prop="new_value" label="目標值" align="center" width="110" show-overflow-tooltip />
              <el-table-column prop="submit_user" label="提交人" align="center" width="100" />
              <el-table-column prop="submit_time" label="提交時間" align="center" width="150" />
            </el-table>
          </div>
        </div>
      </el-main>
    </el-container>

    <el-dialog
      title="移動到其它Team"
      :close-on-press-escape="false"
      :visible.sync="moveLineTeamDialogVisible"
      width="500px"
      :close-on-click-modal="false"
    >
        <div>請選擇要轉移去的Team和生效時間</div>
      <el-select v-model="moveTeam" size="small" class="selectMidSize" placeholder="Team">
        <el-option
          v-for="item in moveTeamList"
              :key="item.key"
              :label="item.data"
          :value="item.key"
        />
        </el-select>
      <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" placeholder="生效工作日" />
      <!-- 20230304 Kimi 增加班别-->
      <el-select v-model="moveTeamShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
        <el-option label="白班" value="D" />
        <el-option label="中班" value="M" />
        <el-option label="夜班" value="N" />
      </el-select>
        <div slot="footer" class="dialog-footer">
          <el-button type="danger" size="small" @click="closeMoveLimeTeamDialog">退 出</el-button>
          <el-button type="success" size="small" @click="submitMoveTeam">提交變更</el-button>
        </div>
    </el-dialog>

    <el-dialog
      title="更改線體類型"
      :close-on-press-escape="false"
      :visible.sync="changeLineTypeDialogVisible"
      width="500px"
      :close-on-click-modal="false"
    >
        <div>請選擇要變更的線體類型和生效時間</div>
      <div>當前線體類型是 {{ currentLineType }}</div>
      <el-select v-model="newLineType" size="small" class="selectMidSize" placeholder="線體類型">
        <el-option
          v-for="item in lineTypeList"
              :key="item.key"
              :label="item.data"
          :value="item.key"
        />
        </el-select>
      <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" placeholder="生效工作日" />
      <!-- 20230304 Kimi 增加班别-->
      <el-select v-model="newLineTypeShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
        <el-option label="白班" value="D" />
        <el-option label="中班" value="M" />
        <el-option label="夜班" value="N" />
      </el-select>
        <div slot="footer" class="dialog-footer">
          <el-button type="danger" size="small" @click="closeChangeLineTypeDialog">退 出</el-button>
          <el-button type="success" size="small" @click="submitChangeLineType">提交變更</el-button>
        </div>
    </el-dialog>

    <el-dialog
      title="更改線體名稱"
      :close-on-press-escape="false"
      :visible.sync="changeLineNameDialogVisible"
      width="500px"
      :close-on-click-modal="false"
    >
        <div>請填寫新的線體名稱和生效時間</div>
      <div>當前線體名稱是 {{ currentLineName }}</div>
      <el-input v-model="newLineName" size="small" style="width:200px" placeholder="請輸入新線體名稱" />
      <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" placeholder="生效工作日" />
      <!-- 20230304 Kimi 增加班别-->
      <el-select v-model="newLineNameShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
        <el-option label="白班" value="D" />
        <el-option label="中班" value="M" />
        <el-option label="夜班" value="N" />
      </el-select>
        <div slot="footer" class="dialog-footer">
          <el-button type="danger" size="small" @click="closeChangeLineNameDialog">退 出</el-button>
          <el-button type="success" size="small" @click="submitChangeLineName">提交變更</el-button>
        </div>
    </el-dialog>

    <el-dialog
      title="更改Team名稱"
      :close-on-press-escape="false"
      :visible.sync="changeTeamNameDialogVisible"
      width="500px"
      :close-on-click-modal="false"
    >
        <div>請填寫新的Team名稱和生效時間</div>
      <div>當前Team名稱是 {{ currentTeamName }}</div>
      <el-input v-model="newTeamName" size="small" style="width:200px" placeholder="請輸入新Team名稱" />
      <el-date-picker v-model="effDate" size="small" style="width:140px;margin-left:5px" type="date" placeholder="生效工作日" />
      <!-- 20230304 Kimi 增加班别-->
      <el-select v-model="newTeamNameShift" size="small" style="width:80px;margin-left:5px" placeholder="Shift">
        <el-option label="白班" value="D" />
        <el-option label="中班" value="M" />
        <el-option label="夜班" value="N" />
      </el-select>
        <div slot="footer" class="dialog-footer">
          <el-button type="danger" size="small" @click="closeChangeTeamNameDialog">退 出</el-button>
          <el-button type="success" size="small" @click="submitChangeTeamName">提交變更</el-button>
        </div>
    </el-dialog>

    <el-dialog
      title="新增Team"
      :close-on-press-escape="false"
      :visible.sync="addNewTeamDialogVisible"
      width="400px"
      :close-on-click-modal="false"
    >
        <div>請填寫新的Team名稱</div>
      <el-input v-model="newTeamName" size="small" style="width:200px" placeholder="請輸入新Team名稱" />
        <div slot="footer" class="dialog-footer">
          <el-button type="danger" size="small" @click="closeAddNewTeamDialog">退 出</el-button>
          <el-button type="success" size="small" @click="submitNewTeam">新增Team</el-button>
        </div>
    </el-dialog>

    <el-dialog
      title="新增線體"
      :close-on-press-escape="false"
      :visible.sync="addNewLineDialogVisible"
      width="400px"
      :close-on-click-modal="false"
    >
        <div>請填寫新的線體名稱，並選擇對應的LineType</div>
      <el-input v-model="newLineName" size="small" style="width:150px;margin-right:5px" placeholder="請輸入新線體名稱" />
      <el-select v-model="newLineType" size="small" class="selectMidSize" placeholder="線體類型">
        <el-option
          v-for="item in lineTypeList"
              :key="item.key"
              :label="item.data"
          :value="item.key"
        />
        </el-select>
        <div slot="footer" class="dialog-footer">
          <el-button type="danger" size="small" @click="closeAddNewLineDialog">退 出</el-button>
          <el-button type="success" size="small" @click="submitNewLine">新增線體</el-button>
        </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="addNewItemTitle"
      :close-on-press-escape="false"
      :visible.sync="addNewItemDialogVisible"
      width="1000px"
      :close-on-click-modal="false"
    />
  </div>
</template>
<script>
import $ from 'jquery'
import {
  getUserMenuPlantList, GetCurrentBaseData, AddNewBaseData, AddBaseDataChangeRequest, GetBaseDataChangeList, CancelBaseDataChangeListItem
} from '@/api/midway.js'
export default {
  data() {
  return {
    tableHeight: 1,
    effDate: '',
    loading: false,
    loadingData: null,
    plantList: [],
    queryPlant: '',
    areaList: [],
    queryArea: '',
    teamList: [],
    queryTeam: '',
    lineList: [],
    queryLine: '',
    stageList: [],
    queryStage: '',
    addNewItemDialogVisible: false,
    addNewItemTitle: '增加新項目',
    moveLineTeamDialogVisible: false,
    moveTeam: '',
    moveTeamList: [],
      moveTeamShift: 'D', // 20230304 Kimi 增加班别
    changeLineTypeDialogVisible: false,
    newLineType: '',
      newLineTypeShift: 'D', // 20230304 Kimi 增加班别
    currentLineType: '',
    lineTypeList: [],
    changeLineNameDialogVisible: false,
    currentLineName: '',
    newLineName: '',
      newLineNameShift: 'D', // 20230304 Kimi 增加班别
    changeTeamNameDialogVisible: false,
    currentTeamName: '',
    newTeamName: '',
      newTeamNameShift: 'D', // 20230304 Kimi 增加班别
    addNewTeamDialogVisible: false,
    addNewLineDialogVisible: false,
    tableChangeList: []
  }
},
  mounted() {
    this.getDefaultDate()
    this.queryPlantList()
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
    }
  },
methods: {
    getDefaultDate() {
    const curDate = new Date()
    this.effDate = new Date(curDate.getTime() + 24 * 60 * 60 * 1000)
  },
    alertMsg(msg) {
    this.$alert(msg, '提示', {
      confirmButtonText: '確定',
      type: 'error'
    })
  },
    getBgColor(type, data) {
    if (type === 'area') {
      return data === this.queryArea ? 'lightblue' : 'white'
    } else if (type === 'team') {
      return data === this.queryTeam ? 'lightblue' : 'white'
    } else if (type === 'line') {
      return data === this.queryLine ? 'lightblue' : 'white'
    } else if (type === 'stage') {
      return data === this.queryStage ? 'lightblue' : 'white'
    }
  },
    async queryPlantList() {
    // start update 20230222 fenglianlong 修改获取menuId来源于主框架值
     // const data = { menu: '', menuId: '79' }
    const data = { menuId: this.$route.query.menuId }
    
    this.plantList = []
    const response = await getUserMenuPlantList(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.plantList = response.data.ReturnObject
  // end update 20230222 fenglianlong ---------------------
    } else {
      this.alertMsg(queryResult)
    }
  },
    async getQueryAreaList() {
    this.areaList = []
    this.queryArea = ''
    this.teamList = []
    this.queryTeam = ''
    this.lineList = []
    this.queryLine = ''
    this.stageList = []
    this.queryStage = ''
    const data = {
      type: 'area',
      key: this.queryPlant
    }
    const response = await GetCurrentBaseData(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.areaList = response.data.ReturnObject[0]
    } else {
      this.alertMsg(queryResult)
    }
    this.getChangeList()
  },
    async getQueryTeamList(key) {
    this.queryArea = key
    this.teamList = []
    this.queryTeam = ''
    this.lineList = []
    this.queryLine = ''
    this.stageList = []
    this.queryStage = ''
    const data = {
      type: 'team',
      key: this.queryArea
    }
    const response = await GetCurrentBaseData(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.teamList = response.data.ReturnObject[0]
    } else {
      this.alertMsg(queryResult)
    }
  },
    async getQueryLineList(key) {
    this.queryTeam = key
    this.lineList = []
    this.queryLine = ''
    this.stageList = []
    this.queryStage = ''
    const data = {
      type: 'line',
      key: this.queryTeam
    }
    const response = await GetCurrentBaseData(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.lineList = response.data.ReturnObject[0]
    } else {
      this.alertMsg(queryResult)
    }
  },
    async getQueryStageList(key) {
    this.queryLine = key
    this.stageList = []
    this.queryStage = ''
    const data = {
      type: 'stage',
      key: this.queryLine
    }
    const response = await GetCurrentBaseData(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.stageList = response.data.ReturnObject[0]
    } else {
      this.alertMsg(queryResult)
    }
  },
    async getChangeList() {
    if (this.queryPlant === '') {
      return
    }
    this.tableChangeList = []
    const data = {
      factory: this.queryPlant
    }
    const response = await GetBaseDataChangeList(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.tableChangeList = response.data.ReturnObject
    } else {
      this.alertMsg(queryResult)
    }
  },
    setSelectedStage(key) {
    this.queryStage = key
  },
    openAddItemDialog() {
    this.addNewItemDialogVisible = true
  },
    closeAddItemDialog() {
    this.addNewItemDialogVisible = false
  },
    async showMoveTeamDialog(line) {
    this.queryLine = line
    this.moveTeam = ''
    const data = {
      type: 'moveteam',
      key: line
    }
    const response = await GetCurrentBaseData(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.moveTeamList = response.data.ReturnObject[0]
    } else {
      this.alertMsg(queryResult)
    }
    this.moveLineTeamDialogVisible = true
  },
    closeMoveLimeTeamDialog() {
    this.moveTeam = ''
    this.moveTeamList = []
    this.moveLineTeamDialogVisible = false
    this.getChangeList()
  },
    async submitMoveTeam() {
    const day = this.$utils.GetDateString(this.effDate)
      const msg = '異動將會在以下工作日 [' + day + '(' + this.moveTeamShift + ')班] 開始時進行，確定要提交請求嗎？'
    if (!confirm(msg)) {
      return
    }
    const data = {
      type: 'changeteam',
      factory: this.queryPlant,
      optKey: this.queryLine,
      oldKey: this.queryTeam,
      oldValue: '',
      newKey: this.moveTeam,
      newValue: '',
      parentKey: this.queryTeam,
        effWorkDay: day,
        effShift: this.moveTeamShift // 20230304 Kimi 增加班别
    }
    const response = await AddBaseDataChangeRequest(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.$alert('修改歸屬Team的請求已提交，請等待系統作業', '提示', {
        confirmButtonText: '確定',
        type: 'success'
      })
      this.closeMoveLimeTeamDialog()
    } else {
      this.alertMsg(queryResult)
    }
  },
    async showChangeLineTypeDialog(line) {
    this.queryLine = line
    this.currentLineType = ''
    this.newLineType = ''
    const data = {
      type: 'changelinetype',
      key: line
    }
    const response = await GetCurrentBaseData(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.currentLineType = response.data.ReturnObject[0][0].line_type
      this.lineTypeList = response.data.ReturnObject[1]
    } else {
      this.alertMsg(queryResult)
    }
    this.changeLineTypeDialogVisible = true
  },
    closeChangeLineTypeDialog() {
    this.newLineType = ''
    this.currentLineType = ''
    this.lineTypeList = []
    this.changeLineTypeDialogVisible = false
    this.getChangeList()
  },
    async submitChangeLineType() {
    if (this.newLineType === '') {
      this.alertMsg('請選擇新的LineType')
      return
    }
      // 改到后端去卡
      // if (this.newLineType === this.currentLineType) {
      //   this.alertMsg('新舊LineType一致，不能提交')
      //   return
      // }
    const day = this.$utils.GetDateString(this.effDate)
      const msg = '異動將會在以下工作日 [' + day + '(' + this.newLineTypeShift + '班)] 開始時進行，確定要提交請求嗎？'
    if (!confirm(msg)) {
      return
    }
    const data = {
      type: 'changelinetype',
      factory: this.queryPlant,
      optKey: this.queryLine,
      oldKey: '',
      oldValue: this.currentLineType,
      newKey: '',
      newValue: this.newLineType,
      parentKey: this.queryTeam,
        effWorkDay: day,
        effShift: this.newLineTypeShift // 20230304 Kimi 增加班别
    }
    const response = await AddBaseDataChangeRequest(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.$alert('修改LineType的請求已提交，請等待系統作業', '提示', {
        confirmButtonText: '確定',
        type: 'success'
      })
      this.closeChangeLineTypeDialog()
    } else {
      this.alertMsg(queryResult)
    }
  },
    showChangeLineNameDialog(line, lineName) {
    this.queryLine = line
    this.currentLineName = lineName
    this.newLineName = ''
    this.changeLineNameDialogVisible = true
  },
    closeChangeLineNameDialog() {
    this.newLineName = ''
    this.currentLineName = ''
    this.changeLineNameDialogVisible = false
    this.getChangeList()
  },
    async submitChangeLineName() {
    if (this.newLineName === '') {
      this.alertMsg('請輸入新的Line名稱')
      return
    }
    if (this.newLineName === this.currentLineName) {
      this.alertMsg('新舊名稱一致，不能提交')
      return
    }
    const day = this.$utils.GetDateString(this.effDate)
      const msg = '異動將會在以下工作日 [' + day + '(' + this.newLineNameShift + '班)] 開始時進行，確定要提交請求嗎？'
    if (!confirm(msg)) {
      return
    }
    const data = {
      type: 'changelinename',
      factory: this.queryPlant,
      optKey: this.queryLine,
      oldKey: '',
      oldValue: '',
      newKey: '',
      newValue: this.newLineName,
      parentKey: this.queryTeam,
        effWorkDay: day,
        effShift: this.newLineNameShift // 20230304 Kimi 增加班别
    }
    const response = await AddBaseDataChangeRequest(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.$alert('修改Line名稱的請求已提交，請等待系統作業', '提示', {
        confirmButtonText: '確定',
        type: 'success'
      })
      this.closeChangeLineNameDialog()
    } else {
      this.alertMsg(queryResult)
    }
  },
    showChangeTeamNameDialog(team, teamName) {
    this.queryTeam = team
    this.currentTeamName = teamName
    this.newTeamName = ''
    this.changeTeamNameDialogVisible = true
  },
    closeChangeTeamNameDialog() {
    this.newTeamName = ''
    this.currentTeamName = ''
    this.changeTeamNameDialogVisible = false
    this.getChangeList()
  },
    async submitChangeTeamName() {
    if (this.newTeamName === '') {
      this.alertMsg('請輸入新的Team名稱')
      return
    }
    if (this.newTeamName === this.currentTeamName) {
      this.alertMsg('新舊名稱一致，不能提交')
      return
    }
    const day = this.$utils.GetDateString(this.effDate)
      const msg = '異動將會在以下工作日 [' + day + '(' + this.newTeamNameShift + '班)] 開始時進行，確定要提交請求嗎？'
    if (!confirm(msg)) {
      return
    }
    const data = {
      type: 'changeteamname',
      factory: this.queryPlant,
      optKey: this.queryTeam,
      oldKey: '',
      oldValue: '',
      newKey: '',
      newValue: this.newTeamName,
      parentKey: this.queryArea,
        effWorkDay: day,
        effShift: this.newTeamNameShift // 20230304 Kimi 增加班别
    }
    const response = await AddBaseDataChangeRequest(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.$alert('修改Team名稱的請求已提交，請等待系統作業', '提示', {
        confirmButtonText: '確定',
        type: 'success'
      })
      this.closeChangeTeamNameDialog()
    } else {
      this.alertMsg(queryResult)
    }
  },
    showAddNewTeamDialog(area) {
    this.queryArea = area
    this.newTeamName = ''
    this.addNewTeamDialogVisible = true
  },
    closeAddNewTeamDialog() {
    this.newTeamName = ''
    this.addNewTeamDialogVisible = false
    this.getChangeList()
  },
    async submitNewTeam() {
    if (this.newTeamName === '') {
      this.alertMsg('請填寫要增加的Team名稱')
      return
    }
    if (!confirm('確定要新增這個Team名稱嗎？')) {
      return
    }
    const data = {
      type: 'addteam',
      factory: this.queryPlant,
      parentKey: this.queryArea,
      value: this.newTeamName
    }
    const response = await AddNewBaseData(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.$alert('增加新的Team成功，請刷新一下', '提示', {
        confirmButtonText: '確定',
        type: 'success'
      })
      this.closeAddNewTeamDialog()
    } else {
      this.alertMsg(queryResult)
    }
  },
    async showAddNewLineDialog(team) {
    this.queryTeam = team
    this.newLineName = ''
    this.newLineType = ''
    this.lineTypeList = []
    const data = {
      type: 'teamalllinetype',
      key: this.queryTeam
    }
    const response = await GetCurrentBaseData(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.lineTypeList = response.data.ReturnObject[0]
    } else {
      this.alertMsg(queryResult)
    }
    this.addNewLineDialogVisible = true
  },
    closeAddNewLineDialog() {
    this.newLineName = ''
    this.newLineType = ''
    this.lineTypeList = []
    this.addNewLineDialogVisible = false
    this.getChangeList()
  },
    async submitNewLine() {
    if (this.newLineName === '') {
      this.alertMsg('請填寫要增加的Line名稱')
      return
    }
    if (this.newLineType === '') {
      this.alertMsg('請選擇新線的LineType')
      return
    }
    if (!confirm('確定要新增這個Line名稱嗎？')) {
      return
    }
    const data = {
      type: 'addline',
      factory: this.queryPlant,
      parentKey: this.queryTeam,
      value: this.newLineName,
      value2: this.newLineType
    }
    const response = await AddNewBaseData(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.$alert('增加新的Line成功，請刷新一下', '提示', {
        confirmButtonText: '確定',
        type: 'success'
      })
      this.closeAddNewLineDialog()
    } else {
      this.alertMsg(queryResult)
    }
  },
    async cancelChange(id) {
    if (!confirm('確定要取消這個變更嗎？')) {
      return
    }
    const data = {
      id: id
    }
    const response = await CancelBaseDataChangeListItem(data)
    const queryResult = response.data.QueryResult
    if (queryResult === 'OK') {
      this.$alert('操作成功', '提示', {
        confirmButtonText: '確定',
        type: 'success'
      })
      this.getChangeList()
    } else {
      this.alertMsg(queryResult)
    }
  },
    resizeTable: function() {
      this.$nextTick(function() {
      const divHeight = $('#tableChangeDiv').height()
      this.tableHeight = divHeight
    })
  }
}
}
</script>
<style lang="less" scoped>
.mainDiv{
width:100%;
height:100%;
display: flex;
}
.fieldDiv{
position: relative;
width:200px;
height:100%;
margin-right:5px;
border:1px solid rgb(23,102,173);
overflow: auto;
background-color: white;
}
.fieldTitleDiv{
width:100%;
font-size: 16px;
color:white;
height:25px;
line-height: 25px;
text-align: center;
background-color: rgb(23,102,173);
}
li {
list-style-type: none;
}
.liDataSpan{
font-size:14px;
color: rgb(23,102,173);
padding-left:5px;
}
.optIcon{
// right:20px;
position:absolute;
padding-top:5px;
cursor: pointer;
}
.icon3{
right:50px;
}
.icon2{
right:30px;
}
.icon1{
right:10px;
}
.icon4{
right:70px;
}
.icon5{
right:90px;
}
</style>
