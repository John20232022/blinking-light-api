<template>
  <div style="height: 100%; width: 100%">
    <el-container style="height: 100%">
      <el-header class="header" style="height: 80px">
        <el-date-picker
          v-model="pickDates"
          style="margin-right: 5px; width: 250px"
          type="daterange"
          align="right"
          unlink-panels
          start-placeholder="開始日期"
          end-placeholder="結束日期"
          size="small"
          @change="getQueryFactoryList"
        />
        <el-select
          v-model="queryFactory"
          size="small"
          class="selectMiniSize"
          placeholder="廠別"
          @change="getQueryAreaList"
        >
          <el-option
            v-for="item in factoryList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select
          v-model="queryArea"
          size="small"
          class="selectMiniSize"
          placeholder="區域"
          @change="getQueryteamList"
        >
          <el-option
            v-for="item in areaList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select
          v-model="queryTeam"
          size="small"
          class="selectMidSize"
          placeholder="Team"
          @change="getQueryLineList"
        >
          <el-option
            v-for="item in teamList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select
          v-model="queryLine"
          size="small"
          class="selectMidSize"
          placeholder="線別"
          @change="getModelList"
        >
          <el-option
            v-for="item in lineList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select
          v-model="queryModel"
          size="small"
          class="selectMidSize"
          placeholder="機種"
          style="width: 300px"
          multiple
          collapse-tags
        >
          <el-option
            v-for="item in modelList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <br />
        <el-date-picker
          v-model="querySTDUPHYearMonth"
          size="small"
          style="width: 200px; margin-right: 5px; margin-top: 5px"
          clearable
          type="month"
          placeholder="標準UPH參考月份"
        />
        <span style="display: inline-block; margin: 0 5px"
          >標準UPH不選則默認為當前選擇的年月</span
        >
        <el-button
          type="primary"
          icon="el-icon-search"
          size="small"
          @click="queryData('month', '')"
          >查詢</el-button
        >
      </el-header>
      <el-main style="padding: 0">
        <el-divider />
        <div class="mainDiv">
          <div id="elYM" class="topDiv" />
          <div id="elDay" class="middleDiv" />
          <div id="elHour" class="bottomDiv" />
        </div>
      </el-main>
    </el-container>
  </div>
</template>
<script>
// import $ from 'jquery'
import {
  GetDPMOutputReviewRptKeyValue,
  GetDPMOutputReviewRptData,
} from "@/api/midway.js";
export default {
  data() {
    return {
      pickDates: [],
      queryFactory: "",
      factoryList: [],
      queryArea: "",
      areaList: [],
      queryTeam: "",
      teamList: [],
      queryLine: "",
      lineList: [],
      queryModel: [],
      modelList: [],
      loadingData: null,
      loading: false,
      chartYM: null,
      chartDay: null,
      chartHour: null,
      querySTDUPHYearMonth: "",
    };
  },
  mounted() {
    this.getDefaultDate();
    window.onresize = () => {
      if (this.chartYM !== null) {
        this.chartYM.resize();
      }
      if (this.chartDay !== null) {
        this.chartDay.resize();
      }
      if (this.chartHour !== null) {
        this.chartHour.resize();
      }
    };
  },
  beforeDestroy() {
    clearInterval(this.refreshTimer);
  },
  methods: {
    getDefaultDate() {
      const curDate = new Date();
      this.pickDates.push(new Date(curDate.getTime() - 2160 * 60 * 60 * 1000)); // 3个月
      this.pickDates.push(new Date(curDate));
      this.getQueryFactoryList();
    },
    clearListData(level) {
      if (level >= 4) {
        this.factoryList = [];
        this.queryFactory = "";
      }
      if (level >= 3) {
        this.areaList = [];
        this.queryArea = "";
      }
      if (level >= 2) {
        this.teamList = [];
        this.queryTeam = "";
      }
      if (level >= 1) {
        this.lineList = [];
        this.queryLine = "";
      }
      this.modelList = [];
      this.queryModel = [];
    },
    async getQueryFactoryList() {
      this.clearListData(4);
      const begin = this.$utils.GetDateString(this.pickDates[0]);
      const end = this.$utils.GetDateString(this.pickDates[1]);
      const data = {
        type: "userfactory",
        key: "",
        begin: begin,
        end: end,
      };
      const response = await GetDPMOutputReviewRptKeyValue(data);
      const queryResult = response.data.QueryResult;
      if (queryResult === "OK") {
        this.factoryList = response.data.ReturnObject;
      } else {
        this.alertMsg(queryResult);
      }
    },
    async getQueryAreaList() {
      this.clearListData(3);
      const begin = this.$utils.GetDateString(this.pickDates[0]);
      const end = this.$utils.GetDateString(this.pickDates[1]);
      const data = {
        type: "userarea",
        key: this.queryFactory,
        begin: begin,
        end: end,
      };
      const response = await GetDPMOutputReviewRptKeyValue(data);
      const queryResult = response.data.QueryResult;
      if (queryResult === "OK") {
        this.areaList = response.data.ReturnObject;
      } else {
        this.alertMsg(queryResult);
      }
    },
    async getQueryteamList() {
      this.clearListData(2);
      const begin = this.$utils.GetDateString(this.pickDates[0]);
      const end = this.$utils.GetDateString(this.pickDates[1]);
      const data = {
        type: "userteam",
        key: this.queryArea,
        begin: begin,
        end: end,
      };
      const response = await GetDPMOutputReviewRptKeyValue(data);
      const queryResult = response.data.QueryResult;
      if (queryResult === "OK") {
        this.teamList = response.data.ReturnObject;
      } else {
        this.alertMsg(queryResult);
      }
    },
    async getQueryLineList() {
      this.clearListData(1);
      const begin = this.$utils.GetDateString(this.pickDates[0]);
      const end = this.$utils.GetDateString(this.pickDates[1]);
      const data = {
        type: "userline",
        key: this.queryTeam,
        begin: begin,
        end: end,
      };
      const response = await GetDPMOutputReviewRptKeyValue(data);
      const queryResult = response.data.QueryResult;
      if (queryResult === "OK") {
        this.lineList = response.data.ReturnObject;
      } else {
        this.alertMsg(queryResult);
      }
    },
    async getModelList() {
      this.clearListData(0);
      const begin = this.$utils.GetDateString(this.pickDates[0]);
      const end = this.$utils.GetDateString(this.pickDates[1]);
      const data = {
        type: "model",
        key: this.queryLine,
        begin: begin,
        end: end,
      };
      const response = await GetDPMOutputReviewRptKeyValue(data);
      const queryResult = response.data.QueryResult;
      this.modelList.push({
        key: "ALL",
        data: "ALL",
      });
      if (queryResult === "OK") {
        response.data.ReturnObject.forEach((x) => {
          this.modelList.push(x);
        });
      } else {
        this.alertMsg(queryResult);
      }
    },
    async queryData(type, key) {
      if (this.queryLine === "") {
        this.alertMsg("查詢條件未選擇完畢");
        return;
      }
      let modelList = "";
      if (this.queryModel.length === 0) {
        modelList = "ALL";
      } else {
        this.queryModel.forEach((x) => {
          modelList = modelList + x + ",";
        });
        if (modelList.length > 1) {
          modelList = modelList.substr(0, modelList.length - 1);
        }
      }
      const factory = this.factoryList.filter(
        (x) => x.key === this.queryFactory
      )[0].data;
      const area = this.areaList.filter((x) => x.key === this.queryArea)[0]
        .data;
      const team = this.teamList.filter((x) => x.key === this.queryTeam)[0]
        .data;
      const line = this.lineList.filter((x) => x.key === this.queryLine)[0]
        .data;
      const begin = this.$utils.GetDateString(this.pickDates[0]);
      const end = this.$utils.GetDateString(this.pickDates[1]);
      let stdYM = "";
      if (this.querySTDUPHYearMonth !== "") {
        stdYM = this.$utils.GetDateString(this.querySTDUPHYearMonth);
        stdYM = stdYM.substr(0, 7);
      }
      const data = {
        factory: factory,
        area: area,
        team: team,
        line: line,
        modelList: modelList,
        begin: begin,
        end: end,
        type: type,
        key: key,
        stdYM: stdYM,
      };
      let title = "";
      let subTitle = "";
      switch (type) {
        case "month":
          this.destroyAllChart();
          var chartDomYM = document.getElementById("elYM");
          this.chartYM = this.$echarts.init(chartDomYM);
          title =
            factory + " " + area + " " + team + " " + line + "產出趨勢(年月)";
          subTitle = "時段: " + begin + " To " + end;
          this.chartYM.showLoading();
          break;
        case "day":
          this.destoryChart(this.chartDay);
          this.destoryChart(this.chartHour);
          var chartDomDAY = document.getElementById("elDay");
          this.chartDay = this.$echarts.init(chartDomDAY);
          title =
            factory + " " + area + " " + team + " " + line + "產出趨勢(日)";
          subTitle = "年月: " + key;
          this.chartDay.showLoading();
          break;
        case "hour":
          this.destoryChart(this.chartHour);
          var chartDomHOUR = document.getElementById("elHour");
          this.chartHour = this.$echarts.init(chartDomHOUR);
          title =
            factory + " " + area + " " + team + " " + line + "產出趨勢(時段)";
          subTitle = "日期: " + key;
          this.chartHour.showLoading();
          break;
      }
      const response = await GetDPMOutputReviewRptData(data);
      const queryResult = response.data.QueryResult;
      if (queryResult === "OK") {
        const obj = response.data.ReturnObject;
        switch (type) {
          case "month":
            this.chartYM.hideLoading();
            this.setChart(this.chartYM, obj, title, subTitle, type);
            break;
          case "day":
            this.chartDay.hideLoading();
            this.setChart(this.chartDay, obj, title, subTitle, type);
            break;
          case "hour":
            this.chartHour.hideLoading();
            if (obj.stdHCString !== "") {
              subTitle = subTitle + " [" + obj.stdHCString + "]";
            }
            this.setChartHour(this.chartHour, obj, title, subTitle, type);
            break;
        }
      } else {
        if (this.chartYM != null) {
          this.chartYM.hideLoading();
        }
        if (this.chartDay != null) {
          this.chartDay.hideLoading();
        }
        if (this.chartHour != null) {
          this.chartHour.hideLoading();
        }
        this.alertMsg(queryResult);
      }
    },
    setChart(chart, data, title, subTitle, type) {
      const series = [];
      data.series.forEach((x) => {
        series.push({
          name: x.name,
          type: x.type,
          // stack: x.stack,
          data: x.data,
        });
      });
      chart.clear();
      const option = {
        title: {
          text: title,
          subtext: subTitle,
        },
        tooltip: {
          trigger: "axis",
        },
        legend: {
          data: data.legendData,
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: true },
            saveAsImage: {},
          },
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: data.xAxisData,
        },
        yAxis: {
          type: "value",
        },
        series: series,
      };
      chart.setOption(option);
      const that = this;
      chart.on("click", function (params) {
        if (type === "month") {
          that.queryData("day", params.name);
        } else if (type === "day") {
          that.queryData("hour", params.name);
        }
      });
      // 显示完图表以后，再显示点击最后一个点后带出的信息
      let queryItem = "";
      try {
        if (data.xAxisData.length > 0) {
          queryItem = data.xAxisData[data.xAxisData.length - 1];
          if (type === "month") {
            this.destoryChart(this.chartDay);
            this.destoryChart(this.chartHour);
            this.queryData("day", queryItem);
          } else if (type === "day") {
            this.destoryChart(this.chartHour);
            that.queryData("hour", queryItem);
          }
        }
        // eslint-disable-next-line no-empty
      } catch {}
    },
    setChartHour(chart, data, title, subTitle, type) {
      const series = [];
      data.series.forEach((x) => {
        if (x.name.indexOf("人力") == -1) {
          series.push({
            name: x.name,
            type: x.type,
            data: x.data,
          });
        } else {
          series.push({
            yAxisIndex: 1,
            name: x.name,
            type: "bar",
            barWidth: 10,
            data: x.data,
          });
        }
      });
      chart.clear();
      const option = {
        title: {
          text: title,
          subtext: subTitle,
        },
        tooltip: {
          trigger: "axis",
        },
        legend: {
          data: data.legendData,
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "14%",
          containLabel: true,
        },
        // dataZoom: [
        //   {
        //     type: "inside",
        //   },
        //   {
        //     type: "slider",
        //   },
        // ],
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: true },
            saveAsImage: {},
          },
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: true,
            data: data.xAxisData,
          },
        ],
        yAxis: [
          {
            type: "value",
          },
          {
            type: "value",
            max: (value) => {
              return value.max;
            },
            min: (value) => {
              return value.min;
            },
            splitLine: {
              show: false,
            },
          },
        ],
        series: series,
      };
      chart.setOption(option);
    },
    yAxisData(number = 0) {
      console.log(number, "number");
      if (number > 0) {
        return [
          {
            type: "value",
            max: (value) => {
              return value.max;
            },
            min: (value) => {
              return value.min;
            },
          },
          {
            type: "value",
            max: (value) => {
              return value.max;
            },
            min: (value) => {
              return value.min;
            },
            splitLine: {
              show: false,
              lineStyle: {
                color: "#222324",
              },
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: "#222324",
              },
            },
            axisLabel: {
              margin: 8,
              formatter: "{value}%",
              textStyle: {
                color: "rgba(255,255,255,0.9)",
              },
            },
          },
        ];
      } else {
        return {
          type: "value",
        };
      }
    },
    destroyAllChart() {
      this.destoryChart(this.chartYM);
      this.destoryChart(this.chartDay);
      this.destoryChart(this.chartHour);
    },
    destoryChart(chart) {
      if (chart !== null && chart !== "" && chart !== undefined) {
        chart.dispose();
      }
    },
    alertMsg(msg) {
      this.$alert(msg, "提示", {
        confirmButtonText: "確定",
        type: "error",
      });
    },
  },
};
</script>
<style lang="less" scoped>
::v-deep main.el-main {
  padding: 0;
}
::v-deep .el-divider--horizontal {
  margin: 0;
}
.selectMiniSize {
  width: 100px;
  margin-right: 5px;
}
.selectMidSize {
  width: 120px;
  margin-right: 5px;
}
section {
  padding-bottom: 0;
}
.el-header {
  padding: 0 5px;
}
.header {
  // height:40px !important;
  // background-color:#1f4e7c;
  background-color: rgba(0, 0, 0, 0);
}
::v-deep .el-carousel__container {
  height: calc(100% - 55px);
  background-color: rgba(0, 0, 0, 0);
}
.mainDiv {
  width: 100%;
  height: calc(100% - 1px);
  // background: white;
}
.topDiv {
  width: 100%;
  height: 34%;
  background: white;
}
.middleDiv {
  margin-top: 5px;
  height: calc(33% - 5px);
  width: 100%;
  background: white;
}
.bottomDiv {
  margin-top: 5px;
  height: calc(33% - 5px);
  width: 100%;
  background: white;
}
</style>
