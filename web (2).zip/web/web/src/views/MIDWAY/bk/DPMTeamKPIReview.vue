<template>
  <div style="height:100%;width:100%;">
    <el-container style="height:100%;">
      <el-header class="header">
        <el-button v-show="showTypeBtnMsg==='YOY' || showTypeBtnMsg==='匯總表'" type="primary" round style="margin-right:20px;" size="small" @click="changePage">{{ showTypeBtnMsg }}</el-button>
        <div v-show="showTypeBtnMsg==='YOY'" style="display:inline">
          <el-select v-model="queryFactory" size="small" class="selectMidSize" placeholder="廠別" @change="getQueryAreaList">
            <el-option
              v-for="item in factoryList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-select v-model="queryArea" size="small" class="selectMidSize" placeholder="區域" @change="getQueryTeamList">
            <el-option
              v-for="item in areaList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-select v-model="queryTeam" size="small" class="selectMidSize" placeholder="Team">
            <el-option
              v-for="item in teamList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <span class="topLineSpan">時間顆粒度>></span>
          <el-button :type="queryType==='year'?'success':'warning'" size="small" @click="queryData('year')">By 年/季</el-button>
          <el-button :type="queryType==='month'?'success':'warning'" size="small" @click="queryData('month')">By 月</el-button>
          <el-button :type="queryType==='week'?'success':'warning'" size="small" @click="queryData('week')">By 周</el-button>
          <el-button :type="queryType==='day'?'success':'warning'" size="small" @click="queryData('day')">By 日</el-button>
        </div>
        <div v-show="showTypeBtnMsg==='匯總表'" style="display:inline">
          <span class="topLineSpan">區域KPI YOY比較>></span>
          <el-button :type="yoyKPI==='Output'?'success':'warning'" size="small" @click="setYOYKPI('Output')">Output</el-button>
          <el-button :type="yoyKPI==='OnlineUPPH'?'success':'warning'" size="small" @click="setYOYKPI('OnlineUPPH')">Online UPPH</el-button>
          <el-button :type="yoyKPI==='EFF'?'success':'warning'" size="small" @click="setYOYKPI('EFF')">EFF</el-button>
          <el-button :type="yoyKPI==='RTY'?'success':'warning'" size="small" @click="setYOYKPI('RTY')">RTY</el-button>
          <el-button :type="yoyKPI==='OEE2'?'success':'warning'" size="small" @click="setYOYKPI('OEE2')">OEE2</el-button>
        </div>
        <div v-show="showTypeBtnMsg==='HISTORY'" style="display:inline">
          <el-button v-show="showTypeBtnMsg==='HISTORY'" type="primary" round style="margin-right:20px;" size="small" @click="closeHistory">返回</el-button>
          <span class="topLineSpan">KPI歷史數據匯總</span>
          <el-select v-model="queryFactoryHistory" size="small" class="selectMidSize" placeholder="廠別" disabled @change="getQueryAreaListHistory"> <!--20230111 Kimi 禁用选择-->
            <el-option
              v-for="item in factoryListHistory"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-select v-model="queryAreaHistory" size="small" class="selectMidSize" placeholder="區域" disabled @change="getQueryTeamListHistory"> <!--20230111 Kimi 禁用选择-->
            <el-option
              v-for="item in areaListHistory"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-select v-model="queryTeamHistory" size="small" class="selectMidSize" placeholder="Team">
            <el-option
              v-for="item in teamListHistory"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-date-picker v-model="queryMonth" size="small" style="width:120px;margin-right:5px" type="month" placeholder="月份" />
          <el-select v-model="queryShift" placeholder="班別" style="width:100px;margin-right:5px" size="small">
            <el-option label="ALL" value="ALL" />
            <el-option label="白班" value="D" />
            <el-option label="夜班" value="N" />
          </el-select>
          <el-select v-model="queryKpi" size="small" class="selectMidSize" placeholder="KPI">
            <el-option
              v-for="item in kpiList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-button type="primary" size="small" @click="queryKPIData">查詢</el-button>
          <el-button type="primary" size="small" @click="downloadData()">下載</el-button>
        </div>
      </el-header>
      <el-main style="padding:0;">
        <div v-show="showTypeBtnMsg==='YOY'" style="height:100%">
          <el-table
            v-loading="loading"
            :data="tableData"
            size="small"
            stripe
            :header-cell-style="getHeaderCellColor"
            :cell-style="getCellColor"
            style="width: 100%;"
          >
            <el-table-column
              v-for="(o, index) in colSetting"
              :key="index"
              :prop="o.prop"
              :label="o.label"
              :width="o.width"
              align="center"
            >
              <template slot-scope="scope">
                <el-link v-if="o.prop==='kpi'" :underline="false" @click="showIndexDialog(scope.row[o.prop])"><span class="defTableCell">{{ scope.row[o.prop] }}</span></el-link>
                <span v-else><span class="defTableCell">{{ scope.row[o.prop] }}</span></span>
              </template>
            </el-table-column>
          </el-table>
          <span class="chartHeadSpan">指標>></span>
          <el-button :type="mainChartKPI==='Output'?'success':'warning'" size="small" @click="setChart('Output')">Output</el-button>
          <el-button :type="mainChartKPI==='OnlineUPPH'?'success':'warning'" size="small" @click="setChart('OnlineUPPH')">Online UPPH</el-button>
          <el-button :type="mainChartKPI==='EFF'?'success':'warning'" size="small" @click="setChart('EFF')">EFF</el-button>
          <el-button :type="mainChartKPI==='RTY'?'success':'warning'" size="small" @click="setChart('RTY')">RTY</el-button>
          <el-button :type="mainChartKPI==='OEE2'?'success':'warning'" size="small" @click="setChart('OEE2')">OEE2</el-button>
          <div id="elChart" class="chartDiv" />
        </div>
        <div v-show="showTypeBtnMsg==='匯總表'" style="height:100%">
          <div class="YOYMainDiv">
            <div class="YOYLeftDiv">
              <el-form label-width="90px" :model="formYOY" size="small" style="padding-top:20px">
                <el-form-item label="廠別">
                  <el-select v-model="formYOY.factory" size="small" multiple collapse-tags placeholder="必選欄位" style="width:240px" @change="getYOYAreaList">
                    <el-option
                      v-for="item in yoyFactoryList"
                      :key="item.key"
                      :label="item.data"
                      :value="item.key"
                    />
                  </el-select>
                </el-form-item>
                <el-form-item label="區域">
                  <el-select v-model="formYOY.area" size="small" multiple collapse-tags placeholder="可選欄位" style="width:240px" @change="getYOYTeamList">
                    <el-option-group
                      v-for="group in yoyAreaList"
                      :key="group.label"
                      :label="group.label"
                    >
                      <el-option
                        v-for="item in group.options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      />
                    </el-option-group>
                  </el-select>
                </el-form-item>
                <el-form-item label="Team">
                  <el-select v-model="formYOY.team" size="small" multiple collapse-tags placeholder="可選欄位" style="width:240px" @change="getYOYLineList">
                    <el-option-group
                      v-for="group in yoyTeamList"
                      :key="group.label"
                      :label="group.label"
                    >
                      <el-option
                        v-for="item in group.options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      />
                    </el-option-group>
                  </el-select>
                </el-form-item>
                <el-form-item label="線別">
                  <el-select v-model="formYOY.line" size="small" multiple collapse-tags placeholder="可選欄位" style="width:240px">
                    <el-option-group
                      v-for="group in yoyLineList"
                      :key="group.label"
                      :label="group.label"
                    >
                      <el-option
                        v-for="item in group.options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      />
                    </el-option-group>
                  </el-select>
                </el-form-item>
                <el-form-item label="比對點數量">
                  <el-select v-model="formYOY.qty" size="small" placeholder="比對點數量" style="width:240px">
                    <el-option label="2" value="2" />
                    <el-option label="3" value="3" />
                    <el-option label="4" value="4" />
                    <el-option label="5" value="5" />
                    <el-option label="6" value="6" />
                    <el-option label="7" value="7" />
                    <el-option label="8" value="7" />
                    <el-option label="9" value="9" />
                    <el-option label="10" value="10" />
                  </el-select>
                </el-form-item>
              </el-form>
              <el-button type="primary" size="small" style="margin-left:20px;width:calc(100% - 45px)" @click="queryYOYData">查詢</el-button>
              <br>
              <br>
              <span style="display:inline-block;font-weight:blod;padding-left:20px;padding-right:10px">顯示方式：</span>
              <el-radio-group v-model="showTypeRadio" @change="setShowData">
                <el-radio :label="1">按數值</el-radio>
                <el-radio :label="2">按百分比</el-radio>
              </el-radio-group>
            </div>
            <div class="YOYRightDiv">
              <div class="YOYContentDiv">
                <div id="yoyTable" class="YOYContentTable">
                  <el-table
                    v-loading="loading"
                    :data="tableYOYYear"
                    size="small"
                    stripe
                    :height="yoyTableHeight"
                    :header-cell-style="getHeaderCellColor"
                    style="width: 100%;"
                  >
                    <el-table-column
                      v-for="(o, index) in colYOYYearSetting"
                      :key="index"
                      :prop="o.prop"
                      :label="o.label"
                      :width="o.width"
                      align="center"
                    />
                  </el-table>
                </div>
                <div id="elYOYChartYear" class="YOYChart" />
              </div>
              <div class="YOYContentDiv">
                <div class="YOYContentTable">
                  <el-table
                    v-loading="loading"
                    :data="tableYOYQuarter"
                    size="small"
                    stripe
                    :height="yoyTableHeight"
                    :header-cell-style="getHeaderCellColor"
                    style="width: 100%;"
                  >
                    <el-table-column
                      v-for="(o, index) in colYOYQuarterSetting"
                      :key="index"
                      :prop="o.prop"
                      :label="o.label"
                      :width="o.width"
                      align="center"
                    />
                  </el-table>
                </div>
                <div id="elYOYChartQuarter" class="YOYChart" />
              </div>
              <div class="YOYContentDiv">
                <div class="YOYContentTable">
                  <el-table
                    v-loading="loading"
                    :data="tableYOYMonth"
                    size="small"
                    stripe
                    :height="yoyTableHeight"
                    :header-cell-style="getHeaderCellColor"
                    style="width: 100%;"
                  >
                    <el-table-column
                      v-for="(o, index) in colYOYMonthSetting"
                      :key="index"
                      :prop="o.prop"
                      :label="o.label"
                      :width="o.width"
                      align="center"
                    />
                  </el-table>
                </div>
                <div id="elYOYChartMonth" class="YOYChart" />
              </div>
            </div>
          </div>
        </div>
        <div v-show="showTypeBtnMsg==='HISTORY'" style="height:100%;">
          <modupphv2 v-if="queryKpi==='UPPH'" ref="modRef" :onedata="sendtooperate" />
          <modeff v-if="queryKpi==='EFF'" ref="modRef" :onedata="sendtooperate" />
          <moduph v-if="queryKpi==='UPH'" ref="modRef" :onedata="sendtooperate" />
          <moduts v-if="queryKpi==='UTS'" ref="modRef" :onedata="sendtooperate" />
          <modoatl v-if="queryKpi==='OATL'" ref="modRef" :onedata="sendtooperate" />
          <modlrr v-if="queryKpi==='LRR'" ref="modRef" :onedata="sendtooperate" />
          <!-- 20230102 Kimi Add Output Index -->
          <modoutput v-if="queryKpi==='Output'" ref="modRef" :onedata="sendtooperate" />
          <!-- 20230111 Kimi Add RTY -->
          <modrty v-if="queryKpi==='RTY'" ref="modRef" :onedata="sendtooperate" />
          <!-- 20230111 Kimi Add OEE1 -->
          <modoee1 v-if="queryKpi==='OEE1'" ref="modRef" :onedata="sendtooperate" />
          <!-- 20230111 Kimi Add OEE2 -->
          <modoee2 v-if="queryKpi==='OEE2'" ref="modRef" :onedata="sendtooperate" />
          <!-- 20230111 Kimi Add OAIL -->
          <modoail v-if="queryKpi==='OAIL'" ref="modRef" :onedata="sendtooperate" />

          <DPMTeamKPIInputMod v-if="queryKpi==='Input'" ref="modRef" :onedata="sendtooperate" />
        </div>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import $ from 'jquery'
import {
  GetDPMQueryKeyValue, GetDPMTeamKPIReviewMainData, GetDPMTeamKPIReviewYOYData
} from '@/api/midway.js'
import modupphv2 from '@/components/MIDWAY/DPMTeamKPI_UPPHModV2.vue'
import modeff from '@/components/MIDWAY/DPMTeamKPI_EFFMod.vue'
import moduph from '@/components/MIDWAY/DPMTeamKPI_UPHMod.vue'
import modoatl from '@/components/MIDWAY/DPMTeamKPI_OATLMod.vue'
import modlrr from '@/components/MIDWAY/DPMTeamKPI_LRRMod.vue'
import moduts from '@/components/MIDWAY/DPMTeamKPI_UTSMod.vue'
import modoutput from '@/components/MIDWAY/DPMTeamKPI_OutputMod.vue' // 20230102 Kimi Add，UTS替换为Output
import modrty from '@/components/MIDWAY/DPMTeamKPI_RTYMod.vue' // 20230111 Kimi Add RTY
import modoee1 from '@/components/MIDWAY/DPMTeamKPI_OEE1Mod.vue' // 20230111 Kimi Add OEE1
import modoee2 from '@/components/MIDWAY/DPMTeamKPI_OEE2Mod.vue' // 20230111 Kimi Add OEE2
import modoail from '@/components/MIDWAY/DPMTeamKPI_OAILMod.vue' // 20230111 Kimi Add OAIL
import DPMTeamKPIInputMod from '@/components/MIDWAY/DPMTeamKPI_InputMod.vue' // 20230111 Kimi Add OAIL
export default {
  components: {
    modupphv2,
    modeff,
    moduph,
    modoatl,
    modlrr,
    moduts,
    modoutput, // 20230102 Kimi Add
    modrty, // 20230111 Kimi Add RTY
    modoee1, // 20230111 Kimi Add OEE1
    modoee2, // 20230111 Kimi Add OEE2
    modoail, // 20230111 Kimi Add OAIL
    DPMTeamKPIInputMod
  },
  data() {
    return {
      showTypeBtnMsg: 'YOY',
      queryDay: '',
      queryFactory: '',
      factoryList: [],
      queryArea: '',
      areaList: [],
      queryTeam: '',
      teamList: [],
      tableHeight: 1,
      loadingData: null,
      loading: false,
      chart: null,
      queryType: '',
      mainChartKPI: '',
      colSetting: [],
      tableData: [],
      mainObject: null,
      formYOY: {
        factory: [],
        area: [],
        team: [],
        line: [],
        qty: 2
      },
      yoyTableHeight: 1,
      yoyFactory: [],
      yoyArea: [],
      yoyLine: [],
      yoyFactoryList: [],
      yoyAreaList: [],
      yoyTeamList: [],
      yoyLineList: [],
      yoyKPI: 'Output',
      chartYOYYear: null,
      chartYOYQuarter: null,
      chartYOYMonth: null,
      tableYOYYear: [],
      colYOYYearSetting: [],
      tableYOYQuarter: [],
      colYOYQuarterSetting: [],
      tableYOYMonth: [],
      colYOYMonthSetting: [],
      yoyObjectData: null,
      showTypeRadio: 1,
      indexDialogTitle: '',
      indexDialogVisible: false,
      sendtooperate: {
        from: 'kpireview',
        factory: '',
        area: '',
        team: '',
        yearMonth: '',
        shift: '',
        kpi: ''
      },
      factoryListHistory: [],
      areaListHistory: [],
      teamListHistory: [],
      queryFactoryHistory: '',
      queryAreaHistory: '',
      queryTeamHistory: '',
      queryMonth: '',
      queryShift: 'ALL',
      queryKpi: '',
      kpiList: []
    }
  },
  computed: {
  },
  mounted() {
    this.resizeTable()
    this.getDefaultDate()
    this.getQueryFactoryList()
    // this.initialData()
    window.onresize = () => {
      this.resizeTable()
      if (this.chart !== null) {
        this.chart.resize()
      }
      if (this.chartYOYYear !== null) {
        this.chartYOYYear.resize()
      }
      if (this.chartYOYQuarter !== null) {
        this.chartYOYQuarter.resize()
      }
      if (this.chartYOYMonth !== null) {
        this.chartYOYMonth.resize()
      }
    }
  },
  // beforeUpdate () {
  //   this.$nextTick(function () {
  //     this.$refs.refYT.doLayout()
  //   })
  // },
  beforeDestroy() {
  },
  methods: {
    getDefaultDate() {
      const curDate = new Date()
      this.queryDay = new Date(curDate.getTime() - 24 * 60 * 60 * 1000)
      this.queryMonth = new Date(curDate.getTime() - 24 * 60 * 60 * 1000)
    },
    changePage() {
      if (this.showTypeBtnMsg === 'YOY') {
        this.showTypeBtnMsg = '匯總表'
        this.$nextTick(function() {
        })
      } else {
        this.showTypeBtnMsg = 'YOY'
      }
      this.resizeTable()
    },
    closeHistory() {
      this.showTypeBtnMsg = 'YOY'
      this.resizeTable()
    },
    async getQueryFactoryList() {
      this.destroyChart()
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.factoryList = []
      this.yoyFactoryList = []
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.factoryList = response.data.ReturnObject
        this.yoyFactoryList = response.data.ReturnObject
        this.factoryListHistory = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryAreaList() {
      this.destroyChart()
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.kpiList = [] // 20230111 Kimi Factory选择时，清空kpi下拉框
      this.queryTeam = ''
      const data = {
        type: 'userarea',
        key: this.queryFactory
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryTeamList() {
      this.destroyChart()
      this.teamList = []
      this.kpiList = [] // 20230111 Kimi Factory选择时，清空kpi下拉框
      this.queryTeam = ''
      const data = {
        type: 'userteam',
        key: this.queryArea
      }
      this.teamList.push({
        key: 0,
        data: 'ALL'
      })
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        for (let i = 0; i < obj.length; i++) {
          this.teamList.push({
            key: obj[i].key,
            data: obj[i].data
          })
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getYOYAreaList() {
      if (this.formYOY.factory.length === 0) {
        this.alertMsg('請選擇廠別')
        return
      }
      this.yoyAreaList = []
      this.yoyTeamList = []
      this.yoyLineList = []
      this.formYOY.area = []
      this.formYOY.team = []
      this.formYOY.line = []

      for (let i = 0; i < this.formYOY.factory.length; i++) {
        const factoryName = this.yoyFactoryList.filter(x => x.key === this.formYOY.factory[i])[0].data
        const data = {
          type: 'userarea',
          key: this.formYOY.factory[i]
        }
        const response = await GetDPMQueryKeyValue(data)
        const queryResult = response.data.QueryResult
        const options = []
        if (queryResult === 'OK') {
          response.data.ReturnObject.forEach(x => {
            options.push({
              value: x.key,
              label: x.data
            })
          })
        } else {
          this.alertMsg(queryResult)
          return
        }
        this.yoyAreaList.push({
          label: factoryName,
          options: options
        })
      }
    },
    async getYOYTeamList() {
      if (this.formYOY.area.length === 0) {
        this.alertMsg('請選擇區域')
        return
      }
      this.yoyTeamList = []
      this.yoyLineList = []
      this.formYOY.team = []
      this.formYOY.line = []

      for (let i = 0; i < this.formYOY.area.length; i++) {
        const areaId = this.formYOY.area[i]
        let factoryName = ''
        let areaName = ''
        for (let j = 0; j < this.yoyAreaList.length; j++) {
          factoryName = this.yoyAreaList[j].label
          const obj = this.yoyAreaList[j].options
          for (let k = 0; k < obj.length; k++) {
            if (obj[k].value === areaId) {
              areaName = obj[k].label
              const data = {
                type: 'userteam',
                key: areaId
              }
              const response = await GetDPMQueryKeyValue(data)
              const queryResult = response.data.QueryResult
              const options = []
              if (queryResult === 'OK') {
                response.data.ReturnObject.forEach(x => {
                  options.push({
                    value: x.key,
                    label: x.data
                  })
                })
              } else {
                this.alertMsg(queryResult)
                return
              }
              this.yoyTeamList.push({
                label: factoryName + ' ' + areaName,
                options: options
              })
              break
            }
          }
        }
      }
    },
    async getYOYLineList() {
      if (this.formYOY.team.length === 0) {
        this.alertMsg('請選擇Team')
        return
      }
      this.yoyLineList = []
      this.formYOY.line = []

      for (let i = 0; i < this.formYOY.team.length; i++) {
        const teamId = this.formYOY.team[i]
        let factoryAndAreaName = ''
        let teamName = ''
        for (let j = 0; j < this.yoyTeamList.length; j++) {
          factoryAndAreaName = this.yoyTeamList[j].label
          const obj = this.yoyTeamList[j].options
          for (let k = 0; k < obj.length; k++) {
            if (obj[k].value === teamId) {
              teamName = obj[k].label
              const data = {
                type: 'userline',
                key: teamId
              }
              const response = await GetDPMQueryKeyValue(data)
              const queryResult = response.data.QueryResult
              const options = []
              if (queryResult === 'OK') {
                response.data.ReturnObject.forEach(x => {
                  options.push({
                    value: x.key,
                    label: x.data
                  })
                })
              } else {
                this.alertMsg(queryResult)
                return
              }
              this.yoyLineList.push({
                label: factoryAndAreaName + ' ' + teamName,
                options: options
              })
              break
            }
          }
        }
      }
    },
    async getYOYList() {
      if (this.formYOY.factory.length === 0) {
        this.alertMsg('請選擇廠別')
        return
      }
      this.yoyAreaList = []
      this.yoyLineList = []
      this.formYOY.area = []
      this.formYOY.line = []

      for (let i = 0; i < this.formYOY.factory.length; i++) {
        const factoryName = this.yoyFactoryList.filter(x => x.key === this.formYOY.factory[i])[0].data
        const data = {
          type: 'userarea',
          key: this.formYOY.factory[i]
        }
        const response = await GetDPMQueryKeyValue(data)
        const queryResult = response.data.QueryResult
        const options = []
        if (queryResult === 'OK') {
          response.data.ReturnObject.forEach(x => {
            options.push({
              value: x.key,
              label: x.data
            })
          })
        } else {
          this.alertMsg(queryResult)
          return
        }
        this.yoyAreaList.push({
          label: factoryName,
          options: options
        })
      }
    },
    async getQueryAreaListHistory() {
      this.getKpiList()
      this.areaListHistory = []
      this.queryAreaHistory = ''
      this.teamListHistory = []
      this.queryTeamHistory = ''
      const data = {
        type: 'userarea',
        key: this.queryFactoryHistory
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaListHistory = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryTeamListHistory() {
      this.teamListHistory = []
      this.queryTeamHistory = ''
      const data = {
        type: 'userteam',
        key: this.queryAreaHistory
      }
      this.teamListHistory.push({
        key: 0,
        data: 'ALL'
      })
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        for (let i = 0; i < obj.length; i++) {
          this.teamListHistory.push({
            key: obj[i].key,
            data: obj[i].data
          })
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getKpiList() {
      this.kpiList = []
      // 20230110 Kimi 增加Area传入，获取不同的KPI
      let area
      try {
        area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      } catch {
        area = this.areaListHistory.filter(x => x.key === this.queryAreaHistory)[0].data
      }
      this.queryKpi = ''
      const data = {
        type: 'kpi',
        key: this.queryFactoryHistory + ',' + area
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.kpiList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    getHeaderCellColor() {
      const style = {
        'background-color': 'rgb(32,55,100)',
        color: 'white'
      }
      return style
    },
    getCellColor({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        return 'color: black; background: rgb(221, 235, 247);'
      } else {
        return 'color: black'
      }
    },
    async queryData(type) {
      this.queryType = type
      if (this.queryFactory === '') {
        this.alertMsg('請選擇廠別')
        return
      }
      if (this.queryArea === '') {
        this.alertMsg('請選擇區域')
        return
      }
      if (this.queryTeam === '') {
        this.queryTeam = 0
      }
      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      const data = {
        factory: factory,
        area: area,
        team: team,
        range: this.queryType
      }
      this.loading = true
      const response = await GetDPMTeamKPIReviewMainData(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.mainObject = response.data.ReturnObject
        this.colSetting = this.mainObject.columns
        this.tableData = this.mainObject.kpiActTable
      } else {
        this.alertMsg(queryResult)
      }
    },
    destroyChart() {
      if (this.chart !== null && this.chart !== '' && this.chart !== undefined) {
        this.chart.dispose()
      }
    },
    destroyYOYChart(type) {
      if (type === 'year') {
        if (this.chartYOYYear !== null && this.chartYOYYear !== '' && this.chartYOYYear !== undefined) {
          this.chartYOYYear.dispose()
        }
      } else if (type === 'quarter') {
        if (this.chartYOYQuarter !== null && this.chartYOYQuarter !== '' && this.chartYOYQuarter !== undefined) {
          this.chartYOYQuarter.dispose()
        }
      } else if (type === 'month') {
        if (this.chartYOYMonth !== null && this.chartYOYMonth !== '' && this.chartYOYMonth !== undefined) {
          this.chartYOYMonth.dispose()
        }
      }
    },
    setChart(kpi) {
      // const rotate = 0
      // if (this.line === '' || this.line.toLowerCase() === 'overall') {
      //   rotate = -30
      // }
      this.mainChartKPI = kpi
      this.destroyChart()
      if (this.mainObject === null) {
        return
      }
      const dataXAxis = []
      const dataAct = []
      const dataGoal = []
      const objAct = this.mainObject.kpiActTable.filter(x => x.kpi === kpi)
      const objGoal = this.mainObject.kpiGoalTable.filter(x => x.kpi === kpi)
      if (objAct.length > 0 && objGoal.length > 0) {
        this.colSetting.forEach(x => {
          const prop = x.prop
          if (prop !== 'kpi') {
            dataXAxis.push(x.label)
            dataAct.push(objAct[0][prop])
            dataGoal.push(objGoal[0][prop])
          }
        })
      }
      const option = {
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: [kpi, 'Goal']
        },
        xAxis: {
          type: 'category',
          data: dataXAxis
          // axisLabel: {
          //   interval: 'auto',
          //   rotate: rotate
          // }
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: kpi,
            data: dataAct,
            type: 'line'
          },
          {
            name: 'Goal',
            data: dataGoal,
            type: 'line'
          }
        ]
      }
      const chartDom = document.getElementById('elChart')
      this.chart = this.$echarts.init(chartDom)
      this.chart.clear()
      this.chart.setOption(option)
    },
    setYOYKPI(kpi) {
      this.yoyKPI = kpi
    },
    async queryYOYData() {
      if (this.yoyKPI === '') {
        this.alertMsg('請選擇KPI')
        return
      }
      if (this.yoyKPI === 'OEE2') {
        this.alertMsg('OEE2還未開放查詢')
        return
      }
      let factoryList = ''
      let areaList = ''
      let teamList = ''
      let lineList = ''
      this.formYOY.factory.forEach(x => {
        factoryList = factoryList + x + ','
      })
      if (factoryList.length > 0) {
        factoryList = factoryList.substr(0, factoryList.length - 1)
      }
      if (factoryList === '') {
        this.alertMsg('至少選擇廠別')
        return
      }
      this.formYOY.area.forEach(x => {
        areaList = areaList + x + ','
      })
      if (areaList.length > 0) {
        areaList = areaList.substr(0, areaList.length - 1)
      }
      this.formYOY.team.forEach(x => {
        teamList = teamList + x + ','
      })
      if (teamList.length > 0) {
        teamList = teamList.substr(0, teamList.length - 1)
      }
      this.formYOY.line.forEach(x => {
        lineList = lineList + x + ','
      })
      if (lineList.length > 0) {
        lineList = lineList.substr(0, lineList.length - 1)
      }
      if (this.yoyKPI === 'EFF') {
        if (areaList === '') {
          this.alertMsg('EFF不支持廠級查詢')
          return
        }
      }
      this.yoyObjectData = null
      const data = {
        factoryList: factoryList,
        areaList: areaList,
        teamList: teamList,
        lineList: lineList,
        kpi: this.yoyKPI,
        qty: this.formYOY.qty
      }
      this.loadingData = this.$loading({
        lock: true,
        text: '正在加載數據，請耐心等待...',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await GetDPMTeamKPIReviewYOYData(data)
      const queryResult = response.data.QueryResult
      this.loadingData.close()
      if (queryResult === 'OK') {
        this.yoyObjectData = response.data.ReturnObject
        this.colYOYYearSetting = this.yoyObjectData.columnsYear
        this.colYOYQuarterSetting = this.yoyObjectData.columnsQuarter
        this.colYOYMonthSetting = this.yoyObjectData.columnsMonth
        this.setShowData()
      } else {
        this.alertMsg(queryResult)
      }
    },
    setShowData() {
      if (this.yoyObjectData !== null) {
        if (this.showTypeRadio === 1) {
          this.tableYOYYear = this.yoyObjectData.yoyYearTable
          this.tableYOYQuarter = this.yoyObjectData.yoyQuarterTable
          this.tableYOYMonth = this.yoyObjectData.yoyMonthTable
        } else {
          this.tableYOYYear = this.yoyObjectData.yoyRateYearTable
          this.tableYOYQuarter = this.yoyObjectData.yoyRateQuarterTable
          this.tableYOYMonth = this.yoyObjectData.yoyRateMonthTable
        }
        this.setYOYChartYear()
        this.setYOYChartQuarter()
        this.setYOYChartMonth()
      }
    },
    setYOYChartYear() {
      this.destroyYOYChart('year')
      const legend = []
      const xAxis = []
      const series = []
      this.colYOYYearSetting.forEach(x => {
        if (x.prop !== 'item') {
          xAxis.push(x.label)
        }
      })
      this.tableYOYYear.forEach(x => {
        const data = []
        for (let i = 0; i < this.colYOYYearSetting.length; i++) {
          const prop = this.colYOYYearSetting[i].prop
          if (prop !== 'item') {
            data.push(x[prop])
          }
        }
        legend.push(x.item)
        series.push({
          name: x.item,
          data: data,
          type: 'line'
        })
      })
      const option = {
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        title: {
          text: this.yoyKPI + ' YOY By Year' + (this.showTypeRadio === 2 ? ' [%]' : '')
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: legend
        },
        xAxis: {
          type: 'category',
          data: xAxis
        },
        yAxis: {
          type: 'value'
        },
        series: series
      }
      const chartDom = document.getElementById('elYOYChartYear')
      this.chartYOYYear = this.$echarts.init(chartDom)
      this.chartYOYYear.clear()
      this.chartYOYYear.setOption(option)
    },
    setYOYChartQuarter() {
      this.destroyYOYChart('quarter')
      const legend = []
      const xAxis = []
      const series = []
      this.colYOYQuarterSetting.forEach(x => {
        if (x.prop !== 'item') {
          xAxis.push(x.label)
        }
      })
      this.tableYOYQuarter.forEach(x => {
        const data = []
        for (let i = 0; i < this.colYOYQuarterSetting.length; i++) {
          const prop = this.colYOYQuarterSetting[i].prop
          if (prop !== 'item') {
            data.push(x[prop])
          }
        }
        legend.push(x.item)
        series.push({
          name: x.item,
          data: data,
          type: 'line'
        })
      })
      const option = {
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        title: {
          text: this.yoyKPI + ' YOY By Quarter' + (this.showTypeRadio === 2 ? ' [%]' : '')
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: legend
        },
        xAxis: {
          type: 'category',
          data: xAxis
        },
        yAxis: {
          type: 'value'
        },
        series: series
      }
      const chartDom = document.getElementById('elYOYChartQuarter')
      this.chartYOYQuarter = this.$echarts.init(chartDom)
      this.chartYOYQuarter.clear()
      this.chartYOYQuarter.setOption(option)
    },
    setYOYChartMonth() {
      this.destroyYOYChart('month')
      const legend = []
      const xAxis = []
      const series = []
      this.colYOYMonthSetting.forEach(x => {
        if (x.prop !== 'item') {
          xAxis.push(x.label)
        }
      })
      this.tableYOYMonth.forEach(x => {
        const data = []
        for (let i = 0; i < this.colYOYMonthSetting.length; i++) {
          const prop = this.colYOYMonthSetting[i].prop
          if (prop !== 'item') {
            data.push(x[prop])
          }
        }
        legend.push(x.item)
        series.push({
          name: x.item,
          data: data,
          type: 'line'
        })
      })
      const option = {
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        title: {
          text: this.yoyKPI + ' YOY By Month' + (this.showTypeRadio === 2 ? ' [%]' : '')
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: legend
        },
        xAxis: {
          type: 'category',
          data: xAxis
        },
        yAxis: {
          type: 'value'
        },
        series: series
      }
      const chartDom = document.getElementById('elYOYChartMonth')
      this.chartYOYMonth = this.$echarts.init(chartDom)
      this.chartYOYMonth.clear()
      this.chartYOYMonth.setOption(option)
    },
    async showIndexDialog(kpi) {
      this.queryFactoryHistory = this.queryFactory
      const data = {
        type: 'userarea',
        key: this.queryFactoryHistory
      }
      this.getKpiList()
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaListHistory = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
        return
      }
      this.queryAreaHistory = this.queryArea
      const data2 = {
        type: 'userteam',
        key: this.queryAreaHistory
      }
      this.teamListHistory = []
      this.teamListHistory.push({
        key: 0,
        data: 'ALL'
      })
      const response2 = await GetDPMQueryKeyValue(data2)
      const queryResult2 = response.data.QueryResult
      if (queryResult2 === 'OK') {
        const obj = response2.data.ReturnObject
        for (let i = 0; i < obj.length; i++) {
          this.teamListHistory.push({
            key: obj[i].key,
            data: obj[i].data
          })
        }
      } else {
        this.alertMsg(queryResult2)
        return
      }
      this.queryTeamHistory = this.queryTeam
      this.queryKpi = kpi
      this.queryShift = 'ALL'
      this.queryKPIData()
    },
    queryKPIData() {
      const area = this.areaListHistory.filter(x => x.key === this.queryAreaHistory)[0].data
      switch (this.queryKpi.toUpperCase()) {
        // 20230102 Kimi Output改用Output，不再使用UTS
        // case 'OUTPUT':
        //   this.queryKpi = 'UTS'
        //   break
        case 'ONLINEUPPH':
          this.queryKpi = 'UPPH'
          break
        case 'RTY':
          this.queryKpi = area === 'FATP' ? 'OATL' : 'RTY' // 20230111 Kimi PCBA直接查RTY，FATP保持OATL
          break
      }
      const factory = this.factoryListHistory.filter(x => x.key === this.queryFactoryHistory)[0].data
      const team = this.teamListHistory.filter(x => x.key === this.queryTeamHistory)[0].data
      this.indexDialogTitle = factory + ' ' + area + ' ' + team + ' ' + this.queryKpi + ' 詳情'
      const yM = this.$utils.GetDateString(this.queryMonth).substr(0, 7).replace('-', '')
      this.sendtooperate.factory = factory
      this.sendtooperate.area = area
      this.sendtooperate.team = team
      this.sendtooperate.yearMonth = yM
      this.sendtooperate.shift = this.queryShift
      this.sendtooperate.kpi = this.queryKpi
      this.showTypeBtnMsg = 'HISTORY'
      this.$nextTick(function() {
        const refKpi = this.$refs.modRef
        if (refKpi != null && refKpi !== undefined) {
          refKpi.initialData()
        }
      })
    },
    downloadData: function() {
      if (this.queryFactoryHistory === '') {
        this.alertMsg('請選擇廠別')
        return
      }
      if (this.queryAreaHistory === '') {
        this.alertMsg('請選擇區域')
        return
      }
      if (this.queryKpi === '') {
        this.alertMsg('請選擇KPI')
        return
      }
      if (this.queryTeamHistory === '') {
        this.queryTeamHistory = 0
      }
      if (this.queryShift === '') {
        this.queryShift = 'ALL'
        return
      }
      let kpi = this.queryKpi
      switch (this.queryKpi.toUpperCase()) {
        case 'UPPH':
          kpi = 'UPPH_v2'
          break
      }

      const factory = this.factoryListHistory.filter(x => x.key === this.queryFactoryHistory)[0].data
      const area = this.areaListHistory.filter(x => x.key === this.queryAreaHistory)[0].data
      const team = this.teamListHistory.filter(x => x.key === this.queryTeamHistory)[0].data
      let yM = this.$utils.GetDateString(this.queryMonth)
      yM = yM.substr(0, 7)

      var url = '/midway/downloadDPMTeamKPIHistoryData'
      url = url + '?factory=' + encodeURIComponent(factory) + '&area=' + encodeURIComponent(area) +
      '&team=' + encodeURIComponent(team) + '&yearMonth=' + encodeURIComponent(yM) +
      '&shift=' + this.queryShift + '&kpi=' + encodeURIComponent(kpi)

      const fileName = factory + '_' + area + '_' + team + '_' + kpi + '(' + yM + ').xlsx'
      this.$utils.downloadFile(url, fileName)
    },
    alertMsg(msg) {
      this.$alert(msg, '提示', {
        confirmButtonText: '確定',
        type: 'error'
      })
    },
    resizeTable: function() {
      this.$nextTick(function() {
        try {
          this.yoyTableHeight = $('#yoyTable').height()
        // eslint-disable-next-line no-empty
        } catch {}
      })
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep main.el-main{
  padding: 0
}
::v-deep .el-divider--horizontal{
  margin:0
}
.selectMidSize{
  width:120px;
  margin-right:5px;
}
.topLineSpan{
  display: inline-block;
  margin:0 10px;
  color: blue;
}
.chartHeadSpan{
  display: inline-block;
  color: blue;
  margin:20px 20px 20px 20px;
}
section{
  padding-bottom: 0;
}
.el-header{
    padding:0 5px
}
.header{
  height:40px !important;
  // background-color:#1f4e7c;
  background-color:rgba(0,0,0,0);
}
::v-deep .el-table td div{
  font-size: 16px;
}
.defTableCell{
  font-size: 16px;
  color: black;
}
// ::v-deep .el-table .cell {
//     white-space: pre-line;
// }
::v-deep .el-table td {
  border:1px solid lightgray;
}
::v-deep #txtIssueContent {
  color: blue
}
.chartDiv{
  // height:calc(100% - 75px);
  height:calc(100% - 315px);
  min-height: 200px;
  width:100%;
  background-color: white;
}
.YOYMainDiv{
  width:100%;
  height:100%;
  display: flex;
}
.YOYLeftDiv{
  height:100%;
  width:350px;
}
.YOYRightDiv{
  height:100%;
  width:calc(100% - 350px);
  background-color: white;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.YOYContentDiv{
  width:100%;
  height:33%;
  display: flex;
}
.YOYContentTable{
  height: 100%;
  width: 30%;
}
.YOYChart{
  height: 100%;
  width: 70%;
}
.modDiv{
  width:100%;
  height:100%;
}
</style>
