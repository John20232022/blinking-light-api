<template>
  <div style="height: 100%; width: 100%" :style="{ 'background-image': getBackgroundColor() }">
    <el-container style="height: 100%">
      <el-header class="header">
        <div class="titleDiv">
          <div class="titleLeft">
            <img src="../../../public/static/img/Branding_logo.png" class="titleImg">
            <div class="title" v-html="dataEntity.title" />
          </div>
          <div>
            <span class="refreshTime">{{ dataEntity.serverTime }}</span>
            <el-dropdown @command="moreMenuClickHandler">
              <el-button size="mini" plain type="primary" style="margin-left: 20px; background-color: rgba(0, 0, 0, 0)">
                操作<i class="el-icon-arrow-down el-icon--right" />
              </el-button>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item v-if="showReturnMenu" icon="el-icon-arrow-left" command="return">返回上層</el-dropdown-item>
                <el-dropdown-item icon="el-icon-data-analysis" command="max" divided>看板模式</el-dropdown-item>
                <el-dropdown-item icon="el-icon-monitor" command="min">窗體模式</el-dropdown-item>
                <el-dropdown-item :icon="autoRefresh === true ? 'el-icon-close' : 'el-icon-refresh'" command="refresh">{{
                  autoRefresh === true ? '停止刷新' : '自動刷新'
                }}</el-dropdown-item>
                <el-dropdown-item icon="el-icon-view" command="viewrange">{{
                  viewRange === 'currentshift' ? '顯示前一班' : '顯示當班'
                }}</el-dropdown-item>
                <el-dropdown-item icon="el-icon-edit-outline" divided command="addlog">異常記錄</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </div>
      </el-header>
      <el-main style="padding: 0">
        <el-divider />
        <div class="detailBody">
          <!--<div class="detailBodyRow">20221201 Kimi 调整Div高度-->
          <div :class="getDivClass('top')">
            <div class="detailBodyCell">
              <div style="width: 100%; text-align: center; overflow-x: auto">
                <table class="indexTable">
                  <tr>
                    <th v-for="(one, index) in dataEntity.index_charts" :key="index">
                      <div class="indexDiv">
                        <div v-if="one.title === 'UPH' || one.title === 'RTY' || one.title === 'OEE2'" class="indexTitleDiv">
                          <el-link :underline="false" @click="getIndexChartData(one.title)">
                            {{ one.title }}
                          </el-link>
                        </div>
                        <div v-else class="indexTitleDiv">
                          {{ one.title }}
                        </div>
                        <div class="indexUnitDiv">
                          {{ one.unit }}
                          <div v-if="one.has_error === 'Y'" class="warningDiv" />
                          <!--20221212 Kimi 有异常的指标增加标识-->
                        </div>
                        <div :id="'chartdiv' + one.title" class="indexChart" />
                      </div>
                    </th>
                  </tr>
                </table>
              </div>
              <div v-show="showKPIChart" id="elTopLeft" class="topLeftChart" />
              <div v-show="showRTYData" style="height: calc(100% - 160px)">
                <el-table
                  id="rtyOAILTable"
                  :cell-style="getCellColor"
                  :data="tableRTYOAIL"
                  size="small"
                  style="width: 100%; height: 45%; min-height: 120px"
                  :header-cell-style="getHeaderCellColor"
                ><!--20221201 Kimi 调整table高度--><!--20221212 Kimi 增加height,min-height-->
                  <el-table-column prop="item" :label="TableName1" width="120" align="center" show-overflow-tooltip /><!--20221201 Kimi 修改label-->
                  <el-table-column
                    v-for="(col, index) in rtyOAILCols"
                    :key="index"
                    :prop="col.prop"
                    :label="col.label"
                    :width="col.width"
                    align="center"
                  />
                </el-table>
                <el-table
                  id="rtyOATLTable"
                  :cell-style="getCellColor2"
                  :data="tableRTYOATL"
                  size="small"
                  style="width: 100%; margin-top: 5px; height: 55%; min-height: 160px"
                  :header-cell-style="getHeaderCellColor"
                ><!--20221201 Kimi 调整table高度--><!--20221212 Kimi 增加height,min-height-->
                  <el-table-column prop="item" :label="TableName2" width="120" align="center" show-overflow-tooltip /><!--20221201 Kimi 修改label-->
                  <el-table-column
                    v-for="(col, index) in rtyOATLCols"
                    :key="index"
                    :prop="col.prop"
                    :label="col.label"
                    :width="col.width"
                    align="center"
                  />
                </el-table>
              </div>
            </div>
            <div v-show="showKPIChart" id="elTopRight" class="detailBodyCell" />
            <div v-show="showRTYData" class="detailBodyCell">
              <div id="elRTYChart" />
              <el-table
                id="rtyTimeRangeTable"
                :data="tableRTYRange"
                size="small"
                style="width: 100%; margin-top: 5px"
                height="161"
                :header-cell-style="getHeaderCellColor"
              >
                <el-table-column prop="time_range" label="時間" width="150" align="center" show-overflow-tooltip />
                <el-table-column prop="reject_qty" label="Reject Qty" width="120" align="center" show-overflow-tooltip />
                <el-table-column prop="rty" label="RTY%" width="100" align="center" show-overflow-tooltip />
                <el-table-column prop="loss_reason" label="異常站點" align="center" show-overflow-tooltip />
              </el-table>
            </div>
          </div>
          <!--<div class="detailBodyRow1">20221201 Kimi 调整div高度，增加class detailBodyRow1-->
          <div :class="getDivClass('buttom')">
            <div id="tableContainer" class="detailBodyCell">
              <div class="tableTitle">{{ bottomLeftTitle }}</div>
              <table v-show="!showRTYData" class="tb">
                <tr v-show="showMasterStage">
                  <td class="tbCategory"><el-button round @click="showMasterStageView('', '', 0)">Major Stage</el-button></td>
                  <td v-for="(st, index) in dataEntity2.masterStage" :key="index" class="tbValue" :colspan="st.colspan">
                    <span v-show="st.isOutput">
                      <el-button
                        round
                        :disabled="!st.isOutput"
                        size="mini"
                        type="primary"
                        @click="showMasterStageView(st.name, st.StageName, st.isShowBind)"
                      >
                        {{ st.name }}</el-button>
                    </span>
                  </td>
                </tr>
                <tr>
                  <td class="tbCategory">Process WIP</td>
                  <td v-for="(st, index) in dataEntity.wip_detail" :key="index" class="tbValue">{{ st.stage }}</td>
                </tr>
                <tr>
                  <td class="tbCategory">Qty</td>
                  <td v-for="(st, index) in dataEntity.wip_detail" :key="index" class="tbValue" :style="{ color: getWIPCellColor(st) }">
                    {{ st.wip }}
                  </td>
                </tr>
                <!-- 20221119 Kimi 增加WIP Target显示 -->
                <tr>
                  <td class="tbCategory">Target</td>
                  <td v-for="(st, index) in dataEntity.wip_detail" :key="index" class="tbValue">{{ st.target }}</td>
                </tr>
              </table>
              <el-table
                v-show="!showRTYData"
                :data="tableDataRange"
                stripe
                size="small"
                :height="tableHeight2"
                :cell-style="getRRangeCellColor"
                style="width: 100%"
              >
                <el-table-column
                  label="MasterStageLabel"
                  width="90"
                  align="center"
                ><!-- 20230414 Kimi 文字变多，加宽到90 -->
                  <template slot-scope="scope">
                    <!-- 20230102 Kimi 绑定按钮用link_color来显示颜色，有未绑定的显示蓝色，否则显示黑色 -->
                    <!-- 20230414 Kimi 绑定的固定文字改用函数来动态获取，因为PCBA这里不用绑定，显示的是三合一是否已经绑定完完整时段，只是一个提示而已-->
                    <el-button
                      v-if="scope.row.row_id !== ''"
                      type="text"
                      size="small"
                      :style="{ color: scope.row.link_color }"
                      @click="showMappingDailog(scope.row)"
                    >{{ getOutputLinkText(scope.row.link_color) }}</el-button>
                  </template>
                </el-table-column>
                <el-table-column prop="sku" label="機種" width="180" header-align="center" show-overflow-tooltip />
                <el-table-column prop="time_range" label="時段" width="120" align="center" />
                <!-- <el-table-column label="投入" header-align="center"> -->
                <el-table-column prop="input" label="投入" width="70" align="center" />
                <!-- <el-table-column prop="input_goal" label="目標" width="70"  align="center"></el-table-column>
                    </el-table-column> -->
                <el-table-column label="產出" header-align="center">
                  <el-table-column prop="actual" label="實際" width="70" align="center" />
                  <el-table-column prop="goal" label="目標" width="70" align="center" />
                  <el-table-column prop="loss" label="損失" width="70" align="center" />
                  <el-table-column prop="loss_time" label="損失(分)" width="80" align="center" />
                  <el-table-column prop="ratio" label="達成率" width="80" align="center" />
                </el-table-column>
              </el-table>
              <el-table v-show="showRTYData" :data="tableDataRTYOATL" stripe size="small" :height="tableHeight" style="width: 100%">
                <el-table-column prop="top" label="" width="80" align="center" show-overflow-tooltip />
                <el-table-column prop="model" label="Model" width="120" align="center" show-overflow-tooltip />
                <el-table-column prop="process_name" label="station" width="120" align="center" show-overflow-tooltip />
                <el-table-column prop="description" label="不良描述" align="center" show-overflow-tooltip />
                <el-table-column prop="qty" label="不良數" width="100" align="center" show-overflow-tooltip />
              </el-table>
            </div>
            <div class="detailBodyCell">
              <div class="tableTitle">{{ bottomRightTitle }}</div>
              <el-table
                v-show="!showRTYData"
                :data="tableDataDRI"
                size="small"
                :row-class-name="tableRowClassName"
                :height="tableHeight"
                style="width: 100%"
              >
                <el-table-column prop="category" label="錯誤代碼" width="110" show-overflow-tooltip />
                <el-table-column prop="issue_msg" label="異常信息" width="170" show-overflow-tooltip />
                <el-table-column prop="start_time" label="異常開始" width="100" align="center" show-overflow-tooltip />
                <el-table-column prop="end_time" label="異常結束" width="100" align="center" show-overflow-tooltip />
                <el-table-column prop="impact_minutes" label="時長" width="70" align="center" />
                <el-table-column prop="loss" label="損失" width="70" align="center" show-overflow-tooltip />
                <!-- <el-table-column prop="status" label="狀態" width="80" align="center" show-overflow-tooltip /> -->
                <el-table-column prop="status" label="狀態" width="80" align="center" show-overflow-tooltip>
                  <template slot-scope="scope">
                    <span style="display: inline-block;cursor: pointer;" @click="handleCxzp(scope.row)">{{ scope.row.status }}</span>
                  </template>
                </el-table-column>
                <!-- <el-table-column prop="duration" label="OpenTime" width="90"></el-table-column> -->
                <el-table-column prop="dri" label="責任人" width="80" show-overflow-tooltip />
                <el-table-column prop="dri_dept" label="責任部門" width="110" show-overflow-tooltip />
                <el-table-column v-if="false" prop="row_id" />
              </el-table>
              <el-table v-show="showRTYData" :data="tableDataRTYOAIL" stripe size="small" :height="tableHeight" style="width: 100%">
                <el-table-column prop="top" label="" width="80" align="center" show-overflow-tooltip />
                <el-table-column prop="model" label="Model" width="120" align="center" show-overflow-tooltip />
                <el-table-column prop="process_name" label="station" width="120" align="center" show-overflow-tooltip />

                <el-table-column prop="description" label="不良描述" align="center" show-overflow-tooltip />
                <el-table-column prop="qty" label="不良數" width="100" align="center" show-overflow-tooltip />
              </el-table>
            </div>
          </div>
        </div>
      </el-main>
    </el-container>

    <el-dialog
      :center="true"
      title="異常記錄維護"
      :close-on-press-escape="false"
      :visible.sync="logMtDialogVisible"
      width="1300px"
      top="2vh"
      :close-on-click-modal="false"
    >
      <div class="logReasonCodeContainer">
        <div v-for="(type, index) in reasonCodeList" :key="index" class="code codeSection">
          <span class="codeType">{{ type.type }}</span>
          <div class="tagStyle">
            <el-tag
              v-for="code in type.codes"
              :key="code.id"
              type="danger"
              style="cursor: pointer; font-size: 14px; margin: 5px"
              @click="reasoncodeSelected(type.type, code)"
            >
              {{ code.reason_code }}
            </el-tag>
          </div>
        </div>
      </div>
      <div class="logDialogContainer">
        <!-- <div class="typeContainer">
          <el-collapse v-model="activeIssueTypes">
            <el-collapse-item v-for="(type,index) in reasonCodeList" :key="index" :title="type.type" :name="type.type">
              <el-button size="mini" v-for="code in type.codes" :key="code.id" type="danger" plain style="margin:0 5px 5px 0">{{code.reason_code}}</el-button>
            </el-collapse-item>
          </el-collapse>
        </div> -->
        <div class="typeContainer">
          <el-form ref="logForm" :model="mtLogForm" label-width="100px" style="margin-right: 20px" size="small">
            <el-form-item label="類別" prop="type">
              <el-input v-model="mtLogForm.type" :disabled="true" style="width: 100%" />
            </el-form-item>
            <el-form-item label="錯誤代碼" prop="reason_code">
              <el-input v-model="mtLogForm.reason_code" :disabled="isNotOtherReason" style="width: 100%" />
            </el-form-item>
            <el-form-item label="段别" prop="stage">
              <el-select v-model="mtLogForm.stage" style="width: 100%" @change="stageChangeHandler">
                <el-option v-for="item in stageList" :key="item.key" :label="item.data" :value="item.data" />
              </el-select>
            </el-form-item>
            <el-form-item label="問題開始" prop="start_time">
              <el-date-picker
                v-model="mtLogForm.start_time"
                type="datetime"
                style="width: 100%"
                :picker-options="pickerOptions1"
                value-format="yyyy-MM-dd HH:mm:ss"
              />
            </el-form-item>
            <el-form-item label="問題結束" prop="end_time">
              <el-date-picker
                v-model="mtLogForm.end_time"
                type="datetime"
                style="width: 100%"
                :picker-options="pickerOptions1"
                value-format="yyyy-MM-dd HH:mm:ss"
              />
            </el-form-item>
            <el-form-item v-for="(item, index) in dymaticItemList" :key="index" :label="item.label">
              <el-input v-if="item.type === 'text' || item.type === 'number'" v-model="mtLogForm.dymaticItems[item.seq].data" style="width: 100%" />
              <el-select v-else v-model="mtLogForm.dymaticItems[item.seq].data" style="width: 100%">
                <el-option v-for="opt in item.options" :key="opt.key" :label="opt.data" :value="opt.data" />
              </el-select>
            </el-form-item>
            <el-button size="mini" type="primary" style="margin: 0 5px 5px 0; width: 300px" @click="SaveNewIssueLog">保存</el-button>
          </el-form>
        </div>
        <div class="logCongtainter">
          <div>
            <el-date-picker v-model="logQueryBegin" type="datetime" :picker-options="pickerOptions1" size="small" style="margin-right: 5px" />
            <el-date-picker v-model="logQueryEnd" type="datetime" size="small" :picker-options="pickerOptions1" />
            <el-button size="mini" type="primary" style="margin: 0 0 5px 5px" @click="queryLogData">查詢</el-button>
            <el-button size="mini" type="primary" style="margin: 0 0 5px 5px" @click="handle_Abnormal_records">异常记录</el-button>
          </div>
          <el-table v-loading="loadingLog" :data="tableDataLogList" size="small" stripe :height="463" style="width: 100%">
            <el-table-column label="" width="50">
              <template slot-scope="scope">
                <el-button type="text" size="small" style="color: red" @click="deleteLog(scope.row)">刪除</el-button>
              </template>
            </el-table-column>
            <el-table-column prop="stage" label="段別" width="70" />
            <el-table-column prop="start_time" label="開始" width="115" />
            <el-table-column prop="end_time" label="結束" width="115" />
            <el-table-column prop="impact_minutes" label="時長" width="70" />
            <el-table-column prop="type" label="類別" width="80" />
            <el-table-column prop="reason_code" label="錯誤代碼" width="100" show-overflow-tooltip />
            <el-table-column prop="update_user" label="填寫人" width="150" show-overflow-tooltip />
            <el-table-column prop="update_time" label="填写时间" width="100" />
            <el-table-column prop="memo" label="備註" width="200" show-overflow-tooltip />
            <el-table-column v-if="false" prop="row_id" />
          </el-table>
        </div>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      title="異常責任人關聯"
      :close-on-press-escape="false"
      :visible.sync="detailRangeDailogVisible"
      width="1300px"
      :close-on-click-modal="false"
    >
      <div class="issueDetailMainDiv">
        <div style="width: 390px; height: 520px; flex: none">
          <div class="tableTitle">{{ MasterStageLabel }} 分時段LOSS清單</div>
          <el-table
            ref="rangeTable"
            v-loading="loadingLossList"
            :data="tableDataIssueRangeDetail"
            size="small"
            height="500"
            :row-class-name="setSelectedLossColor"
            style="width: 100%"
            @selection-change="lossItemSelectedChanged"
          >
            <el-table-column type="selection" width="55" />
            <el-table-column prop="start_time" label="開始" width="60" />
            <el-table-column prop="end_time" label="結束" width="60" />
            <el-table-column prop="actual" label="實際值" width="70" />
            <el-table-column prop="goal" label="目標值" width="70" />
            <el-table-column prop="loss" label="LOSS" width="70" />
            <el-table-column v-if="false" prop="row_id" />
            <el-table-column v-if="false" prop="full_start_time" />
            <el-table-column v-if="false" prop="full_end_time" />
          </el-table>
        </div>
        <div style="height: 520px; width: 860px; margin-left: 5px; flex: none">
          <div class="tableTitle">LOSS原因</div>
          <el-table
            v-loading="loadingCanMatchLog"
            :data="tableDataCanMatchLog"
            :row-class-name="setSelectedReasonColor"
            size="small"
            height="500"
            style="width: 100%"
          >
            <el-table-column label="" width="50">
              <template slot-scope="scope">
                <el-radio v-model="selectedReason" :label="scope.row.row_id"><span /></el-radio>
              </template>
            </el-table-column>
            <el-table-column prop="stage" label="段別" width="60" />
            <el-table-column prop="start_time" label="開始" width="115" />
            <el-table-column prop="end_time" label="結束" width="115" />
            <el-table-column prop="impact_minutes" label="時長" width="55" show-overflow-tooltip />
            <el-table-column prop="type" label="類別" width="70" />
            <el-table-column prop="reason_code" label="錯誤代碼" width="100" show-overflow-tooltip />
            <el-table-column prop="memo" label="備註" width="200" show-overflow-tooltip />
            <el-table-column prop="update_user" label="填寫人" width="150" show-overflow-tooltip />
            <el-table-column prop="update_time" label="填写时间" width="100" />
          </el-table>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <span v-show="currentDRIEmpId !== ''" class="driSpan">當前責任人：</span>
        <span class="driSpan">{{ currentDRIEmpId }}</span>
        <span class="driSpan" style="margin-right: 50px">{{ currentDRIName }}</span>
        <el-button type="primary" size="small" @click="showDRIFilter(null)">分配責任人</el-button>
        <el-button type="success" size="small" style="margin: 0 20px" @click="saveDispatchUser(false)">提交給責任人回復</el-button>
        <el-button type="warning" size="small" style="margin: 0 20px 0 0" @click="saveDispatchUser(true)">僅綁定責任人(不需回復)</el-button>
        <el-button size="small" @click="closeDetailRangeDailog">關閉</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      title="責任人篩選"
      :close-on-press-escape="false"
      :visible.sync="driFilterDialogVisible"
      width="1300px"
      :close-on-click-modal="false"
    >
      <div class="driFilterMainDiv">
        <div style="width: 620px; height: 520px; flex: none">
          <div class="tableTitle">在職員工篩選</div>
          <el-input v-model="driFilterString" placeholder="請輸入AD、工號、姓名進行篩選" size="small" style="width: 100%; margin: 10px 0">
            <el-button slot="append" icon="el-icon-search" @click="queryEmpList" />
          </el-input>
          <el-table v-loading="loading" :data="tableDRIFilter" stripe size="small" height="448px" style="width: 100%">
            <el-table-column label="" width="50">
              <template slot-scope="scope">
                <el-button type="text" size="small" style="color: blue" @click="chooseDRI(scope.row)">選擇</el-button>
              </template>
            </el-table-column>
            <el-table-column prop="bu" label="BU" width="75" />
            <el-table-column prop="name" label="姓名" width="75" show-overflow-tooltip />
            <el-table-column prop="employee_id" label="工號" width="90" show-overflow-tooltip />
            <el-table-column prop="dept_id" label="成本中心" width="90" show-overflow-tooltip />
            <el-table-column prop="department" label="部門" show-overflow-tooltip />
            <el-table-column prop="email" label="郵箱" width="180" show-overflow-tooltip />
          </el-table>
        </div>
        <div style="height: 520px; width: 620px; margin-left: 10px; flex: none; background-color: red">
          <div class="tableTitle">常用人員清單</div>
          <el-table v-loading="loadingCommonDRI" :data="tableDRICommom" stripe size="small" height="500" style="width: 100%">
            <el-table-column label="" width="100">
              <template slot-scope="scope">
                <el-button type="text" size="small" style="color: blue" @click="chooseDRI(scope.row)">選擇</el-button>
                <el-button type="text" size="small" style="color: red" @click="removeDRI(scope.row)">移除</el-button>
              </template>
            </el-table-column>
            <el-table-column prop="bu" label="BU" width="75" />
            <el-table-column prop="name" label="姓名" width="75" show-overflow-tooltip />
            <el-table-column prop="employee_id" label="工號" width="90" show-overflow-tooltip />
            <el-table-column prop="dept_id" label="成本中心" width="90" show-overflow-tooltip />
            <el-table-column prop="department" label="部門" show-overflow-tooltip />
            <el-table-column prop="email" label="郵箱" width="180" show-overflow-tooltip />
          </el-table>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="closeDRIFilterDailog">關閉</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="title3IN1"
      :close-on-press-escape="false"
      :visible.sync="log3IN1DialogVisible"
      width="1200px"
      top="2vh"
      :close-on-click-modal="false"
    >
      <div style="height: 600px">
        <span class="threeIN1TitleSpan">工單基本信息:</span>
        <div>
          <span class="stepHeadSpan">Step1 選擇正確的工作日和班別:</span>
          <el-date-picker
            v-model="log3IN1WorkDay"
            type="date"
            :picker-options="pickerOptions1"
            size="small"
            style="width: 150px; margin-right: 5px"
            @change="getWorkDayWorkTime"
          >工作日</el-date-picker>
          <el-select v-model="log3IN1Shift" placeholder="請選擇班別" style="width: 100px" size="small" @change="getWorkDayWorkTime">
            <!-- start add 20230210 fenglianlong  三班制修改 -->
            <el-option v-for="item in workshiftList" :key="item.shift_code" :label="item.shift_name" :value="item.shift_code" />
            <!-- <el-option label="白班" value="D"></el-option>
             <el-option label="中班" value="M"></el-option>
             <el-option label="夜班" value="N"></el-option> -->
            <!-- end add 20230210 ------------------------->
          </el-select>
          <el-select
            v-model="log3IN1WorkTime"
            placeholder="工作區段"
            size="small"
            filterable
            style="width: 400px; margin: 0 5px; background-color: yellow"
            @change="getWorkTime"
          >
            <el-option v-for="item in workTimeList" :key="item.work_time" :label="getWorkTimeString(item)" :value="item.work_time">
              <!-- <span>{{ item.start_time }}~{{item.end_time}}</span> -->
            </el-option>
          </el-select>
          <!-- <span class="spanMemo">本線工作時間：{{workTimeStart}} ~ {{workTimeEnd}}</span> -->
        </div>
        <div>
          <!-- <span class="stepHeadSpan">Step2 選擇正確的班別代碼:</span>
          <el-select v-model="shiftCode" placeholder="班別" size="small" filterable style="width:100px;margin-right:5px;">
            <el-option
              v-for="item in shiftCodeList"
              :key="item.runs_id"
              :label="item.runs_id"
              :value="item.runs_name">
              <span style="float: left">{{ item.runs_id }}</span>
              <span style="float: right; color: #8492a6; font-size: 13px">{{ item.runs_name }}</span>
            </el-option>
          </el-select> -->
          <span class="stepHeadSpan">Step2 選擇區段和製程:</span>
          <el-select
            v-model="log3IN1Stage"
            placeholder="區段"
            size="small"
            style="width: 180px; margin-right: 5px"
            filterable
            @change="getMESProcessList"
          >
            <el-option v-for="item in log3IN1StageList" :key="item.stage_id" :label="item.stage_name" :value="item.stage_id" />
          </el-select>
          <el-select
            v-model="log3IN1Process"
            placeholder="製程"
            size="small"
            style="width: 200px; margin-right: 5px"
            filterable
            @change="setIssueBeginData"
          >
            <el-option v-for="item in log3IN1ProcessList" :key="item.process_id" :label="item.process_name" :value="item.process_id" />
          </el-select>
          <span class="spanMemo">區段代碼: {{ log3IN1Operation }}</span>

          <span class="spanMemo">损失时间: {{ timeLoss }}分钟</span>
        </div>
        <div>
          <span class="stepHeadSpan">Step3 選擇Issue時間區段:</span>
          <el-date-picker
            v-model="log3IN1Begin"
            type="datetime"
            size="small"
            style="width: 190px; margin-right: 5px"
            placeholder="Issue開始"
            readonly
          />
          <el-date-picker
            v-model="log3IN1End"
            type="datetime"
            size="small"
            style="width: 190px; margin-right: 5px"
            placeholder="Issue結束"
            @change="getWOList"
          />
          <span class="spanMemo">{{ log3IN1Range }} 分</span>
          <span class="stepHeadSpan" style="margin-left: 30px">Step4 選擇要填寫的工單:</span>
          <el-select v-model="log3IN1WO" placeholder="工單" size="small" filterable style="width: 150px" @change="getWOBaseData">
            <el-option v-for="item in log3IN1WOlist" :key="item.work_order" :label="item.work_order" :value="item.work_order" />
          </el-select>
        </div>
        <div class="woBaseInfoDiv">
          <table>
            <tr>
              <td class="tdWOTitle">工單號碼</td>
              <td><el-input v-model="woBase.wo" size="small" readonly /></td>
              <td class="tdWOTitle">工單批量</td>
              <td><el-input v-model="woBase.wo_qty" size="small" readonly /></td>
              <td class="tdWOTitle">投入(已計算)</td>
              <td><el-input v-model="woBase.calc_qty" size="small" readonly /></td>
              <td class="tdWOTitle">投入(本次)</td>
              <td><el-input id="inputWOQty" v-model="woBase.current_qty" size="small" /></td>
              <td class="tdWOTitle">投入(累计)</td>
              <td><el-input v-model="woBase.total_qty" size="small" readonly /></td>
              <td class="tdWOTitle">待維修</td>
              <td><el-input v-model="woBase.in_repair" size="small" readonly /></td>
            </tr>
            <tr>
              <td class="tdWOTitle">機種名稱</td>
              <td colspan="3"><el-input v-model="woBase.part_no" size="small" readonly /></td>
              <td class="tdWOTitle">標準UPH</td>
              <td><el-input v-model="woBase.uph" size="small" readonly /></td>
              <td class="tdWOTitle">新機種</td>
              <td><el-input v-model="woBase.new_model" size="small" readonly /></td>
              <td class="tdWOTitle">等效點數</td>
              <td><el-input v-model="woBase.normolization_factor" size="small" readonly /></td>
              <td>
                <el-tooltip class="item" effect="dark" placement="bottom">
                  <div slot="content">
                    <ul>
                      <li>投入(已計算): 在本界面當前工單(同段別+站別)已經記錄過的數量(即投入(本次)填寫的數量)</li>
                      <li>投入(本次): 理論上等於投入(累計)減去投入(已計算)的數量，可以修改</li>
                      <li>投入(累計): 當前工單(同段別+站別)已經在MES中投入的數量</li>
                    </ul>
                  </div>
                  <el-link type="primary" style="margin-left: 15px">說明</el-link>
                </el-tooltip>
              </td>
            </tr>
          </table>
        </div>
        <span class="threeIN1TitleSpan">Loss Time詳情:</span>
        <el-table :data="log3IN1ReasonCode" size="small" style="width: 100%; margin-top: 5px" height="350" stripe :span-method="arraySpanMethod">
          <el-table-column prop="type" label="分類" width="180" align="center" show-overflow-tooltip>
            <template slot-scope="scope">
              {{ getComputedType(scope.row) }}
            </template>
          </el-table-column>
          <el-table-column label="異常信息" width="140" align="center" show-overflow-tooltip>
            <template slot-scope="scope">
              {{ getComputedReasonCode(scope.row) }}
            </template>
          </el-table-column>
          <el-table-column prop="unit" label="單位" width="60" align="center" show-overflow-tooltip />
          <el-table-column label="損失" width="100" align="center">
            <template slot-scope="scope">
              <el-input v-model="scope.row.loss" size="small" @blur="keyInLossChange(scope.row)" /><!--20221201 Kimi 更具换线工时来填充换线次数-->
            </template>
          </el-table-column>
          <el-table-column label="責任人" align="center" width="170" show-overflow-tooltip>
            <template slot-scope="scope">
              {{ getComputedDRI(scope.row) }}
            </template>
          </el-table-column>
          <el-table-column label="操作責任人" align="center" width="100">
            <template slot-scope="scope">
              <el-button
                v-show="scope.row.need_dri === 'Y'"
                type="text"
                size="small"
                style="color: blue"
                @click="showDRIFilter(scope.row)"
              >設置</el-button>
              <el-button
                v-show="scope.row.need_dri === 'Y'"
                type="text"
                size="small"
                style="color: red"
                @click="clearRowDRI(scope.row)"
              >清除</el-button>
            </template>
          </el-table-column>
          <el-table-column label="需要回復" align="center" width="80">
            <template slot-scope="scope">
              <el-checkbox v-show="scope.row.need_response === 'Y'" v-model="scope.row.need_check" />
            </template>
          </el-table-column>
          <el-table-column prop="description" label="說明" align="center" show-overflow-tooltip>
            <template slot-scope="scope"> <el-input v-model="scope.row.description" size="small" /><!--20230425 wangjun 更具為填寫框--> </template>
          </el-table-column>
        </el-table>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="success" size="small" @click="save3IN1Data">确认领班权限</el-button>
        <el-button type="danger" size="small" @click="close3IN1Dialog">退 出</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      title="領班權限確認"
      :close-on-press-escape="false"
      :visible.sync="log3IN1AuthCheckDialogVisible"
      width="400px"
      top="2vh"
      :close-on-click-modal="false"
    >
      <div style="height: 200px">
        <span class="authHeadSpan">領班工號: </span><el-input ref="inputAuthEmpId" v-model="log3IN1AuthEmpId" size="small" />
        <span class="authHeadSpan">密碼:</span><el-input v-model="log3IN1AuthPwd" size="small" show-password />
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="success" size="small" @click="check3IN1AuthAndSubmit">確認並正式提交數據</el-button>
        <el-button type="danger" size="small" @click="cancelAuthCheck">取 消</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="异常记录"
      :visible.sync="abnormalRecordsShow"
      :before-close="handleCancelabnormalRecords"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      append-to-body
      width="1100px"
    >
      <el-table :data="dataEntity.ems_data">
        <el-table-column align="center" width="200" prop="eqp_id" label="设备ID" />
        <el-table-column align="center" width="120" prop="impact_minutes" label="损失时间" />
        <el-table-column align="center" prop="start_time" label="开始时间" />
        <el-table-column align="center" prop="end_time" label="结束时间" />
        <el-table-column align="center" width="100" prop="reason_code_type" label="類別" />
        <el-table-column align="center" width="120" prop="reason_code" label="錯誤代碼" />
        <el-table-column align="center" label="操作" width="100">
          <template slot-scope="scope">
            <el-button type="primary" plain icon="el-icon-check" size="mini" @click="handleSettingEms(scope.row)">选择</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>

    <DialogDri ref="DialogDri" v-model="dialogVisibleCxzp" @closeView="initialData" />
  </div>
</template>
<script>
import $ from 'jquery'
import DialogDri from '@/views/components/DPMDashboardLineDetail/dialogDri'
import {
  GetDPMQueryKeyValue,
  GetDPMDashboardLineDetailData,
  GetDPMReasonCode,
  GetEmpInfoList,
  GetCommonDRIList,
  GetDPMDashboardLineIndexData,
  GetDPMRangeIssueData,
  GetDPMLogDymaticItems,
  GetDPMIssueLogData,
  SaveIssueLog, // GetWorkShiftCode, // GetWorkStartAndEndTime
  DeleteIssueLog,
  GetDPMCanMatchLogData,
  RemoveCommonDRIList,
  SaveDispatchUser,
  GetDPMDashboardParentId,
  GetDPMDashboardLineIndexDataRTY,
  GetDPMPCBAReasonCode,
  GetMESStageList,
  GetMESProcessList,
  GetMAX3IN1EndTime,
  GetDPM3IN1WOList,
  Get3IN1WOBaseData,
  Check3IN1SavePrivilege,
  submit3IN1Data,
  GetWorkTimeList,
  GetDPMPCBAReasonCodeDefaultValue,
  GetWorkshiftList,
  GetDashboardLineStageDetailData,
  GetPcbaEmsData_API
} from '@/api/midway.js'
export default {
  components: {
    DialogDri
  },
  data() {
    return {
      dialogVisibleCxzp: false,
      timeLoss: 0,
      abnormalRecordsShow: false,
      isShowBind: 0, // FATP的时候，如果值为1，那么MasterStageLabel 显示是否绑定 2023-05-22
      bottomLeftTitle: '分時段產出清單',
      bottomRightTitle: '問題追蹤',
      showKPIChart: true,
      showRTYData: false,
      chartTest: null,
      leftTopChart: null,
      rightTopChart: null,
      rtyChart: null,
      isNotOtherReason: true,
      tableHeight: 1,
      tableHeight2: 1,
      tableDataRange: [],
      tableDataDRI: [],
      logMtDialogVisible: false,
      reasonCodeList: [],
      activeIssueTypes: [],
      level: 'line',
      keyid: '',
      parentId: '0',
      mtLogForm: {
        lineId: '',
        type: '',
        reason_code: '',
        stage: 'ALL',
        start_time: null,
        end_time: null,
        dymaticItems: []
      },
      dymaticItemList: [],
      stageList: [],
      pickerOptions1: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      selectedReason: '',
      detailRangeDailogVisible: false,
      tableDataIssueRangeDetail: [],
      tableDataIssueRangeSelected: [],
      tableDataCanMatchLog: [],
      loadingCanMatchLog: false,
      driFilterDialogVisible: false,
      driFilterString: '',
      tableDRIFilter: [],
      tableDRICommom: [],
      currentDRIEmpId: '',
      currentDRIName: '',
      loading: false,
      loadingCommonDRI: false,
      loadingLossList: false,
      tableDataLogList: [],
      loadingLog: false,
      logQueryBegin: '',
      logQueryEnd: '',
      parentRowId: '',
      viewRange: 'currentshift',
      currentKPIName: 'UPH',
      showReturnMenu: true,
      selectedCode: [],
      userAllCode: [],
      selectFilterTitle: '',
      tableFilterData: [],
      filterColName: '',
      filterTableSelected: [],
      selectFilterDialogVisible: false,
      dataEntity: {
        area: '',
        title: 'DPM Line Detail',
        shift: '',
        onlineDLQty: '0',
        onlineDLTargetQty: '0',
        offlineVarDLQty: '0',
        offlineFixDLQty: '0',
        hasError: 'N',
        model: '',
        serverTime: '',
        line: '',
        site: '',
        factory: '',
        team: '',
        workday: '',
        shift_code: '',
        index_charts: [],
        efficiency: '',
        efficiency_color: '',
        rty: '',
        rty_color: '',
        rty_show: '',
        uph: '',
        uph_color: '',
        uph_show: '',
        upph: '',
        upph_color: '',
        upph_show: '',
        uts: '',
        uts_color: '',
        uts_show: '',
        oee2: '',
        oee2_color: '',
        oee2_show: '',
        chartData: [],
        wip_detail: [],
        ems_data: []
      },
      loadingData: null,
      autoRefresh: false,
      refreshTimer: null,
      currentCode: null,
      chartInput: null,
      chartOutput: null,
      chartWip: null,
      chartEff: null,
      chartRTY: null,
      chartUPH: null,
      chartOnlineDL: null,
      // chartUPPHOnlineDL: null,
      chartOEE1: null,
      chartOEE2: null,
      chartUTS: null,
      rtyOAILCols: [],
      rtyOATLCols: [],
      tableRTYOAIL: [],
      tableRTYOATL: [],
      tableRTYRange: [],
      tableDataRTYOATL: [],
      tableDataRTYOAIL: [],
      log3IN1DialogVisible: false,
      log3IN1WorkDay: '',
      log3IN1Begin: '',
      log3IN1End: '',
      log3IN1WorkTime: '',
      workTimeList: [],
      // add 20230210 fenglianlong  三班制修改
      workshiftList: [],
      log3IN1WO: '',
      log3IN1WOlist: [],
      log3IN1Range: 0,
      title3IN1: '',
      log3IN1Shift: '',
      workTimeStart: '',
      workTimeEnd: '',
      shiftCode: '',
      shiftCodeList: [],
      log3IN1StageList: [],
      log3IN1ProcessList: [],
      log3IN1Stage: '',
      log3IN1Process: '',
      log3IN1Operation: '',
      log3IN1ReasonCode: [],
      woBase: {
        wo: '',
        stage: '',
        process: '',
        line: '',
        part_no: '',
        uph: '',
        wo_qty: 0,
        in_repair: 0,
        calc_qty: 0,
        current_qty: 0,
        total_qty: 0,
        new_model: 'N',
        normolization_factor: 1
      },
      spanRows: [],
      log3IN1SelectedRow: null,
      log3IN1AuthCheckDialogVisible: false,
      log3IN1AuthEmpId: '',
      log3IN1AuthPwd: '',
      log3IN1AuthResult: '',
      TableName1: 'Process',
      TableName2: 'Process',

      showMasterStage: true,
      dataEntity2: {
        masterStage: []
      },
      MasterStageLabel: '',
      MasterStageOutputStage: ''
    }
  },
  computed: {},
  mounted() {
    this.$nextTick(() => {
      this.resizeTable()
    })
    this.initialData()
    window.onresize = () => {
      this.resizeTable()
      if (this.leftTopChart !== null) {
        this.leftTopChart.resize()
      }
      if (this.rightTopChart !== null) {
        this.rightTopChart.resize()
      }
      if (this.rtyChart !== null) {
        this.rtyChart.resize()
      }
      if (this.chartInput !== null) {
        this.chartInput.resize()
      }
      if (this.chartOutput !== null) {
        this.chartOutput.resize()
      }
      if (this.chartWip !== null) {
        this.chartWip.resize()
      }
      if (this.chartUPH !== null) {
        this.chartUPH.resize()
      }
      if (this.chartOnlineDL !== null) {
        this.chartOnlineDL.resize()
      }
      if (this.chartEff !== null) {
        this.chartEff.resize()
      }
      if (this.chartRTY !== null) {
        this.chartRTY.resize()
      }
      if (this.chartOEE2 !== null) {
        this.chartOEE2.resize()
      }
      if (this.chartOEE1 !== null) {
        this.chartOEE1.resize()
      }
    }
  },
  beforeDestroy() {
    clearInterval(this.refreshTimer)
  },
  methods: {
    // 2023-05-31 by zhujunjie 异常记录详情弹窗
    handle_Abnormal_records() {
      this.abnormalRecordsShow = true
    },
    // 2023-05-31 by zhujunjie 异常记录详情弹窗关闭
    handleCancelabnormalRecords() {
      this.abnormalRecordsShow = false
    },

    handleSettingEms(obj) {
      this.$confirm('确定要选择这条数据吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.abnormalRecordsShow = false

          this.clearKeyLogFormData()

          this.mtLogForm.type = obj.reason_code_type
          this.mtLogForm.reason_code = obj.reason_code
          this.mtLogForm.start_time = obj.start_time
          this.mtLogForm.end_time = obj.end_time

          const codesArr = this.reasonCodeList.filter((item) => item.type == obj.reason_code_type)[0]['codes']
          this.currentCode = codesArr.filter((item) => item.reason_code == obj.reason_code)[0]
          this.refreshDymaticList(this.currentCode?.id, this.mtLogForm.stage)

          this.$message({
            type: 'success',
            message: '选择成功!'
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消操作'
          })
        })
    },

    // 20221201 Kimi 根据KPI调整Div大小
    getDivClass(position) {
      if (this.currentKPIName === 'UPH') {
        if (this.showMasterStage) {
          return 'detailBodyRow3'
        } else {
          return 'detailBodyRow2'
        }
      } else {
        if (position === 'top') {
          return 'detailBodyRow'
        } else {
          return 'detailBodyRow1'
        }
      }
    },
    getBackgroundColor() {
      if (this.viewRange === 'currentshift') {
        return 'radial-gradient(#26589A, #191D50)'
      } else {
        return 'radial-gradient(#60c8d2,#191D50)'
      }
    },
    getWIPCellColor(st) {
      try {
        if (parseFloat(st.wip) > parseFloat(st.target)) {
          return 'red'
        } else {
          return 'black'
        }
      } catch {
        return 'black'
      }
    },
    tableRowClassName({ row, rowIndex }) {
      if (row.category === '未知') {
        return 'error-row'
      }
      if (row.status === '重新指派') {
        return 'warning'
      }
    },
    async initialData() {
      this.keyid = this.$route.query.keyid // 当前的keyid是area的id
      // this.parentId = this.$route.query.area // linedetail退回去就是line层级，line的parent就是area的id（退回line层级时，keyid就是areaid）
      if (this.keyid === undefined) {
        this.keyid = ''
      }
      // 抓取是看当班还是前已班的数据
      const viewRangeObj = window.localStorage.getItem('market_dpm_viewrange')
      if (!viewRangeObj) {
        this.viewRange = 'currentshift'
      } else {
        this.viewRange = viewRangeObj
      }
      if (this.viewRange !== 'currentshift' && this.viewRange !== 'previousshift') {
        this.viewRange = 'currentshift'
      }
      // 抓取是看点击的KPI是哪一个
      const currentKPI = window.localStorage.getItem('market_dpm_clickKPI')
      if (!currentKPI) {
        this.currentKPIName = 'UPH'
      } else {
        this.currentKPIName = currentKPI
      }
      window.localStorage.setItem('market_dpm_viewrange', this.viewRange)
      window.localStorage.setItem('market_dpm_clickKPI', this.currentKPIName)

      this.getDashBoardData()
    },
    async showPrevLevel() {
      const data = {
        level: 'linedetail',
        id: this.keyid
      }
      const response = await GetDPMDashboardParentId(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const pId = response.data.ReturnObject
        const query = {
          level: 'line',
          keyid: pId
        }
        this.$router.push({
          path: '/DPMDashboardLine',
          query: query
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getDashBoardData() {
      const data = {
        lineid: this.keyid,
        viewrange: this.viewRange
      }
      // 查询数据
      this.loadingData = this.$loading({
        lock: true,
        text: '正在加載數據，請耐心等待...',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await GetDPMDashboardLineDetailData(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.dataEntity.area = obj.area
        this.dataEntity.title = obj.title
        this.dataEntity.shift = obj.shift
        this.dataEntity.onlineDLQty = obj.online_dl_qty
        this.dataEntity.onlineDLTargetQty = obj.online_dl_target_qty
        this.dataEntity.offlineVarDLQty = obj.offline_var_dl_qty
        this.dataEntity.offlineFixDLQty = obj.offline_fix_dl_qty
        this.dataEntity.model = obj.model
        this.dataEntity.line = obj.line
        this.dataEntity.index_charts = obj.index_charts
        this.dataEntity.wip_detail = obj.wip_detail
        this.dataEntity.site = obj.site
        this.dataEntity.factory = obj.factory
        this.dataEntity.team = obj.team
        this.dataEntity.workday = obj.workday
        this.dataEntity.shift_code = obj.shift_code
        this.dataEntity.ems_data = obj.ems_data
        // this.dataEntity.efficiency = obj.efficiency
        // this.dataEntity.efficiency_color = obj.efficiency_color
        // this.dataEntity.efficiency_show = obj.efficiency_show
        // this.dataEntity.rty = obj.rty
        // this.dataEntity.rty_color = obj.rty_color
        // this.dataEntity.rty_show = obj.rty_show
        // this.dataEntity.uph = obj.uph
        // this.dataEntity.uph_color = obj.uph_color
        // this.dataEntity.uph_show = obj.uph_show
        // this.dataEntity.upph = obj.upph
        // this.dataEntity.upph_color = obj.upph_color
        // this.dataEntity.upph_show = obj.upph_show
        // this.dataEntity.uts = obj.uts
        // this.dataEntity.uts_color = obj.uts_color
        // this.dataEntity.uts_show = obj.uts_show
        // this.dataEntity.oee2 = obj.oee2
        // this.dataEntity.oee2_color = obj.oee2_color
        // this.dataEntity.oee2_show = obj.oee2_show
        // this.dataEntity.hasError = obj.has_error
        this.dataEntity.serverTime = obj.server_time

        // start add 20230210 fenglianlong  三班制修改
        this.getWorkDayWorkshift()
        // end add 20230210-----------------------
        this.showMasterStage = obj.showMasterStage === 'Y'
        //  如果不需要顯示多段產出 則不獲取dataEntity2數據
        if (this.showMasterStage) {
          this.dataEntity2.masterStage = obj.MasterStageOutput
        }
        this.log3IN1Shift = this.dataEntity.shift_code
        const tempWorkDay = obj.workday.substr(0, 4) + '-' + obj.workday.substr(4, 2) + '-' + obj.workday.substr(6, 2)
        this.log3IN1WorkDay = new Date(tempWorkDay)

        this.tableDataRange = obj.archive_rate
        this.dataEntity.index_charts.forEach((x) => {
          this.showIndexChart(x)
        })

        // 2023-3-14 BY JUNWWANG
        if (this.dataEntity.area === 'PCBA') {
          this.TableName1 = 'Before Reflow'
          this.TableName2 = 'After Reflow'
        }

        // ======================================================================
        // 显示指标柱状图
        if (this.dataEntity.area === 'PCBA') {
          // PCBA没有UPH
          if (this.currentKPIName === 'UPH' || this.currentKPIName === 'OEE1') {
            this.currentKPIName = 'OEE2'
            window.localStorage.setItem('market_dpm_clickKPI', this.currentKPIName)
          }
        } else {
          if (this.currentKPIName === 'OEE2' || this.currentKPIName === 'OEE1') {
            this.currentKPIName = 'UPH'
            window.localStorage.setItem('market_dpm_clickKPI', this.currentKPIName)
          }
        }
        this.getIndexChartData(this.currentKPIName)
        // ======================================================================
        if (this.currentKPIName !== 'RTY') {
          // 显示loss bridge
          const lossBridge = obj.loss_bridge
          if (this.rightTopChart !== null) {
            this.rightTopChart.dispose()
          }
          const series = []
          // 注意，placeholder的series要在前面才可以
          series.push({
            name: lossBridge.seriesHolder.name,
            type: lossBridge.seriesHolder.type,
            data: lossBridge.seriesHolder.data,
            label: lossBridge.seriesHolder.label,
            itemStyle: lossBridge.seriesHolder.itemStyle,
            emphasis: lossBridge.seriesHolder.emphasis,
            stack: 'Total'
          })
          series.push({
            name: lossBridge.seriesValue.name,
            type: lossBridge.seriesValue.type,
            data: lossBridge.seriesValue.data,
            label: lossBridge.seriesValue.label,
            stack: 'Total'
          })
          var chartDom = document.getElementById('elTopRight')
          this.rightTopChart = this.$echarts.init(chartDom)
          this.rightTopChart.clear()
          var option
          option = {
            tooltip: {
              trigger: 'axis',
              formatter: function(params) {
                var tar = params[1]
                return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value
              }
            },
            toolbox: {
              feature: {
                dataView: { show: true, readOnly: true },
                saveAsImage: {}
              }
            },
            xAxis: {
              type: 'category',
              data: lossBridge.xAxis
            },
            yAxis: {
              type: 'value',
              axisLabel: {
                formatter: '{value} %'
              }
            },
            series: series
          }
          this.rightTopChart.setOption(option)
          // ======================================================================
          // 显示错误跟踪明细
          this.tableDataDRI = obj.issue_track
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    // 20230414 Kimi 增加动态显示文字的函数
    // getOutputLinkText(color) {
    //   if(this.dataEntity.area === 'FATP' && this.isShowBind == 0 && this.showMasterStage){

    //       return ""
    //   }else{
    //     if (color === 'black') {
    //         return this.dataEntity.area === 'FATP' ? '已綁定完' : 'Keyin完成'
    //       } else {
    //         return this.dataEntity.area === 'FATP' ? '未綁定完' : 'Keyin未完成'
    //       }
    //   }

    // },

    getOutputLinkText(color) {
      if (color === 'black') {
        return this.dataEntity.area === 'FATP' ? '已綁定完' : 'Keyin完成'
      } else {
        return this.dataEntity.area === 'FATP' ? '未綁定完' : 'Keyin未完成'
      }
    },

    // 20221203 Kimi 对未绑定和绑定完成的行显示不同的颜色
    // 20230102 Kimi 颜色显示方式更新，绑定按钮单独用link_color来显示颜色，其他栏位用color来显示颜色
    getRRangeCellColor({ row, column, rowIndex, columnIndex }) {
      if (columnIndex > 0) {
        return 'color: ' + (row.color === '' ? 'black' : row.color)
      }
    },
    showIndexChart(x) {
      const index = x.title
      const act = x.act
      const goal = x.goal
      let value = x.value
      const color = x.color
      let fontColor = x.color

      // if (index.toLowerCase() === 'input' || index.toLowerCase() === 'output' || index.toLowerCase() === 'wip') {
      // 20221212 Kimi Output显示达成率，不再显示灰色if (index.toLowerCase() === 'input' || index.toLowerCase() === 'output') {

      // 20230312 WANGJUN恢复input颜色
      // if (index.toLowerCase() === 'input') {
      //   color = 'transparent' // 'rgb(168,168,168)'
      //   fontColor = 'black'
      // } else if (index.toLowerCase() === 'wip') {
      //   fontColor = 'black'
      // }
      if (index.toLowerCase() === 'wip') {
        fontColor = 'black'
      }

      if (index.toLowerCase() === 'oee1' || index.toLowerCase() === 'oee2') {
        const seriesValue = parseFloat(goal) === 0 ? 0 : (100 * parseFloat(act)) / parseFloat(goal)
        value = seriesValue.toFixed(1)
      }

      const formatter = ['{a|' + act + '}', '{b|' + goal + '}'].join('\n')
      const gaugeData = [
        {
          value: value,
          // name: one.name,
          title: {
            offsetCenter: ['0%', '-20%']
          },
          detail: {
            valueAnimation: true,
            fontSize: 20,
            borderColor: 'transparent',
            offsetCenter: ['0%', '-20%']
          }
        }
      ]
      // const color = 'rgb(229,64,50)'
      var option = {
        backgroundColor: 'rgba(0,0,0,0)',
        series: [
          {
            type: 'gauge',
            startAngle: 90,
            endAngle: -270,
            pointer: {
              show: false
            },
            progress: {
              show: true,
              overlap: false,
              roundCap: true,
              clip: false,
              itemStyle: {
                borderWidth: 1,
                borderColor: '#464646',
                color: color
              }
            },
            axisLine: {
              lineStyle: {
                width: 5,
                color: [[1, '#A8A8A8']]
              }
            },
            splitLine: {
              show: false,
              distance: 0,
              length: 10
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              show: false,
              distance: 50
            },
            data: gaugeData,
            title: {
              fontSize: 14
            },
            detail: {
              width: 30,
              height: 13,
              fontSize: 10,
              color: 'black',
              borderColor: 'auto',
              borderRadius: 5,
              borderWidth: 1,
              rich: {
                a: {
                  color: fontColor,
                  fontSize: 18,
                  lineHeight: 18,
                  fontWeight: 'bolder'
                },
                b: {
                  color: 'gray',
                  fontSize: 14,
                  lineHeight: 16
                }
              },
              formatter: formatter
            }
          }
        ]
      }
      const id = 'chartdiv' + index
      this.$nextTick(() => {
        const chartDom = document.getElementById(id)
        switch (index.toLowerCase()) {
          case 'input':
            if (this.chartInput !== null && this.chartInput !== '' && this.chartInput !== undefined) {
              this.chartInput.dispose()
            }
            this.chartInput = this.$echarts.init(chartDom)
            this.chartInput.clear()
            this.chartInput.setOption(option)
            break
          case 'output':
            if (this.chartOutput !== null && this.chartOutput !== '' && this.chartOutput !== undefined) {
              this.chartOutput.dispose()
            }
            this.chartOutput = this.$echarts.init(chartDom)
            this.chartOutput.clear()
            this.chartOutput.setOption(option)
            break
          case 'wip':
            if (this.chartWip !== null && this.chartWip !== '' && this.chartWip !== undefined) {
              this.chartWip.dispose()
            }
            this.chartWip = this.$echarts.init(chartDom)
            this.chartWip.clear()
            this.chartWip.setOption(option)
            break
          case 'uph':
            if (this.chartUPH !== null && this.chartUPH !== '' && this.chartUPH !== undefined) {
              this.chartUPH.dispose()
            }
            this.chartUPH = this.$echarts.init(chartDom)
            this.chartUPH.clear()
            this.chartUPH.setOption(option)
            break
          case 'online dl':
            if (this.chartOnlineDL !== null && this.chartOnlineDL !== '' && this.chartOnlineDL !== undefined) {
              this.chartOnlineDL.dispose()
            }
            this.chartOnlineDL = this.$echarts.init(chartDom)
            this.chartOnlineDL.clear()
            this.chartOnlineDL.setOption(option)
            break
          case 'effciency':
            if (this.chartEff !== null && this.chartEff !== '' && this.chartEff !== undefined) {
              this.chartEff.dispose()
            }
            this.chartEff = this.$echarts.init(chartDom)
            this.chartEff.clear()
            this.chartEff.setOption(option)
            break
          case 'oee2':
            if (this.chartOEE2 !== null && this.chartOEE2 !== '' && this.chartOEE2 !== undefined) {
              this.chartOEE2.dispose()
            }
            this.chartOEE2 = this.$echarts.init(chartDom)
            this.chartOEE2.clear()
            this.chartOEE2.setOption(option)
            break
          case 'oee1':
            if (this.chartOEE1 !== null && this.chartOEE1 !== '' && this.chartOEE1 !== undefined) {
              this.chartOEE1.dispose()
            }
            this.chartOEE1 = this.$echarts.init(chartDom)
            this.chartOEE1.clear()
            this.chartOEE1.setOption(option)
            break
          case 'rty':
            if (this.chartRTY !== null && this.chartRTY !== '' && this.chartRTY !== undefined) {
              this.chartRTY.dispose()
            }
            this.chartRTY = this.$echarts.init(chartDom)
            this.chartRTY.clear()
            this.chartRTY.setOption(option)
            break
        }
      })
    },
    alertMsg(msg) {
      this.$alert(msg, '提示', {
        confirmButtonText: '確定',
        type: 'error'
      })
    },
    moreMenuClickHandler(command) {
      if (command === 'return') {
        if (this.level === undefined || this.level === '' || this.level === 'factory') {
          return
        }
        this.showPrevLevel()
      } else if (command === 'max' || command === 'min') {
        // 调整界面
        const model = {
          type: command
        }
        this.$emit('change-show-model', model)
        const that = this
        setTimeout(function() {
          that.fullScreen(command)
        }, 300)
      } else if (command === 'refresh') {
        this.autoRefresh = !this.autoRefresh
        const that = this
        if (this.autoRefresh) {
          this.refreshTimer = setInterval(function() {
            if (that.viewRange === 'currentshift') {
              that.initialData()
            }
          }, 120000)
        } else {
          clearInterval(this.refreshTimer)
        }
      } else if (command === 'viewrange') {
        if (this.viewRange === 'currentshift') {
          this.viewRange = 'previousshift'
        } else {
          this.viewRange = 'currentshift'
        }
        window.localStorage.setItem('market_dpm_viewrange', this.viewRange)
        this.initialData()
      } else if (command === 'addlog') {
        if (this.dataEntity.area === 'PCBA') {
          this.title3IN1 = this.dataEntity.line + '三合一記錄頁面'
          this.getPCBAReasonCode()
          this.getWorkDayWorkTime() // 抓取上下班时间，供user选择参考
          // this.getShiftCodeList()
          this.getMESStageList()
          this.log3IN1DialogVisible = true
        } else {
          this.tableDataLogList = []
          this.GetReasonCodes()
          this.GetStageList()
          // 设置查询的默认时间,当前往前推12小时
          const curDate = new Date()
          this.logQueryBegin = new Date(curDate.getTime() - 12 * 60 * 60 * 1000)
          this.logQueryEnd = new Date(curDate)
          this.logMtDialogVisible = true
        }
      }
    },
    fullScreen(type) {
      if (type === 'max') {
        const el = document.documentElement
        const rfs = el.requestFullscreen || el.webkitRequestFullScreen || el.mozRequestFullScreen || el.msRequestFullScreen
        if (typeof rfs !== 'undefined' && rfs) {
          rfs.call(el)
        }
      } else {
        const el = document
        const rfs = el.cancelFullScreen || el.webkitCancelFullScreen || el.mozCancelFullScreen || el.exitFullScreen
        if (typeof rfs !== 'undefined' && rfs) {
          rfs.call(el)
        }
      }
    },
    resizeTable: function() {
      this.$nextTick(function() {
        const divHeight = $('#tableContainer').height()
        this.tableHeight = divHeight - 22
        this.tableHeight2 = divHeight - 115
      })
    },
    getRowClass({ row, column, rowIndex, columnIndex }) {
      return 'background:transparent !important;'
    },
    async GetStageList() {
      const data = {
        type: 'stage',
        key: this.keyid
      }
      this.stageList = []
      this.stageList.push({
        key: 'ALL',
        data: 'ALL'
      })
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        obj.forEach((x) => {
          this.stageList.push(x)
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    clearKeyLogFormData() {
      this.mtLogForm.lineId = this.keyid
      this.mtLogForm.type = ''
      this.mtLogForm.reason_code = ''
      this.mtLogForm.stage = 'ALL'
      this.mtLogForm.start_time = ''
      this.mtLogForm.end_time = ''
      this.mtLogForm.dymaticItems.forEach((x) => {
        x.data = ''
      })
    },
    async GetReasonCodes() {
      this.clearKeyLogFormData()
      const data = {
        level: this.level,
        id: this.keyid
      }
      this.activeIssueTypes = []
      const response = await GetDPMReasonCode(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.reasonCodeList = obj
        this.reasonCodeList.forEach((x) => {
          this.activeIssueTypes.push(x.type)
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    async reasoncodeSelected(type, code) {
      this.clearKeyLogFormData()
      this.mtLogForm.type = type
      // if (type === '其他' && (code.reason_code === '其他原因' || code.reason_code === '其他故障')) {
      //   this.isNotOtherReason = false
      //   this.mtLogForm.reason_code = ''
      // } else {
      this.isNotOtherReason = true
      this.mtLogForm.reason_code = code.reason_code
      // }
      this.currentCode = code
      this.refreshDymaticList(code.id, this.mtLogForm.stage)
    },
    stageChangeHandler() {
      if (this.currentCode === null) {
        return
      }
      this.refreshDymaticList(this.currentCode.id, this.mtLogForm.stage)
    },
    async refreshDymaticList(codeId, stage) {
      const data = {
        id: codeId,
        stage: stage
      }
      const response = await GetDPMLogDymaticItems(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.dymaticItemList = obj
        // 将动态项填充到表单项中
        this.mtLogForm.dymaticItems = []
        this.dymaticItemList.forEach((i) => {
          this.mtLogForm.dymaticItems.push({
            label: i.label,
            data: '',
            required: i.required,
            type: i.type
          })
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    async SaveNewIssueLog() {
      if (this.mtLogForm.type === '') {
        this.alertMsg('錯誤代碼未選擇')
        return
      }
      if (this.mtLogForm.reason_code === '') {
        this.alertMsg('錯誤代碼未填寫')
        return
      }
      if (this.mtLogForm.start_time === '') {
        this.alertMsg('異常開始時間未選擇')
        return
      }
      if (this.mtLogForm.end_time === '') {
        this.alertMsg('異常結束時間未選擇')
        return
      }
      if (this.mtLogForm.start_time >= this.mtLogForm.end_time) {
        this.alertMsg('異常開始時間不能等於或晚於結束時間')
        return
      }
      for (let i = 0; i < this.mtLogForm.dymaticItems.length; i++) {
        if (this.mtLogForm.dymaticItems[i].data === '') {
          // 看看是否是必填项目
          // if (this.dymaticItemList[i].required) {
          if (this.mtLogForm.dymaticItems[i].required) {
            this.alertMsg(this.mtLogForm.dymaticItems[i].label + ' 還未填寫內容')
            return
          }
        }
        if (this.mtLogForm.dymaticItems[i].type.toLowerCase() === 'number') {
          if (this.mtLogForm.dymaticItems[i].data !== '') {
            if (isNaN(this.mtLogForm.dymaticItems[i].data)) {
              this.alertMsg(this.mtLogForm.dymaticItems[i].label + ' 的內容不是數字')
              return
            }
          }
        }
      }
      if (!confirm('確定要提交異常信息嗎？')) {
        return
      }
      this.loadingData = this.$loading({
        lock: true,
        text: '正在提交數據，請耐心等待...',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })

      const params = { ...this.mtLogForm, viewrange: this.viewRange }

      const response = await SaveIssueLog(params)

      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.clearKeyLogFormData()
        this.$alert('保存異常原因成功', '提示', {
          confirmButtonText: '確定',
          type: 'success'
        })
        this.queryLogData()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async deleteLog(row) {
      if (!confirm('確定要刪除這條記錄嗎？')) {
        return
      }
      this.loadingData = this.$loading({
        lock: true,
        text: '正在刪除數據，請耐心等待...',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const data = {
        rowId: row.row_id
      }
      const response = await DeleteIssueLog(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert('刪除成功', '提示', {
          confirmButtonText: '確定',
          type: 'success'
        })
        this.queryLogData()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async queryLogData() {
      if (this.logQueryBegin > this.logQueryEnd) {
        this.alertMsg('開始時間不能晚於結束時間')
        return
      }
      const interval = this.logQueryEnd - this.logQueryBegin
      if (interval > 129600000) {
        this.alertMsg('查詢間隔不能超過36小時')
        return
      }
      const begin = this.$utils.GetDateTimeString(this.logQueryBegin)
      const end = this.$utils.GetDateTimeString(this.logQueryEnd)
      const data = {
        lineId: this.keyid,
        begin: begin,
        end: end
      }
      this.tableDataLogList = []
      this.loadingLog = true
      const response = await GetDPMIssueLogData(data)
      this.loadingLog = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.tableDataLogList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeLogMtDialog() {
      this.logMtDialogVisible = false
    },
    showMappingDailog(row) {
      this.detailRangeDailogVisible = true
      this.getRangeDetailData(row.row_id)
      this.getCanMatchLog()
    },
    async getRangeDetailData(rowid) {
      this.parentRowId = rowid
      const data = {
        pid: rowid,
        index: 'UPH'
      }
      this.tableDataIssueRangeDetail = []
      this.loadingLossList = true
      const response = await GetDPMRangeIssueData(data)
      this.loadingLossList = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.tableDataIssueRangeDetail = obj
        if (this.tableDataIssueRangeDetail.length === 0) {
          this.$alert('沒有記錄，可能是已經填寫完畢，或是當前區段還未結束', '提示', {
            confirmButtonText: '確定',
            type: 'warning'
          })
          // this.closeDetailRangeDailog()
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getCanMatchLog() {
      this.selectedReason = ''
      const data = {
        lineId: this.keyid,
        viewRange: this.viewRange
      }
      this.loadingCanMatchLog = true
      this.tableDataCanMatchLog = []
      const response = await GetDPMCanMatchLogData(data)
      this.loadingCanMatchLog = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.tableDataCanMatchLog = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    lossItemSelectedChanged(val) {
      this.tableDataIssueRangeSelected = val
    },
    setSelectedLossColor({ row }) {
      if (this.tableDataIssueRangeSelected.filter((x) => x.row_id === row.row_id).length > 0) {
        return 'selected-row'
      }
      return ''
    },
    setSelectedReasonColor({ row }) {
      if (row.row_id === this.selectedReason) {
        return 'selected-row'
      }
      return ''
    },
    closeDetailRangeDailog() {
      this.detailRangeDailogVisible = false
    },
    async showDRIFilter(row) {
      this.log3IN1SelectedRow = row
      if (this.dataEntity.area === 'FATP') {
        if (this.tableDataIssueRangeSelected.length === 0) {
          this.alertMsg('請先選擇LOSS清單項')
          return
        }
        if (this.selectedReason === '') {
          this.alertMsg('請先選擇LOSS原因')
          return
        }
      } else {
        if (this.log3IN1SelectedRow === null) {
          this.alertMsg('未確認選中的行，請重新點擊')
          return
        }
        if (row.loss === '' || row.loss === null || row.loss === undefined) {
          this.alertMsg('損失未填寫，不能分配責任人')
          return
        }
        try {
          const loss = parseFloat(row.loss)
          if (loss <= 0) {
            this.alertMsg('損失不能小於等於0')
            return
          }
        } catch {
          this.alertMsg('損失不是數字')
          return
        }
      }
      this.currentDRIEmpId = ''
      this.currentDRIName = ''
      this.tableDRIFilter = []
      this.driFilterString = ''
      this.driFilterDialogVisible = true
      this.getCommonDRIList()
    },
    async getCommonDRIList() {
      this.loadingCommonDRI = true
      const response = await GetCommonDRIList()
      this.loadingCommonDRI = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.tableDRICommom = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async saveDispatchUser(autoClose) {
      if (this.tableDataIssueRangeSelected.length === 0) {
        this.alertMsg('請先選擇LOSS清單項')
        return
      }
      if (this.selectedReason === '') {
        this.alertMsg('請先選擇LOSS原因')
        return
      }
      if (this.currentDRIEmpId === '') {
        this.alertMsg('請先分配責任人')
        return
      }
      const msg = '確定要將問題分配給 ' + this.currentDRIEmpId + ' ' + this.currentDRIName + ' 來處理嗎？分配以後不能更改！'
      if (!confirm(msg)) {
        return
      }
      this.loadingData = this.$loading({
        lock: true,
        text: '正在分配責任人，請耐心等待...',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const lossList = []
      this.tableDataIssueRangeSelected.forEach((x) => {
        lossList.push({
          p_row_id: x.p_row_id,
          row_id: x.row_id
        })
      })
      const data = {
        log_row_id: this.selectedReason,
        dri: this.currentDRIEmpId,
        auto_close: autoClose ? 'Y' : 'N',
        loss_list: lossList
      }
      const response = await SaveDispatchUser(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert('分配責任人成功！', '提示', {
          confirmButtonText: '確定',
          type: 'success'
        })
        this.getRangeDetailData(this.parentRowId)
        this.getCanMatchLog()
        this.currentDRIEmpId = ''
        this.currentDRIName = ''
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeDRIFilterDailog() {
      this.driFilterDialogVisible = false
    },
    async queryEmpList() {
      if (this.driFilterString === null) {
        this.alertMsg('請輸入篩選條件')
        return
      }
      if (this.driFilterString === '') {
        this.alertMsg('請輸入篩選條件')
        return
      }
      this.loading = true
      const data = {
        filter: this.driFilterString
      }
      const response = await GetEmpInfoList(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.tableDRIFilter = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    chooseDRI(row) {
      this.currentDRIEmpId = row.employee_id
      this.currentDRIName = row.name
      if (this.log3IN1SelectedRow !== null) {
        this.log3IN1SelectedRow.dri = row.employee_id
        this.log3IN1SelectedRow.dri_name = row.name
      }
      this.closeDRIFilterDailog()
    },
    async removeDRI(row) {
      const msg = row.employee_id + ' ' + row.name
      if (!confirm('確定要將 ' + msg + '從常用人員清單中移除嗎？')) {
        return
      }
      const data = {
        empId: row.employee_id
      }
      const response = await RemoveCommonDRIList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert('移除常用責任人成功', '提示', {
          confirmButtonText: '確定',
          type: 'success'
        })
        this.getCommonDRIList()
      } else {
        this.alertMsg(queryResult)
      }
    },
    getCellColor({ row, columnIndex, rowIndex, column }) {
      if (columnIndex >= 1 && row.item === 'FPY') {
        const color = this.rtyOAILCols[columnIndex - 1].color
        return 'color: ' + color
      }
    },
    getCellColor2({ row, columnIndex, rowIndex }) {
      if (columnIndex >= 1 && row.item === 'FPY') {
        const color = this.rtyOATLCols[columnIndex - 1].color
        return 'color: ' + color
      }
    },
    async getIndexChartData(index) {
      this.currentKPIName = index
      // -----------------------------------------
      // 20221201 Kimi 根据KPI调整Div大小
      this.getDivClass('top')
      this.getDivClass('buttom')
      this.$nextTick(() => {
        if (this.rightTopChart !== null) {
          this.rightTopChart.resize()
        }
      })
      // -----------------------------------------
      window.localStorage.setItem('market_dpm_clickKPI', this.currentKPIName)
      if (this.leftTopChart !== null) {
        this.leftTopChart.dispose()
      }
      if (this.rtyChart !== null) {
        this.rtyChart.dispose()
      }
      if (index !== 'RTY') {
        this.bottomLeftTitle = '分時段產出清單'
        this.bottomRightTitle = '問題追蹤'
        this.showKPIChart = true
        this.showRTYData = false
        const data = {
          lineid: this.keyid,
          index: index,
          viewrange: this.viewRange
        }
        const response = await GetDPMDashboardLineIndexData(data)
        const queryResult = response.data.QueryResult
        if (queryResult === 'OK') {
          const obj = response.data.ReturnObject
          const series = []
          const dataList = []
          // 20220926 Kimi PCBA指标横过来显示
          var markLineData = []
          if (this.dataEntity.area === 'PCBA') {
            markLineData = [{ xAxis: obj.markline_yAxis, name: obj.markline_name }]
          } else {
            markLineData = [{ yAxis: obj.markline_yAxis, name: obj.markline_name }]
          }
          obj.seriesData.forEach((x) => {
            dataList.push({
              value: x.value,
              itemStyle: {
                color: x.itemStyle.color
              }
            })
          })
          series.push({
            data: dataList,
            type: 'bar',
            label: {
              show: true,
              position: 'inside'
            },
            markLine: {
              data: markLineData, // [{ yAxis: obj.markline_yAxis, name: obj.markline_name }],
              label: {
                formater: '{b}:{c}',
                color: 'rgb(0,175,80)',
                fontSize: 14
              },
              lineStyle: {
                color: 'rgb(0,175,80)',
                width: 3
              }
            }
          })
          var chartDom = document.getElementById('elTopLeft')
          this.leftTopChart = this.$echarts.init(chartDom)
          this.leftTopChart.clear()
          var option
          // 20220926 Kimi PCBA横过来显示，X轴和Y轴对调
          if (this.dataEntity.area === 'PCBA') {
            option = {
              title: {
                text: index + '達成率',
                left: 'center'
              },
              tooltip: {
                trigger: 'axis'
              },
              toolbox: {
                feature: {
                  dataView: { show: true, readOnly: true },
                  saveAsImage: {}
                }
              },
              yAxis: {
                type: 'category',
                data: obj.xAxisData
              },
              xAxis: {
                type: 'value'
              },
              series: series
            }
          } else {
            option = {
              title: {
                text: index + '達成率',
                left: 'center'
              },
              tooltip: {
                trigger: 'axis'
              },
              toolbox: {
                feature: {
                  dataView: { show: true, readOnly: true },
                  saveAsImage: {}
                }
              },
              xAxis: {
                type: 'category',
                data: obj.xAxisData
              },
              yAxis: {
                type: 'value',
                max: Math.round((obj.markline_yAxis > 0 ? obj.markline_yAxis : 100) * 1.1)
              },
              series: series
            }
          }
          this.leftTopChart.setOption(option)
        } else {
          this.alertMsg(queryResult)
        }
      } else {
        if (this.dataEntity.area === 'PCBA') {
          this.bottomLeftTitle = 'Before Reflow'
          this.bottomRightTitle = 'After Reflow'
        } else {
          this.bottomLeftTitle = 'OATL記錄'
          this.bottomRightTitle = 'OAIL記錄'
        }

        this.showKPIChart = false
        this.showRTYData = true
        const data = {
          lineid: this.keyid,
          viewrange: this.viewRange
        }
        const response = await GetDPMDashboardLineIndexDataRTY(data)
        const queryResult = response.data.QueryResult
        if (queryResult === 'OK') {
          const obj = response.data.ReturnObject
          // 20221201 Kimi 原表名称不动，更改数据源，以免修改太多地方
          // this.rtyOAILCols = obj.oail.cols
          // this.tableRTYOAIL = obj.oail.datas
          // this.rtyOATLCols = obj.oatl.cols
          // this.tableRTYOATL = obj.oatl.datas
          this.rtyOAILCols = obj.summary.cols
          this.tableRTYOAIL = obj.summary.datas
          this.rtyOATLCols = obj.detail.cols
          this.tableRTYOATL = obj.detail.datas
          this.tableDataRTYOATL = obj.oatl_defect
          this.tableDataRTYOAIL = obj.oail_defect
          this.tableRTYRange = obj.rty_range

          const series = []
          const legend = []
          const dataListGoal = []
          const dataListRTY = []
          let rtyMin = 100
          let goalMin = 100
          obj.series[0].data.forEach((x) => {
            dataListGoal.push({
              value: x
            })
            if (goalMin > x) {
              goalMin = x
            }
          })
          obj.series[1].data.forEach((x) => {
            dataListRTY.push({
              value: x
            })
            if (rtyMin > x) {
              rtyMin = x
            }
          })
          // 取实际值和goal的最小值，最小值再下探5%作为折线图的下限
          let yMin = rtyMin
          if (rtyMin > goalMin) {
            yMin = goalMin
          }
          yMin = yMin - yMin * 0.05
          legend.push(obj.series[0].name)
          legend.push(obj.series[1].name)
          series.push({
            data: dataListGoal,
            type: 'line',
            name: legend[0],
            label: {
              show: false,
              position: 'inside'
            }
          })
          series.push({
            data: dataListRTY,
            type: 'line',
            name: legend[1],
            label: {
              show: true,
              position: 'inside'
            }
          })
          var chartDomRTY = document.getElementById('elRTYChart')
          this.rtyChart = this.$echarts.init(chartDomRTY)
          this.rtyChart.clear()
          var optionRTY
          optionRTY = {
            // title: {
            //   text: index,
            //   left: 'center'
            // },
            tooltip: {
              trigger: 'axis'
            },
            toolbox: {
              feature: {
                dataView: { show: true, readOnly: true },
                saveAsImage: {}
              }
            },
            legend: {
              data: legend
            },
            xAxis: {
              type: 'category',
              data: obj.xAxisData
            },
            yAxis: {
              type: 'value',
              min: yMin,
              max: 100
            },
            series: series
          }
          this.rtyChart.setOption(optionRTY)
        } else {
          this.alertMsg(queryResult)
        }
      }
      this.$nextTick(() => {
        this.resizeTable()
      })
    },
    getHeaderCellColor() {
      const style = {
        'background-color': 'rgb(52,124,186)',
        color: 'white'
      }
      return style
    },
    close3IN1Dialog() {
      this.log3IN1DialogVisible = false
    },
    // 20221201 Kimi 更具换线工时来填充换线次数
    keyInLossChange(row) {
      // 如果是换线工时，则进行下去
      if (row.type === '生產損失' && row.reason_code === '換線工時') {
        // 需要有reasoncode是换线次数的项目
        const targetRows = this.log3IN1ReasonCode.filter((x) => x.reason_code === '換線次數')
        // 只能有1项，多了不行
        if (targetRows != null && targetRows.length === 1) {
          // 若换线工时没有内容，默认0
          if (row.loss === '') {
            row.loss = 0
          }
          try {
            // 判断换线工时是否是合理的数字
            let fLoss = parseFloat(row.loss)
            console.log()
            if (fLoss < 0 || isNaN(fLoss)) {
              fLoss = 0
            }
            row.loss = fLoss
            if (fLoss > 0) {
              try {
                const targetLossData = parseFloat(targetRows[0].loss)
                // 若输入的换线次数是小于等于0的数字，则设置为1，如果是大于等于0了，则不做变化
                if (targetLossData <= 0 || isNaN(targetLossData)) {
                  targetRows[0].loss = 1
                }
              } catch {
                targetRows[0].loss = 1
              }
            } else {
              targetRows[0].loss = 0
            }
          } catch {
            row.loss = 0
            targetRows[0].loss = 0
          }
        }
      }
    },
    save3IN1Data() {
      // if (this.shiftCode === '') {
      //   this.alertMsg('請選擇班別代碼')
      //   return
      // }
      if (this.log3IN1Range === '' || this.log3IN1Range === 0) {
        this.alertMsg('時間區段為0')
        return
      }
      if (this.woBase.wo === '') {
        this.alertMsg('請選擇正確的工單')
        return
      }
      if (this.woBase.current_qty === '' || this.woBase.current_qty === 0) {
        this.alertMsg('投入(本次)數量還未填寫')
        return
      }
      try {
        const qty = parseInt(this.woBase.current_qty)
        if (qty < 0) {
          this.alertMsg('投入(本次)數量不能小於0')
          return
        }
      } catch {
        this.alertMsg('投入(本次)數量不是數字')
        return
      }
      let totalLoss = 0
      let hasLoss = false
      for (let i = 0; i < this.log3IN1ReasonCode.length; i++) {
        if (this.log3IN1ReasonCode[i].loss === '') {
          this.log3IN1ReasonCode[i].loss = 0
        }
        try {
          const loss = parseInt(this.log3IN1ReasonCode[i].loss)
          if (loss < 0) {
            this.alertMsg('Loss不能小於0')
            return
          }
          if (loss > 0) {
            hasLoss = true
            if (this.log3IN1ReasonCode[i].dri === '' && this.log3IN1ReasonCode[i].need_dri === 'Y') {
              this.alertMsg('Loss大於0則必須分配責任人')
              return
            }
          }
          if (this.log3IN1ReasonCode[i].unit !== '次') {
            totalLoss = totalLoss + loss
          }
        } catch {
          this.alertMsg('Loss必須是數字')
          return
        }
      }
      if (totalLoss > this.log3IN1Range) {
        this.alertMsg('Total loss大於當前選定時段的長度' + this.log3IN1Range)
        return
      }
      if (hasLoss === false) {
        if (!confirm('沒有填寫任何的Loss項目，確定要提交數據嗎？')) {
          return
        }
      }
      this.log3IN1AuthEmpId = ''
      this.log3IN1AuthPwd = ''
      this.log3IN1AuthCheckDialogVisible = true
      this.$nextTick(() => {
        this.$refs.inputAuthEmpId.focus()
      })
    },
    async getWorkDayWorkshift() {
      // start add 20230210 fenglianlong  三班制修改
      this.workshiftList = []
      const data = {
        factory: this.dataEntity.factory,
        line: this.dataEntity.line
      }
      const response = await GetWorkshiftList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.workshiftList = response.data.ReturnObject
      } else {
        this.alertMsg('無法獲取當前線別班別, ' + queryResult)
      }
      // end add 20230210-----------------------
    },
    async getWorkDayWorkTime() {
      if (this.log3IN1WorkDay === null) {
        const tempWorkDay =
          this.dataEntity.workday.substr(0, 4) + '-' + this.dataEntity.workday.substr(4, 2) + '-' + this.dataEntity.workday.substr(6, 2)
        this.log3IN1WorkDay = new Date(tempWorkDay)
      }
      const tempWD = this.$utils.GetDateString(this.log3IN1WorkDay).replace(/-/g, '')
      const data = {
        factory: this.dataEntity.factory,
        shift: this.log3IN1Shift,
        line: this.dataEntity.line,
        workDay: tempWD
      }
      this.log3IN1WorkTime = ''
      this.workTimeList = []
      this.workTimeStart = ''
      this.workTimeEnd = ''
      // const response = await GetWorkStartAndEndTime(data)
      const response = await GetWorkTimeList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.workTimeList = response.data.ReturnObject
        // this.workTimeStart = response.data.ReturnObject.start_time
        // this.workTimeEnd = response.data.ReturnObject.end_time
        this.setIssueBeginData()
      } else {
        this.alertMsg('無法獲取當前線別班別的工作起止時間, ' + queryResult)
      }
    },
    getWorkTimeString(item) {
      return item.start_time + ' ~ ' + item.end_time
    },
    getWorkTime() {
      this.workTimeStart = this.workTimeList.filter((x) => x.work_time === this.log3IN1WorkTime)[0].start_time
      this.workTimeEnd = this.workTimeList.filter((x) => x.work_time === this.log3IN1WorkTime)[0].end_time
      this.log3IN1Begin = null
      this.log3IN1End = null

      // -------------------------------------------------------
      // 20220914 Kimi 选择工作时间段的时候就去查询begin时间
      this.setIssueBeginData()
      // -------------------------------------------------------
    },
    // async getShiftCodeList () {
    //   const response = await GetWorkShiftCode()
    //   const queryResult = response.data.QueryResult
    //   if (queryResult === 'OK') {
    //     this.shiftCodeList = response.data.ReturnObject
    //   } else {
    //     this.alertMsg('無法獲取班別代碼清單, ' + queryResult)
    //   }
    // },
    async getMESStageList() {
      this.log3IN1Stage = ''
      this.log3IN1Process = ''
      this.log3IN1StageList = []
      this.log3IN1ProcessList = []
      this.log3IN1Operation = ''

      // by zhujunjie 2023-06-05
      const param = {
        factory: this.dataEntity.factory
      }
      const response = await GetMESStageList(param)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.log3IN1StageList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getMESProcessList() {
      this.log3IN1Process = ''
      this.log3IN1ProcessList = []
      this.log3IN1Operation = this.log3IN1StageList.filter((x) => x.stage_id === this.log3IN1Stage)[0].operation
      const data = {
        stageId: this.log3IN1Stage
      }
      const response = await GetMESProcessList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.log3IN1ProcessList = response.data.ReturnObject
        this.setIssueBeginData()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getPCBAReasonCode() {
      this.spanRows = []
      this.log3IN1ReasonCode = []
      const data = {
        factory: this.dataEntity.factory
      }
      const response = await GetDPMPCBAReasonCode(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        obj.forEach((x) => {
          this.log3IN1ReasonCode.push({
            id: x.id,
            type: x.type,
            reason_code: x.reason_code,
            description: '', // 20230425 wangjun 改為空
            reason_code_en: x.reason_code_en,
            need_dri: x.need_dri,
            loss: 0,
            dri: '',
            dri_name: '',
            need_check: x.need_response === 'Y',
            unit: x.unit,
            type_en: x.type_en,
            need_response: x.need_response
          })
        })
        // 查看返回的表格，看需要合并单元格的行数
        let lastType = ''
        let spanQty = 0
        let rowIndex = 0
        for (let i = 0; i < obj.length; i++) {
          const type = obj[i].type
          if (type !== lastType) {
            lastType = type
            if (spanQty > 0) {
              this.spanRows.push({
                rowIndex: rowIndex,
                spanQty: spanQty
              })
              rowIndex = i
              spanQty = 0
            }
          }
          spanQty = spanQty + 1
          if (i === obj.length - 1) {
            this.spanRows.push({
              rowIndex: rowIndex,
              spanQty: spanQty
            })
          }
        }
      } else {
        this.alertMsg('無法獲取錯誤代碼, ' + queryResult)
      }
    },
    arraySpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        const ff = this.spanRows.filter((x) => x.rowIndex === rowIndex)
        if (ff.length > 0) {
          return [ff[0].spanQty, 1]
        } else {
          return [0, 0]
        }
      }
    },
    getComputedType(row) {
      if (row.type_en === '') {
        return row.type
      } else {
        return row.type + '(' + row.type_en + ')'
      }
    },
    getComputedReasonCode(row) {
      if (row.reason_code_en === '') {
        return row.reason_code
      } else {
        return row.reason_code + '(' + row.reason_code_en + ')'
      }
    },
    getComputedDRI(row) {
      if (row.dri === '') {
        return ''
      } else {
        return row.dri + ' ' + row.dri_name
      }
    },
    clearRowDRI(row) {
      row.dri = ''
      row.dri_name = ''
    },

    // by zhujunjie 2023-05-31
    GetPcbaEmsData() {
      if (this.log3IN1WorkTime && this.log3IN1Process) {
        const process = this.log3IN1ProcessList.filter((x) => x.process_id == this.log3IN1Process)[0].process_name
        const params = {
          lineid: this.keyid,
          viewrange: this.viewRange,
          work_time: this.log3IN1WorkTime,
          process: process
        }

        GetPcbaEmsData_API(params).then((res) => {
          const obj = res.data
          if (obj.QueryResult == 'OK') {
            this.timeLoss = obj.ReturnObject
          }
        })
      }
    },
    async setIssueBeginData() {
      // by zhujunjie 2023-05-31
      this.GetPcbaEmsData()

      // -------------------------------------------------------------------------------------------------
      // 20220914 Kimi 查询范围卡到work_date+shift+line即可，不用卡到stage和process了，这一段注释掉
      // 因为报工需要细到每个stage，PCBA在生产时，stage的切换是连续的，不会同时存在，因此时间上也需要连续
      // if (this.log3IN1Stage === '') {
      //   return
      // }
      // if (this.log3IN1Process === '') {
      //   return
      // }
      // -------------------------------------------------------------------------------------------------
      this.log3IN1End = ''
      // -------------------------------------------------------------------------------------------------
      // 20220914 Kimi 这一段注释掉
      // const stage = this.log3IN1StageList.filter(x => x.stage_id === this.log3IN1Stage)[0].stage_name
      // const process = this.log3IN1ProcessList.filter(x => x.process_id === this.log3IN1Process)[0].process_name
      // -------------------------------------------------------------------------------------------------
      const workDay = this.$utils.GetDateString(this.log3IN1WorkDay).replace(/-/g, '')
      if (this.workTimeStart === '') {
        // this.alertMsg('無法確定本區段的開始和結束時間，請確認是否有維護好')
        return
      }
      const data = {
        factory: this.dataEntity.factory,
        workDay: workDay,
        shift: this.log3IN1Shift,
        area: this.dataEntity.area,
        team: this.dataEntity.team,
        line: this.dataEntity.line,
        stage: '', // 20220914 Kimi 这里传空白
        process: '' // 20220914 Kimi 这里传空白
      }
      let dbMaxEndData = ''
      const response = await GetMAX3IN1EndTime(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        dbMaxEndData = response.data.ReturnObject
      }
      const wKStart = new Date(this.workTimeStart)
      if (dbMaxEndData === '') {
        this.log3IN1Begin = wKStart
      } else {
        const maxD = new Date(dbMaxEndData)
        if (maxD >= wKStart) {
          this.log3IN1Begin = maxD
        } else {
          this.log3IN1Begin = wKStart
        }
      }
    },
    clearAll3IN1Data() {
      this.log3IN1Range = 0
      this.log3IN1WO = ''
      this.log3IN1WOlist = []
      this.woBase.wo = ''
      this.woBase.stage = ''
      this.woBase.process = ''
      this.woBase.line = ''
      this.woBase.part_no = ''
      this.woBase.uph = ''
      this.woBase.wo_qty = 0
      this.woBase.in_repair = 0
      this.woBase.calc_qty = 0
      this.woBase.current_qty = 0
      this.woBase.total_qty = 0
      this.woBase.new_model = 'N'
      this.normolization_factor = 1
      this.log3IN1ReasonCode.forEach((x) => {
        x.loss = 0
        x.dri = ''
        x.dri_name = ''
        // x.need_check = true  20221026 Kimi 这里不能设置为true，会把需要自动close的给设置为需要填写对策
      })
    },
    async getWOList() {
      this.log3IN1WO = ''
      if (this.log3IN1Begin === null || this.log3IN1Begin === '' || this.log3IN1End === null || this.log3IN1End === '') {
        return
      }
      const wkEnd = new Date(this.workTimeEnd)
      if (this.log3IN1End > wkEnd) {
        this.log3IN1End = wkEnd
      }
      const interval = this.log3IN1End - this.log3IN1Begin
      if (interval <= 0) {
        this.log3IN1End = ''
        this.alertMsg('結束時間不能早於等於開始時間')
        return
      }
      if (interval > 14400000) {
        this.log3IN1End = ''
        this.alertMsg('時間間隔不能超過4小時')
        return
      }
      this.clearAll3IN1Data()
      this.log3IN1Range = parseInt(interval / (60 * 1000))
      const begin = this.$utils.GetDateTimeString(this.log3IN1Begin)
      const end = this.$utils.GetDateTimeString(this.log3IN1End)
      const data = {
        factory: this.dataEntity.factory,
        line: this.dataEntity.line,
        stageId: this.log3IN1Stage,
        processId: this.log3IN1Process,
        begin: begin,
        end: end
      }
      const response = await GetDPM3IN1WOList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.log3IN1WOlist = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getWOBaseData() {
      const begin = this.$utils.GetDateTimeString(this.log3IN1Begin)
      const end = this.$utils.GetDateTimeString(this.log3IN1End)
      const workDay = this.$utils.GetDateString(this.log3IN1WorkDay).replace(/-/g, '')
      const data = {
        factory: this.dataEntity.factory,
        workDay: workDay,
        shift: this.log3IN1Shift,
        line: this.dataEntity.line,
        stageId: this.log3IN1Stage,
        processId: this.log3IN1Process,
        wo: this.log3IN1WO,
        begin: begin,
        end: end
      }
      const response = await Get3IN1WOBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.woBase.wo = obj.wo
        this.woBase.stage = obj.stage
        this.woBase.process = obj.process
        this.woBase.line = obj.line
        this.woBase.part_no = obj.part_no
        this.woBase.uph = obj.uph
        this.woBase.wo_qty = obj.wo_qty
        this.woBase.in_repair = obj.in_repair
        this.woBase.calc_qty = obj.calc_qty
        this.woBase.current_qty = obj.current_qty
        this.woBase.total_qty = obj.total_qty
        this.woBase.new_model = obj.new_model
        this.woBase.normolization_factor = obj.normolization_factor

        // 循环reasoncode，对指定的code查询默认值
        this.log3IN1ReasonCode.forEach(async(x) => {
          if (x.type === '其他' && x.reason_code === '換料次數') {
            const begin = this.$utils.GetDateTimeString(this.log3IN1Begin)
            const end = this.$utils.GetDateTimeString(this.log3IN1End)
            const d2 = {
              factory: this.dataEntity.factory,
              line: this.dataEntity.line,
              area: this.dataEntity.area,
              team: this.dataEntity.team,
              type: x.type,
              reasonCode: x.reason_code,
              workDay: workDay,
              shift: this.log3IN1Shift,
              begin: begin,
              end: end,
              wo: this.woBase.wo
            }
            const resp2 = await GetDPMPCBAReasonCodeDefaultValue(d2)
            const qR = resp2.data.QueryResult
            if (qR === 'OK') {
              x.loss = resp2.data.ReturnObject
            } else {
              this.alertMsg('無法獲得默認值 ' + qR)
            }
          }
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    async check3IN1AuthAndSubmit() {
      if (this.log3IN1AuthEmpId === '') {
        this.alertMsg('請輸入領班工號')
        return
      }
      if (this.log3IN1AuthPwd === '') {
        this.alertMsg('請輸入領班密碼')
        return
      }
      const data = {
        lineId: this.keyid,
        userId: this.log3IN1AuthEmpId,
        password: this.log3IN1AuthPwd
      }
      const response = await Check3IN1SavePrivilege(data)
      const queryResult = response.data.QueryResult
      let checkResult = ''
      if (queryResult === 'OK') {
        checkResult = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
        return
      }
      if (checkResult !== 'OK') {
        this.alertMsg(checkResult)
        return
      }
      this.log3IN1AuthCheckDialogVisible = false
      if (!confirm('確定要提交數據嗎？')) {
        return
      }
      this.loadingData = this.$loading({
        lock: true,
        text: '正在提交數據，請耐心等待...',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const stage = this.log3IN1StageList.filter((x) => x.stage_id === this.log3IN1Stage)[0].stage_name
      const operation = this.log3IN1StageList.filter((x) => x.stage_id === this.log3IN1Stage)[0].operation
      const process = this.log3IN1ProcessList.filter((x) => x.process_id === this.log3IN1Process)[0].process_name
      const workDay = this.$utils.GetDateString(this.log3IN1WorkDay).replace(/-/g, '')
      const sTime = this.$utils.GetDateTimeString(this.log3IN1Begin)
      const eTime = this.$utils.GetDateTimeString(this.log3IN1End)
      const rundId = '' // this.shiftCodeList.filter(x => x.runs_name === this.shiftCode)[0].runs_id
      const dataSubmit = {
        factory: this.dataEntity.factory,
        area: this.dataEntity.area,
        team: this.dataEntity.team,
        line: this.dataEntity.line,
        stage: stage,
        process: process,
        operation: operation,
        runs_id: rundId,
        work_date: workDay,
        shift_code: this.log3IN1Shift,
        start_time: sTime,
        end_time: eTime,
        minutes: this.log3IN1Range,
        wo: this.woBase.wo,
        model: this.woBase.part_no,
        std_uph: this.woBase.uph,
        wo_qty: this.woBase.wo_qty,
        wo_input_calc: this.woBase.calc_qty,
        wo_input: this.woBase.current_qty,
        wo_input_total: this.woBase.total_qty,
        wait_for_repair: this.woBase.in_repair,
        new_model: this.woBase.new_model,
        approve_user: this.log3IN1AuthEmpId,
        lineoff_time: this.workTimeEnd,
        reason_codes: []
      }
      this.log3IN1ReasonCode.forEach((x) => {
        if (parseInt(x.loss) > 0) {
          dataSubmit.reason_codes.push({
            type: x.type,
            reason_code: x.reason_code,
            impact: x.loss,
            need_check: x.need_check ? 'Y' : 'N',
            dri: x.dri,
            unit: x.unit,
            need_dri: x.need_dri,
            description: x.description
          })
        }
      })
      const responseSubmit = await submit3IN1Data(dataSubmit)
      const queryResultSubmit = responseSubmit.data.QueryResult
      let submitResult = ''
      this.loadingData.close()
      if (queryResultSubmit === 'OK') {
        submitResult = response.data.ReturnObject
        if (submitResult === 'OK') {
          if (!confirm('提交數據成功，需要繼續填寫下一筆數據嗎？')) {
            this.log3IN1DialogVisible = false
          } else {
            this.setIssueBeginData()
            this.clearAll3IN1Data()
          }
        }
      } else {
        this.alertMsg(queryResultSubmit)
      }
    },
    cancelAuthCheck() {
      this.log3IN1AuthEmpId = ''
      this.log3IN1AuthPwd = ''
      this.log3IN1AuthResult = 'cancel'
      this.log3IN1AuthCheckDialogVisible = false
    },

    async showMasterStageView(MasterStage, StageName, isShowBind = 0) {
      this.isShowBind = isShowBind
      this.MasterStageLabel = MasterStage
      this.MasterStageOutputStage = StageName
      console.log(MasterStage, StageName)
      if (MasterStage === '' && StageName === '') {
        this.getDashBoardData()
        return
      }
      const data = {
        lineid: this.keyid,
        viewrange: this.viewRange,
        MasterStage: MasterStage
      }
      this.loadingData = this.$loading({
        lock: true,
        text: '正在加載數據，請耐心等待...',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await GetDashboardLineStageDetailData(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.tableDataRange = obj.archive_rate
        //  Start right Line Chart
        {
          var optionCline = this.leftTopChart.getOption()
          if (this.leftTopChart !== null) {
            this.leftTopChart.dispose()
          }
          var chartDom = document.getElementById('elTopLeft')
          this.leftTopChart = this.$echarts.init(chartDom)
          this.leftTopChart.clear()
          const series = []
          const dataList = []
          var markLineData = []
          markLineData = [{ yAxis: obj.markline_yAxis, name: obj.markline_name }]
          obj.seriesData.forEach((x) => {
            dataList.push({
              value: x.value,
              itemStyle: {
                color: x.itemStyle.color
              }
            })
          })
          series.push({
            data: dataList,
            type: 'bar',
            label: {
              show: true,
              position: 'inside'
            },
            markLine: {
              data: markLineData,
              label: {
                formater: '{b}:{c}',
                color: 'rgb(0,175,80)',
                fontSize: 14
              },
              lineStyle: {
                color: 'rgb(0,175,80)',
                width: 3
              }
            }
          })
          optionCline.xAxis[0].data = obj.xAxisData
          optionCline.series = series
          this.leftTopChart.setOption(optionCline)
        }
        //  END RIGHT PLDINE CHART
        //  START RIGHT BRIDGE CHART
        {
          const lossBridge = obj.loss_bridge
          optionCline = this.rightTopChart.getOption()
          if (this.rightTopChart !== null) {
            this.rightTopChart.dispose()
          }
          chartDom = document.getElementById('elTopRight')
          this.rightTopChart = this.$echarts.init(chartDom)
          this.rightTopChart.clear()
          const series = []
          // 注意，placeholder的series要在前面才可以
          series.push({
            name: lossBridge.seriesHolder.name,
            type: lossBridge.seriesHolder.type,
            data: lossBridge.seriesHolder.data,
            label: lossBridge.seriesHolder.label,
            itemStyle: lossBridge.seriesHolder.itemStyle,
            emphasis: lossBridge.seriesHolder.emphasis,
            stack: 'Total'
          })
          series.push({
            name: lossBridge.seriesValue.name,
            type: lossBridge.seriesValue.type,
            data: lossBridge.seriesValue.data,
            label: lossBridge.seriesValue.label,
            stack: 'Total'
          })
          optionCline.xAxis[0].data = lossBridge.xAxis
          optionCline.series = series
          optionCline.title = {
            subtext: this.MasterStageLabel
          }
          this.rightTopChart.setOption(optionCline)
        }
        //  END RIGHT LOSS BRIDGE CHART
        this.tableDataDRI = obj.issue_track
      }
    },

    handleCxzp(obj) {
      console.log(obj)
      if (obj.status == '重新指派') {
        this.dialogVisibleCxzp = true
        this.$nextTick(() => {
          this.$refs['DialogDri'].init(obj.row_id)
        })
      } else {
        this.dialogVisibleCxzp = false
      }
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep main.el-main {
  padding: 0;
}
::v-deep .el-divider--horizontal {
  margin: 0;
}
section {
  padding-bottom: 0;
}
.el-header {
  padding: 0 5px;
}
.header {
  height: 50px !important;
  // background-color:#1f4e7c;
  background-color: rgba(0, 0, 0, 0);
}
.titleDiv {
  display: flex;
  justify-content: space-between;
  color: white;
}
.title {
  line-height: 50px;
  font-size: 28px;
}
.titleImg {
  // padding:5px 20px 5px 20px;
  margin-top: 8px;
  margin-left: 10px;
  margin-right: 20px;
  width: 160px;
  height: 35px;
}
.titleLeft {
  display: flex;
}
.refreshTime {
  display: inline-block;
  line-height: 40px;
  padding-top: 5px;
  font-size: 20px;
}
.indexDiv {
  // text-align: center;
  width: 115px;
}
.indexChart {
  width: 100%;
  height: 115px;
  padding-left: 5px;
  // border-bottom: 1px solid gray;
}
.indexTitleDiv {
  width: 100%;
  font-size: 20px;
}
.indexUnitDiv {
  width: 100%;
  color: gray;
  font-size: 12px;
  border-bottom: 1px solid gray;
  position: relative; // 20221212 Kimi Add
}
.chartDiv {
  // cursor: pointer;
  // width:150px;
  // height:150px;
  flex: none;
}
.summaryTitle {
  display: flex;
  justify-content: flex-start;
  // align-items: center;
  flex-wrap: nowrap;
  height: 50px;
  // width:100%;
  background-color: rgba(0, 0, 0, 0);
}
.mainSDivDay {
  // width: 50%;
  height: 100%;
  float: left;
}
.mainSpanCategory {
  font-size: 18px;
  line-height: 50px;
  display: inline-block;
  color: white;
}
.mainSummaryDiv {
  height: 50px;
  padding-left: 8px;
  margin-bottom: 10px;
  flex: none;
}
.prevWord {
  font-size: 14px;
  display: inline-block;
  color: white;
  padding-right: 10px;
}
.mainSummaryDiv1 {
  border-left: 8px solid #359cb6;
}
.mainSummaryDiv2 {
  border-left: 8px solid #38c386;
}
.mainSummaryDiv3 {
  border-left: 8px solid #f49e12;
}
.mainSummaryModel {
  flex: 1;
  text-align: right;
}
.mainSSpanValue {
  font-size: 30px;
  // float: right;
  line-height: 50px;
  margin-left: 30px;
  margin-right: 50px;
}
.mainSSpanValue1 {
  color: #359cb6;
}
.mainSSpanValue2 {
  color: #38c386;
}
.mainSSpanValue3 {
  color: #f49e12;
}
.mainSSpanValueModel {
  color: white;
}
.lineGroup {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  // height: 800px;
  height: calc(100% - 55px);
}
.oneLine {
  margin: 15px 5px 0 5px;
}
::v-deep .el-carousel__container {
  height: calc(100% - 55px);
  background-color: rgba(0, 0, 0, 0);
}
.detailBody {
  height: calc(100% - 1px);
  // height: 100%;
  width: 100%;
  background: white;
}
.detailBodyRow {
  width: 100%;
  height: calc(60% + 20px);
  padding-top: 5px;
  display: flex;
  justify-content: space-between;
}
.detailBodyRow1 {
  width: 100%;
  height: calc(40% - 20px);
  padding-top: 5px;
  display: flex;
  justify-content: space-between;
}
.detailBodyRow2 {
  width: 100%;
  height: 50%;
  padding-top: 5px;
  display: flex;
  justify-content: space-between;
}
.detailBodyRow3 {
  width: 100%;
  height: 47%;
  padding-top: 5px;
  display: flex;
  justify-content: space-between;
}
.detailBodyCell {
  width: 50%;
  height: 100%;
  padding: 0 5px;
}
#elRTYChart {
  height: calc(100% - 161px);
}
.topLeftTable {
  width: 100%;
  height: 60px;
  text-align: center;
  overflow: scroll;
  background-color: yellow !important;
}
.indexTable {
  // table-layout: fixed;
  width: 100%;
  font-size: 18px;
  margin: 0 auto;
  border-collapse: collapse;
  overflow: scroll;
}
.indexTable th {
  height: 30px;
  font-size: 24px;
  text-align: center;
  font-weight: bold;
  background-color: white;
}
::v-deep .indexTable span {
  font-size: 24px;
  font-weight: bold;
}
.topLeftChart {
  width: 100%;
  margin-top: 15px;
  height: calc(100% - 150px);
}
// ::v-deep .el-table {
//   background-color: transparent;
// }
// .table-wrapper ::v-deep .el-table--fit{
//         padding: 20px;
// }
//  .table-wrapper ::v-deep .el-table, .el-table__expanded-cell {
//     background-color: transparent;
// }

//  .table-wrapper ::v-deep  .el-table tr {
//     background-color: transparent!important;
// }
//  .table-wrapper ::v-deep   .el-table--enable-row-transition .el-table__body td, .el-table .cell{
//     background-color: transparent;
// }
.typeContainer {
  width: 320px;
  height: 100%;
  overflow: auto;
}
// .typeContainer{
//   display: flex;
//   flex-wrap: wrap;
//   width: 100%;
//   margin:30px auto;
//   justify-content: center;
// }
.logCongtainter {
  width: calc(100% - 320px);
}
.logReasonCodeContainer {
  width: 100%;
  display: flex;
  height: 190px;
  // margin-bottom: 10px;
  overflow-x: auto;
}
.logDialogContainer {
  width: 100%;
  display: flex;
  height: 500px;
}
.codeType {
  display: block;
  width: 100%;
  color: white;
  background-color: rgb(51, 85, 161);
  height: 30px;
  padding-top: 5px;
  font-size: 20px;
}
.code {
  flex: none;
  margin-right: 5px;
  width: 200px;
  height: 160px;
  box-shadow: 0 0 10px rgb(205, 205, 205);
  margin-bottom: 10px;
  overflow-y: hidden;
}
.codeSection {
  width: 200px;
  border: 1px solid rgb(51, 85, 161);
  text-align: center;
  color: rgb(51, 85, 161);
}
.tagStyle {
  width: 198px;
  height: 120px;
  text-align: center;
  display: table-cell;
  vertical-align: middle;
  overflow-y: auto;
}
.issueDetailMainDiv {
  display: flex;
  width: 100%;
  height: 520px;
}
.tableTitle {
  background-color: rgb(51, 85, 161);
  color: white;
  text-align: center;
}
::v-deep .el-table .selected-row {
  background: #ffba4a;
}
.driFilterMainDiv {
  display: flex;
  width: 100%;
  height: 520px;
}
.driSpan {
  display: inline-block;
  color: red;
  font-size: 18px;
  margin-right: 10px;
}
::v-deep .el-table .warning-row {
  background: lightyellow;
}
::v-deep .el-table .error-row {
  background: rgb(252, 210, 217);
}
::v-deep .el-table .warning {
  background: rgba(230, 162, 60, 0.75);
}

::v-deep #rtyOAILTable.el-table--small td {
  padding: 0;
}
::v-deep #rtyOAILTable.el-table--small th {
  padding: 0;
}
::v-deep #rtyOATLTable.el-table--small td {
  padding: 0;
}
::v-deep #rtyOATLTable.el-table--small th {
  padding: 0;
}
::v-deep #rtyTimeRangeTable.el-table--small td {
  padding: 0;
}
::v-deep #rtyTimeRangeTable.el-table--small th {
  padding: 0;
}
.tb {
  margin: 0 auto;
  font-size: 16px;
  border: 1px solid #cccccc;
  border-collapse: collapse;
  margin-bottom: 10px;
}
.tbCategory {
  width: 170px;
  height: 26px;
  font-size: 14px;
  text-align: center;
  background-color: #f4f4f4;
  border-bottom: 1px solid #cccccc;
  border-right: 1px solid #cccccc;
}
.tbValue {
  width: 300px;
  height: 26px;
  font-size: 14px;
  text-align: center;
  border-bottom: 1px solid #cccccc;
  border-right: 1px solid #cccccc;
}
.threeIN1TitleSpan {
  display: block;
  color: rgb(52, 124, 184);
  border-bottom: 1px solid rgb(52, 124, 184);
  font-size: 18px;
  margin: 10px 0 5px 0;
  font-weight: bold;
  font-style: italic;
}
.spanMemo {
  display: inline-block;
  color: gray;
  background-color: yellow;
  margin: 0 10px;
}
.stepHeadSpan {
  display: inline-block;
  margin-top: 10px;
  margin-right: 5px;
  color: rgb(52, 124, 184);
  font-weight: bold;
}
.woBaseInfoDiv {
  border: 1px solid rgb(52, 124, 184);
  margin-top: 10px;
  padding-right: 5px;
  padding-top: 5px;
  padding-bottom: 5px;
}
.tdWOTitle {
  width: 90px;
  padding: 0 5px;
  text-align: center;
  height: 40px;
}
::v-deep #inputWOQty.el-input__inner {
  background-color: rgb(103, 194, 58);
  color: red;
  font-weight: bold;
}
.authHeadSpan {
  display: inline-block;
  width: 150px;
}
// ::v-deep .el-table td {
//   border:1px solid lightgray;
// }
.warningDiv {
  // 20221212 Kimi Add
  position: absolute;
  width: 10px;
  height: 10px;
  background: tomato;
  bottom: 5px;
  left: 100px;
  border-radius: 5px;
}
</style>
