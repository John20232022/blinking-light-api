<template>
  <div style="height:100%;width:100%">
    <el-container style="height:100%;">
      <el-header class="header">
        <div class="titleDiv">
          <div class="title">A6 P5 PCBA & SMT 看板</div>
          <div>
            <span class="refreshTime">2021-11-02 11:21:00</span>
            <el-button size="mini" plain type="primary" style="margin-left:20px;">返回</el-button>
          </div>
        </div>
      </el-header>
      <el-main style="padding:0;">
        <el-carousel indicator-position="outside" style="height:100%">
          <el-carousel-item v-for="item in bigChartData" :key="item.id">
            <div class="lineGroup">
              <div v-for="(onelineData,index) in item.data" :key="index" class="oneLine">
                <lineComp :onedata="onelineData" />
              </div>
            </div>
          </el-carousel-item>
        </el-carousel>
      </el-main>
    </el-container>
  </div>
</template>
<script>
// import {
//   getApiInvokeQtyByFunc
// } from '@/api/kanban.js'
import lineComp from '@/components/MIDWAY/DPMPlantViewOneLine.vue'
export default {
  components: {
    lineComp
  },
  data() {
    return {
      loading: false,
      hideCol: false,
      execStatusChart: null,
      apiInvokeQtyChart: null,
      apiInvokeQtyGroupByFuncChart: null,
      apiInvokeQtyHourTop10Chart: null,
      programErrorChart: null,
      statusData: [],
      statusReport: [],
      apiInvokeQtyData: null,
      apiInvokeQtyGroupByFuncData: null,
      apiInvokeHourTop10Data: null,
      programErrorSummary: [],
      programErrorReport: [],
      chartPCBARTY: null,
      chartPCBAUPH: null,
      chartPCBAUPPH: null,
      bigChartData: [],
      chartData: [],
      chartData2: []
    }
  },
  mounted() {
    this.mockChart()
  },
  beforeDestroy() {
    clearInterval(this.intervalProgramExecStatus)
  },
  methods: {
    mockChart() {
      const p501 = {
        line: 'P501',
        group: 'PCBA',
        data: [
          {
            type: 'RTY',
            value: 40,
            name: 'RTYYYYYRTYYYYRTY'
          },
          {
            type: 'UPH',
            value: 70,
            name: 'UPH'
          },
          {
            type: 'UPPH',
            value: 90,
            name: 'UPPH'
          },
          {
            type: 'UTS',
            value: 75,
            name: 'UTS'
          }
        ]
      }
      const p502 = {
        line: 'P502',
        group: 'PCBA',
        data: [
          {
            type: 'RTY',
            value: 80,
            name: 'RTY'
          },
          {
            type: 'UPH',
            value: 90,
            name: 'UPH'
          },
          {
            type: 'UPPH',
            value: 20,
            name: 'UPPH'
          },
          {
            type: 'UTS',
            value: 85,
            name: 'UTS'
          }
        ]
      }
      const p503 = {
        line: 'P503',
        group: 'PCBA',
        data: [
          {
            type: 'RTY',
            value: 60,
            name: 'RTY'
          },
          {
            type: 'UPH',
            value: 60,
            name: 'UPH'
          },
          {
            type: 'UPPH',
            value: 70,
            name: 'UPPH'
          },
          {
            type: 'UTS',
            value: 65,
            name: 'UTS'
          }
        ]
      }
      const p504 = {
        line: 'P504',
        group: 'PCBA',
        data: [
          {
            type: 'RTY',
            value: 70,
            name: 'RTY'
          },
          {
            type: 'UPH',
            value: 70,
            name: 'UPH'
          },
          {
            type: 'UPPH',
            value: 70,
            name: 'UPPH'
          },
          {
            type: 'UTS',
            value: 75,
            name: 'UTS'
          }
        ]
      }
      const p505 = {
        line: 'P505',
        group: 'PCBA',
        data: [
          {
            type: 'RTY',
            value: 40,
            name: 'RTY'
          },
          {
            type: 'UPH',
            value: 90,
            name: 'UPH'
          },
          {
            type: 'UPPH',
            value: 100,
            name: 'UPPH'
          },
          {
            type: 'UTS',
            value: 95,
            name: 'UTS'
          }
        ]
      }
      const p506 = {
        line: 'P506',
        group: 'PCBA',
        data: [
          {
            type: 'RTY',
            value: 95,
            name: 'RTY'
          },
          {
            type: 'UPH',
            value: 70,
            name: 'UPH'
          },
          {
            type: 'UPPH',
            value: 90,
            name: 'UPPH'
          },
          {
            type: 'UTS',
            value: 45,
            name: 'UTS'
          }
        ]
      }
      this.chartData.push(p501)
      this.chartData.push(p502)
      this.chartData.push(p503)
      this.chartData.push(p504)
      this.chartData.push(p505)
      this.chartData.push(p506)
      this.bigChartData.push({
        id: 1,
        data: this.chartData
      })
      const p507 = {
        line: 'P507',
        group: 'PCBA',
        data: [
          {
            type: 'RTY',
            value: 40,
            name: 'RTY'
          },
          {
            type: 'UPH',
            value: 70,
            name: 'UPH'
          },
          {
            type: 'UPPH',
            value: 90,
            name: 'UPPH'
          },
          {
            type: 'UTS',
            value: 75,
            name: 'UTS'
          }
        ]
      }
      const p508 = {
        line: 'P508',
        group: 'PCBA',
        data: [
          {
            type: 'RTY',
            value: 80,
            name: 'RTY'
          },
          {
            type: 'UPH',
            value: 90,
            name: 'UPH'
          },
          {
            type: 'UPPH',
            value: 20,
            name: 'UPPH'
          },
          {
            type: 'UTS',
            value: 85,
            name: 'UTS'
          }
        ]
      }
      const p509 = {
        line: 'P509',
        group: 'PCBA',
        data: [
          {
            type: 'RTY',
            value: 60,
            name: 'RTY'
          },
          {
            type: 'UPH',
            value: 60,
            name: 'UPH'
          },
          {
            type: 'UPPH',
            value: 70,
            name: 'UPPH'
          },
          {
            type: 'UTS',
            value: 65,
            name: 'UTS'
          }
        ]
      }
      const p510 = {
        line: 'P510',
        group: 'PCBA',
        data: [
          {
            type: 'RTY',
            value: 70,
            name: 'RTY'
          },
          {
            type: 'UPH',
            value: 70,
            name: 'UPH'
          },
          {
            type: 'UPPH',
            value: 70,
            name: 'UPPH'
          },
          {
            type: 'UTS',
            value: 75,
            name: 'UTS'
          }
        ]
      }
      const p511 = {
        line: 'P511',
        group: 'PCBA',
        data: [
          {
            type: 'RTY',
            value: 40,
            name: 'RTY'
          },
          {
            type: 'UPH',
            value: 90,
            name: 'UPH'
          },
          {
            type: 'UPPH',
            value: 100,
            name: 'UPPH'
          },
          {
            type: 'UTS',
            value: 95,
            name: 'UTS'
          }
        ]
      }
      const p512 = {
        line: 'P512',
        group: 'PCBA',
        data: [
          {
            type: 'RTY',
            value: 95,
            name: 'RTY'
          },
          {
            type: 'UPH',
            value: 70,
            name: 'UPH'
          },
          {
            type: 'UPPH',
            value: 90,
            name: 'UPPH'
          },
          {
            type: 'UTS',
            value: 45,
            name: 'UTS'
          }
        ]
      }
      this.chartData2.push(p507)
      this.chartData2.push(p508)
      this.chartData2.push(p509)
      this.chartData2.push(p510)
      this.chartData2.push(p511)
      this.chartData2.push(p512)
      this.bigChartData.push({
        id: 2,
        data: this.chartData2
      })
      // console.log(this.bigChartData[0].data)
    },
    showRTYChart: function() {
      // const that = this
      var chartDom = document.getElementById('pcba_rty')
      this.chartPCBARTY = this.$echarts.init(chartDom)
      var option
      const gaugeData = [
        {
          value: 40,
          name: 'RTY',
          title: {
            offsetCenter: ['0%', '-20%']
          },
          detail: {
            valueAnimation: true,
            offsetCenter: ['0%', '20%']
          }
        }
      ]

      option = {
        series: [
          {
            type: 'gauge',
            startAngle: 90,
            endAngle: -270,
            pointer: {
              show: false
            },
            progress: {
              show: true,
              overlap: false,
              roundCap: true,
              clip: false,
              itemStyle: {
                borderWidth: 1,
                borderColor: '#464646',
                color: 'red'
              }
            },
            axisLine: {
              lineStyle: {
                width: 10,
                color: [[1, '#E6EBF8']]
              }
            },
            splitLine: {
              show: false,
              distance: 0,
              length: 10
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              show: false,
              distance: 50
            },
            data: gaugeData,
            title: {
              fontSize: 14
            },
            detail: {
              width: 45,
              height: 13,
              fontSize: 13,
              color: 'auto',
              borderColor: 'auto',
              borderRadius: 15,
              borderWidth: 1,
              formatter: '{value}%'
            }
          }
        ]
      }

      // setTimeout(function () {
      //   that.queryApiInvokeQty()
      // }, 0)

      // this.intervalApiInvokeQty = setInterval(function () {
      //   that.queryApiInvokeQty()
      // }, 60000)

      this.chartPCBARTY.setOption(option)
    },
    showUPHChart: function() {
      // const that = this
      var chartDom = document.getElementById('pcba_uph')
      this.chartPCBAUPH = this.$echarts.init(chartDom)
      var option
      const gaugeData = [
        {
          value: 40,
          name: 'RTY',
          title: {
            offsetCenter: ['0%', '-20%']
          },
          detail: {
            valueAnimation: true,
            offsetCenter: ['0%', '20%']
          }
        }
      ]

      option = {
        series: [
          {
            type: 'gauge',
            startAngle: 90,
            endAngle: -270,
            pointer: {
              show: false
            },
            progress: {
              show: true,
              overlap: false,
              roundCap: true,
              clip: false,
              itemStyle: {
                borderWidth: 1,
                borderColor: '#464646',
                color: 'red'
              }
            },
            axisLine: {
              lineStyle: {
                width: 10,
                color: [[1, '#E6EBF8']]
              }
            },
            splitLine: {
              show: false,
              distance: 0,
              length: 10
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              show: false,
              distance: 50
            },
            data: gaugeData,
            title: {
              fontSize: 14
            },
            detail: {
              width: 45,
              height: 13,
              fontSize: 13,
              color: 'auto',
              borderColor: 'auto',
              borderRadius: 15,
              borderWidth: 1,
              formatter: '{value}%'
            }
          }
        ]
      }

      // setTimeout(function () {
      //   that.queryApiInvokeQty()
      // }, 0)

      // this.intervalApiInvokeQty = setInterval(function () {
      //   that.queryApiInvokeQty()
      // }, 60000)

      this.chartPCBAUPH.setOption(option)
    },
    showUPPHChart: function() {
      // const that = this
      var chartDom = document.getElementById('pcba_upph')
      this.chartPCBAUPPH = this.$echarts.init(chartDom)
      var option
      const gaugeData = [
        {
          value: 40,
          name: 'RTY',
          title: {
            offsetCenter: ['0%', '-20%']
          },
          detail: {
            valueAnimation: true,
            offsetCenter: ['0%', '20%']
          }
        }
      ]

      option = {
        series: [
          {
            type: 'gauge',
            startAngle: 90,
            endAngle: -270,
            pointer: {
              show: false
            },
            progress: {
              show: true,
              overlap: false,
              roundCap: true,
              clip: false,
              itemStyle: {
                borderWidth: 1,
                borderColor: '#464646',
                color: 'red'
              }
            },
            axisLine: {
              lineStyle: {
                width: 10,
                color: [[1, '#E6EBF8']]
              }
            },
            splitLine: {
              show: false,
              distance: 0,
              length: 10
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              show: false,
              distance: 50
            },
            data: gaugeData,
            title: {
              fontSize: 14
            },
            detail: {
              width: 45,
              height: 13,
              fontSize: 13,
              color: 'auto',
              borderColor: 'auto',
              borderRadius: 15,
              borderWidth: 1,
              formatter: '{value}%'
            }
          }
        ]
      }

      // setTimeout(function () {
      //   that.queryApiInvokeQty()
      // }, 0)

      // this.intervalApiInvokeQty = setInterval(function () {
      //   that.queryApiInvokeQty()
      // }, 60000)

      this.chartPCBAUPPH.setOption(option)
    },
    setRowStyle: function(row, rowIndex) {
      if (row.row.status === 'NG') {
        return 'color:red!important;'
      }
    },
    async queryApiInvokeQtyGroupByFunc() {
      // this.apiInvokeQtyGroupByFuncChart.showLoading()
      // const response = await getApiInvokeQtyByFunc()
      // this.apiInvokeQtyGroupByFuncChart.hideLoading()
      // const queryResult = response.data.QueryResult
      // if (queryResult === 'OK') {
      //   this.apiInvokeQtyGroupByFuncData = response.data.ReturnObject
      //   this.apiInvokeQtyGroupByFuncChart.setOption({
      //     yAxis: {
      //       data: this.apiInvokeQtyGroupByFuncData.yAxisData
      //     },
      //     series: [{
      //       data: this.apiInvokeQtyGroupByFuncData.seriesData
      //     }]
      //   })
      // } else {
      //   this.$alert(queryResult, '提示', {
      //     confirmButtonText: '確定',
      //     type: 'error'
      //   })
      // }
    }
    // resizeTable: function() {
    //   this.$nextTick(function() {
    //     const divHeight = $('#tableContainer').height()
    //     this.tableHeight = divHeight
    //   })
    // }
  }
}
</script>
<style lang="less" scoped>
.el-header{
    padding:0 5px
}
.header{
  height:50px !important;
  background-color:#1f4e7c;
}
.titleDiv{
  display:flex;
  justify-content: space-between;
  color:white;
}
.title{
  line-height: 50px;
  font-size:28px;
}
.refreshTime{
  display: inline-block;
  line-height: 40px;
  padding-top:5px;
  font-size:20px;
}
.lineGroup{
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  height: 800px;
}
.oneLine{
  margin:10px;
}
::v-deep .el-carousel__container{
  height:800px
}
</style>
