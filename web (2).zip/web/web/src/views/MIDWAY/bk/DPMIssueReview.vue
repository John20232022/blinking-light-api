<template>
  <div style="height:100%;width:100%">
    <el-container style="height:100%;width:100%">
      <el-header style="padding:0;height:40px">
        <el-date-picker
          v-model="pickDates"
          style="width:350px"
          type="datetimerange"
          align="right"
          unlink-panels
          :picker-options="pickerOptions1"
          start-placeholder="開始日期"
          end-placeholder="結束日期"
          size="small"
        />
        <el-select v-model="queryPlant" placeholder="廠別" size="small" style="width:120px;margin-left:5px" @change="getUserArea">
          <el-option
            v-for="item in plantList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryArea" placeholder="區域" size="small" style="width:100px;margin-left:5px" @change="getUserTeam">
          <el-option
            v-for="item in areaList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryTeam" placeholder="Team" size="small" multiple collapse-tags style="width:230px;margin-left:5px" @change="getUserLine">
          <el-option
            v-for="item in teamList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryLine" placeholder="線別" size="small" style="width:130px;margin-left:5px">
          <el-option
            v-for="item in lineList"
            :key="item.key"
            :label="item.data"
            :value="item.data"
          />
        </el-select>
        <el-select v-model="queryScope" placeholder="狀態" style="width:100px;margin-left:5px" size="small">
          <el-option label="所有" value="all" />
          <el-option label="待分配" value="waitdispatch" />
          <el-option label="待填寫" value="waitsolution" />
          <el-option label="待確認" value="waitcheck" />
          <el-option label="已結案" value="closed" />
        </el-select>
        <el-select v-model="data_from" placeholder="數據來源" style="width:100px;margin:0 5px" size="small">
          <el-option label="所有" value="all" />
          <el-option label="异常记录" value="1" />
          <el-option label="EMS" value="2" />
        </el-select>
        <el-button type="primary" size="small" @click="queryData(true)">查詢</el-button>
        <el-button type="primary" size="small" @click="downloadData()">下載</el-button>
      </el-header>
      <el-main style="padding:0;height:100%">
        <div id="tableContainer" style="height:100%;">
          <el-table
            v-loading="loadingDetail"
            :data="tableData"
            size="mini"
            :row-class-name="tableRowClassName"
            :height="tableHeight"
            style="width: 100%;"
          >
            <el-table-column prop="seq" label="次序" width="60" />
            <el-table-column prop="status" label="狀態" width="70">
              <template slot-scope="scope">
                <!-- 20230102 Kimi 取消此页面的确认功能，改到我的异常中去 -->
                <span
                  v-if="scope.row.status!=='待填寫' && scope.row.status!=='待分配' && scope.row.status!=='待確認'"
                  style="cursor: pointer;"
                  @click="showDg(scope.row)"
                >{{ scope.row.status }}</span>
                <span v-else>{{ scope.row.status }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="factory_code" label="廠別" width="70" />
            <el-table-column prop="work_date" label="工作日" width="85" />
            <el-table-column prop="shift_code" label="班別" width="60" />
            <el-table-column prop="area" label="區域" width="70" show-overflow-tooltip />
            <el-table-column prop="team" label="Team" width="70" show-overflow-tooltip />
            <el-table-column prop="pdline_name" label="線別" width="90" show-overflow-tooltip />
            <el-table-column prop="stage_name" label="段別" width="70" show-overflow-tooltip />
            <el-table-column prop="start_time" label="區間開始" width="150" />
            <el-table-column prop="end_time" label="區間結束" width="150" />
            <el-table-column prop="actual" label="實際" width="60" show-overflow-tooltip />
            <el-table-column prop="goal" label="目標" width="60" show-overflow-tooltip />
            <el-table-column prop="gap" label="損失" width="60" show-overflow-tooltip />
            <el-table-column prop="loss_time" label="工時損失" width="150" />
            <el-table-column prop="impact_minutes" label="影響時長" width="80" />
            <el-table-column prop="impact_persons" label="影響效率人數" width="110" />
            <el-table-column prop="issue_start_time" label="異常開始" width="150" />
            <el-table-column prop="issue_end_time" label="異常結束" width="150" />
            <el-table-column label="異常記錄人" width="140" show-overflow-tooltip>
              <template slot-scope="scope">
                <span>{{ scope.row.issue_log_user }}</span>
                <span>{{ scope.row.issue_log_user_name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="type" label="分類" width="70" show-overflow-tooltip />
            <el-table-column prop="reason_code" label="錯誤代碼" width="120" show-overflow-tooltip />
            <el-table-column prop="reason_desc" label="異常信息" width="180" show-overflow-tooltip />
            <el-table-column label="責任人" width="140" show-overflow-tooltip>
              <template slot-scope="scope">
                <span>{{ scope.row.dri }}</span>
                <span>{{ scope.row.dri_name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="dri_deptid" label="成本中心" width="90" show-overflow-tooltip />
            <el-table-column prop="dri_dept" label="責任部門" width="120" show-overflow-tooltip />
            <el-table-column prop="solution" label="解決方案" width="200" show-overflow-tooltip />
            <el-table-column prop="keyin_solution_time" label="填寫時間" width="150" />
            <el-table-column prop="memo" label="備註" width="180" show-overflow-tooltip />
            <el-table-column label="分配人" width="140" show-overflow-tooltip>
              <template slot-scope="scope">
                <span>{{ scope.row.dispatch_user }}</span>
                <span>{{ scope.row.dispatch_user_name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="dispatch_time" label="分配時間" width="150" />
            <el-table-column prop="check_result" label="確認結果" width="100" />
            <el-table-column label="確認人" width="140" show-overflow-tooltip>
              <template slot-scope="scope">
                <span>{{ scope.row.check_user }}</span>
                <span>{{ scope.row.check_user_name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="check_time" label="確認時間" width="150" />
            
            <el-table-column v-if="false" prop="row_id" label="ROWID" width="120" />
            <el-table-column v-if="false" prop="site" label="SITE" width="120" />
            <el-table-column label="數據來源" width="100">
              <template slot-scope="scope">
                <span v-if="scope.row.data_from == 1">异常记录</span>
                <span v-if="scope.row.data_from == 2">EMS</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </el-main>
      <el-footer style="margin:0 auto">
        <el-pagination
          :current-page="pageIndex"
          :page-sizes="[30, 50, 100]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </el-footer>
    </el-container>

    <el-dialog
      :center="true"
      title="确认解决方案"
      :close-on-press-escape="false"
      top="3vh"
      :visible.sync="evalDialogVisible"
      width="560px"
      :close-on-click-modal="false"
    >
      <table class="tb" style="width:510px">
        <tr>
          <td class="tbCategory">線別</td>
          <td class="tbCategory">段別</td>
          <td class="tbCategory">工作日</td>
          <td class="tbCategory">班別</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.pdline_name }}</td>
          <td class="tbValue">{{ selectedRow.stage_name }}</td>
          <td class="tbValue">{{ selectedRow.work_date }}</td>
          <td class="tbValue">{{ selectedRow.shift_code }}</td>
        </tr>
        <tr>
          <td class="tbCategory">區段開始</td>
          <td class="tbCategory">區段結束</td>
          <td class="tbCategory">異常開始</td>
          <td class="tbCategory">異常結束</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.start_time }}</td>
          <td class="tbValue">{{ selectedRow.end_time }}</td>
          <td class="tbValue">{{ selectedRow.issue_start_time }}</td>
          <td class="tbValue">{{ selectedRow.issue_end_time }}</td>
        </tr>
        <tr>
          <td class="tbCategory">分類</td>
          <td class="tbCategory">錯誤代碼</td>
          <td class="tbCategory">影響時長</td>
          <td class="tbCategory">影響產出</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.type }}</td>
          <td class="tbValue">{{ selectedRow.reason_code }}</td>
          <td class="tbValue">{{ selectedRow.impact_minutes }}分鐘</td>
          <td class="tbValue">{{ selectedRow.gap }}</td>
        </tr>
      </table>
      <el-divider />
      <table class="tb" style="width:510px">
        <tr>
          <td class="tbCategory">責任人</td>
          <td class="tbCategory">填寫時間</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.dri }}{{ selectedRow.dri_name }}</td>
          <td class="tbValue">{{ selectedRow.keyin_solution_time }}</td>
        </tr>
      </table>
      <el-input v-model="selectedRow.solution" style="margin-top:5px" type="textarea" :rows="4" :readonly="true" />
      <el-divider />
      <div style="text-align:center">
        <el-radio v-model="evalResult" label="OK">通過</el-radio>
        <el-radio v-model="evalResult" label="NG">未通過</el-radio>
      </div>
      <el-input v-model="memo" style="margin-top:5px" placeholder="備註" size="small" />
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="saveEval">保存</el-button>
        <el-button size="small" @click="closeEvalDialog">關閉</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      title="評判記錄"
      :close-on-press-escape="false"
      top="3vh"
      :visible.sync="resultDialogVisible"
      width="560px"
      :close-on-click-modal="false"
    >
      <table class="tb" style="width:510px">
        <tr>
          <td class="tbCategory">線別</td>
          <td class="tbCategory">段別</td>
          <td class="tbCategory">工作日</td>
          <td class="tbCategory">班別</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.pdline_name }}</td>
          <td class="tbValue">{{ selectedRow.stage_name }}</td>
          <td class="tbValue">{{ selectedRow.work_date }}</td>
          <td class="tbValue">{{ selectedRow.shift_code }}</td>
        </tr>
        <tr>
          <td class="tbCategory">區段開始</td>
          <td class="tbCategory">區段結束</td>
          <td class="tbCategory">異常開始</td>
          <td class="tbCategory">異常結束</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.start_time }}</td>
          <td class="tbValue">{{ selectedRow.end_time }}</td>
          <td class="tbValue">{{ selectedRow.issue_start_time }}</td>
          <td class="tbValue">{{ selectedRow.issue_end_time }}</td>
        </tr>
        <tr>
          <td class="tbCategory">分類</td>
          <td class="tbCategory">錯誤代碼</td>
          <td class="tbCategory">影響時長</td>
          <td class="tbCategory">影響產出</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.type }}</td>
          <td class="tbValue">{{ selectedRow.reason_code }}</td>
          <td class="tbValue">{{ selectedRow.impact_minutes }}分鐘</td>
          <td class="tbValue">{{ selectedRow.gap }}</td>
        </tr>
      </table>
      <el-divider />
      <table class="tb" style="width:510px">
        <tr>
          <td class="tbCategory">責任人</td>
          <td class="tbCategory">填寫時間</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.dri }}{{ selectedRow.dri_name }}</td>
          <td class="tbValue">{{ selectedRow.keyin_solution_time }}</td>
        </tr>
      </table>
      <el-input v-model="selectedRow.solution" style="margin-top:5px" type="textarea" :rows="4" :readonly="true" />
      <el-divider />
      <table class="tb" style="width:510px">
        <tr>
          <td class="tbCategory">評判結果</td>
          <td class="tbCategory">評判時間</td>
          <td class="tbCategory">評判人</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.check_result }}</td>
          <td class="tbValue">{{ selectedRow.check_time }}</td>
          <td class="tbValue">{{ selectedRow.check_user }}{{ selectedRow.check_user_name }}</td>
        </tr>
      </table>
      <el-input v-model="selectedRow.memo" style="margin-top:5px" placeholder="備註" :readonly="true" size="small" />
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="closeResultDialog">關閉</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import {
  DPMQueryIssueToReview, GetDPMQueryKeyValue, SaveEvalSolution
} from '@/api/midway.js'

export default {
  data() {
    return {
      pickerOptions1: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      pickDates: [],
      queryPlant: '',
      queryArea: '',
      queryTeam: [],
      queryLine: '',
      plantList: [],
      areaList: [],
      teamList: [],
      lineList: [],
      queryScope: 'all',
      data_from:'all',
      tableHeight: 1,
      tableData: [],
      loading: false,
      loadingDetail: false,
      filter: '',
      pageIndex: 1,
      pageSize: 50,
      total: 0,
      evalDialogVisible: false,
      resultDialogVisible: false,
      selectedRow: '',
      loadingData: null,
      evalResult: '',
      memo: ''
    }
  },
  mounted() {
    this.getDefaultDate()
    this.getUserPlant()
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
    }
  },
  methods: {
    alertMsg(msg) {
      this.$alert(msg, '提示', {
        confirmButtonText: '確定',
        type: 'error'
      })
    },
    tableRowClassName({ row, rowIndex }) {
      if (row.status === '待填寫') {
        return 'waitsolution-row'
      } else if (row.status === '待分配') {
        return 'waitdispatch-row'
      } else if (row.status === '待確認') {
        return 'waitcheck-row'
      } else if (row.status === '通過') {
        return 'ok-row'
      } else if (row.status === '未通過') {
        return 'ng-row'
      }
      return ''
    },
    getDefaultDate() {
      const curDate = new Date()
      this.pickDates.push(new Date(curDate.getTime() - 48 * 60 * 60 * 1000))
      this.pickDates.push(new Date(curDate))
    },
    handleSizeChange: function(val) {
      this.pageSize = val
    },
    handleCurrentChange: function(val) {
      this.pageIndex = val
      this.queryData(false)
    },
    async getUserPlant() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.plantList = []
      this.queryPlant = ''
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = []
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.plantList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserArea() {
      const data = {
        type: 'userarea',
        key: this.queryPlant
      }
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = []
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserTeam() {
      const data = {
        type: 'userteam',
        key: this.queryArea
      }
      this.teamList = []
      this.queryTeam = []
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.teamList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserLine() {
      this.lineList = []
      this.queryLine = ''
      if (this.queryTeam.length === 1) {
        const data = {
          type: 'userline',
          key: this.queryTeam
        }
        const response = await GetDPMQueryKeyValue(data)
        const queryResult = response.data.QueryResult
        if (queryResult === 'OK') {
          this.lineList.push({
            key: 'all',
            data: 'ALL'
          })
          const obj = response.data.ReturnObject
          obj.forEach(x => {
            this.lineList.push(x)
          })
        } else {
          alert(queryResult)
        }
      } else {
        this.lineList.push({
          key: 'all',
          data: 'ALL'
        })
      }
    },
    async queryData(resetIndex) {
      if (this.pickDates.length === 0) {
        this.alertMsg('请选择日期')
        return
      }
      if (this.queryPlant === '') {
        this.alertMsg('請選擇廠別')
        return
      }
      if (this.queryArea === '') {
        this.alertMsg('請選擇區域')
        return
      }
      if (this.queryTeam.length === 0) {
        this.alertMsg('請選擇Team')
        return
      }
      let teams = ''
      this.queryTeam.forEach(t => {
        teams = teams + this.teamList.filter(x => x.key === t)[0].data + ','
      })
      if (teams.substr(teams.length - 1, 1) === ',') {
        teams = teams.substr(0, teams.length - 1)
      }
      if (resetIndex) {
        this.pageIndex = 1
      }
      const begin = this.$utils.GetDateTimeString(this.pickDates[0])
      const end = this.$utils.GetDateTimeString(this.pickDates[1])
      const factory = this.plantList.filter(x => x.key === this.queryPlant)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = teams // this.teamList.filter(x => x.key === this.queryTeam)[0].data
      const data = {
        factory: factory,
        area: area,
        team: team,
        line: this.queryLine,
        begin: begin,
        end: end,
        status: this.queryScope,
        data_from: this.data_from,
        pageIndex: this.pageIndex,
        pageSize: this.pageSize
      }
      this.loadingDetail = true
      const response = await DPMQueryIssueToReview(data)
      this.loadingDetail = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.total = response.data.ReturnObject.total
        this.tableData = response.data.ReturnObject.queryData
      } else {
        alert(queryResult)
      }
    },
    downloadData: function() {
      if (this.pickDates.length === 0) {
        this.alertMsg('请选择日期')
        return
      }
      if (this.queryPlant === '') {
        this.alertMsg('請選擇廠別')
        return
      }
      if (this.queryArea === '') {
        this.alertMsg('請選擇區域')
        return
      }
      if (this.queryTeam.length === 0) {
        this.alertMsg('請選擇Team')
        return
      }
      let teams = ''
      this.queryTeam.forEach(t => {
        teams = teams + this.teamList.filter(x => x.key === t)[0].data + ','
      })
      if (teams.substr(teams.length - 1, 1) === ',') {
        teams = teams.substr(0, teams.length - 1)
      }

      const begin = this.$utils.GetDateTimeString(this.pickDates[0])
      const end = this.$utils.GetDateTimeString(this.pickDates[1])
      const factory = this.plantList.filter(x => x.key === this.queryPlant)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      // const team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      var url = '/midway/downloadDPMIssueReview'
      url = url + '?factory=' + encodeURIComponent(factory) + '&area=' + encodeURIComponent(area) +
       '&team=' + encodeURIComponent(teams) + '&line=' + encodeURIComponent(this.queryLine) +
      '&begin=' + begin + '&end=' + end + '&status=' + encodeURIComponent(this.queryScope)
      console.log(url)
      this.$utils.downloadFile(url, '異常問題回顧.xlsx')
    },
    resizeTable: function() {
      this.$nextTick(function() {
        const divHeight = $('#tableContainer').height()
        this.tableHeight = divHeight
      })
    },
    showDg(row) {
      if (row.status === '待確認') {
        this.showEvalDailog(row)
      } else {
        this.showResultDailog(row)
      }
    },
    showEvalDailog(row) {
      this.evalResult = ''
      this.memo = ''
      this.selectedRow = row
      this.evalDialogVisible = true
    },
    showResultDailog(row) {
      this.selectedRow = row
      this.resultDialogVisible = true
    },
    async saveEval() {
      if (this.evalResult === '') {
        this.alertMsg('請選擇確認結果')
        return
      }
      if (!confirm('確定要確認此解決方案嗎？')) {
        return
      }
      this.loadingData = this.$loading({
        lock: true,
        text: '正在提交數據，請耐心等待...',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const data = {
        rowId: this.selectedRow.row_id,
        result: this.evalResult,
        memo: this.memo
      }
      const response = await SaveEvalSolution(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.closeEvalDialog()
        this.$alert('保存確認結果成功', '提示', {
          confirmButtonText: '確定',
          type: 'success'
        })
        this.queryData(false)
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeEvalDialog() {
      this.evalDialogVisible = false
    },
    closeResultDialog() {
      this.resultDialogVisible = false
    }
  }

}
</script>
<style lang="less" scoped>
::v-deep section {
padding-bottom: 0;
border: 0;
}

::v-deep .el-table .waitdispatch-row {
background: rgb(151, 160, 240);
}
::v-deep .el-table .waitsolution-row {
background: rgb(255, 255, 255);
}
::v-deep .el-table .waitcheck-row {
background: rgb(252, 252, 173);
}
::v-deep .el-table .ok-row {
background: rgb(127, 243, 133);
}
::v-deep .el-table .ng-row {
background: rgb(245, 180, 191);
}
.tb{
  margin:0 auto;
  border:1px solid #cccccc;
  border-collapse:collapse;
  margin-bottom:10px;
  width: 100%;
  table-layout: fixed;
}
.tbTitle{
  width:100%;
  padding:10px 10px;
  font-size:14px;
  font-weight: 600;
  border-bottom:1px solid #cccccc;
  overflow: hidden;
  white-space: nowrap;
  text-overflow:ellipsis;
  word-wrap: break-word;
}
.tbCategory{
  height:30px;
  font-size:12px;
  text-align: center;
  background-color:#f4f4f4;
  border-bottom:1px solid #cccccc;
  border-right:1px solid #cccccc;
}
.tbValue{
  height:30px;
  font-size:12px;
  text-align: center;
  border-bottom:1px solid #cccccc;
  border-right:1px solid #cccccc;
}
</style>
