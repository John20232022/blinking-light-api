<template>
  <div style="height:100%;width:100%">
    <el-container style="height:100%;width:100%">
      <el-header style="padding:0;height:40px">
        <el-date-picker
          v-model="pickDates"
          style="width:400px"
          type="datetimerange"
          align="right"
          unlink-panels
          :picker-options="pickerOptions1"
          start-placeholder="開始日期"
          end-placeholder="結束日期"
          size="small"
        />
        <el-select v-model="queryPlant" placeholder="廠別" size="small" style="width:120px;margin-left:5px" @change="getUserArea">
          <el-option
            v-for="item in plantList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryArea" placeholder="區域" size="small" style="width:100px;margin-left:5px" @change="getUserTeam">
          <el-option
            v-for="item in areaList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryTeam" placeholder="Team" size="small" multiple collapse-tags style="width:230px;margin:0 5px">
          <el-option
            v-for="item in teamList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-input v-model="queryLine" placeholder="線體(可選)" size="small" style="width:120px;margin:0 5px" /><!--20230111 Kimi 增加线别查询条件-->
        <el-button type="primary" size="small" @click="queryData(true)">查詢</el-button>
        <el-button type="primary" size="small" @click="downloadData()">下載</el-button>
      </el-header>
      <el-main style="padding:0;height:100%">
        <div id="tableContainer" style="height:100%;">
          <el-table
            ref="lossTable"
            v-loading="loadingDetail"
            :data="tableData"
            size="mini"
            stripe
            :height="tableHeight"
            style="width: 100%;"
          >
            <el-table-column prop="seq" label="次序" width="60" align="center" />
            <el-table-column prop="work_date" label="工作日" width="85" align="center" />
            <el-table-column prop="shift_code" label="班別" width="60" align="center" />
            <el-table-column prop="team_name" label="Team" width="150" align="center" show-overflow-tooltip /><!--20230111 Kimi 调整Team宽度-->
            <el-table-column prop="pdline_name" label="線別" width="150" align="center" show-overflow-tooltip /><!--20230111 Kimi 调整Team宽度-->
            <el-table-column prop="stage_name" label="段別" width="120" align="center" show-overflow-tooltip /><!--20230111 Kimi 调整Team宽度-->
            <el-table-column prop="process_name" label="站別" width="150" align="center" show-overflow-tooltip /><!--20230111 Kimi 调整Team宽度-->
            <el-table-column prop="operation" label="段別代碼" width="90" align="center" show-overflow-tooltip />
            <!-- <el-table-column prop="runs_id" label="班別代碼" width="90" align="center" show-overflow-tooltip></el-table-column> -->
            <el-table-column prop="start_time" label="區間開始" align="center" width="160" />
            <el-table-column prop="end_time" label="區間結束" align="center" width="160" />
            <el-table-column prop="minutes" label="影響時長" align="center" width="80" />
            <el-table-column prop="wo" label="工單" width="90" align="center" />
            <el-table-column prop="model" label="機種" width="150" align="center" />
            <!-- start add 20230225 fenglianlong 增加等效点数 -->
            <el-table-column prop="normolization_factor" label="等效點數" width="80" align="center" />
            <!-- end add 20230225 fenglianlong 增加等效点数 -->
            <el-table-column prop="std_uph" label="UPH" width="80" align="center" />
            <el-table-column prop="wo_qty" label="批量" width="80" align="center" />
            <el-table-column prop="wo_input_calc" label="投入(已計算)" width="110" align="center" />
            <el-table-column prop="wo_input" label="投入(本次)" width="90" align="center" />
            <el-table-column prop="wo_input_total" label="投入(累計)" width="90" align="center" />
            <el-table-column prop="wait_for_repair" label="待維修" width="80" align="center" />
            <el-table-column prop="new_model" label="新機種" width="80" align="center" />
            <el-table-column label="異常記錄人" width="140" show-overflow-tooltip align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.update_user }}</span>
                <span>{{ scope.row.update_username }}</span>
              </template>
            </el-table-column>
            <el-table-column label="確認人" width="140" show-overflow-tooltip align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.approve_user }}</span>
                <span>{{ scope.row.approve_username }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="update_time" label="記錄時間" width="160" align="center" />
            <el-table-column
              v-for="(t, index) in colSetting"
              :key="index"
              :label="t.label"
              align="center"
            >
              <el-table-column
                v-for="(o, index2) in t.subline"
                :key="index2"
                :prop="o.prop"
                :label="o.label"
                :width="o.width"
                align="center"
                show-overflow-tooltip
              />
            </el-table-column>
          </el-table>
        </div>
      </el-main>
      <el-footer style="margin:0 auto">
        <el-pagination
          :current-page="pageIndex"
          :page-sizes="[30, 50, 100]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </el-footer>
    </el-container>
  </div>
</template>
<script>
import $ from 'jquery'
import {
  GetDPMQueryKeyValue, Query3IN1Report
} from '@/api/midway.js'

export default {
  data() {
    return {
      pickerOptions1: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      pickDates: [],
      queryPlant: '',
      queryArea: '',
      queryTeam: [],
      queryLine: '', // 20231111 Kimi 若没有，请新增
      plantList: [],
      areaList: [],
      teamList: [],
      tableHeight: 1,
      tableData: [],
      loading: false,
      loadingDetail: false,
      filter: '',
      pageIndex: 1,
      pageSize: 50,
      total: 0,
      loadingData: null,
      memo: '',
      colSetting: []
    }
  },
  mounted() {
    this.getDefaultDate()
    this.getUserPlant()
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
    }
  },
  methods: {
    alertMsg(msg) {
      this.$alert(msg, '提示', {
        confirmButtonText: '確定',
        type: 'error'
      })
    },
    getDefaultDate() {
      const curDate = new Date()
      this.pickDates.push(new Date(curDate.getTime() - 48 * 60 * 60 * 1000))
      this.pickDates.push(new Date(curDate))
    },
    handleSizeChange: function(val) {
      this.pageSize = val
    },
    handleCurrentChange: function(val) {
      this.pageIndex = val
      this.queryData(false)
    },
    async getUserPlant() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.plantList = []
      this.queryPlant = ''
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = []
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.plantList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserArea() {
      const data = {
        type: 'userarea',
        key: this.queryPlant
      }
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = []
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserTeam() {
      const data = {
        type: 'userteam',
        key: this.queryArea
      }
      this.teamList = []
      this.queryTeam = []
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.teamList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async queryData(resetIndex) {
      if (this.pickDates.length === 0) {
        this.alertMsg('请选择日期')
        return
      }
      if (this.queryPlant === '') {
        this.alertMsg('請選擇廠別')
        return
      }
      if (this.queryArea === '') {
        this.alertMsg('請選擇區域')
        return
      }
      if (this.queryTeam.length === 0) {
        this.alertMsg('請選擇Team')
        return
      }
      let teams = ''
      this.queryTeam.forEach(t => {
        teams = teams + this.teamList.filter(x => x.key === t)[0].data + ','
      })
      if (teams.substr(teams.length - 1, 1) === ',') {
        teams = teams.substr(0, teams.length - 1)
      }
      if (resetIndex) {
        this.pageIndex = 1
      }
      // const begin = this.$utils.GetDateString(this.pickDates[0])
      // const end = this.$utils.GetDateString(this.pickDates[1])
      const begin = this.$utils.GetDateTimeString(this.pickDates[0])
      const end = this.$utils.GetDateTimeString(this.pickDates[1])
      const factory = this.plantList.filter(x => x.key === this.queryPlant)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const data = {
        factory: factory,
        area: area,
        teams: teams,
        line: this.queryLine, // 20230111 Kimi 增加Line
        begin: begin,
        end: end,
        pageIndex: this.pageIndex,
        pageSize: this.pageSize
      }
      this.loadingDetail = true
      this.colSetting = []
      const response = await Query3IN1Report(data)
      this.loadingDetail = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        const reasonCodes = obj.reasonCodes
        reasonCodes.forEach(x => {
          const temp = this.colSetting.filter(t => t.label === x.type)
          if (temp.length === 0) {
            this.colSetting.push({
              label: x.type,
              subline: []
            })
          }
        })
        this.colSetting.forEach(x => {
          const temp = reasonCodes.filter(t => t.type === x.label)
          temp.forEach(t => {
            x.subline.push({
              prop: t.col,
              label: t.reason_code, // + (t.unit === '' ? '' : '(' + t.unit + ')'),
              width: t.reason_code.length >= 6 ? 135 : 100
            })
          })
        })
        this.total = obj.total
        this.tableData = obj.queryData
        this.$nextTick(() => {
          this.$refs.lossTable.doLayout()
        })
      } else {
        alert(queryResult)
      }
    },
    downloadData: function() {
      if (this.pickDates.length === 0) {
        this.alertMsg('请选择日期')
        return
      }
      if (this.queryPlant === '') {
        this.alertMsg('請選擇廠別')
        return
      }
      if (this.queryArea === '') {
        this.alertMsg('請選擇區域')
        return
      }
      if (this.queryTeam.length === 0) {
        this.alertMsg('請選擇Team')
        return
      }
      let teams = ''
      this.queryTeam.forEach(t => {
        teams = teams + this.teamList.filter(x => x.key === t)[0].data + ','
      })
      if (teams.substr(teams.length - 1, 1) === ',') {
        teams = teams.substr(0, teams.length - 1)
      }

      const begin = this.$utils.GetDateTimeString(this.pickDates[0])
      const end = this.$utils.GetDateTimeString(this.pickDates[1])
      const factory = this.plantList.filter(x => x.key === this.queryPlant)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      var url = '/midway/download3IN1Report'
      url = url + '?factory=' + encodeURIComponent(factory) + '&area=' + encodeURIComponent(area) +
         '&teams=' + encodeURIComponent(teams) + '&line=' + encodeURIComponent(this.queryLine) + '&begin=' + begin + '&end=' + end
      // console.log(url)
      this.$utils.downloadFile(url, 'PCBA三合一數據報表.xlsx')
    },
    resizeTable: function() {
      this.$nextTick(function() {
        const divHeight = $('#tableContainer').height()
        this.tableHeight = divHeight
      })
    }
  }

}
</script>
<style lang="less" scoped>
::v-deep section {
  padding-bottom: 0;
  border: 0;
}
::v-deep .el-table td {
  border:1px solid lightgray;
}
</style>
