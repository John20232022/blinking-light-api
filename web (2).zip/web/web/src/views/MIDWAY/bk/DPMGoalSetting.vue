<template>
  <div style="height: 100%; width: 100%;padding:10px">
    <el-container style="height: 100%">
      <el-header style="padding: 0; height: 40px">
        <el-select v-model="queryPlant" size="small" class="selectMidSize" placeholder="廠別" @change="selectFactoryHandler">
          <el-option v-for="item in plantList" :key="item.plant" :label="item.plant" :value="item.plant"> </el-option>
        </el-select>
        <span style="display: inline-block; margin-left: 20px; color: blue">若提交錯誤，可以填寫正確的數據後再次提交</span>
      </el-header>
      <el-main style="padding: 0; height: 1px" id="tabMain">
        <el-tabs v-model="tabActiveName">
          <el-tab-pane label="Area KPI" name="area" lazy>
            <el-date-picker
              size="small"
              style="width: 140px; margin: 0 5px 5px 5px"
              v-model="effDateArea"
              type="date"
              placeholder="生效工作日"
            ></el-date-picker>
            <el-button type="success" size="small" @click="submitChange('area')">在此日期生效選中行的變更</el-button>
            <div :style="{ height: getTabDivHeight() }">
              <el-table
                :data="tableDataArea"
                ref="tbDataArea"
                v-loading="loading"
                size="small"
                stripe
                :height="tabDivHeight"
                @selection-change="areaSelectionChange"
                style="width: 100%"
              >
                <el-table-column type="selection" width="55" align="center"></el-table-column>
                <el-table-column prop="data" label="區域" width="100" align="center" fixed show-overflow-tooltip></el-table-column>
                <el-table-column v-for="o in colSettingArea" :key="o.label" :label="o.label" :width="o.width" align="center">
                  <el-table-column
                    v-for="child in o.subCols"
                    :key="child.label"
                    :prop="child.prop"
                    :label="child.label"
                    :width="child.width"
                    align="center"
                  >
                    <template slot-scope="scope">
                      <el-input type="text" size="mini" v-model="scope.row[child.prop]"></el-input>
                    </template>
                  </el-table-column>
                </el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
          <el-tab-pane label="Team KPI" name="team" lazy>
            <span>請選擇Area</span>
            <el-select
              v-model="queryArea"
              size="small"
              class="selectMidSize"
              style="width: 140px; margin: 0 5px 5px 5px"
              placeholder="Area"
              @change="selectAreaHandler"
            >
              <el-option v-for="item in areaList" :key="item.key" :label="item.data" :value="item.key"> </el-option>
            </el-select>
            <el-date-picker
              size="small"
              style="width: 140px; margin: 0 5px 5px 100px"
              v-model="effDateTeam"
              type="date"
              placeholder="生效工作日"
            ></el-date-picker>
            <el-button type="success" size="small" @click="submitChange('team')">在此日期生效選中行的變更</el-button>
            <div :style="{ height: getTabDivHeight() }">
              <el-table
                :data="tableDataTeam"
                ref="tbDataTeam"
                v-loading="loading"
                size="small"
                stripe
                :height="tabDivHeight"
                @selection-change="teamSelectionChange"
                style="width: 100%"
              >
                <el-table-column type="selection" width="55" align="center"></el-table-column>
                <el-table-column prop="data" label="Team" width="100" align="center" fixed show-overflow-tooltip></el-table-column>
                <el-table-column v-for="o in colSettingTeam" :key="o.label" :label="o.label" :width="o.width" align="center">
                  <el-table-column
                    v-for="child in o.subCols"
                    :key="child.label"
                    :prop="child.prop"
                    :label="child.label"
                    :width="child.width"
                    align="center"
                  >
                    <template slot-scope="scope">
                      <el-input type="text" size="mini" v-model="scope.row[child.prop]"></el-input>
                    </template>
                  </el-table-column>
                </el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
          <el-tab-pane label="Line KPI" name="line" lazy>
            <span>請選擇Area和Team</span>
            <el-select
              v-model="queryArea2"
              size="small"
              class="selectMidSize"
              style="width: 140px; margin: 0 5px 5px 5px"
              placeholder="Area"
              @change="getQueryTeamList"
            >
              <el-option v-for="item in areaList" :key="item.key" :label="item.data" :value="item.key"> </el-option>
            </el-select>
            <el-select v-model="queryTeam" size="small" class="selectMidSize" style="width: 140px" placeholder="Team" @change="selectTeamHandler">
              <el-option v-for="item in teamList" :key="item.key" :label="item.data" :value="item.key"> </el-option>
            </el-select>
            <el-date-picker
              size="small"
              style="width: 140px; margin: 0 5px 5px 100px"
              v-model="effDateLine"
              type="date"
              placeholder="生效工作日"
            ></el-date-picker>
            <el-button type="success" size="small" @click="submitChange('line')">在此日期生效選中行的變更</el-button>
            <div :style="{ height: getTabDivHeight() }">
              <el-table
                :data="tableDataLine"
                ref="tbDataLine"
                v-loading="loading"
                size="small"
                stripe
                :height="tabDivHeight"
                @selection-change="lineSelectionChange"
                style="width: 100%"
              >
                <el-table-column type="selection" width="55" align="center"></el-table-column>
                <el-table-column prop="data" label="Line" width="120" align="center" fixed show-overflow-tooltip></el-table-column>
                <el-table-column v-for="o in colSettingLine" :key="o.label" :label="o.label" :width="o.width" align="center">
                  <el-table-column
                    v-for="child in o.subCols"
                    :key="child.label"
                    :prop="child.prop"
                    :label="child.label"
                    :width="child.width"
                    align="center"
                  >
                    <template slot-scope="scope">
                      <el-input type="text" size="mini" v-model="scope.row[child.prop]"></el-input>
                    </template>
                  </el-table-column>
                </el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
          <el-tab-pane label="待辦列表" name="changelist" lazy>
            <el-button type="primary" icon="el-icon-search" size="small" style="margin-bottom: 5px" @click="refreshChangeList"
              >刷新待辦清單</el-button
            >
            <div :style="{ height: getTabDivHeight() }">
              <el-table :data="tableDataChangeList" v-loading="loading" size="small" stripe :height="tabDivHeight" style="width: 100%">
                <el-table-column prop="level" label="類別" width="70" align="center" fixed show-overflow-tooltip></el-table-column>
                <el-table-column prop="data" label="操作對象" width="150" align="center" fixed show-overflow-tooltip></el-table-column>
                <el-table-column prop="eff_work_date" label="生效日期" width="120" align="center" fixed show-overflow-tooltip></el-table-column>
                <el-table-column prop="index_name" label="KPI" width="180" align="center" fixed show-overflow-tooltip></el-table-column>
                <el-table-column prop="yellow" label="黃色" width="100" align="center" fixed show-overflow-tooltip></el-table-column>
                <el-table-column prop="green" label="綠色" width="100" align="center" fixed show-overflow-tooltip></el-table-column>
                <el-table-column prop="submit_user" label="提交人" width="120" align="center" fixed show-overflow-tooltip></el-table-column>
                <el-table-column prop="submit_time" label="提交時間" width="160" align="center" fixed show-overflow-tooltip></el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
        </el-tabs>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import $ from 'jquery';
import { getUserMenuPlantList, GetCurrentBaseData, GetGoalSettingData, UploadGoalSettingData, GetGoalSettingChangeList } from '@/api/midway.js';
export default {
  mounted() {
    this.getDefaultDate();
    this.queryPlantList();
    this.resizeTable();
    window.onresize = () => {
      this.resizeTable();
    };
  },
  data() {
    return {
      effDateArea: '',
      effDateTeam: '',
      effDateLine: '',
      tabActiveName: 'area',
      tabDivHeight: 1,
      tableHeight: 1,
      effDate: '',
      loading: false,
      loadingData: null,
      plantList: [],
      queryPlant: '',
      areaList: [],
      queryArea: '',
      teamList: [],
      queryTeam: '',
      lineList: [],
      colSettingArea: [],
      tableDataArea: [],
      tableDataAreaChange: [],
      colSettingTeam: [],
      tableDataTeam: [],
      tableDataTeamChange: [],
      queryArea2: '',
      colSettingLine: [],
      tableDataLine: [],
      tableDataLineChange: [],
      tableDataChangeList: []
    };
  },
  methods: {
    getTabDivHeight() {
      return this.tabDivHeight + 'px';
    },
    getDefaultDate() {
      const curDate = new Date();
      this.effDateArea = new Date(curDate.getTime() + 24 * 60 * 60 * 1000);
      this.effDateTeam = new Date(curDate.getTime() + 24 * 60 * 60 * 1000);
      this.effDateLine = new Date(curDate.getTime() + 24 * 60 * 60 * 1000);
    },
    alertMsg(msg) {
      this.$alert(msg, '提示', {
        confirmButtonText: '確定',
        type: 'error'
      });
    },
    async queryPlantList() {
      // start update 20230222 fenglianlong 修改获取menuId来源于主框架值
      // const data = { menu: '', menuId: '109' }
      const data = { menuId: this.$route.query.menuId };
      this.plantList = [];
      const response = await getUserMenuPlantList(data);
      const queryResult = response.data.QueryResult;
      // const queryResult = response.data.queryResult
      if (queryResult === 'OK') {
        this.plantList = response.data.ReturnObject;
        // this.plantList = response.data.returnObject
        // end update 20230222 fenglianlong ---------------------
      } else {
        this.alertMsg(queryResult);
      }
    },
    selectFactoryHandler() {
      this.getGoalSettingData('area', 0);
      this.getQueryAreaList();
    },
    selectAreaHandler() {
      this.getGoalSettingData('team', this.queryArea);
    },
    selectTeamHandler() {
      this.getGoalSettingData('line', this.queryTeam);
    },
    async getGoalSettingData(level, key) {
      if (this.queryPlant === '') {
        return;
      }
      const data = {
        factory: this.queryPlant,
        level: level,
        key: key
      };
      const response = await GetGoalSettingData(data);
      const queryResult = response.data.QueryResult;
      if (queryResult === 'OK') {
        if (level === 'area') {
          this.tableDataAreaChange = [];
          this.colSettingArea = response.data.ReturnObject[0];
          this.tableDataArea = response.data.ReturnObject[1];
          this.$nextTick(() => {
            this.$refs.tbDataArea.doLayout();
          });
        } else if (level === 'team') {
          this.tableDataTeamChange = [];
          this.colSettingTeam = response.data.ReturnObject[0];
          this.tableDataTeam = response.data.ReturnObject[1];
          this.$nextTick(() => {
            this.$refs.tbDataTeam.doLayout();
          });
        } else if (level === 'line') {
          this.tableDataLineChange = [];
          this.colSettingLine = response.data.ReturnObject[0];
          this.tableDataLine = response.data.ReturnObject[1];
          this.$nextTick(() => {
            this.$refs.tbDataLine.doLayout();
          });
        }
      } else {
        this.alertMsg(queryResult);
      }
    },
    async getQueryAreaList() {
      this.areaList = [];
      this.queryArea = '';
      this.queryArea2 = '';
      this.teamList = [];
      this.queryTeam = '';
      this.colSettingArea = [];
      this.colSettingTeam = [];
      this.colSettingLine = [];
      this.tableDataArea = [];
      this.tableDataAreaChange = [];
      this.tableDataTeam = [];
      this.tableDataTeamChange = [];
      this.tableDataLine = [];
      this.tableDataLineChange = [];
      const data = {
        type: 'area',
        key: this.queryPlant
      };
      const response = await GetCurrentBaseData(data);
      const queryResult = response.data.QueryResult;
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject[0];
      } else {
        this.alertMsg(queryResult);
      }
    },
    async getQueryTeamList() {
      this.teamList = [];
      this.queryTeam = '';
      this.colSettingLine = [];
      this.tableDataLine = [];
      this.tableDataLineChange = [];
      const data = {
        type: 'team',
        key: this.queryArea2
      };
      const response = await GetCurrentBaseData(data);
      const queryResult = response.data.QueryResult;
      if (queryResult === 'OK') {
        this.teamList = response.data.ReturnObject[0];
      } else {
        this.alertMsg(queryResult);
      }
    },
    areaSelectionChange(val) {
      this.tableDataAreaChange = val;
    },
    teamSelectionChange(val) {
      this.tableDataTeamChange = val;
    },
    lineSelectionChange(val) {
      this.tableDataLineChange = val;
    },
    async submitChange(type) {
      let tbUpload;
      let msg;
      let day;

      if (type == 'area') {
        console.log(this.effDateArea, '----this.effDateArea');
        if (this.effDateArea) {
          day = this.$utils.GetDateString(this.effDateArea);
        }
        if (!day) {
          this.$message({
            message: '请选择生效日期',
            type: 'warning'
          });
        }
      }
      if (type == 'team') {
        if (this.effDateTeam) {
          day = this.$utils.GetDateString(this.effDateTeam);
        }
        if (!day) {
          this.$message({
            message: '请选择生效日期',
            type: 'warning'
          });
        }
      }
      if (type == 'line') {
        if (this.effDateLine) {
          day = this.$utils.GetDateString(this.effDateLine);
        }
        if (!day) {
          this.$message({
            message: '请选择生效日期',
            type: 'warning'
          });
        }
      }

      if (type === 'area') {
        tbUpload = this.tableDataAreaChange;
        msg = '確定要提交 ' + tbUpload.length + ' 個Area的KPI Goal值嗎？';
      } else if (type === 'team') {
        tbUpload = this.tableDataTeamChange;
        msg = '確定要提交 ' + tbUpload.length + ' 個Team的KPI Goal值嗎？';
      } else if (type === 'line') {
        tbUpload = this.tableDataLineChange;
        msg = '確定要提交 ' + tbUpload.length + ' 條線的KPI Goal值嗎？';
      } else {
        tbUpload = [];
      }
      if (tbUpload.length === 0) {
        this.alertMsg('沒有選中任何行');
        return;
      }
      if (!confirm(msg)) {
        return;
      }

      if (!confirm('若提交錯誤，可以填寫正確的數據後再次提交，確定繼續嗎？')) {
        return;
      }

      this.loadingData = this.$loading({
        lock: true,
        text: '正在提交數據，請耐心等待...',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      });

      const uploadObject = {
        factory: this.queryPlant,
        effDate: day,
        items: []
      };
      tbUpload.forEach((x) => {
        for (var key in x) {
          let index;
          let color;
          if (key.endsWith('Yellow')) {
            index = key.replace('Yellow', '');
            color = 'Yellow';
          } else if (key.endsWith('Green')) {
            index = key.replace('Green', '');
            color = 'Green';
          } else {
            color = '';
          }
          if (color !== '') {
            const existObject = uploadObject.items.filter((t) => t.level === x.level && t.key === x.key && t.index === index);
            if (existObject.length > 0) {
              if (color === 'Yellow') {
                existObject[0].Yellow = x[key];
              } else {
                existObject[0].Green = x[key];
              }
            } else {
              if (color === 'Yellow') {
                uploadObject.items.push({
                  level: x.level,
                  key: x.key,
                  data: x.data,
                  index: index,
                  Yellow: x[key]
                });
              } else {
                uploadObject.items.push({
                  level: x.level,
                  key: x.key,
                  data: x.data,
                  index: index,
                  Green: x[key]
                });
              }
            }
          }
        }
      });
      console.log(uploadObject)
      //return false;
      const response = await UploadGoalSettingData(uploadObject);
      this.loadingData.close();

      const queryResult = response.data.QueryResult;
      if (queryResult === 'OK') {
        this.$alert('修改請求提交成功，請等待系統作業', '提示', {
          confirmButtonText: '確定',
          type: 'success'
        });
      } else {
        this.alertMsg(queryResult);
      }
    },
    async refreshChangeList() {
      if (this.queryPlantList === '') {
        return;
      }
      const data = {
        factory: this.queryPlant
      };
      this.loading = true;
      const response = await GetGoalSettingChangeList(data);
      this.loading = false;
      const queryResult = response.data.QueryResult;
      if (queryResult === 'OK') {
        this.tableDataChangeList = response.data.ReturnObject;
      } else {
        this.alertMsg(queryResult);
      }
    },
    resizeTable: function () {
      this.$nextTick(function () {
        // const divHeight = $('#tableChangeDiv').height()
        // this.tableHeight = divHeight
        const divHeightTab = $('#tabMain').height();
        this.tabDivHeight = divHeightTab - 55 - 40;
      });
    }
  }
};
</script>
<style lang="less" scoped>
.mainDiv {
  width: 100%;
  height: 100%;
  display: flex;
}
.fieldDiv {
  position: relative;
  width: 200px;
  height: 100%;
  margin-right: 5px;
  border: 1px solid rgb(23, 102, 173);
  overflow: auto;
  background-color: white;
}
.fieldTitleDiv {
  width: 100%;
  font-size: 16px;
  color: white;
  height: 25px;
  line-height: 25px;
  text-align: center;
  background-color: rgb(23, 102, 173);
}
li {
  list-style-type: none;
}
.liDataSpan {
  font-size: 14px;
  color: rgb(23, 102, 173);
  padding-left: 5px;
}
.optIcon {
  // right:20px;
  position: absolute;
  padding-top: 5px;
  cursor: pointer;
}
.icon3 {
  right: 50px;
}
.icon2 {
  right: 30px;
}
.icon1 {
  right: 10px;
}
.icon4 {
  right: 70px;
}
.icon5 {
  right: 90px;
}
</style>
