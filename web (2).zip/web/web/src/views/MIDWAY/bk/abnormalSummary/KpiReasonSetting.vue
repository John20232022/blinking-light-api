<template>
  <div>
    <el-form :model="queryParams" ref="queryForm" :inline="true" size="small">
      <el-form-item prop="factoryType">
        <el-select v-model="queryParams.factory" @change="changeFactory" placeholder="厂别">
          <el-option v-for="item in factoryTypeList" :key="item.data" :label="item.data" :value="item.data"> </el-option>
        </el-select>
      </el-form-item>
      <el-form-item prop="area">
        <el-select disabled @change="changeArea" v-model="queryParams.area" placeholder="区域">
          <el-option v-for="item in areaList" :key="item.data" :label="item.data" :value="item.data"> </el-option>
        </el-select>
      </el-form-item>
      <el-form-item prop="team">
        <el-select :disabled="!queryParams.area" v-model="queryParams.team" placeholder="team">
          <el-option v-for="item in teamList" :key="item.data" :label="item.data" :value="item.data"> </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="el-icon-search"
          @click="handleQuery"
          :disabled="!queryParams.factory || !queryParams.area || !queryParams.team"
        >
          搜索
        </el-button>
        <el-button type="primary" icon="el-icon-plus" @click="handleAdd" plain> 新增 </el-button>
      </el-form-item>
    </el-form>

    <el-table :data="tableData" :height="tableHeight" v-loading="loading">
      <el-table-column prop="id" label="id" align="center"> </el-table-column>
      <el-table-column prop="factory" label="factory" align="center"> </el-table-column>
      <el-table-column prop="team" label="team" align="center"> </el-table-column>
      <el-table-column prop="type" label="type" align="center"> </el-table-column>
      <el-table-column prop="reason_code" label="reason_code" align="center"> </el-table-column>
      <el-table-column prop="value" label="value" align="center"> </el-table-column>
      <el-table-column prop="type_num" label="type_num" align="center" />
      <el-table-column width="150" align="center" label="操作">
        <template slot-scope="scope">
          <el-button icon="el-icon-edit" @click.stop="handleEdit(scope.row)" type="text"> 编辑 </el-button>
          <el-button icon="el-icon-delete" @click="handleDelete(scope.row.id)" type="text"> 删除 </el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination :total="total" :page.sync="queryParams.pageIndex" :limit.sync="queryParams.pageSize" @pagination="getList" />

    <DialogKpiReasonSetting ref="DialogKpiReasonSetting" v-model="dialogVisible" @closeView="handleQuery" />
  </div>
</template>

<script>
import { GetDPMQueryKeyValue_API, GetKpiReasonSetting_API, DeleteKpiReasonSetting_API } from '@/api/kpiSetting';
// 分页组件
import Pagination from '@/components/Pagination';
import DialogKpiReasonSetting from '@/views/components/abnormalSummary/dialogKpiReasonSetting';
export default {
  name: 'KpiReasonSetting',
  components: {
    Pagination,
    DialogKpiReasonSetting
  },
  data() {
    return {
      loading: false,
      tableData: [],
      factoryTypeList: [],
      areaList: [],
      teamList: [],
      total: 0,
      tableHeight: document.documentElement.scrollHeight - 180 + 'px',
      queryParams: {
        factory: undefined,
        area: undefined,
        team: undefined,
        pageIndex: 1,
        pageSize: 20
      },
      dialogVisible: false,
      dialogTitle: ''
    };
  },
  created() {
    this.getFactoryTypeList();
  },
  methods: {
    getFactoryTypeList() {
      const data = {
        type: 'userfactory',
        key: ''
      };
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.factoryTypeList = res.data.ReturnObject;
      });
    },
    changeFactory(val) {
      this.queryParams.area = undefined;
      this.queryParams.team = undefined;
      this.queryParams.pageIndex = 1;
      this.queryParams.pageSize = 20;

      this.areaList = [];
      this.teamList = [];

      const obj = this.factoryTypeList.filter((item) => item.data == val)[0];
      const data = {
        type: 'userarea',
        key: obj.key
      };
      GetDPMQueryKeyValue_API(data).then((res) => {
        const arr = res.data.ReturnObject;
        this.areaList = arr.filter((item) => {
          return item.data == 'PCBA';
        });
        if (this.areaList.length == 0) {
          this.$message({
            message: '該廠區沒有PCBA',
            type: 'warning'
          });
        } else {
          this.queryParams.area = this.areaList[0].data;
          this.changeArea(this.queryParams.area);
        }
      });
    },
    changeArea(val) {
      this.queryParams.team = undefined;
      this.queryParams.pageIndex = 1;
      this.queryParams.pageSize = 20;

      this.teamList = [];
      const obj = this.areaList.filter((item) => item.data == val)[0];
      const data = {
        type: 'userteam',
        key: obj.key
      };
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.teamList = res.data.ReturnObject;
        this.teamList.unshift({ key: 'ALL', data: 'ALL' });
      });
    },
    handleAdd() {
      this.dialogVisible = true;
      this.$nextTick(() => {
        this.$refs['DialogKpiReasonSetting'].init();
      });
    },
    //弹窗-修改文档
    handleEdit(obj) {
      this.dialogVisible = true;
      this.$nextTick(() => {
        this.$refs['DialogKpiReasonSetting'].editTemp({ ...obj }, this.factoryTypeList, this.areaList, this.teamList);
      });
    },
    handleDelete(id) {
      this.$confirm('確定要刪除嗎?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        const param = {
          id: id
        };
        this.loading = true;
        DeleteKpiReasonSetting_API(param).then((res) => {
          if (res.data.QueryResult == 'OK') {
            this.handleQuery();
            this.loading = false;
          } else {
            this.$message.error(res.data.QueryResult);
            this.loading = false;
          }
        });
      });
    },
    handleQuery() {
      this.queryParams.pageIndex = 1;
      this.queryParams.pageSize = 20;
      this.getList();
    },
    getList() {
      this.loading = true;
      GetKpiReasonSetting_API(this.queryParams).then((res) => {
        if (res.data.QueryResult == 'OK') {
          this.tableData = res.data.ReturnObject.queryData;
          this.total = res.data.ReturnObject.total;
          this.loading = false;
        } else {
          this.$message.error(res.data.QueryResult);
          this.loading = false;
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>

</style>