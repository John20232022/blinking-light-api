<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" size="small">
      <el-form-item prop="factoryType">
        <el-select v-model="queryParams.factory" @change="changeFactory" placeholder="厂别">
          <el-option v-for="item in factoryTypeList" :key="item.data" :label="item.data" :value="item.data"> </el-option>
        </el-select>
      </el-form-item>
      <el-form-item prop="area">
        <el-select disabled @change="changeArea" v-model="queryParams.area" placeholder="区域">
          <el-option v-for="item in areaList" :key="item.data" :label="item.data" :value="item.data"> </el-option>
        </el-select>
      </el-form-item>
      <el-form-item prop="team">
        <el-select :disabled="!queryParams.area" v-model="queryParams.team" placeholder="team">
          <el-option v-for="item in teamList" :key="item.data" :label="item.data" :value="item.data"> </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="handleQuery('YEAR')" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team">
          by年
        </el-button>
        <el-button type="primary" @click="handleQuery('MONTH')" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team">
          by月
        </el-button>
        <el-button type="primary" @click="handleQuery('WEEK')" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team">
          by周
        </el-button>
        <el-button type="primary" @click="handleQuery('DAY')" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team">
          by日
        </el-button>
      </el-form-item>
    </el-form>

    <!--
      colspan 列
      rowspan 行

    -->
    <div class="table-box">
      <table class="abnormalRecords-table">
        <tr>
          <th colspan="1" rowspan="3" style="min-width: 114px">Work Type</th>
          <th colspan="1" rowspan="3" style="min-width: 100px">佔比</th>
          <th colspan="1" rowspan="3" style="min-width: 100px">項目</th>
          <th colspan="2" rowspan="2">AP Goal(月)</th>
          <th colspan="2" rowspan="1" style="min-width: 200px">MTD</th>

          <th colspan="2" rowspan="1" v-for="(item, index) in dayLilst" :key="index">
            <span>{{ item.label }}</span>
          </th>
        </tr>
        <tr>
          <th colspan="1" rowspan="1">總線數</th>
          <th colspan="1" rowspan="1">{{ busesNumber.open_line }}</th>

          <th colspan="1" rowspan="1" v-for="(item, index) in titleDetai" :key="index">{{ item.open_line }}</th>
        </tr>
        <tr>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">Hr</th>
          <th colspan="1" rowspan="1">ACT vs Goal</th>
          <th colspan="1" rowspan="1">Time(hr)</th>

          <th colspan="1" rowspan="1" v-for="(item, index) in titleDetai" :key="index">{{ item.type }}</th>
        </tr>
        <tr style="font-weight: bold; font-size: 16px">
          <td colspan="1" rowspan="6" class="bg01">WorkTime(%)</td>
          <td colspan="1" rowspan="6" class="bg02">{{ WorkTime }}%</td>
          <td colspan="1" rowspan="1" class="bg02">OEE2(%)</td>
          <td colspan="1" rowspan="1" class="bg02">{{ apDataPercent.oee2 }}%</td>
          <td colspan="1" rowspan="1" class="bg02">{{ apDataHr.oee2 }}</td>
          <td colspan="1" rowspan="1" class="bg02">{{ busesNumber.oee2_per }}%</td>
          <td colspan="1" rowspan="1" class="bg02">{{ busesNumber.oee2 }}</td>
          <td colspan="1" rowspan="1" v-for="(item, index) in titleDetai" :key="index">
            {{ item.oee2 }}
          </td>
        </tr>
        <tr style="font-weight: bold; font-size: 16px">
          <td colspan="1" rowspan="1" class="bg02">Total(%)</td>
          <td colspan="1" rowspan="1" class="bg02">{{ apDataPercent.total }}%</td>
          <td colspan="1" rowspan="1" class="bg02">{{ apDataHr.total }}</td>
          <td colspan="1" rowspan="1" class="bg02">{{ busesNumber.total_per }}%</td>
          <td colspan="1" rowspan="1" class="bg02">{{ busesNumber.total }}</td>
          <td colspan="1" rowspan="1" v-for="(item, index) in titleDetai" :key="index">
            {{ item.total }}
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1" class="bg03">Loss Time(%)</td>
          <td colspan="1" rowspan="1" class="bg04">{{ apDataPercent.loss_time }}%</td>
          <td colspan="1" rowspan="1" class="bg04">{{ apDataHr.loss_time }}</td>
          <td colspan="1" rowspan="1" class="bg04">{{ busesNumber.loss_time_per }}%</td>
          <td colspan="1" rowspan="1" class="bg04">{{ busesNumber.loss_time }}</td>
          <td colspan="1" rowspan="1" v-for="(item, index) in titleDetai" :key="index">
            {{ item.loss_time }}
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1" class="bg03">Down Time(%)</td>
          <td colspan="1" rowspan="1" class="bg04">{{ apDataPercent.down_time }}%</td>
          <td colspan="1" rowspan="1" class="bg04">{{ apDataHr.down_time }}</td>
          <td colspan="1" rowspan="1" class="bg04">{{ busesNumber.down_time_per }}%</td>
          <td colspan="1" rowspan="1" class="bg04">{{ busesNumber.down_time }}</td>
          <td colspan="1" rowspan="1" v-for="(item, index) in titleDetai" :key="index">
            {{ item.down_time }}
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1" class="bg03">Yield Loss(%)</td>
          <td colspan="1" rowspan="1" class="bg04">{{ apDataPercent.yidle_loss }}%</td>
          <td colspan="1" rowspan="1" class="bg04">{{ apDataHr.yidle_loss }}</td>
          <td colspan="1" rowspan="1" class="bg04">{{ busesNumber.yield_loss_per }}%</td>
          <td colspan="1" rowspan="1" class="bg04">{{ busesNumber.yield_loss }}</td>
          <td colspan="1" rowspan="1" v-for="(item, index) in titleDetai" :key="index">
            {{ item.yield_loss }}
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1" class="bg03">Unkwn(%)</td>
          <td colspan="1" rowspan="1" class="bg04">{{ apDataPercent.unknow }}%</td>
          <td colspan="1" rowspan="1" class="bg04">{{ apDataHr.unknow }}</td>
          <td colspan="1" rowspan="1" class="bg04">{{ busesNumber.unknow_per }}%</td>
          <td colspan="1" rowspan="1" class="bg04">{{ busesNumber.unknow }}</td>
          <td colspan="1" rowspan="1" v-for="(item, index) in titleDetai" :key="index">
            {{ item.unknow }}
          </td>
        </tr>
        <tr style="font-weight: bold; font-size: 16px">
          <td colspan="1" rowspan="1" class="bg01">IdleTime(%)</td>
          <td colspan="1" rowspan="1" class="bg02">{{ IdleTime }}%</td>
          <td colspan="1" rowspan="1" class="bg02">IdleTime(%)</td>
          <td colspan="1" rowspan="1" class="bg02">-</td>
          <td colspan="1" rowspan="1" class="bg02">-</td>
          <td colspan="1" rowspan="1" class="bg02">-</td>
          <td colspan="1" rowspan="1" class="bg02">{{ busesNumber.idletime }}</td>
          <td colspan="1" rowspan="1" v-for="(item, index) in titleDetai" :key="index">
            {{ item.idletime }}
          </td>
        </tr>
        <tr>
          <td colspan="2" rowspan="2" class="bg05">change line</td>
          <td colspan="1" rowspan="1" class="bg06">總換線次數</td>
          <td colspan="1" rowspan="1" class="bg06">-</td>
          <td colspan="1" rowspan="1" class="bg06">-</td>
          <td colspan="1" rowspan="1" class="bg06">-</td>
          <td colspan="1" rowspan="1" class="bg06">{{ busesNumber.change_line_count }}</td>
          <td
            colspan="1"
            rowspan="1"
            class="bg06"
            v-for="(item, index) in titleDetai"
            :key="index"
            :class="{ isEmpty: item.change_line_count == 'no' }"
          >
            <span v-if="item.change_line_count != 'no'">{{ item.change_line_count }}</span>
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1" class="bg06">NPI換線次數</td>
          <td colspan="1" rowspan="1" class="bg06">-</td>
          <td colspan="1" rowspan="1" class="bg06">-</td>
          <td colspan="1" rowspan="1" class="bg06">-</td>
          <td colspan="1" rowspan="1" class="bg06">{{ busesNumber.npi_change_count }}</td>
          <td
            colspan="1"
            rowspan="1"
            class="bg06"
            v-for="(item, index) in titleDetai"
            :key="index"
            :class="{ isEmpty: item.npi_change_count == 'no' }"
          >
            <span v-if="item.npi_change_count != 'no'">{{ item.npi_change_count }}</span>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>

<script>
import { GetDPMQueryKeyValue_API, GetPcbaIssueHistoryData_API } from '@/api/kpiSetting';
export default {
  name: 'abnormalRecords',
  data() {
    return {
      factoryTypeList: [],
      areaList: [],
      teamList: [],
      queryParams: {
        factory: undefined,
        area: undefined,
        team: undefined
      },
      busesNumber: {}, //总线体
      dayLilst: [],
      titleDetai: [],
      detail: [],
      apDataPercent: {},
      apDataHr: {},
      today: new Date().getDate(),
      WorkTime: 0,
      IdleTime: 0
    };
  },
  created() {
    this.getFactoryTypeList();
  },
  methods: {
    handleQuery(type) {
      this.getList(type);
    },
    getList(type) {
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      });
      const params = {
        factory: this.queryParams.factory,
        area: this.queryParams.area,
        team: this.queryParams.team,
        type: type
      };
      console.log(params);
      GetPcbaIssueHistoryData_API(params).then((res) => {
        if (res.data.QueryResult == 'OK') {
          const ReturnObject = res.data.ReturnObject;
          this.titleDetai = [];
          this.dayLilst = ReturnObject.date;
          ReturnObject.detail.forEach((item) => {
            if (item.date == 'MTD') {
              this.busesNumber = item;

              this.IdleTime = ((this.busesNumber.idletime / this.today) * 24).toFixed(2);
              this.WorkTime = (100 - this.IdleTime).toFixed(2);
            } else {
              this.titleDetai.push({
                open_line: '開線數',
                type: '%',
                oee2: item.oee2_per + '%',
                total: item.total_per + '%',
                loss_time: item.loss_time_per + '%',
                down_time: item.down_time_per + '%',
                yield_loss: item.yield_loss_per + '%',
                unknow: item.unknow_per + '%',
                idletime: item.idletime_per + '%',
                change_line_count: 'no',
                npi_change_count: 'no'
              });
              this.titleDetai.push({
                open_line: type == 'DAY' ? item.open_line : '',
                type: 'hr',
                oee2: item.oee2,
                total: item.total,
                loss_time: item.loss_time,
                down_time: item.down_time,
                yield_loss: item.yield_loss,
                unknow: item.unknow,
                idletime: item.idletime,
                change_line_count: item.change_line_count,
                npi_change_count: item.npi_change_count
              });
            }
          });

          ReturnObject.apData.forEach((item) => {
            if (item.type == 'Percent') {
              this.apDataPercent = item;
            }
            if (item.type == 'Hr') {
              this.apDataHr = item;
            }
          });
          loading.close();
        } else {
          loading.close();
        }
      });
    },
    getFactoryTypeList() {
      const data = {
        type: 'userfactory',
        key: ''
      };
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.factoryTypeList = res.data.ReturnObject;
      });
    },
    changeFactory(val) {
      this.queryParams.area = undefined;
      this.queryParams.team = undefined;
      this.areaList = [];
      this.teamList = [];
      const obj = this.factoryTypeList.filter((item) => item.data == val)[0];
      const data = {
        type: 'userarea',
        key: obj.key
      };
      GetDPMQueryKeyValue_API(data).then((res) => {
        const arr = res.data.ReturnObject;
        this.areaList = arr.filter((item) => {
          return item.data == 'PCBA';
        });
        if (this.areaList.length == 0) {
          this.$message({
            message: '該廠區沒有PCBA',
            type: 'warning'
          });
        } else {
          this.queryParams.area = this.areaList[0].data;
          this.changeArea(this.queryParams.area);
        }
      });
    },
    changeArea(val) {
      this.queryParams.team = undefined;
      this.teamList = [];
      const obj = this.areaList.filter((item) => item.data == val)[0];
      const data = {
        type: 'userteam',
        key: obj.key
      };
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.teamList = res.data.ReturnObject;
      });
    }
  }
};
</script>


<style scoped lang="less">
::v-deep .el-form-item--small.el-form-item {
  margin-bottom: 10px;
}
.app-container {
  padding: 10px;
  .table-box {
    width: 100%;
    min-height: 430px;
    overflow-x: auto;
    .abnormalRecords-table {
      border-collapse: collapse;
      border: 1px solid #dcdfe6;
      min-width: 1000px;
      tr th {
        padding: 6px 0px;
        border: 1px solid #dcdfe6;
        background-color: #154479;
        color: #ffffff;
        min-width: 80px;
        font-size: 14px;
      }
      tr td {
        padding: 8px 0px;
        border: 1px solid #dcdfe6;
        min-width: 80px;
        text-align: center;
      }
      tr {
        .bg01 {
          background-color: #1a6090;
          color: #ffffff;
        }
        .bg02 {
          background-color: #7ca6cb;
        }
        .bg03 {
          background-color: #8fcbee;
        }
        .bg04 {
          background-color: #c3e5f7;
        }
        .bg05 {
          background-color: #bdd7ee;
        }
        .bg06 {
          background-color: #ddebf7;
        }
        .isEmpty {
          background-color: #dcdfe6;
        }
      }
    }
  }
}
</style>