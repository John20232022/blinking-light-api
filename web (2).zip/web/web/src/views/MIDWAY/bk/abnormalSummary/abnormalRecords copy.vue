<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" size="small">
      <el-form-item prop="factoryType">
        <el-select v-model="queryParams.factory" @change="changeFactory" placeholder="厂别">
          <el-option v-for="item in factoryTypeList" :key="item.data" :label="item.data" :value="item.data"> </el-option>
        </el-select>
      </el-form-item>
      <el-form-item prop="area">
        <el-select disabled @change="changeArea" v-model="queryParams.area" placeholder="区域">
          <el-option v-for="item in areaList" :key="item.data" :label="item.data" :value="item.data"> </el-option>
        </el-select>
      </el-form-item>
      <el-form-item prop="team">
        <el-select :disabled="!queryParams.area" v-model="queryParams.team" placeholder="team">
          <el-option v-for="item in teamList" :key="item.data" :label="item.data" :value="item.data"> </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="handleQuery" :disabled="!queryParams.factory || !queryParams.area || !queryParams.team"> by年 </el-button>
        <el-button type="primary" @click="handleQuery" :disabled="!queryParams.factory || !queryParams.area || !queryParams.team"> by月 </el-button>
        <el-button type="primary" @click="handleQuery" :disabled="!queryParams.factory || !queryParams.area || !queryParams.team"> by周 </el-button>
        <el-button type="primary" @click="handleQuery('DAY')" :disabled="!queryParams.factory || !queryParams.area || !queryParams.team">
          by日
        </el-button>
      </el-form-item>
    </el-form>

    <!--
      colspan 列
      rowspan 行

    -->
    <div class="table-box">
      <table class="abnormalRecords-table">
        <tr>
          <th colspan="1" rowspan="3" style="min-width: 114px">Work Type</th>
          <th colspan="1" rowspan="3" style="min-width: 100px">佔比</th>
          <th colspan="1" rowspan="3" style="min-width: 100px">項目</th>
          <th colspan="2" rowspan="2">AP Goal(月)</th>
          <th colspan="2" rowspan="1" style="min-width: 200px">MTD</th>

          <th colspan="2" rowspan="1">1-MAY</th>
          <th colspan="2" rowspan="1">2-MAY</th>
          <th colspan="2" rowspan="1">3-MAY</th>
          <th colspan="2" rowspan="1">4-MAY</th>
          <th colspan="2" rowspan="1">5-MAY</th>
          <th colspan="2" rowspan="1">6-MAY</th>
          <th colspan="2" rowspan="1">7-MAY</th>
          <th colspan="2" rowspan="1">8-MAY</th>
          <th colspan="2" rowspan="1">9-MAY</th>
          <th colspan="2" rowspan="1">10-MAY</th>
        </tr>
        <tr>
          <th colspan="1" rowspan="1">總線數</th>
          <th colspan="1" rowspan="1">21</th>
          <th colspan="1" rowspan="1">開線數</th>
          <th colspan="1" rowspan="1">0</th>
          <th colspan="1" rowspan="1">開線數</th>
          <th colspan="1" rowspan="1">0</th>
          <th colspan="1" rowspan="1">開線數</th>
          <th colspan="1" rowspan="1">0</th>
          <th colspan="1" rowspan="1">開線數</th>
          <th colspan="1" rowspan="1">0</th>
          <th colspan="1" rowspan="1">開線數</th>
          <th colspan="1" rowspan="1">0</th>
          <th colspan="1" rowspan="1">開線數</th>
          <th colspan="1" rowspan="1">0</th>
          <th colspan="1" rowspan="1">開線數</th>
          <th colspan="1" rowspan="1">0</th>
          <th colspan="1" rowspan="1">開線數</th>
          <th colspan="1" rowspan="1">0</th>
          <th colspan="1" rowspan="1">開線數</th>
          <th colspan="1" rowspan="1">0</th>
          <th colspan="1" rowspan="1">開線數</th>
          <th colspan="1" rowspan="1">0</th>
        </tr>
        <tr>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">Hr</th>
          <th colspan="1" rowspan="1">ACT vs Goal</th>
          <th colspan="1" rowspan="1">Time(hr)</th>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">hr</th>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">hr</th>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">hr</th>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">hr</th>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">hr</th>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">hr</th>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">hr</th>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">hr</th>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">hr</th>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">hr</th>
        </tr>
        <tr>
          <td colspan="1" rowspan="6">WorkTime(%)</td>
          <td colspan="1" rowspan="6">64.1(%)</td>
          <td colspan="1" rowspan="1">OEE2(%)</td>
          <td colspan="1" rowspan="1">89%</td>
          <td colspan="1" rowspan="1">2824.9</td>
          <td colspan="1" rowspan="1">99.8%</td>
          <td colspan="1" rowspan="1">2818.5</td>
          <td colspan="1" rowspan="1">0%</td>
          <td colspan="1" rowspan="1">0</td>
          <td colspan="1" rowspan="1">88.2%</td>
          <td colspan="1" rowspan="1">325.1</td>
          <td colspan="1" rowspan="1">90.6%</td>
          <td colspan="1" rowspan="1">337.4</td>
          <td colspan="1" rowspan="1">90.9%</td>
          <td colspan="1" rowspan="1">340.3</td>
          <td colspan="1" rowspan="1">91.6%</td>
          <td colspan="1" rowspan="1">351.8</td>
          <td colspan="1" rowspan="1">89.0%</td>
          <td colspan="1" rowspan="1">291.8</td>
          <td colspan="1" rowspan="1">89.3%</td>
          <td colspan="1" rowspan="1">251.0</td>
          <td colspan="1" rowspan="1">87.9%</td>
          <td colspan="1" rowspan="1">323.5</td>
          <td colspan="1" rowspan="1">86.5%</td>
          <td colspan="1" rowspan="1">306.7</td>
          <td colspan="1" rowspan="1">84.8%</td>
          <td colspan="1" rowspan="1">290.8</td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">Total(%)</td>
          <td colspan="1" rowspan="1">89%</td>
          <td colspan="1" rowspan="1">2824.9</td>
          <td colspan="1" rowspan="1">99.8%</td>
          <td colspan="1" rowspan="1">2818.5</td>
          <td colspan="1" rowspan="1">0%</td>
          <td colspan="1" rowspan="1">0</td>
          <td colspan="1" rowspan="1">88.2%</td>
          <td colspan="1" rowspan="1">325.1</td>
          <td colspan="1" rowspan="1">90.6%</td>
          <td colspan="1" rowspan="1">337.4</td>
          <td colspan="1" rowspan="1">90.9%</td>
          <td colspan="1" rowspan="1">340.3</td>
          <td colspan="1" rowspan="1">91.6%</td>
          <td colspan="1" rowspan="1">351.8</td>
          <td colspan="1" rowspan="1">89.0%</td>
          <td colspan="1" rowspan="1">291.8</td>
          <td colspan="1" rowspan="1">89.3%</td>
          <td colspan="1" rowspan="1">251.0</td>
          <td colspan="1" rowspan="1">87.9%</td>
          <td colspan="1" rowspan="1">323.5</td>
          <td colspan="1" rowspan="1">86.5%</td>
          <td colspan="1" rowspan="1">306.7</td>
          <td colspan="1" rowspan="1">84.8%</td>
          <td colspan="1" rowspan="1">290.8</td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">Loss Time(%)</td>
          <td colspan="1" rowspan="1">89%</td>
          <td colspan="1" rowspan="1">2824.9</td>
          <td colspan="1" rowspan="1">99.8%</td>
          <td colspan="1" rowspan="1">2818.5</td>
          <td colspan="1" rowspan="1">0%</td>
          <td colspan="1" rowspan="1">0</td>
          <td colspan="1" rowspan="1">88.2%</td>
          <td colspan="1" rowspan="1">325.1</td>
          <td colspan="1" rowspan="1">90.6%</td>
          <td colspan="1" rowspan="1">337.4</td>
          <td colspan="1" rowspan="1">90.9%</td>
          <td colspan="1" rowspan="1">340.3</td>
          <td colspan="1" rowspan="1">91.6%</td>
          <td colspan="1" rowspan="1">351.8</td>
          <td colspan="1" rowspan="1">89.0%</td>
          <td colspan="1" rowspan="1">291.8</td>
          <td colspan="1" rowspan="1">89.3%</td>
          <td colspan="1" rowspan="1">251.0</td>
          <td colspan="1" rowspan="1">87.9%</td>
          <td colspan="1" rowspan="1">323.5</td>
          <td colspan="1" rowspan="1">86.5%</td>
          <td colspan="1" rowspan="1">306.7</td>
          <td colspan="1" rowspan="1">84.8%</td>
          <td colspan="1" rowspan="1">290.8</td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">Down Time(%)</td>
          <td colspan="1" rowspan="1">89%</td>
          <td colspan="1" rowspan="1">2824.9</td>
          <td colspan="1" rowspan="1">99.8%</td>
          <td colspan="1" rowspan="1">2818.5</td>
          <td colspan="1" rowspan="1">0%</td>
          <td colspan="1" rowspan="1">0</td>
          <td colspan="1" rowspan="1">88.2%</td>
          <td colspan="1" rowspan="1">325.1</td>
          <td colspan="1" rowspan="1">90.6%</td>
          <td colspan="1" rowspan="1">337.4</td>
          <td colspan="1" rowspan="1">90.9%</td>
          <td colspan="1" rowspan="1">340.3</td>
          <td colspan="1" rowspan="1">91.6%</td>
          <td colspan="1" rowspan="1">351.8</td>
          <td colspan="1" rowspan="1">89.0%</td>
          <td colspan="1" rowspan="1">291.8</td>
          <td colspan="1" rowspan="1">89.3%</td>
          <td colspan="1" rowspan="1">251.0</td>
          <td colspan="1" rowspan="1">87.9%</td>
          <td colspan="1" rowspan="1">323.5</td>
          <td colspan="1" rowspan="1">86.5%</td>
          <td colspan="1" rowspan="1">306.7</td>
          <td colspan="1" rowspan="1">84.8%</td>
          <td colspan="1" rowspan="1">290.8</td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">Yield Loss(%)</td>
          <td colspan="1" rowspan="1">89%</td>
          <td colspan="1" rowspan="1">2824.9</td>
          <td colspan="1" rowspan="1">99.8%</td>
          <td colspan="1" rowspan="1">2818.5</td>
          <td colspan="1" rowspan="1">0%</td>
          <td colspan="1" rowspan="1">0</td>
          <td colspan="1" rowspan="1">88.2%</td>
          <td colspan="1" rowspan="1">325.1</td>
          <td colspan="1" rowspan="1">90.6%</td>
          <td colspan="1" rowspan="1">337.4</td>
          <td colspan="1" rowspan="1">90.9%</td>
          <td colspan="1" rowspan="1">340.3</td>
          <td colspan="1" rowspan="1">91.6%</td>
          <td colspan="1" rowspan="1">351.8</td>
          <td colspan="1" rowspan="1">89.0%</td>
          <td colspan="1" rowspan="1">291.8</td>
          <td colspan="1" rowspan="1">89.3%</td>
          <td colspan="1" rowspan="1">251.0</td>
          <td colspan="1" rowspan="1">87.9%</td>
          <td colspan="1" rowspan="1">323.5</td>
          <td colspan="1" rowspan="1">86.5%</td>
          <td colspan="1" rowspan="1">306.7</td>
          <td colspan="1" rowspan="1">84.8%</td>
          <td colspan="1" rowspan="1">290.8</td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">Unkwn(%)</td>
          <td colspan="1" rowspan="1">89%</td>
          <td colspan="1" rowspan="1">2824.9</td>
          <td colspan="1" rowspan="1">99.8%</td>
          <td colspan="1" rowspan="1">2818.5</td>
          <td colspan="1" rowspan="1">0%</td>
          <td colspan="1" rowspan="1">0</td>
          <td colspan="1" rowspan="1">88.2%</td>
          <td colspan="1" rowspan="1">325.1</td>
          <td colspan="1" rowspan="1">90.6%</td>
          <td colspan="1" rowspan="1">337.4</td>
          <td colspan="1" rowspan="1">90.9%</td>
          <td colspan="1" rowspan="1">340.3</td>
          <td colspan="1" rowspan="1">91.6%</td>
          <td colspan="1" rowspan="1">351.8</td>
          <td colspan="1" rowspan="1">89.0%</td>
          <td colspan="1" rowspan="1">291.8</td>
          <td colspan="1" rowspan="1">89.3%</td>
          <td colspan="1" rowspan="1">251.0</td>
          <td colspan="1" rowspan="1">87.9%</td>
          <td colspan="1" rowspan="1">323.5</td>
          <td colspan="1" rowspan="1">86.5%</td>
          <td colspan="1" rowspan="1">306.7</td>
          <td colspan="1" rowspan="1">84.8%</td>
          <td colspan="1" rowspan="1">290.8</td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">IdleTime(%)</td>
          <td colspan="1" rowspan="1">35.9%</td>
          <td colspan="1" rowspan="1">IdleTime(%)</td>
          <td colspan="1" rowspan="1">-</td>
          <td colspan="1" rowspan="1">-</td>
          <td colspan="1" rowspan="1">-</td>
          <td colspan="1" rowspan="1">138.0</td>
          <td colspan="1" rowspan="1">0%</td>
          <td colspan="1" rowspan="1">0</td>
          <td colspan="1" rowspan="1">88.2%</td>
          <td colspan="1" rowspan="1">325.1</td>
          <td colspan="1" rowspan="1">90.6%</td>
          <td colspan="1" rowspan="1">337.4</td>
          <td colspan="1" rowspan="1">90.9%</td>
          <td colspan="1" rowspan="1">340.3</td>
          <td colspan="1" rowspan="1">91.6%</td>
          <td colspan="1" rowspan="1">351.8</td>
          <td colspan="1" rowspan="1">89.0%</td>
          <td colspan="1" rowspan="1">291.8</td>
          <td colspan="1" rowspan="1">89.3%</td>
          <td colspan="1" rowspan="1">251.0</td>
          <td colspan="1" rowspan="1">87.9%</td>
          <td colspan="1" rowspan="1">323.5</td>
          <td colspan="1" rowspan="1">86.5%</td>
          <td colspan="1" rowspan="1">306.7</td>
          <td colspan="1" rowspan="1">84.8%</td>
          <td colspan="1" rowspan="1">290.8</td>
        </tr>
        <tr>
          <td colspan="2" rowspan="2">change line</td>
          <td colspan="1" rowspan="1">總換線次數</td>
          <td colspan="1" rowspan="1">-</td>
          <td colspan="1" rowspan="1">-</td>
          <td colspan="1" rowspan="1">-</td>
          <td colspan="1" rowspan="1">218</td>
          <td colspan="1" rowspan="1">0%</td>
          <td colspan="1" rowspan="1">0</td>
          <td colspan="1" rowspan="1">88.2%</td>
          <td colspan="1" rowspan="1">325.1</td>
          <td colspan="1" rowspan="1">90.6%</td>
          <td colspan="1" rowspan="1">337.4</td>
          <td colspan="1" rowspan="1">90.9%</td>
          <td colspan="1" rowspan="1">340.3</td>
          <td colspan="1" rowspan="1">91.6%</td>
          <td colspan="1" rowspan="1">351.8</td>
          <td colspan="1" rowspan="1">89.0%</td>
          <td colspan="1" rowspan="1">291.8</td>
          <td colspan="1" rowspan="1">89.3%</td>
          <td colspan="1" rowspan="1">251.0</td>
          <td colspan="1" rowspan="1">87.9%</td>
          <td colspan="1" rowspan="1">323.5</td>
          <td colspan="1" rowspan="1">86.5%</td>
          <td colspan="1" rowspan="1">306.7</td>
          <td colspan="1" rowspan="1">84.8%</td>
          <td colspan="1" rowspan="1">290.8</td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">NPI換線次數</td>
          <td colspan="1" rowspan="1">-</td>
          <td colspan="1" rowspan="1">-</td>
          <td colspan="1" rowspan="1">-</td>
          <td colspan="1" rowspan="1">84</td>
          <td colspan="1" rowspan="1">0%</td>
          <td colspan="1" rowspan="1">0</td>
          <td colspan="1" rowspan="1">88.2%</td>
          <td colspan="1" rowspan="1">325.1</td>
          <td colspan="1" rowspan="1">90.6%</td>
          <td colspan="1" rowspan="1">337.4</td>
          <td colspan="1" rowspan="1">90.9%</td>
          <td colspan="1" rowspan="1">340.3</td>
          <td colspan="1" rowspan="1">91.6%</td>
          <td colspan="1" rowspan="1">351.8</td>
          <td colspan="1" rowspan="1">89.0%</td>
          <td colspan="1" rowspan="1">291.8</td>
          <td colspan="1" rowspan="1">89.3%</td>
          <td colspan="1" rowspan="1">251.0</td>
          <td colspan="1" rowspan="1">87.9%</td>
          <td colspan="1" rowspan="1">323.5</td>
          <td colspan="1" rowspan="1">86.5%</td>
          <td colspan="1" rowspan="1">306.7</td>
          <td colspan="1" rowspan="1">84.8%</td>
          <td colspan="1" rowspan="1">290.8</td>
        </tr>
      </table>
    </div>
  </div>
</template>

<script>
import { obj20230726 } from '@/assets/js/testData';
import { GetDPMQueryKeyValue_API, GetPcbaIssueHistoryData_API } from '@/api/kpiSetting';
export default {
  name: 'abnormalRecords',
  data() {
    return {
      factoryTypeList: [],
      areaList: [],
      teamList: [],
      queryParams: {
        factory: undefined,
        area: undefined,
        team: undefined
      },
      obj: obj20230726,
      date: [],
      detail: [],
      apData: []
    };
  },
  created() {
    this.getFactoryTypeList();
    this.date = obj20230726
  },
  methods: {
    handleQuery(type) {
      this.getList(type);
    },
    getList(type) {
      const params = {
        factory: this.queryParams.factory,
        area: this.queryParams.area,
        team: this.queryParams.team,
        type: type
      };
      console.log(params);
      GetPcbaIssueHistoryData_API(params).then((res) => {
        if (res.data.QueryResult == 'OK') {
        }
      });
    },
    getFactoryTypeList() {
      const data = {
        type: 'userfactory',
        key: ''
      };
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.factoryTypeList = res.data.ReturnObject;
      });
    },
    changeFactory(val) {
      this.queryParams.area = undefined;
      this.queryParams.team = undefined;
      this.areaList = [];
      this.teamList = [];
      const obj = this.factoryTypeList.filter((item) => item.data == val)[0];
      const data = {
        type: 'userarea',
        key: obj.key
      };
      GetDPMQueryKeyValue_API(data).then((res) => {
        const arr = res.data.ReturnObject;
        this.areaList = arr.filter((item) => {
          return item.data == 'PCBA';
        });
        if (this.areaList.length == 0) {
          this.$message({
            message: '該廠區沒有PCBA',
            type: 'warning'
          });
        } else {
          this.queryParams.area = this.areaList[0].data;
          this.changeArea(this.queryParams.area);
        }
      });
    },
    changeArea(val) {
      this.queryParams.team = undefined;
      this.teamList = [];
      const obj = this.areaList.filter((item) => item.data == val)[0];
      const data = {
        type: 'userteam',
        key: obj.key
      };
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.teamList = res.data.ReturnObject;
      });
    }
  }
};
</script>


<style scoped lang="less">
.app-container {
  padding: 10px;
  .table-box {
    width: 100%;
    min-height: 500px;
    overflow-x: auto;
    .abnormalRecords-table {
      border-collapse: collapse;
      border: 1px solid #dcdfe6;
      width: 1800px;
      tr th {
        padding: 10px 0px;
        border: 1px solid #dcdfe6;
        background-color: #154479;
        color: #ffffff;
        min-width: 66px;
        font-size: 14px;
      }
      tr td {
        padding: 10px 0px;
        border: 1px solid #dcdfe6;
        min-width: 66px;
        text-align: center;
      }
    }
  }
}
</style>