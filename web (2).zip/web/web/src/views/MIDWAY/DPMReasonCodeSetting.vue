<template>
  <div style="height:100%;width:100%;">
    <el-row>
      <el-col :span="4">
        <el-select v-model="MTselectFacroty" :placeholder="$t('common.phdSelectFactory')">
          <el-option
            v-for="item in MTFacrotyList"
            :key="item.factory"
            :label="item.factory"
            :value="item.factory"
          />
        </el-select>
      </el-col>
      <el-col :span="4">
        <el-button type="primary" @click="ShowDiag('add')">{{ $t('common.btnAdd') }}</el-button>
      </el-col>
    </el-row>
    <el-row style="margin-top: 8px;">
      <el-col style="border: 3px solid rgb(218, 218, 224); height: 600px;" :span="5">
        <el-row>
          <el-col :span="5" :offset="14" style="display: inline-flex;">
            <el-button type="primary" @click="SaveCheckedNodes()">{{ $t('common.btnSave') }}</el-button>
            <el-button type="primary" @click="refreashTree()">{{ $t('common.btnQuery') }}</el-button>
          </el-col>
        </el-row>
        <div style="overflow:scroll; height: 580px;">
          <el-tree
            ref="tree"
            :data="TreeData"
            show-checkbox
            node-key="id"
            :default-checked-keys="defalutNodes"
            @node-click="handleNodeClick"
          />
        </div>
      </el-col>
      <el-col :span="18">
        <el-table
          :data="MainDetailInfo"
          height="600px"
          style="overflow:scroll"
          :header-cell-style="getHeaderCellColor"
          :row-style="tableRowStyle"
        >
          <el-table-column
            v-for="item1 in MainDetailInfocolset"
            :key="item1.name"
            :prop="item1.name"
            :label="item1.label"
            :width="item1.width"
          >
            <template #default="scoped">
              <div style="height: 20px;font-size:16px;padding: 0; font-weight: 300;">{{ scoped.row[item1.name] }}</div>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="250">
            <template slot-scope="scope">
              <el-button
                size="mini"
                type="info"
                @click="selectitemfixParent(scope.$index, scope.row)"
              >{{ $t('ReasonCodeSetting.edit') }}</el-button>
              <el-button
                size="mini"
                type="danger"
                @click="selectitemdeleteParent(scope.$index, scope.row)"
              >{{ $t('ReasonCodeSetting.delete_Type') }}</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <el-dialog
      title="ReasonCode_DeTail_Setting"
      :visible.sync="ShowDiaglogFlag"
      :before-close="handleCancel"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      append-to-body
      width="800px"
    >
      <div style="height: 520px">
        <el-col :span="6">
          <!--resonCode 控件类型和label-->
          <el-row style="border-bottom: 3px; border-width: 3px;border-bottom-color: darkgray;border-right: 3px;border-right-color: darkgray;">
            <el-row style="margin-top: 10px;">
              <span> <span style="color: red;">*</span>{{ $t('ReasonCodeSetting.plsChooseRc') }}
                <el-select v-model="SelectResaonCodeId" filterable :placeholder="$t('ReasonCodeSetting.plsChooseRc')" :disabled=" flag === 'fix'">
                  <el-option
                    v-for="item in ResaonCodeoptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                    <span style="float: left; color: #8492a6; font-size: 13px">{{ item.Type_Name }}</span>
                    <span style="float: right; ">{{ item.Reason_Name }}</span>
                  </el-option>
                </el-select>
              </span>
            </el-row>
            <el-row style="margin-top: 10px;">
              <span> <span style="color: red;">*</span>{{ $t('ReasonCodeSetting.plsChooseCtr') }}
                <el-select v-model="SelectCtrType" filterable :placeholder="$t('ReasonCodeSetting.plsChooseCtr')" :disabled=" flag === 'fix'">
                  <el-option
                    v-for="item in SelectCtrTypeoptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </span>
            </el-row>
            <el-row style="margin-top: 10px;">
              <span> <span style="color: red;">*</span>{{ $t('ReasonCodeSetting.plsChooseLb') }}
                <el-select v-model="SelectLabelName" filterable :placeholder="$t('ReasonCodeSetting.plsChooseLb')" :disabled=" flag === 'fix'">
                  <el-option
                    v-for="item in LabelNameoptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </span>
            </el-row>
            <el-row style="margin-top: 10px;">
              <span> <span style="color: red;">*</span>{{ $t('common.colSeq') }}
                <el-input-number v-model="selectseq" />
              </span>
            </el-row>
          </el-row>
          <el-row v-if="SelectCtrType === 'select'" style="border-bottom: 3px; border-width: 3px;border-bottom-color: darkgray;border-right: 3px;border-right-color: darkgray;">
            <!--item 明细添加-->
            <el-row style="margin-top: 10px;">
              <span>{{ $t('dpmDashboardLineDetail.lblStage') }}
                <el-select v-model="SelectStage" filterable multiple :placeholder="$t('dpmDashboardLineDetail.lblStage')">
                  <el-option
                    v-for="item in Stageoptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </span>
            </el-row>
            <el-row style="margin-top: 10px;">
              <span>{{ $t('ReasonCodeSetting.plsChooseitem') }}
                <el-input v-model="SelectItem" :placeholder="$t('ReasonCodeSetting.plsChooseitem')" />
              </span>
            </el-row>
            <el-row style="margin-top: 10px;">
              <el-button type="primary" @click="addItemLine">{{ $t('common.btnAdd') }}</el-button>
            </el-row>
          </el-row>
        </el-col>
        <el-col v-if="SelectCtrType === 'select'" :span="15" style="border-color: lightgray; border-left: 3px; margin-left: 20px;">
          <el-row style="margin-top: 8px;">
            <el-table
              :data="tableData2"
              style="width: 100%"
            >
              <el-table-column
                label="stage"
                width="120"
                prop="stage"
              />
              <el-table-column
                label="item"
                width="120"
                prop="item"
              />
              <el-table-column :label="$t('ReasonCodeSetting.Opeartion')">
                <template slot-scope="scope">
                  <el-button
                    size="mini"
                    type="danger"
                    @click="selectitemdelete(scope.$index, scope.row)"
                  >{{ $t('ReasonCodeSetting.delete') }}</el-button>
                </template>
              </el-table-column>
            </el-table>
          </el-row>
        </el-col>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleCancel">{{ $t('common.btnCancel') }}</el-button>
        <el-button @click="handleSave">{{ $t('common.btnSave') }}</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
// import $ from 'jquery'
import { GetIssueCheckSearchingComBox, GetResonCodeListData, SaveSelectedResonCode, GetResoncodedetailSetting, SaveResoncodedetailSetting } from '@/api/midway.js'
export default {
  data() {
    return {
      MTFacrotyList: [],
      MTselectFacroty: '',
      TreeData: [],
      defalutNodes: [],
      MTselectDate: '',
      MainDetailInfo: [],
      MainDetailInfocolset: [],
      selectTreeDataNode: '',
      ShowDiaglogFlag: false,
      SelectResaonCodeId: '',
      ResaonCodeoptions: [],
      SelectCtrType: '',
      SelectCtrTypeoptions: [{ value: 'text', label: 'text' }, { value: 'number', label: 'number' }, { value: 'select', label: 'select' }],
      SelectLabelName: '',
      LabelNameoptions: [],
      queryKey: '',
      selectseq: '',
      tableData2: [],
      Stageoptions: [],
      SelectStage: '',
      SelectItem: '',
      SelectLabelNameId: '',
      Selectreason_codeId: '',
      flag: '',
      isloading: false
    }
  },
  watch: {
    MTselectFacroty: {
      handler(newVal, oldVal) {
        this.refreashTree()
      }
    }
  },
  mounted() {
    this.getComboxlist('MT', 'MTFacrotyList', '')
  },
  methods: {
    getTabDivHeight() {
    },
    refreashTree() {
      this.searchingData('Main')
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    handleNodeClick(data, node, self) {
      this.selectTreeDataNode = data.id
      console.log(this.selectTreeDataNode)
      if (!node.isLeaf) {
        return
      } else {
        if (!this.isloading) {
          this.searchingData('Main_Detail')
        }
      }
    },
    tableRowStyle({ row, rowIndex }) {
      if (row.WORK_TYPE === '') {
        return {
          'background-color': '#FFE4E1',
          padding: '0',
          height: '18px'
        }
      } else {
        return {
          padding: '0',
          height: '18px'
        }
      }
    },
    getHeaderCellColor() {
      const style = {
        'background-color': 'rgb(32,55,100)',
        color: 'white',
        padding: '0',
        height: '20px'
      }
      return style
    },
    getInfoData(className) {
      var tempresult = this.ProblemInfo.filter((item, index) => {
        if (item.class === className) {
          return true
        }
      })
      return tempresult
    },
    async getComboxlist(page, target, conditon) {
      const data = {
        page: page,
        target: target,
        MTselectDate: this.MTselectDate,
        conditon: conditon
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoading'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await GetIssueCheckSearchingComBox(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this[target] = response.data.ReturnObject[0]
        this.loadingData.close()
      } else {
        this.loadingData.close()
        this.alertMsg(queryResult)
      }
    },
    async searchingData(searchingType) {
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoading'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      try {
        if (searchingType === 'Main') {
          const data = {
            searchingType: searchingType,
            factory: this.MTselectFacroty
          }
          const response = await GetResonCodeListData(data)
          const queryResult = response.data.QueryResult
          if (queryResult === 'OK') {
            this.TreeData = response.data.ReturnObject.LeftListInfo
            this.defalutNodes = response.data.ReturnObject.Leftdefault
            this.loadingData.close()
          } else {
            this.loadingData.close()
            this.alertMsg(queryResult)
          }
        } else if (searchingType === 'Main_Detail') {
          this.isloading = true
          const data = {
            searchingType: 'Main_Detail',
            factory: this.MTselectFacroty,
            id: this.selectTreeDataNode
          }
          this.loadingData = this.$loading({
            lock: true,
            text: this.$t('common.altMsgLoading'),
            spinner: 'el-icon-loading',
            background: 'rgba(0, 0, 0, 0.7)'
          })
          const response = await GetResonCodeListData(data)
          const queryResult = response.data.QueryResult
          if (queryResult === 'OK') {
            this.MainDetailInfo = response.data.ReturnObject.RightListInfo
            this.MainDetailInfocolset = response.data.ReturnObject.colSet
            this.loadingData.close()
            this.isloading = false
          } else {
            this.loadingData.close()
            this.alertMsg(queryResult)
            this.isloading = false
          }
        }
      } catch (err) {
        this.loadingData.close()
        this.isloading = false
      } finally {
        this.loadingData.close()
        this.isloading = false
      }
    },
    async SaveCheckedNodes() {
      const data = {
        searchingType: 'Main',
        NodeList: this.$refs.tree.getCheckedNodes(),
        factory: this.MTselectFacroty
      }
      var msg = this.$t('ReasonCodeSetting.CmfSave_Authority')
      if (confirm(msg) === true) {
        this.loadingData = this.$loading({
          lock: true,
          text: this.$t('common.altMsgLoading'),
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        })
        const response = await SaveSelectedResonCode(data)
        const queryResult = response.data.QueryResult
        if (queryResult === 'OK') {
          this.loadingData.close()
          alert(response.data.ReturnObject.info)
        } else {
          this.loadingData.close()
          this.alertMsg(queryResult)
        }
      } else {
        return
      }
    },
    handleCancel() {
      this.ShowDiaglogFlag = false
    },
    ShowDiag(flag) {
      this.ShowDiaglogFlag = true
      this.tableData2 = []
      this.flag = ''
      this.SelectStage = ''
      this.SelectItem = ''
      this.initCtrInfo(flag)
    },
    async initCtrInfo(flag) {
      if (this.MTselectFacroty === '') {
        var msg = this.$t('ReasonCodeSetting.SaveErrorWithoutFactory')
        // this.alertMsg('請選擇廠別再添加明細')
        this.alertMsg(msg)
        this.ShowDiaglogFlag = false
        return
      }
      const data = {
        flag: flag,
        SelectResaonCodeId: this.SelectResaonCodeId,
        SelectCtrType: this.SelectCtrType,
        SelectLabelName: this.SelectLabelName,
        factory: this.MTselectFacroty
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoading'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await GetResoncodedetailSetting(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.LabelNameoptions = response.data.ReturnObject.LabelNameSet
        this.ResaonCodeoptions = response.data.ReturnObject.ReasonCodeSet
        this.Stageoptions = response.data.ReturnObject.StageSet
        this.loadingData.close()
        if (flag === 'add') {
          this.SelectResaonCodeId = ''
          this.SelectCtrType = ''
          this.SelectLabelName = ''
        }
      } else {
        this.loadingData.close()
        this.alertMsg(queryResult)
        this.SelectResaonCodeId = ''
        this.SelectCtrType = ''
        this.SelectLabelName = ''
      }
    },
    async handleSave() {
      const data = {
        flag: '',
        SelectResaonCodeId: this.flag === 'fix' ? this.Selectreason_codeId : this.SelectResaonCodeId,
        SelectCtrType: this.SelectCtrType,
        SelectLabelName: this.flag === 'fix' ? this.SelectLabelNameId : this.SelectLabelName,
        selectseq: this.selectseq,
        queryKey: this.queryKey,
        itemList: this.tableData2,
        factory: this.MTselectFacroty
      }
      if (this.SelectCtrType === '' || this.SelectResaonCodeId === '' || this.SelectLabelName === '' || this.selectseq === '') {
        // this.alertMsg('带*是必填選項')
        var msg = this.$t('ReasonCodeSetting.SaveErrorWithout*')
        this.alertMsg(msg)
        return
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoading'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await SaveResoncodedetailSetting(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.loadingData.close()
        this.$alert(this.$t('common.altMsgSaveOk'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'info'
        })
        this.ShowDiaglogFlag = false
      } else {
        this.loadingData.close()
        this.alertMsg(queryResult)
      }
      this.searchingData('Main_Detail')
    },
    selectitemdelete(index, row) {
      var tmpstage = row.stage
      var tmpitem = row.item
      var newArray = this.tableData2.filter((a, index) => {
        return a.stage + a.item !== tmpstage + tmpitem
      })
      this.tableData2 = newArray
    },
    addItemLine() {
      if (this.SelectStage.length > 0) {
        for (var i = 0; i < this.SelectStage.length; i++) {
          var newArray = { 'stage': this.SelectStage[i], 'item': this.SelectItem }
          var CheckArray = this.tableData2.filter(a => a.stage === this.SelectStage[i] && a.item === this.SelectItem)
          if (CheckArray.length > 0) {
          // this.alertMsg('列表已添加此Item,不能重復添加')
            var msg = this.$t('ReasonCodeSetting.SaveErrorItemRepeat')
            this.alertMsg(msg)
          } else {
            this.tableData2.push(newArray)
          }
        }
        console.log(this.tableData2)
      } else {
        var newArray2 = { 'stage': '', 'item': this.SelectItem }
        var CheckArray2 = this.tableData2.filter(a => a.stage === '' && a.item === this.SelectItem)
        if (CheckArray2.length > 0) {
          // this.alertMsg('列表已添加此Item,不能重復添加')
          var msg2 = this.$t('ReasonCodeSetting.SaveErrorItemRepeat')
          this.alertMsg(msg2)
        } else {
          this.tableData2.push(newArray2)
        }
      }
    },
    selectitemfixParent(index, row) {
      this.flag = 'fix'
      this.initCtrInfo(this.flag)
      this.ShowDiaglogFlag = true
      this.SelectCtrType = row.type1
      this.selectseq = row.seq
      this.SelectStage = row.stage
      this.SelectLabelName = row.label
      this.SelectResaonCodeId = row.reason_code
      this.SelectLabelNameId = row.Label_NUM
      this.Selectreason_codeId = row.id
      this.SelectItem = row.item
      this.queryKey = row.query_key
      var newarray = this.MainDetailInfo.filter((a, index) => {
        return a.queryKey + a.type1 === row.queryKey + row.type1
      })
      this.tableData2 = []
      for (var i = 0; i < newarray.length; i++) {
        var newArray2 = { 'stage': newarray[i].stage, 'item': newarray[i].item }
        this.tableData2.push(newArray2)
      }
    },
    async selectitemdeleteParent(index, row) {
      const data = {
        flag: 'delete',
        SelectResaonCodeId: row.id,
        SelectCtrType: row.type1,
        SelectLabelName: row.Label_NUM,
        selectseq: '',
        queryKey: row.query_key,
        itemList: this.tableData2,
        factory: this.MTselectFacroty
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoading'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await SaveResoncodedetailSetting(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.loadingData.close()
        this.$alert(this.$t('common.altMsgSaveOk'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'info'
        })
        this.ShowDiaglogFlag = false
      } else {
        this.loadingData.close()
        this.alertMsg(queryResult)
      }
      this.searchingData('Main_Detail')
    }
  }
}
</script>
<style lang="less" scoped>
  .el-table {
  /deep/ .el-table__body-wrapper::-webkit-scrollbar {
    width: 15px; /*滚动条宽度*/
    height: 15px; /*滚动条高度*/
  }
  /*定义滚动条轨道 内阴影+圆角*/
  /deep/ .el-table__body-wrapper::-webkit-scrollbar-track {
    box-shadow: 0px 1px 3px rgba(red, green, blue, 0) inset; /*滚动条的背景区域的内阴影*/
    border-radius: 12px; /*滚动条的背景区域的圆角*/
    background-color: rgba(red, green, blue, 0); /*滚动条的背景颜色*/
    width: 200px;
  }
  /*定义滑块 内阴影+圆角*/
  /deep/ .el-table__body-wrapper::-webkit-scrollbar-thumb {
    box-shadow: 0px 1px 3px rgba(red, green, blue, 0) inset; /*滚动条的内阴影*/
    border-radius: 12px; /*滚动条的圆角*/
    background-color: rgb(27, 117, 219); /*滚动条的背景颜色*/
    width: 200px;
  }
}
</style>
<style>
.el-table .el-table__fixed {
  height:auto ;
  bottom:auto
}
.el-table__body-wrapper {
  z-index:1
}
  .el-collapse .el-collapse-item__header {
    color: white;
    font-size: 18px;
    background-color: cornflowerblue;
    border-radius: 10px;
}
  .el-collapse-item__content {
    font-size: 18px;
    border-color: cornflowerblue;
    border-width: 5px;
    border-radius: 5px;
}
</style>
