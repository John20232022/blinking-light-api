<template>
  <div style="height:100%;width:100%;">
    <el-container style="height:100%;">
      <el-header class="header">
        <div style="display:inline">
          <el-select v-model="queryFactory" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectFactory')" @change="getQueryAreaList">
            <el-option
              v-for="item in factoryList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-select v-model="queryArea" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectArea')" @change="getQueryTeamList">
            <el-option
              v-for="item in areaList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-select v-model="queryTeam" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectTeam')" @change="getQueryLineList">
            <el-option
              v-for="item in teamList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <el-select v-model="queryLine" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectLine')">
            <el-option
              v-for="item in lineList"
              :key="item.key"
              :label="item.data"
              :value="item.key"
            />
          </el-select>
          <span class="topLineSpan">{{ $t('dpmSummaryOfissues.lblTimeGranularity') }}>></span>
          <el-button :type="queryType==='year'?'success':'warning'" size="small" @click="queryData('year')">{{ $t('dpmSummaryOfissues.btnByYear') }}</el-button>
          <el-button :type="queryType==='month'?'success':'warning'" size="small" @click="queryData('month')">{{ $t('dpmSummaryOfissues.btnByMonth') }}</el-button>
          <el-button :type="queryType==='week'?'success':'warning'" size="small" @click="queryData('week')">B{{ $t('dpmSummaryOfissues.btnByWeek') }}</el-button>
          <el-button :type="queryType==='day'?'success':'warning'" size="small" @click="queryData('day')">{{ $t('dpmSummaryOfissues.btnByDay') }}</el-button>
        </div>
      </el-header>
      <el-main style="padding:0;">
        <div style="height:100%">
          <el-table
            v-loading="loading"
            :data="tableData"
            size="small"
            stripe
            :header-cell-style="getHeaderCellColor"
            :cell-style="getCellColor"
            style="width: 100%;"
          >
            <el-table-column
              v-for="o in colSetting"
              :key="o.label"
              :label="o.label"
              :prop="o.prop"
              :width="o.width"
              :fixed="o.b_fixed"
              align="center"
            >
              <el-table-column
                v-for="child in o.subCols"
                :key="child.label"
                :prop="child.prop"
                :label="child.label"
                :width="child.width"
                :fixed="o.b_fixed"
                align="center"
              />
            </el-table-column>
          </el-table>

        </div>

      </el-main>
    </el-container>
  </div>
</template>
<script>
// import $ from 'jquery'
import {
  GetDPMQueryKeyValue, GetDPMSummaryOfIssuesData
} from '@/api/midway.js'

export default {

  data() {
    return {
      queryFactory: '',
      factoryList: [],
      queryArea: '',
      areaList: [],
      queryTeam: '',
      queryLine: '',
      queryDay: '',
      tableData: [],
      colSetting: [],
      lineList: [],
      queryType: '',
      teamList: [],
      loading: false

    }
  },
  computed: {
  },
  mounted() {
    this.getDefaultDate()
    this.getQueryFactoryList()
  },
  beforeDestroy() {
  },
  methods: {
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    getDefaultDate() {
      const curDate = new Date()
      this.queryDay = new Date(curDate.getTime() - 24 * 60 * 60 * 1000)
      this.queryMonth = new Date(curDate.getTime() - 24 * 60 * 60 * 1000)
    },
    async getQueryFactoryList() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.factoryList = []

      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.factoryList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryAreaList() {
      this.areaList = []
      this.queryArea = ''
      this.teamList = []

      this.queryTeam = ''
      const data = {
        type: 'userarea',
        key: this.queryFactory
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryTeamList() {
      this.teamList = []
      this.queryTeam = ''
      const data = {
        type: 'userteam',
        key: this.queryArea
      }
      this.teamList.push({
        key: 0,
        data: 'ALL'
      })
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        for (let i = 0; i < obj.length; i++) {
          this.teamList.push({
            key: obj[i].key,
            data: obj[i].data
          })
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryLineList() {
      this.lineList = []
      this.queryLine = ''
      const data = {
        type: 'userline',
        key: this.queryTeam
      }
      this.lineList.push({
        key: 0,
        data: 'ALL'
      })
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        for (let i = 0; i < obj.length; i++) {
          this.lineList.push({
            key: obj[i].key,
            data: obj[i].data
          })
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    async queryData(type) {
      this.queryType = type
      if (this.queryFactory === '') {
        this.alertMsg(this.$t('dpmSummaryOfissues.altMsgFactoryEmpty'))
        return
      }
      if (this.queryArea === '') {
        this.alertMsg(this.$t('dpmSummaryOfissues.altMsgAreaEmpty'))
        return
      }

      if (this.queryTeam === '') {
        this.queryTeam = 0
      }
      if (this.queryLine === '') {
        this.queryLine = 0
      }
      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      const line = this.lineList.filter(x => x.key === this.queryLine)[0].data
      const data = {
        factory: factory,
        area: area,
        team: team,
        line: line,
        range: this.queryType
      }
      this.loading = true
      const response = await GetDPMSummaryOfIssuesData(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.mainObject = response.data.ReturnObject
        this.colSetting = this.mainObject.columns
        this.tableData = this.mainObject.IssuesPercentageTable
      } else {
        this.alertMsg(queryResult)
      }
    },
    getHeaderCellColor() {
      const style = {
        'background-color': 'rgb(32,55,100)',
        color: 'white'
      }
      return style
    },
    getCellColor({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0 || columnIndex === 1) {
        return 'color: black; background: rgb(221, 235, 247);'
      } else {
        var goal
        var item
        var cols
        var cols_number
        var index_tmp = 0
        if (this.queryType !== 'year') {
          goal = row['goal']
          if (goal !== null) {
            goal = Number(goal.replace('%', ''))
          } else {
            goal = 0
          }

          item = column.label.toLowerCase()

          if (this.queryType === 'day') {
            index_tmp = columnIndex - 3
          }
          if (this.queryType === 'week') {
            index_tmp = columnIndex - 2
          }
          if (this.queryType === 'month') {
            index_tmp = columnIndex - 3
          }
          if (item.includes('goal') === false && item.includes('reason_code') === false && item.includes('type') === false && item.includes('ytd') === false && item.includes('mtd') === false) {
            item = 'col' + index_tmp
            cols = row[item]
            if (cols !== null) {
              cols_number = Number(row[item].replace('%', ''))
              if (goal > 0) {
                if (cols_number > goal) {
                  return 'color: #FF3B4B'
                }
              }
              // if (cols_number > goal) {
              //   return 'color: #FF3B4B'
              // }
            }
          }
        } else {
          // year
          // 奇数
          if (columnIndex % 2 !== 0) {
            item = column.label.toLowerCase()
            if (item.includes('goal') === false && item.includes('reason_code') === false && item.includes('type') === false && item.includes('ytd') === false && item.includes('mtd') === false) {
            // 只有实际值列需要颜色变化
              if (item.includes('-a') === true) {
                index_tmp = (columnIndex - 1) / 2
                item = 'col' + index_tmp
                // 目标值为前一项item - 1
                goal = row[item + '-G']
                if (goal !== null && goal !== undefined) {
                  goal = Number(goal.replace('%', ''))
                } else {
                  goal = 0
                }
                cols = row[item + '-A']
                if (cols !== null && cols !== undefined) {
                  cols_number = Number(cols.replace('%', ''))
                  if (goal > 0) {
                    if (cols_number > goal) {
                      return 'color: #FF3B4B'
                    }
                  }
                }
              }
            }
          }
        }

        return 'color: black'
      }
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep main.el-main{
  padding: 0
}
::v-deep .el-divider--horizontal{
  margin:0
}
.selectMidSize{
  width:120px;
  margin-right:5px;
}
.topLineSpan{
  display: inline-block;
  margin:0 10px;
  color: blue;
}
.chartHeadSpan{
  display: inline-block;
  color: blue;
  margin:20px 20px 20px 20px;
}
section{
  padding-bottom: 0;
}
.el-header{
    padding:0 5px
}
.header{
  height:40px !important;
  // background-color:#1f4e7c;
  background-color:rgba(0,0,0,0);
}
::v-deep .el-table td div{
  font-size: 16px;
}
.defTableCell{
  font-size: 16px;
  color: black;
}
// ::v-deep .el-table .cell {
//     white-space: pre-line;
// }
::v-deep .el-table td {
  border:1px solid lightgray;
}

</style>
