<template>
  <div style="height:100%;width:100%;background-image:radial-gradient(#26589A, #191D50)" />
</template>
<script>
import {
  GetDashboardInitialLevel
} from '@/api/midway.js'
export default {
  data() {
    return {
      loadingData: null,
      level: 'factory',
      keyid: ''
    }
  },
  computed: {
  },
  mounted() {
    this.GetInitLevel()
  },
  methods: {
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    async GetInitLevel() {
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoading'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await GetDashboardInitialLevel()
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        // console.log(obj)
        this.level = obj.level
        this.keyid = obj.parent_id === '0' ? '' : obj.parent_id
        let url = ''
        if (this.level === 'factory') {
          url = '/DPMDashboardFactory'
        } else if (this.level === 'area') {
          url = '/DPMDashboardArea'
        } else if (this.level === 'team') {
          url = '/DPMDashboardTeam'
        } else if (this.level === 'line') {
          url = '/DPMDashboardLine'
        }
        const query = {
          level: this.level,
          keyid: this.keyid
        }
        // console.log('---query---')
        // console.log(query)
        this.$router.push({
          path: url,
          query: query
        })
      } else {
        this.alertMsg(queryResult)
      }
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep main.el-main{
padding: 0
}
</style>
