<template>
  <div ref="chart" :style="{width: '100%', height: '100%'}" />
</template>

<script>
// import echarts from "echarts";
import * as echarts from 'echarts'
export default {
  props: {
    height: {
      type: String,
      default: '100%'
    },
    width: {
      type: String,
      default: '100%'
    }
  },
  data() {
    return {
      isShow: false,
      chart: null,
      axisData: [],
      histogramData: {},
      lineChartData: {}
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.chart = echarts.init(this.$refs.chart)
    })
  },
  methods: {
    setUp(axisData, histogramData, lineChartData, checkboxProjectList) {
      this.$forceUpdate()
      this.isShow = true
      this.histogramData = histogramData
      this.lineChartData = lineChartData
      const hData = []

      this.histogramData.forEach((item) => {
        const isEmpty = String(item['LABEL'])
        let actData = 0
        if (isEmpty === '') {
          hData.push(null)
        } else {
          checkboxProjectList.forEach((itemKey) => {
            const str = String(item[itemKey])
            let val = 0
            if (str !== 'undefined') {
              val = parseFloat(str)
            }
            actData = actData + val
          })
          // const str = String(item.losshr)
          // const val = str.slice(0, str.length - 1)
          // preData.push(Number(val))
          hData.push(actData.toFixed(2))
        }
      })

      const lData = []
      this.lineChartData.forEach((item) => {
        let actData = 0
        const isEmpty = String(item['LABEL'])
        if (isEmpty === '') {
          lData.push(null)
        } else {
          checkboxProjectList.forEach((itemKey) => {
            let val = 0
            const str = String(item[itemKey])
            if (str !== 'undefined') {
              val = parseFloat(str)
            }
            actData = actData + val
          })
          // const str = String(item.lossper)
          // const val = str.slice(0, str.length - 1)
          // preData.push(Number(val))
          lData.push(actData.toFixed(2))
        }
      })

      this.axisData = axisData
      // this.apGoal = apGoal
      // this.handleItem('人')
      const xData = this.axisData // this.dayList.map((item) => item.label)
      const params = {
        xData: xData,
        hData: hData,
        lData: lData
      }
      this.resetOptions(params)
    },

    resetOptions(params) {
      // 设置图表选项
      const option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
            label: {
              backgroundColor: '#6a7985'
            }
          }
        },
        legend: {
          data: ['Loss Time(h)', 'Loss Rate(%)']
        },
        // toolbox: {
        //     feature: {
        //     saveAsImage: {}
        //     }
        // },
        grid: {
          left: '10px',
          top: '40px',
          right: '10px',
          bottom: '10px',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            data: params.xData,
            axisLine: {
              show: true,
              lineStyle: {
                color: 'black',
                width: 1,
                type: 'solid'
              }
            },
            axisLabel: {
              interval: 0,
              // rotate:50,
              show: true,
              splitNumber: 15,
              textStyle: {
                color: '#606266',
                fontSize: '12'
              }
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            // name: 'Bar Y-Axis',
            splitLine: { show: false }
          },
          {
            type: 'value',
            // name: 'Line Y-Axis',
            splitLine: { show: false },
            axisLabel: {
              formatter: '{value}%'
            }
          }
        ],
        series: [
          {
            name: 'Loss Time(h)',
            type: 'bar',
            yAxisIndex: 0,
            data: params.hData,
            itemStyle: {
              normal: {
                opacity: 1,
                barBorderRadius: 2,
                color: '#409EFF'
              }
            }
          },
          {
            name: 'Loss Rate(%)',
            type: 'line',
            yAxisIndex: 1,
            data: params.lData,
            itemStyle: {
              normal: {
                opacity: 1,
                // barBorderRadius: 2,
                color: '#409EFF'
              }
            }
          }
        ]
      }

      // 设置图表选项
      this.chart.setOption(option)

      // 适应窗口大小
      window.addEventListener('resize', () => {
        this.chart.resize()
      })
    }
  }
}
</script><style scoped>
   div {
    width: 600px;
    height: 400px;
  }
  </style>

