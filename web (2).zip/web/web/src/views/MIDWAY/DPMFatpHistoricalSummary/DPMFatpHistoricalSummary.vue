<template>
  <div class="app-container">
    <el-form ref="queryForm" :model="queryParams" :inline="true" size="small">
      <el-form-item prop="factoryType">
        <el-select v-model="queryParams.factory" :placeholder="$t('common.phdSelectFactory')" @change="changeFactory">
          <el-option v-for="item in factoryList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item>
      <el-form-item prop="area">
        <el-select v-model="queryParams.area" :disabled="!queryParams.factory" :placeholder="$t('common.phdSelectArea')">
          <el-option label="FATP" value="FATP" />
        </el-select>
      </el-form-item>
      <el-form-item prop="team">
        <el-select v-model="queryParams.team" multiple collapse-tags :disabled="!queryParams.area" :placeholder="$t('common.phdSelectTeam')" @change="changeTeam">
          <el-option v-for="item in teamList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item>
      <el-form-item prop="line">
        <el-select v-model="queryParams.line" multiple collapse-tags :disabled="!queryParams.team" :placeholder="$t('common.phdSelectLine')">
          <el-option v-for="item in lineList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-select v-model="queryParams.shift" :placeholder="$t('common.colShift')">
          <el-option
            v-for="item in workshiftList"
            :key="item.shift_code"
            :label="item.shift_name"
            :value="item.shift_code"
          />
          <!-- <el-option v-for="item in shiftList" :key="item" :label="item" :value="item" /> -->
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-select v-model="queryParams.showType" @change="showTypeChange"><!--:placeholder="$t('common.colShift')"-->
          <el-option label="loss_time" value="loss_time" />
          <el-option label="loss_rate" value="loss_rate" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team || !queryParams.line" @click="handleQuery('YEAR')">
          {{ $t('abnormalRecords.btnByYearQuarter') }}
        </el-button>
        <el-button type="primary" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team || !queryParams.line" @click="handleQuery('MONTH')">
          {{ $t('abnormalRecords.btnByMonth') }}
        </el-button>
        <el-button type="primary" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team || !queryParams.line" @click="handleQuery('WEEK')">
          {{ $t('abnormalRecords.btnByWeek') }}
        </el-button>
        <el-button type="primary" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team || !queryParams.line" @click="handleQuery('DAY')">
          {{ $t('abnormalRecords.btnByDay') }}
        </el-button>

        <el-button type="primary" plain :disabled="dayList.length == 0" @click="handleExportExcel()"> downLoad </el-button>
      </el-form-item>
    </el-form>
    <div class="table-box">
      <table id="out-table01" class="historicalSummary-table">
        <tr>
          <th colspan="2" rowspan="1" style="min-width: 114px">KPI</th>
          <th colspan="2" rowspan="1" style="min-width: 100px">Accumulate</th>
          <th v-for="(item, index) in dayList" :key="index" colspan="1" rowspan="1">
            <span>{{ item.label }}</span>
          </th>
        </tr>
        <tr>
          <th colspan="1" rowspan="5" style="min-width: 50px">MFG<br>KPI</th>
          <th colspan="1" rowspan="1" style="min-width: 100px" class="bg02">{{ $t('dpmFatpHistoricalSummary.lblStdTime') }}</th>
          <th colspan="2" rowspan="1" style="min-width: 80px" class="bg02">{{ mtdData.std_time }}</th>
          <td v-for="(item, index) in titleDetail" :key="index" colspan="1" rowspan="1">
            <span>{{ item.std_time }}</span>
          </td>
        </tr>
        <tr>
          <th colspan="1" rowspan="1" style="min-width: 100px" class="bg02">{{ $t('dpmFatpHistoricalSummary.lblActTime') }}</th>
          <th colspan="2" rowspan="1" style="min-width: 80px" class="bg02">{{ mtdData.act_time }}</th>
          <td v-for="(item, index) in titleDetail" :key="index" colspan="1" rowspan="1">
            <span>{{ item.act_time }}</span>
          </td>
        </tr>
        <tr>
          <th colspan="1" rowspan="1" style="min-width: 100px" class="bg02">{{ $t('dpmFatpHistoricalSummary.lblEfficiency') }}MF</th>
          <th colspan="2" rowspan="1" style="min-width: 80px" class="bg02">{{ mtdData.eff_MF }}%</th>
          <td v-for="(item, index) in titleDetail" :key="index" colspan="1" rowspan="1">
            <span>{{ item.eff_MF }}%</span>
          </td>
        </tr>
        <tr>
          <th colspan="1" rowspan="1" style="min-width: 100px" class="bg02">{{ $t('dpmFatpHistoricalSummary.lblEfficiency') }}ACT</th>
          <th colspan="2" rowspan="1" style="min-width: 80px" class="bg02">{{ mtdData.eff_ACT }}%</th>
          <td v-for="(item, index) in titleDetail" :key="index" colspan="1" rowspan="1">
            <span>{{ item.eff_ACT }}%</span>
          </td>
        </tr>
        <tr>
          <th colspan="1" rowspan="1" style="min-width: 100px" class="bg02">GAP</th>
          <th colspan="2" rowspan="1" style="min-width: 80px" class="bg02" :class="getRedColor(mtdData.Gap)">{{ mtdData.Gap }}%</th>
          <td v-for="(item, index) in titleDetail" :key="index" colspan="1" rowspan="1" :class="getRedColor(item.gap)">
            <span>{{ item.gap }}%</span>
          </td>
        </tr>
        <tr v-for="(itemLoss, indexLoss) in lossDetailLeft" :key="indexLoss">
          <th v-if="indexLoss=='0'" colspan="1" :rowspan="rowsNumber">{{ itemLoss.KPI }}</th>
          <td colspan="1" rowspan="1" :class="getColor(itemLoss.loss_level,'reasoncode')">{{ itemLoss.reasoncode }}</td>
          <td colspan="1" rowspan="1" :class="getColor(itemLoss.loss_level,'mtdlosshr')">{{ itemLoss.mtdlosshr }}</td>
          <td colspan="1" rowspan="1" :class="getColor(itemLoss.loss_level,'mtdlossper')">{{ itemLoss.mtdlossper }}%</td>
          <td v-for="(item, indexRight) in lossDetailRight[indexLoss]" :key="indexRight" :class="getNumberColor(itemLoss.loss_level)">
            <span v-if="queryParams.showType==='loss_time'"> {{ item }}</span>
            <span v-else> {{ item }}%</span>
          </td>
        </tr>
        <tr v-for="(itemMfgLeft, indexMfgLeft) in mfgDetailLeft" :key="'mfgDetailLeft-'+indexMfgLeft"><!--key值拼接mfgDetailLeft-是为了防止前端报错-->
          <th colspan="1" rowspan="1">{{ itemMfgLeft.KPI }}</th>
          <td colspan="1" rowspan="1" :class="getColor(itemMfgLeft.loss_level,'reasoncode')">{{ itemMfgLeft.reasoncode }}</td>
          <td colspan="1" rowspan="1" :class="getColor(itemMfgLeft.loss_level,'mtdlosshr')">{{ itemMfgLeft.mtdlosshr }}</td>
          <td colspan="1" rowspan="1" :class="getColor(itemMfgLeft.loss_level,'mtdlossper')">{{ itemMfgLeft.mtdlossper }}%</td>
          <td v-for="(itemMfgRight, indexMfgRight) in mfgDetailRight[0]" :key="indexMfgRight" :class="getNumberColor(itemMfgLeft.loss_level)">
            <span> {{ itemMfgRight }}</span>
          </td>
        </tr>
      </table>
    </div>
    <el-checkbox-group v-model="checkboxProjectList" style="margin-top: 20px;" @change="getCheckedData">
      <el-checkbox-button v-for="(item, index) in projectList" :key="index" :label="item" type="primary" plain size="middle" round>{{ item }}</el-checkbox-button>
    </el-checkbox-group>
    <el-row>
      <DPMFatpIssueEcharts ref="DPMFatpIssueEcharts" />
    </el-row>
    <el-row style="margin-top: 30px; height: 300px;">
      <DPMFatpIssueMTDEcharts ref="DPMFatpIssueMTDEcharts" />
    </el-row>
  </div>
</template>
<script>
import { GetDPMQueryKeyValue, GetFatpHistoricalSummaryData, GetWorkshiftList } from '@/api/midway.js'
import DPMFatpIssueEcharts from '@/views/MIDWAY/DPMFatpHistoricalSummary/DPMFatpIssueEcharts'
import DPMFatpIssueMTDEcharts from '@/views/MIDWAY/DPMFatpHistoricalSummary/DPMFatpIssueMTDEcharts'
// import { data } from 'jquery'

export default {
  name: 'DPMFatpHistoricalSummary',
  components: {
    DPMFatpIssueEcharts,
    DPMFatpIssueMTDEcharts
  },
  data() {
    return {
      dialogVisible: false,
      factoryList: [],
      areaList: [],
      teamList: [],
      lineList: [],
      queryParams: {
        factory: undefined,
        area: undefined,
        team: undefined,
        line: undefined,
        shift: 'ALL',
        showType: 'loss_time'
      },
      dayList: [],
      mtdData: {},
      titleDetail: [],
      axisLine: [],
      // lossDetail: {},
      lossDetailLeft: {},
      lossDetailRight: {},
      mfgDetailLeft: {},
      mfgDetailRight: {},
      echartData: {},
      apDataPercent: [{ type: 'Percent' }, { type: 'Hr' }],
      rowsNumber: 0,
      axisData: [],
      histogramData: {},
      lineChartData: {},
      workshiftList: [],
      // shiftList: [
      //   'D',
      //   'N',
      //   'M',
      //   'ALL'
      // ],
      projectList: [],
      checkboxProjectList: []
    }
  },
  created() {
    this.getFactoryList()
  },
  methods: {
    async getWorkDayWorkshift() {
      this.workshiftList = []
      const data = {
        factory: this.queryParams.factory,
        hasALL: 'Y'
      }
      const response = await GetWorkshiftList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.workshiftList = response.data.ReturnObject
      } else {
        this.alertMsg(
          this.$utils.ReplacePlaceHolder(
            this.$t('dpmDashboardLineDetail.altMsgCannotGetShift'),
            [queryResult]
          )
        )
      }
    },
    getFactoryList() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      GetDPMQueryKeyValue(data).then((res) => {
        this.factoryList = res.data.ReturnObject
      })
    },
    getColor(losslevel, type) {
      if (losslevel === 1) {
        if (type === 'mtdlosshr' || type === 'mtdlossper') {
          return 'isFirstLevelNumberic'
        } else {
          return 'isFirstLevel'
        }
      } else if (losslevel === 2) {
        if (type === 'mtdlosshr' || type === 'mtdlossper') {
          return 'isSecondLevelNumberic'
        } else {
          return 'isSecondLevel'
        }
      } else if (losslevel === 3) {
        return 'isThirdLevel'
      }
    },
    getNumberColor(losslevel) {
      if (losslevel === 1) {
        return 'isFirstLevelRightNumberic'
      } else if (losslevel === 2) {
        return 'isSecondLevelRightNumberic'
      } else {
        return 'noStyle'
      }
    },
    getRedColor(val) {
      if (Number(val) < 0) {
        return 'isRedNumberic'
      }
    },
    changeFactory(val) {
      this.getWorkDayWorkshift()
      this.queryParams.area = undefined
      this.queryParams.team = undefined
      this.queryParams.line = undefined
      this.areaList = []
      this.teamList = []
      this.lineList = []
      const obj = this.factoryList.filter((item) => item.data === val)[0]
      const data = {
        type: 'userarea',
        key: obj.key
      }
      GetDPMQueryKeyValue(data).then((res) => {
        const arr = res.data.ReturnObject
        this.areaList = arr.filter((item) => {
          return item.data === 'FATP'
        })
        this.queryParams.area = this.areaList[0].data
        this.changeArea(this.queryParams.area)
      })
    },
    changeArea(val) {
      this.queryParams.team = undefined
      this.queryParams.line = undefined
      this.teamList = [{ data: 'ALL', key: 'ALL' }]
      this.lineList = []
      const obj = this.areaList.filter((item) => item.data === val)[0]
      const data = {
        type: 'userteam',
        key: obj.key
      }
      GetDPMQueryKeyValue(data).then((res) => {
        res.data.ReturnObject.forEach((item) => {
          this.teamList.push({
            data: item.data,
            key: item.key
          })
        })
      })
      this.queryParams.team = ['ALL']
      this.changeTeam(this.queryParams.team)
    },
    changeTeam(val) {
      this.queryParams.line = undefined
      this.lineList = [{ data: 'ALL', key: 'ALL' }]
      if (val[0] !== 'ALL' && val !== '') {
        if (val.length === 1) {
          let key = ''
          val.forEach((itemSelected) => {
            const obj = this.teamList.filter((item) => item.data === itemSelected)
            key = key + obj[0].key + ','
          })
          key = key.substring(0, key.length - 1)
          const data = {
            type: 'userline',
            key: key// obj.key
          }
          GetDPMQueryKeyValue(data).then((res) => {
            res.data.ReturnObject.forEach((item) => {
              this.lineList.push({
                data: item.data,
                key: item.key
              })
            })
          })
        }
      }
      this.queryParams.line = ['ALL']
    },
    showTypeChange() {
      if (this.type === undefined) {
        return
      } else {
        this.handleQuery(this.type)
      }
    },
    handleQuery(type) {
      this.type = type
      this.getList(type)
    },
    getList(type) {
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      let lines = ''
      this.queryParams.line.forEach((itemLines) => {
        lines = lines + itemLines + ','
      })
      lines = lines.substring(0, lines.length - 1)
      let teams = ''
      this.queryParams.team.forEach((itemteams) => {
        teams = teams + itemteams + ','
      })
      teams = teams.substring(0, teams.length - 1)
      const params = {
        factory: this.queryParams.factory,
        area: this.queryParams.area,
        team: teams, // this.queryParams.team,
        line: lines, // this.queryParams.line,
        shift: this.queryParams.shift,
        type: type,
        showType: this.queryParams.showType
      }
      GetFatpHistoricalSummaryData(params).then((res) => {
        if (res.data.QueryResult === 'OK') {
          const ReturnObject = res.data.ReturnObject
          this.titleDetail = []
          this.dayList = ReturnObject.date
          this.axisLine = ReturnObject.axisLine
          ReturnObject.detailData.forEach((item) => {
            if (item.label === 'Accumulate') {
              this.mtdData = item
            } else {
              this.titleDetail.push({
                std_time: item.std_time,
                act_time: item.act_time,
                eff_MF: item.eff_MF,
                eff_ACT: item.eff_ACT,
                gap: item.Gap
              })
            }
          })
          this.rowsNumber = ReturnObject.rowsCount
          // 表格中loss数据源
          // this.lossDetail = ReturnObject.lossData
          // loss表格左侧有底色数据
          this.lossDetailLeft = ReturnObject.lossLeftData
          // loss表格右侧无底色数据
          // if (this.queryParams.showType === 'loss_time') {
          this.lossDetailRight = ReturnObject.lossRightData
          // } else {
          //   this.lossDetailRight = {}
          //   console.log('ReturnObject.lossRightData')
          //   console.log(ReturnObject.lossRightData)
          //   debugger
          //   ReturnObject.lossRightData.forEach((itemLossRight) => {
          //     const rightJson = {}
          //     itemLossRight.forEach(item => {
          //       rightJson.push({
          //         key: item.key,
          //         data: item.data + '%'
          //       })
          //     })
          //   })
          // }
          // mfg单条数据
          this.mfgDetailLeft = ReturnObject.mfgLeftData
          this.mfgDetailRight = ReturnObject.mfgRightData

          this.projectList = ReturnObject.lossEchartTitleList
          this.checkboxProjectList = []
          this.checkboxProjectList.push(this.projectList[0])
          this.echartData = ReturnObject.lossEchartList

          this.histogramData = ReturnObject.histogramData
          this.lineChartData = ReturnObject.lineChartData
          this.axisData = ReturnObject.axisData
          loading.close()
          this.$nextTick(() => {
            this.$refs['DPMFatpIssueEcharts'].setUp(this.axisLine, this.echartData, this.checkboxProjectList)
            this.$refs['DPMFatpIssueMTDEcharts'].setUp(this.axisData, this.histogramData, this.lineChartData, this.checkboxProjectList)
          })
        } else {
          loading.close()
        }
      })
    },
    getCheckedData() {
      this.$nextTick(() => {
        this.$refs['DPMFatpIssueEcharts'].setUp(this.axisLine, this.echartData, this.checkboxProjectList)
        this.$refs['DPMFatpIssueMTDEcharts'].setUp(this.axisData, this.histogramData, this.lineChartData, this.checkboxProjectList)
      })
    },
    getFactoryTypeList() {

    }
  }
}
</script>
  <style scoped lang="less">
  .app-container {
    padding: 10px;
    .table-box {
      width: 100%;
      min-height: 430px;
      overflow-x: auto;
      .historicalSummary-table {
        border-collapse: collapse;
        border: 1px solid #dcdfe6;
        min-width: 1000px;
        tr th {
          height: 30px;
          border: 1px solid #dcdfe6;
          background-color: #154479;
          color: #ffffff;
          min-width: 80px;
          font-size: 14px;
        }
        tr td {
          height: 36px;
          border: 1px solid #dcdfe6;
          min-width: 80px;
          text-align: center;
        }
        tr {
          .bg01 {
            background-color: #154479;
            color: #ffffff;
          }
          .bg02 {
            background-color: #1966aa;
          }
          .bg03 {
            background-color: #8fcbee;
          }
          .bg04 {
            background-color: #c3e5f7;
          }
          .bg05 {
            background-color: #bdd7ee;
          }
          .bg06 {
            background-color: #ddebf7;
          }
          .isEmpty {
            background-color: #dcdfe6;
          }
          .isFirstLevel{
            background-color: #154479;
            color: #ffffff;
            text-align: left;
            font-weight: bold;
            font-size: large;
          }
          .isFirstLevelNumberic{
            background-color: #154479;
            color: #ffffff;
            text-align: right;
            font-weight: bold;
            font-size: large;
          }
          .isSecondLevel{
            background-color: #1966aa;
            color: #ffffff;
            text-align: left;
            font-weight: bold;
          }
          .isFirstLevelRightNumberic{
            background-color: #154479;
            color: #ffffff;
            font-size: large;
            font-weight: bold;
          }
          .isSecondLevelRightNumberic{
            background-color: lightskyblue;
          }
          .isSecondLevelNumberic{
            background-color: #1966aa;
            color: #ffffff;
            text-align: right;
            font-weight: bold;
          }
          .isThirdLevel{
            background-color: #c3e5f7;
            text-align: right;
          }
          .noStyle{
            background-color:white;
          }
        .isRedNumberic{
            color: red;
        }
        }
      }
    }
    .el-checkbox-button{
      //border: 1px solid #DCDFE6;
      border-radius: 4px !important;
    }
  }
  </style>

