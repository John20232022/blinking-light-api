<template>
  <div style="height: 100%; width: 100%">
    <el-container style="height: 100%; width: 100%">
      <el-header style="padding: 0">
        <el-date-picker
          v-model="pickDates"
          style="margin-right: 5px; width: 280px"
          type="daterange"
          align="right"
          unlink-panels
          :picker-options="pickerOptions1"
          :start-placeholder="$t('common.phdStartDate')"
          :end-placeholder="$t('common.phdEndDate')"
          size="small"
        />
        <el-select v-model="queryScope" :placeholder="$t('common.phdStatus')" style="width: 120px; margin-right: 5px" size="small" @change="changeScopeHandler">
          <el-option :label="$t('dpmMyIssue.selAll')" value="all" />
          <el-option :label="$t('dpmMyIssue.selWaitSoulation')" value="waitsolution" />
          <el-option :label="$t('dpmMyIssue.selMyAssign')" value="myassign" />
        </el-select>
        <el-input v-model="filter" :placeholder="$t('dpmMyIssue.phdFilterLine')" prefix-icon="el-icon-search" clearable size="small" style="width: 200px; margin: 5px 5px 0 0" />
        <el-button type="primary" icon="el-icon-search" size="small" @click="queryData(true)">{{ $t('common.btnQuery') }}</el-button>
        <el-button type="primary" icon="el-icon-download" size="small" @click="downloadData()">{{ $t('common.btnDownload') }}</el-button>
      </el-header>
      <el-main style="padding: 0; height: 100%">
        <div id="tableContainer" style="height: 100%">
          <el-table v-loading="loadingDetail" :data="tableData" size="mini" :row-class-name="tableRowClassName" :height="tableHeight" style="width: 100%">
            <el-table-column prop="seq" :label="$t('common.colSeq')" width="60" />
            <el-table-column prop="status" :label="$t('common.colStatus')" width="70">
              <template slot-scope="scope">
                <!-- <span v-if="scope.row.status==='待填寫' || scope.row.status==='待確認'" @click="showKeyInSolutionDailog(scope.row)" style="cursor: pointer;">{{scope.row.status}}</span> -->
                <span v-if="scope.row.status === 'toBeFillIn'" style="cursor: pointer" @click="showDg(scope.row)">{{ $t('dpmMyIssue.selWaitSoulation') }}</span>
                <span v-else-if="scope.row.status === 'toBeConfirmed' || scope.row.status === 'toBeConfirmed2'" style="cursor: pointer" @click="showDg(scope.row)">{{ $t('dpmIssueReview.selWaitCheck') }}</span>
                <span v-else-if="scope.row.status === 'ok'" style="cursor: pointer">{{ $t('dpmMyIssue.lblPass') }}</span>
                <span v-else-if="scope.row.status === 'ng'" style="cursor: pointer">{{ $t('dpmMyIssue.lblReject') }}</span>
                <span v-else-if="scope.row.status === 'returned'" style="cursor: pointer" @click="handleCxzp(scope.row)">{{ $t('dpmMyIssue.lblReturned') }}</span>
                <span v-else-if="scope.row.status === 'toBeDistributed'" style="cursor: pointer">{{ $t('dpmMyIssue.lblToBeDistributed') }}</span>
                <span v-else>{{ scope.row.status }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="factory_code" :label="$t('common.colFactory')" width="70" align="center" />
            <el-table-column prop="work_date" :label="$t('common.colWorkDay')" width="85" align="center" />
            <el-table-column prop="shift_code" :label="$t('common.colShift')" width="60" align="center" />
            <el-table-column prop="area" :label="$t('common.colArea')" width="70" show-overflow-tooltip align="center" />
            <el-table-column prop="pdline_name" :label="$t('common.colLine')" width="90" show-overflow-tooltip align="center" />
            <el-table-column prop="stage_name" :label="$t('common.colStage')" width="70" show-overflow-tooltip align="center" />
            <!-- <el-table-column prop="start_time" :label="$t('dpmMyIssue.colRangeStart')" width="150" align="center" />
            <el-table-column prop="end_time" :label="$t('dpmMyIssue.colRangeEnd')" width="150" align="center" /> -->
            <el-table-column prop="issue_start_time" :label="$t('dpmMyIssue.colIssueStart')" width="150" align="center" />
            <el-table-column prop="issue_end_time" :label="$t('dpmMyIssue.colIssueEnd')" width="150" align="center" />
            <el-table-column prop="actual" :label="$t('common.colAct')" width="60" show-overflow-tooltip align="center" />
            <el-table-column prop="goal" :label="$t('common.colGoal')" width="60" show-overflow-tooltip align="center" />
            <el-table-column prop="gap" :label="$t('common.colLoss')" width="60" show-overflow-tooltip align="center" />
            <el-table-column prop="impact_minutes" :label="$t('dpmMyIssue.colLossTime')" width="80" align="center" />
            <el-table-column prop="impact_persons" :label="$t('dpmMyIssue.colImpactPersons')" width="110" align="center" />
            <el-table-column :label="$t('dpmMyIssue.colIssueKeyinUser')" width="140" show-overflow-tooltip align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.issue_log_user }}</span>
                <span>{{ scope.row.issue_log_user_name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="type" :label="$t('common.colType')" width="70" show-overflow-tooltip align="center" />
            <el-table-column prop="reason_code" :label="$t('dpmMyIssue.colReasonCode')" width="120" show-overflow-tooltip align="center" />
            <el-table-column prop="reason_desc" :label="$t('dpmMyIssue.colReasonDesc')" width="180" show-overflow-tooltip header-align="center" />
            <el-table-column :label="$t('common.colDRI')" width="140" show-overflow-tooltip align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.dri }}</span>
                <span>{{ scope.row.dri_name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="dri_deptid" :label="$t('common.colCostCenter')" width="90" show-overflow-tooltip align="center" />
            <el-table-column prop="dri_dept" :label="$t('common.colDRIDept')" width="120" show-overflow-tooltip header-align="center" />
            <el-table-column prop="solution" :label="$t('common.colSolution')" width="200" show-overflow-tooltip header-align="center" />
            <el-table-column prop="keyin_solution_time" :label="$t('dpmMyIssue.colKeyinTime')" width="150" align="center" />
            <el-table-column prop="memo" :label="$t('common.colMemo')" width="180" show-overflow-tooltip header-align="center" />
            <el-table-column :label="$t('dpmMyIssue.colDispatchUser')" width="140" show-overflow-tooltip align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.dispatch_user }}</span>
                <span>{{ scope.row.dispatch_user_name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="dispatch_time" :label="$t('dpmMyIssue.colDispatchTime')" width="150" align="center" />
            <el-table-column prop="check_result" :label="$t('dpmMyIssue.colCheckResult')" width="100" align="center" />
            <el-table-column :label="$t('dpmMyIssue.colCheckUser')" width="140" show-overflow-tooltip align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.check_user }}</span>
                <span>{{ scope.row.check_user_name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="check_time" :label="$t('dpmMyIssue.colCheckTime')" width="150" align="center" />
            <el-table-column v-if="false" prop="row_id" label="ROWID" width="120" align="center" />
            <el-table-column v-if="false" prop="site" label="SITE" width="120" align="center" />
          </el-table>
        </div>
      </el-main>
      <el-footer style="margin: 0 auto">
        <el-pagination :current-page="pageIndex" :page-sizes="[30, 50, 100]" :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper" :total="total" @size-change="handleSizeChange" @current-change="handleCurrentChange" />
      </el-footer>
    </el-container>

    <el-dialog :center="true" :title="$t('dpmMyIssue.lblTitleKeyinSolution')" :close-on-press-escape="false" :visible.sync="solutionDialogVisible" width="560px" :close-on-click-modal="false">
      <table class="tb" style="width: 510px">
        <tr>
          <td class="tbCategory">{{ $t('common.colLine') }}</td>
          <td class="tbCategory">{{ $t('common.colStage') }}</td>
          <td class="tbCategory">{{ $t('common.colWorkDay') }}</td>
          <td class="tbCategory">{{ $t('common.colShift') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.pdline_name }}</td>
          <td class="tbValue">{{ selectedRow.stage_name }}</td>
          <td class="tbValue">{{ selectedRow.work_date }}</td>
          <td class="tbValue">{{ selectedRow.shift_code }}</td>
        </tr>
        <tr>
          <td class="tbCategory">{{ $t('dpmMyIssue.colRangeStart') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colRangeEnd') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colIssueStart') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colIssueEnd') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.start_time }}</td>
          <td class="tbValue">{{ selectedRow.end_time }}</td>
          <td class="tbValue">{{ selectedRow.issue_start_time }}</td>
          <td class="tbValue">{{ selectedRow.issue_end_time }}</td>
        </tr>
        <tr>
          <td class="tbCategory">{{ $t('dpmMyIssue.colCategory') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colReasonCode') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colImpactTime') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colImpactOutput') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.type }}</td>
          <td class="tbValue">{{ selectedRow.reason_code }}</td>
          <td class="tbValue">{{ selectedRow.impact_minutes }}{{ $t('dpmMyIssue.colMinutes') }}</td>
          <td class="tbValue">{{ selectedRow.gap }}</td>
        </tr>
        <tr>
          <td class="tbCategory">{{ $t('dpmMyIssue.colReasonDesc') }}</td>
          <td class="tbValue" colspan="3">{{ selectedRow.reason_desc }}</td>
        </tr>
      </table>
      <el-divider />

      <div>
        <el-switch v-model="standard_reasons_switch" active-text="" inactive-text="" />
      </div>

      <el-select v-if="standard_reasons_switch" v-model="solutionContent" style="margin-top: 10px" :placeholder="$t('dpmMyIssue.phdKeyinSolution')">
        <el-option v-for="item in standard_reasons_arr" :key="item.standard_reasons_num" :label="item.standard_reasons" :value="item.standard_reasons" />
      </el-select>
      <el-input v-if="!standard_reasons_switch" v-model="solutionContent" style="margin-top: 10px" type="textarea" :rows="4" :placeholder="$t('dpmMyIssue.phdKeyinSolution')" />
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" plain @click="assignmentSubmit">{{ $t('dpmMyIssue.btnDispatchError') }}</el-button>
        <el-button size="small" type="primary" @click="saveSolution">{{ $t('common.btnSave') }}</el-button>
        <el-button size="small" @click="closeSolutionDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <!-- 20230102 Kimi Add, 增加确认解决方案弹窗 -->
    <el-dialog :center="true" :title="$t('dpmMyIssue.lblTitleCheckSolution')" :close-on-press-escape="false" top="3vh" :visible.sync="evalDialogVisible" width="560px" :close-on-click-modal="false">
      <table class="tb" style="width: 510px">
        <tr>
          <td class="tbCategory">{{ $t('common.colLine') }}</td>
          <td class="tbCategory">{{ $t('common.colStage') }}</td>
          <td class="tbCategory">{{ $t('common.colWorkDay') }}</td>
          <td class="tbCategory">{{ $t('common.colShift') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.pdline_name }}</td>
          <td class="tbValue">{{ selectedRow.stage_name }}</td>
          <td class="tbValue">{{ selectedRow.work_date }}</td>
          <td class="tbValue">{{ selectedRow.shift_code }}</td>
        </tr>
        <tr>
          <td class="tbCategory">{{ $t('dpmMyIssue.colRangeStart') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colRangeEnd') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colIssueStart') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colIssueEnd') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.start_time }}</td>
          <td class="tbValue">{{ selectedRow.end_time }}</td>
          <td class="tbValue">{{ selectedRow.issue_start_time }}</td>
          <td class="tbValue">{{ selectedRow.issue_end_time }}</td>
        </tr>
        <tr>
          <td class="tbCategory">{{ $t('dpmMyIssue.colCategory') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colReasonCode') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colImpactTime') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colImpactOutput') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.type }}</td>
          <td class="tbValue">{{ selectedRow.reason_code }}</td>
          <td class="tbValue">{{ selectedRow.impact_minutes }}{{ $t('dpmMyIssue.colMinutes') }}</td>
          <td class="tbValue">{{ selectedRow.gap }}</td>
        </tr>
      </table>
      <el-divider />
      <table class="tb" style="width: 510px">
        <tr>
          <td class="tbCategory">{{ $t('common.colDRI') }}</td>
          <td class="tbCategory">{{ $t('dpmMyIssue.colKeyinTime') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.dri }}{{ selectedRow.dri_name }}</td>
          <td class="tbValue">{{ selectedRow.keyin_solution_time }}</td>
        </tr>
      </table>
      <el-input v-model="selectedRow.solution" style="margin-top: 5px" type="textarea" :rows="4" :readonly="true" />
      <el-divider />
      <div style="text-align: center">
        <el-radio v-model="evalResult" label="OK">{{ $t('dpmMyIssue.lblPass') }}</el-radio>
        <el-radio v-model="evalResult" label="NG">{{ $t('dpmMyIssue.lblReject') }}</el-radio>
      </div>
      <el-input v-model="memo" style="margin-top: 5px" :placeholder="$t('common.colMemo')" size="small" />
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="saveEval">{{ $t('common.btnSave') }}</el-button>
        <el-button size="small" @click="closeEvalDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>
    <DialogDri ref="DialogDri" v-model="dialogVisibleCxzp" />
  </div>
</template>
<script>
import $ from 'jquery'
import { DownloadDPMMyIssue_API } from '@/api/upload_download'
import { DPMQueryMyIssue, SaveIssueSolution, SaveEvalSolution, UnassignIssueLog_API, GetMyissueStandardReason_API } from '@/api/midway.js'
import DialogDri from '@/views/components/DPMDashboardLineDetail/dialogDri'

export default {
  components: {
    DialogDri
  },
  data() {
    return {
      dialogVisibleCxzp: false,
      pickerOptions1: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      pickDates: [],
      queryScope: 'all',
      tableHeight: 1,
      tableData: [],
      loading: false,
      loadingDetail: false,
      filter: '',
      pageIndex: 1,
      pageSize: 50,
      total: 0,
      solutionDialogVisible: false,
      selectedRow: '',
      solutionContent: '',
      loadingData: null,
      evalDialogVisible: false, // 20230102 Kimi Add
      evalResult: '', // 20230102 Kimi Add
      memo: '', // 20230102 Kimi Add
      standard_reasons_switch: true,
      standard_reasons_arr: [] // 20240813 zhujunjie add
    }
  },
  mounted() {
    this.getDefaultDate()
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
    }
  },
  methods: {
    handleCxzp(obj) {
      if (obj.status === 'returned') {
        this.dialogVisibleCxzp = true
        this.$nextTick(() => {
          this.$refs['DialogDri'].init(obj.row_id)
        })
      } else {
        this.dialogVisibleCxzp = false
      }
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    tableRowClassName({ row, rowIndex }) {
      if (row.status === 'toBeFillIn') {
        return 'waitsolution-row'
      } else if (row.status === 'toBeConfirmed' || row.status === 'toBeConfirmed2') {
        return 'waitcheck-row'
      } else if (row.status === 'ok') {
        return 'ok-row'
      } else if (row.status === 'ng') {
        return 'ng-row'
      } else if (row.status === 'returned') {
        return 'returned-row'
      } else if (row.status === 'toBeDistributed') {
        return 'toBeDistributed-row'
      }
      return ''
    },
    getDefaultDate() {
      const curDate = new Date()
      this.pickDates.push(new Date(curDate.getTime() - 48 * 60 * 60 * 1000))
      this.pickDates.push(new Date(curDate))
    },
    handleSizeChange: function(val) {
      this.pageSize = val
    },
    handleCurrentChange: function(val) {
      this.pageIndex = val
      this.queryData(false)
    },
    async queryData(resetIndex) {
      if (this.pickDates.length === 0) {
        this.alertMsg(this.$t('dpmMyIssue.altMsgWorkDayEmpty'))
        return
      }
      if (resetIndex) {
        this.pageIndex = 1
      }
      const begin = this.$utils.GetDateString(this.pickDates[0])
      const end = this.$utils.GetDateString(this.pickDates[1])
      const data = {
        begin: begin,
        end: end,
        status: this.queryScope,
        filter: this.filter,
        pageIndex: this.pageIndex,
        pageSize: this.pageSize
      }
      this.loadingDetail = true
      const response = await DPMQueryMyIssue(data)
      this.loadingDetail = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.total = response.data.ReturnObject.total
        this.tableData = response.data.ReturnObject.queryData
      } else {
        alert(queryResult)
      }
    },
    downloadData: function() {
      if (this.pickDates.length === 0) {
        this.alertMsg(this.$t('dpmMyIssue.altMsgWorkDayEmpty'))
        return
      }
      const begin = this.$utils.GetDateString(this.pickDates[0])
      const end = this.$utils.GetDateString(this.pickDates[1])
      const status = encodeURIComponent(this.queryScope)
      const filter = encodeURIComponent(this.filter)
      const params = {
        begin: begin,
        end: end,
        status: status,
        filter: filter
      }
      // var url = '/midway/downloadDPMMyIssue'
      // url = url + '?begin=' + begin + '&end=' + end + '&status=' + encodeURIComponent(this.queryScope) + '&filter=' + encodeURIComponent(this.filter) + '&lang=' + this.$route.query.lang
      // this.$utils.downloadFile(url, this.$t('dpmMyIssue.lblFile'))
      DownloadDPMMyIssue_API(params, this.$t('dpmMyIssue.lblFile'))
    },
    resizeTable: function() {
      this.$nextTick(function() {
        const divHeight = $('#tableContainer').height()
        this.tableHeight = divHeight
      })
    },
    showKeyInSolutionDailog(row) {
      this.selectedRow = row
      this.solutionContent = '' // 20230102 Kimi Add，清空solution
      if (row.solution !== '') {
        this.solutionContent = row.solution
      }
      this.solutionDialogVisible = true
      GetMyissueStandardReason_API({ row_id: row.row_id }).then((res) => {
        const queryResult = res.data.QueryResult
        if (queryResult === 'OK') {
          this.standard_reasons_arr = res.data.ReturnObject
          if (this.standard_reasons_arr.length > 0) {
            this.standard_reasons_switch = true
          } else {
            this.standard_reasons_switch = false
          }
        }
      })
    },
    // 指派錯責任人
    async assignmentSubmit() {
      if (this.solutionContent === '') {
        this.alertMsg(this.$t('dpmMyIssue.altMsgKeyInSolution'))
        return
      } else if (this.solutionContent.length <= 3) {
        this.alertMsg(this.$t('dpmMyIssue.altMsgReturnMark'))
        return
      }

      this.$confirm(this.$t('dpmMyIssue.altMsgConfirmDispatchError'), this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        cancelButtonText: this.$t('common.altMsgBtnCancel'),
        type: 'warning'
      })
        .then(() => {
          const param = {
            rowId: this.selectedRow.row_id,
            returnRemark: this.solutionContent
          }
          UnassignIssueLog_API(param).then((res) => {
            const queryResult = res.data.QueryResult
            if (queryResult === 'OK') {
              this.$message({
                type: 'success',
                message: this.$t('common.altMsgOptSuccess')
              })
              this.closeSolutionDialog() // 關閉彈窗
              this.queryData(false) // 刷新數據
            } else {
              this.$message({
                type: 'warning',
                message: queryResult
              })
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: this.$t('common.altMsgCanceled')
          })
        })
    },
    async saveSolution() {
      if (this.solutionContent === '') {
        this.alertMsg(this.$t('dpmMyIssue.altMsgKeyInSolution'))
        return
      }
      if (!confirm(this.$t('dpmMyIssue.altMsgConfirmSubmitSolution'))) {
        return
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoadingSubmit'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const data = {
        rowId: this.selectedRow.row_id,
        solution: this.solutionContent
      }
      const response = await SaveIssueSolution(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.closeSolutionDialog()
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.queryData(false)
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeSolutionDialog() {
      this.solutionContent = ''
      this.solutionDialogVisible = false
    },
    changeScopeHandler() {
      this.tableData = []
    },
    // --------------------------------------------------------------------------
    // 20230102 Kimi， 将确认改到myassign下面， 取消异常问题回顾中的确认功能
    showDg(row) {
      if (row.status === 'toBeConfirmed') {
        this.showEvalDailog(row)
      } else {
        this.showKeyInSolutionDailog(row)
      }
    },
    showEvalDailog(row) {
      this.evalResult = ''
      this.memo = ''
      this.selectedRow = row
      this.evalDialogVisible = true
    },
    async saveEval() {
      if (this.evalResult === '') {
        this.alertMsg(this.$t('dpmMyIssue.altMsgCheckEmpty'))
        return
      }
      if (!confirm(this.$t('dpmMyIssue.altMsgConfirmCheck'))) {
        return
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoadingSubmit'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const data = {
        rowId: this.selectedRow.row_id,
        result: this.evalResult,
        memo: this.memo
      }
      const response = await SaveEvalSolution(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.closeEvalDialog()
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.queryData(false)
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeEvalDialog() {
      this.evalDialogVisible = false
    },
    closeResultDialog() {
      this.resultDialogVisible = false
    }
    // --------------------------------------------------------------------------
  }
}
</script>
<style lang="less" scoped>
::v-deep section {
  padding-bottom: 0;
  border: 0;
}
::v-deep .el-table .waitsolution-row {
  background: rgb(255, 255, 255);
}
::v-deep .el-table .waitcheck-row {
  background: rgb(252, 252, 173);
}
::v-deep .el-table .ok-row {
  background: rgb(127, 243, 133);
}
::v-deep .el-table .ng-row {
  background: rgb(245, 180, 191);
}
::v-deep .el-table .returned-row {
  background: rgb(255, 103, 254);
}
::v-deep .el-table .toBeDistributed-row {
  background: rgb(76, 147, 217);
}
.tb {
  margin: 0 auto;
  border: 1px solid #cccccc;
  border-collapse: collapse;
  margin-bottom: 10px;
  width: 100%;
  table-layout: fixed;
}
.tbTitle {
  width: 100%;
  padding: 10px 10px;
  font-size: 14px;
  font-weight: 600;
  border-bottom: 1px solid #cccccc;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  word-wrap: break-word;
}
.tbCategory {
  height: 30px;
  font-size: 12px;
  text-align: center;
  background-color: #f4f4f4;
  border-bottom: 1px solid #cccccc;
  border-right: 1px solid #cccccc;
}
.tbValue {
  height: 30px;
  font-size: 12px;
  text-align: center;
  border-bottom: 1px solid #cccccc;
  border-right: 1px solid #cccccc;
}
</style>
