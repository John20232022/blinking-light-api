<template>
  <div class="header-bg">
    <div class="header-logo">
      <img src="@/assets/images/logo.png">
    </div>
    <h2>PCBA Quality Dashboard</h2>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.header-bg {
  width: calc(100%);
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  margin: 0 0 0 0;
  padding: 2px 0;
  border-radius: 10px;
  position: relative;
  background: linear-gradient(to right, #00b0b9 30%, #0075b9 100%);
  height: 70px;
  h2 {
    margin: 0;
    padding: 0;
    font-size: 28px;
    text-align: center;
    line-height: 70px;
    height: 70px;
    letter-spacing: 0px;
    font-weight: bold;
    background: rgba(255, 255, 255, 0.9) -webkit-linear-gradient(-15deg, #409eff 5%, rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0.5), #ffffff 10%) no-repeat;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    -webkit-animation: cliptext 5s linear infinite;
  }
  @keyframes cliptext {
    0% {
      background-position: left 0;
    }
    100% {
      background-position: 1200px 0;
    }
  }
}
.header-logo {
  position: absolute;
  width: 150px;
  left: 20px;
  top: 52%;
  transform: translateY(-50%);
  z-index: 100;
  img {
    width: 100%;
  }
}
</style>
