<template>
  <div>
    <div ref="chart" :class="className" :style="{ width, height }" />
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
  name: 'Left03',
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '248px'
    }
  },
  data() {
    return {
      chart: null
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.chart = echarts.init(this.$refs.chart)
    })
  },
  methods: {
    setUp(OAIL_DataList) {
      const xData = []
      const seriesData = []
      let markLineNum
      OAIL_DataList.forEach((item) => {
        markLineNum = item.GOAL
        xData.push(item.PDLINE_NAME)
        const params = {
          value: Number(item.RESULT.toFixed(2)),
          itemStyle: {
            color: item.RESULT < markLineNum ? '#67C23A' : '#5470C6'
          }
        }
        seriesData.push(params)
      })
      seriesData.forEach((item) => {
        if (item.value > markLineNum) {
          markLineNum = item.value
        }
      })
      this.resetOption(xData, seriesData, markLineNum)
    },
    resetOption(xData, seriesData, markLineNum) {
      const colorArr = ['#5470C6', '#91CC75', '#FAC858', '#EE6666', '#73C0DE', '#3BA272', '#FC8452', '#9A60B4']
      const option = {
        color: colorArr,
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        toolbox: {
          show: true
        },
        grid: {
          left: '5px',
          top: '30px',
          right: '5px',
          bottom: '0',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: xData,
          boundaryGap: true,
          axisLine: {
            show: true,
            margin: 0
          },
          axisTick: {
            show: true
          },
          axisLabel: {
            interval: 0,
            show: true,
            fontSize: 16
          }
        },
        yAxis: {
          type: 'value',
          max: markLineNum,
          axisLabel: {
            show: true,
            fontSize: 16
          },
          axisTick: {
            show: true
          },
          axisLine: {
            show: true
          },
          splitLine: {
            show: false
          }
        },
        series: {
          data: seriesData,
          type: 'bar',
          barWidth: '26',
          label: {
            show: true,
            position: 'top',
            fontSize: 16
          },
          markLine: {
            silent: true,
            label: {
              position: 'middle',
              padding: [0, 0, 0, 80],
              color: '#67C23A',
              fontSize: 16
            },
            lineStyle: {
              color: '#67C23A'
            },
            data: [
              {
                yAxis: markLineNum
              }
            ]
          }
        }
      }
      this.chart.setOption(option)
    }
  }
}
</script>

<style scoped lang="scss">
</style>
