<template>
  <div class="right01 flex justify-around items-center">
    <div v-for="(item, index) in list" :key="index" class="right01-box">
      <Right01Echarts :set-data="item.data" />
      <span class="name">{{ item.PDLINE_NAME }}</span>
    </div>
  </div>
</template>

<script>
import Right01Echarts from '@/views/MIDWAY/pcbaDashboard/right01_echarts'
export default {
  name: 'Right01',
  components: {
    Right01Echarts
  },
  data() {
    return {
      list: []
    }
  },

  methods: {
    setUp(arr) {
      this.list = arr
    }
  }
}
</script>

<style scoped lang="scss">
.right01 {
  min-height: 240px;
  overflow-x: auto;
  .right01-box {
    min-width: 350px;
    .name {
      display: block;
      text-align: center;
      margin: 0 auto 5px;
      font-size: 16px;
      color: #6e7079;
    }
  }
  .right01-box:last-child {
    border-bottom: 0;
  }
}
</style>
