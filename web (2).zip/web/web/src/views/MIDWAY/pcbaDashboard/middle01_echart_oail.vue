<template>
  <div class="middle01_echart_rty">
    <div ref="chart" :class="className" :style="{ width, height }" />
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
  name: 'Middle01EchartOail',
  props: {
    item: {
      type: Object,
      default: () => {
        return {}
      }
    },
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '200px'
    },
    height: {
      type: String,
      default: '248px'
    }
  },
  data() {
    return {
      chart: null
    }
  },
  watch: {
    item: {
      handler(newValue, oldValue) {
        setTimeout(() => {
          this.initChart(newValue)
        }, 1000)
      },
      immediate: true, // 默认是false，watch在首次绑定amount时，是否立即执行handler函数
      deep: true // 默认是false，在监听对象变化时，一般情况下无法监听对象内部属性的变化。deep属性为true时，可以对对象深度监听
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.chart = echarts.init(this.$refs.chart)
    })
  },
  methods: {
    initChart(newValue) {
      const xData = ['OAIL']
      const markLineNum = newValue.GOAL
      const params = {
        value: Number(newValue.RESULT.toFixed(2)),
        itemStyle: {
          color: newValue.RESULT < markLineNum ? '#67C23A' : '#5470C6'
        }
      }
      const seriesData = [params]

      this.resetOption(xData, seriesData, markLineNum)
      // this.resetOption()
    },
    resetOption(xData, seriesData, markLineNum) {
      const colorArr = ['#5470C6', '#91CC75', '#FAC858', '#EE6666', '#73C0DE', '#3BA272', '#FC8452', '#9A60B4']
      const option = {
        color: colorArr,
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        toolbox: {
          show: true
        },
        grid: {
          left: '5px',
          top: '20px',
          right: '50px',
          bottom: '0',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: xData,
          boundaryGap: true,
          axisLine: {
            show: true,
            margin: 0
          },
          axisTick: {
            show: true
          },
          axisLabel: {
            interval: 0,
            show: true,
            fontSize: 16
          }
        },
        yAxis: {
          type: 'value',
          max: markLineNum,
          axisLabel: {
            show: true,
            fontSize: 16
          },
          axisTick: {
            show: true
          },
          axisLine: {
            show: true
          },
          splitLine: {
            show: false
          }
        },
        series: {
          data: seriesData,
          type: 'bar',
          barWidth: '26',
          label: {
            show: true,
            position: 'top',
            fontSize: 16
          },
          markLine: {
            silent: true,
            label: {
              fontSize: 16
            },
            lineStyle: {
              color: '#67C23A'
            },
            data: [
              {
                yAxis: markLineNum
              }
            ]
          }
        }
      }
      this.chart.setOption(option)
    }
  }
}
</script>

<style scoped lang="scss">
</style>
