<template>
  <div class="left02 flex items-center">
    <div v-for="(item, index) in NDF_DataList" :key="index" class="number-name">
      <span class="number" :class="'status' + item.status">{{ item.RESULT }}%</span>
      <span class="name">{{ item.PDLINE_NAME }}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BarEcharts',
  data() {
    return {
      NDF_DataList: []
    }
  },
  methods: {
    setUp(NDF_DataList) {
      const arr = NDF_DataList
      arr.forEach((item) => {
        item.RESULT = Number(item.RESULT.toFixed(2))
        if (item.RESULT < 1) {
          item.status = 1
        }
        if (item.RESULT >= 1 && item.RESULT <= 2) {
          item.status = 2
        }
        if (item.RESULT > 2) {
          item.status = 3
        }
      })
      this.NDF_DataList = arr
    }
  }
}
</script>

<style scoped lang="scss">
.left02 {
  flex-wrap: wrap;
  min-height: 208px;
  .number-name {
    min-width: 150px;
    .number {
      text-align: center;
      width: 90px;

      height: 90px;
      line-height: 90px;
      border-radius: 90px;
      color: #ffffff;
      background-color: #73c0de;
      display: block;
      font-size: 20px;
      margin: 0 auto;
    }
    .number.status1 {
      background-color: #73c0de;
    }
    .number.status2 {
      background-color: #fac858;
    }
    .number.status3 {
      background-color: #fc8452;
    }
    .name {
      text-align: center;
      font-size: 16px;
      display: block;
      margin: 8px auto;
      color: #6E7079;
    }
  }
}
</style>
