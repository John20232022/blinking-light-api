<template>
  <div>
    <div ref="chart" :class="className" :style="{ width, height }" />
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
  name: 'BarEcharts',
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '248px'
    }
  },
  data() {
    return {
      chart: null
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.chart = echarts.init(this.$refs.chart)
    })
  },
  methods: {
    setUp(RTY_DataList) {
      const xData = []
      const seriesData = []
      let markLineNum
      RTY_DataList.forEach((item) => {
        xData.push(item.PDLINE_NAME)
        markLineNum = Number((item.GOAL * 100).toFixed(2))
        console.log()
        const params = {
          value: Number((item.RESULT * 100).toFixed(2)),
          itemStyle: {
            color: Number((item.RESULT * 100)) > markLineNum ? '#67C23A' : '#5470C6'
          }
        }
        seriesData.push(params)
      })
      this.resetOption(xData, seriesData, markLineNum)
    },
    resetOption(xData, seriesData, markLineNum) {
      const colorArr = ['#5470C6', '#91CC75', '#FAC858', '#EE6666', '#73C0DE', '#3BA272', '#FC8452', '#9A60B4']
      const option = {
        color: colorArr,
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        toolbox: {
          show: true
        },
        grid: {
          left: '5px',
          top: '30px',
          right: '5px',
          bottom: '0',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: xData,
          boundaryGap: true,
          axisLine: {
            show: true,
            margin: 0
          },
          axisTick: {
            show: true
          },
          axisLabel: {
            interval: 0,
            show: true,
            fontSize: 16
          }
        },
        yAxis: {
          type: 'value',
          axisLabel: {
            show: true,
            formatter: '{value} %',
            fontSize: 16
          },
          axisTick: {
            show: true
          },
          axisLine: {
            show: true
          },
          splitLine: {
            show: false
          }
        },
        series: {
          data: seriesData,
          type: 'bar',
          barWidth: '26',
          label: {
            show: true,
            position: 'top',
            fontSize: 16,
            formatter: (params) => {
              return params.value + '%'
            }
          },
          tooltip: {
            valueFormatter: (value) => {
              return value + '%'
            }
          },
          markLine: {
            silent: true,
            label: {
              position: 'middle',
              padding: [0, 0, 0, 100],
              color: '#67C23A',
              fontSize: 16,
              formatter: (params) => {
                return params.value + '%'
              }
            },
            lineStyle: {
              color: '#67C23A'
            },
            data: [
              {
                yAxis: markLineNum
              }
            ]
          }
        }
      }
      this.chart.setOption(option)
    }
  }
}
</script>

<style scoped lang="scss">
</style>
