<template>
  <FullScreenSolt>
    <div class="app-container">
      <HeaderTop />

      <div v-if="isShow" class="main-content">
        <el-row :gutter="10">
          <el-col :span="12">
            <el-card class="card-box">
              <div slot="header">
                <div class="card-title">KPI</div>
              </div>
              <div class="card-content">
                <Middle01 ref="Middle01" />
              </div>
            </el-card>

            <el-card class="card-box">
              <div slot="header">
                <div class="card-title">NDF Rate</div>
              </div>
              <div class="card-content">
                <Left02 ref="Left02" />
              </div>
            </el-card>
            <el-card class="card-box">
              <div slot="header">
                <div class="card-title">OAIL</div>
              </div>
              <div class="card-content">
                <Left03 ref="Left03" />
              </div>
            </el-card>
          </el-col>
          <el-col :span="12">
            <el-card class="card-box">
              <div slot="header">
                <div class="card-title">RTY</div>
              </div>
              <div class="card-content">
                <Left01 ref="Left01" />
              </div>
            </el-card>
            <el-card class="card-box">
              <div slot="header">
                <div class="card-title">Total 不良柏拉图</div>
              </div>
              <div class="card-content">
                <Middle02 ref="Middle02" />
              </div>
            </el-card>
            <el-card class="card-box">
              <div slot="header">
                <div class="card-title">A9-SMT</div>
              </div>
              <div class="card-content">
                <Right01 ref="Right01" />
              </div>
            </el-card>
          </el-col>
        </el-row>
      </div>
    </div>
  </FullScreenSolt>
</template>

<script>
import { GetPCBAQRADashboard_API } from '@/api/midway'
import FullScreenSolt from '@/components/FullScreenSolt/index'
import moment from 'moment'
import HeaderTop from '@/views/MIDWAY/pcbaDashboard/headerTop'
import Left01 from '@/views/MIDWAY/pcbaDashboard/left01'
import Left02 from '@/views/MIDWAY/pcbaDashboard/left02'
import Left03 from '@/views/MIDWAY/pcbaDashboard/left03'
import Middle01 from '@/views/MIDWAY/pcbaDashboard/middle01'
import Middle02 from '@/views/MIDWAY/pcbaDashboard/middle02'
import Right01 from '@/views/MIDWAY/pcbaDashboard/right01'
export default {
  name: 'PcbaDashboard',
  components: {
    FullScreenSolt,
    HeaderTop,
    Left01,
    Left02,
    Left03,
    Middle01,
    Middle02,
    Right01
  },
  data() {
    return {
      isShow: true,
      timerId: null,
      RTY_DataList: [],
      NDF_DataList: [],
      OAIL_DataList: [],
      ReturnObject: {
        lineKPIData: [],
        opuKPIData: [],
        lineDefectChartData: [],
        opuDefectChartData: []
      }
    }
  },
  created() {
    this.getData()
  },
  mounted() {
    this.timerId = setInterval(() => {
      this.isShow = false
      setTimeout(() => {
        this.isShow = true
      }, 1000)
      this.getData()
    }, 300000)
  },
  beforeDestroy() {
    clearTimeout(this.timerId)
  },
  methods: {
    getData() {
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      var currentDateTime = moment().format('YYYYMMDD')
      const params = {
        workdate: currentDateTime,
        opu: 'A9'
      }
      GetPCBAQRADashboard_API(params).then((res) => {
        if (res.data.QueryResult === 'OK') {
          this.ReturnObject = res.data.ReturnObject
          this.initData()
          loading.close()
        } else {
          loading.close()
        }
      })
    },
    initData() {
      const RTY_DataList = []
      const NDF_DataList = []
      const OAIL_DataList = []
      this.ReturnObject.lineKPIData.forEach((item) => {
        if (item.KPI === 'RTY') {
          RTY_DataList.push(item)
        }
        if (item.KPI === 'NDF') {
          NDF_DataList.push(item)
        }
        if (item.KPI === 'OAIL') {
          OAIL_DataList.push(item)
        }
      })
      const opuKPIData = this.ReturnObject.opuKPIData
      const opuDefectChartData = this.ReturnObject.opuDefectChartData
      const lineDefectChartData = this.ReturnObject.lineDefectChartData
      const newArr = this.filterArr(lineDefectChartData)
      this.$nextTick(() => {
        setTimeout(() => {
          this.$refs['Left01'].setUp(RTY_DataList)
          this.$refs['Left02'].setUp(NDF_DataList)
          this.$refs['Left03'].setUp(OAIL_DataList)

          this.$refs['Middle01'].setUp(opuKPIData)
          this.$refs['Middle02'].setUp(opuDefectChartData)
          this.$refs['Right01'].setUp(newArr)
        }, 1000)
      })
    },
    filterArr(lineDefectChartData) {
      const PDLINE_NAME_ARR = lineDefectChartData.map((item) => item.PDLINE_NAME)
      const arr = Array.from(new Set(PDLINE_NAME_ARR))
      const newArr = []
      arr.forEach((item) => {
        const params = {
          PDLINE_NAME: item,
          data: []
        }
        newArr.push(params)
      })
      newArr.forEach((item01) => {
        lineDefectChartData.forEach((item02) => {
          if (item01.PDLINE_NAME === item02.PDLINE_NAME) {
            item01.data.push(item02)
          }
        })
      })
      return newArr
    }
  }
}
</script>

<style lang="scss" scoped>
.app-container {
  padding: 10px 10px 0 10px;
  color: #606266;
  overflow: hidden;
  width: 1920px;
  height: 1080px;
  .main-content {
    .card-box {
      margin-top: 10px;
      .card-title {
        font-size: 20px;
        line-height: 24px;
      }
    }
    ::v-deep .el-card__header {
      padding: 10px 20px;
    }
    ::v-deep .el-card__body {
      min-height: 272px;
      min-width: 620px;
      padding: 10px 4px;
    }
  }
}
</style>
