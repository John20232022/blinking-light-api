<template>
  <div class="middle01 flex justify-around items-center">
    <div v-for="(item, index) in opuKPIData" :key="index" class="number-name">
      <Middle01EchartRty v-if="item.KPI === 'RTY'" :item="item" />

      <Middle01EchartNdf v-if="item.KPI === 'NDF'" :item="item" />

      <Middle01EchartOail v-if="item.KPI === 'OAIL'" :item="item" />
    </div>
  </div>
</template>

<script>
import Middle01EchartRty from '@/views/MIDWAY/pcbaDashboard/middle01_echart_rty'
import Middle01EchartNdf from '@/views/MIDWAY/pcbaDashboard/middle01_echart_ndf'
import Middle01EchartOail from '@/views/MIDWAY/pcbaDashboard/middle01_echart_oail'
export default {
  name: 'Middle01',
  components: {
    Middle01EchartRty,
    Middle01EchartNdf,
    Middle01EchartOail
  },
  data() {
    return {
      opuKPIData: []
    }
  },
  methods: {
    setUp(opuKPIData) {
      this.opuKPIData = opuKPIData
    }
  }
}
</script>

<style scoped lang="scss">
.middle01 {
  min-height: 168px;
  .number-name {
    .name {
      display: block;
      margin: 0 auto;
      text-align: center;
    }
  }
}
</style>
