<template>
  <div class="middle01_echart_ndf">
    <span class="number" :class="'status' + obj.status">{{ obj.RESULT.toFixed(2) }}%</span>
    <span class="name">{{ obj.KPI }}</span>
  </div>
</template>

<script>
export default {
  name: 'Middle01EchartNdf',
  props: {
    item: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  data() {
    return {
      obj: null
    }
  },
  watch: {
    item: {
      handler(newValue, oldValue) {
        const obj = newValue
        if (obj.RESULT < 1) {
          obj.status = 1
        }
        if (obj.RESULT >= 1 && obj.RESULT <= 2) {
          obj.status = 2
        }
        if (obj.RESULT > 2) {
          obj.status = 3
        }
        this.obj = obj
      },
      immediate: true, // 默认是false，watch在首次绑定amount时，是否立即执行handler函数
      deep: true // 默认是false，在监听对象变化时，一般情况下无法监听对象内部属性的变化。deep属性为true时，可以对对象深度监听
    }
  }
}
</script>

<style scoped lang="scss">
.middle01_echart_ndf {
  padding: 18px 0 0 0 ;
  .number {
    width: 150px;
    text-align: center;
    height: 150px;
    line-height: 150px;
    border-radius: 150px;
    color: #ffffff;
    background-color: #73c0de;
    display: block;
    font-size: 20px;
  }
  .number.status1 {
    background-color: #73c0de;
  }
  .number.status2 {
    background-color: #fac858;
  }
  .number.status3 {
    background-color: #fc8452;
  }
  .name {
    text-align: center;
    font-size: 16px;
    display: block;
    margin: 50px auto 0;
    color: #6e7079;
  }
}
</style>
