<template>
  <div>
    <div ref="chart" :class="className" :style="{ width, height }" />
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
  name: 'Middle02',
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '248px'
    }
  },
  data() {
    return {
      chart: null
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.chart = echarts.init(this.$refs.chart)
    })
  },
  methods: {
    sum(arr) {
      return arr.reduce((prev, curr) => {
        return prev + curr
      })
    },
    setUp(opuDefectChartData) {
      const xData = []
      const seriesData = []

      opuDefectChartData.forEach((item, index) => {
        xData.push(item.DEFECT_DESC)
        seriesData.push(item.NUM)
      })

      const total = this.sum(seriesData)
      const perData = []
      let Cumulative = 0
      seriesData.forEach((item) => {
        Cumulative += item
        perData.push(Number(((Cumulative / total) * 100).toFixed(2)))
      })

      const colorArr = ['#001d66', '#002c8c', '#003eb3', '#0958d9', '#1677ff', '#4096ff', '#69b1ff', '#91caff', '#bae0ff', '#e6f4ff']
      const newSeriesData = []
      seriesData.forEach((item, index) => {
        newSeriesData.push({
          value: item,
          itemStyle: { color: colorArr[index] }
        })
      })
      this.resetOption(xData, newSeriesData, perData)
    },
    resetOption(xData, seriesData, perData) {
      // const colorArr = ['#5470C6', '#91CC75', '#FAC858', '#EE6666', '#73C0DE', '#3BA272', '#FC8452', '#9A60B4']
      const option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        legend: {},
        toolbox: {
          show: true
        },
        grid: {
          left: '5px',
          top: '50px',
          right: '5px',
          bottom: '0',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: xData,
          boundaryGap: true,
          axisLine: {
            show: true,
            margin: 0
          },
          axisTick: {
            show: true
          },
          axisLabel: {
            interval: 0,
            show: true,
            fontSize: 16
          }
        },
        yAxis: [
          {
            type: 'value',
            axisLabel: {
              show: true,
              fontSize: 16
            },
            axisTick: {
              show: true
            },
            axisLine: {
              show: true
            },
            splitLine: {
              show: false
            }
          },
          {
            type: 'value',
            axisLabel: {
              show: true,
              formatter: '{value} %',
              fontSize: 16
            },
            axisTick: {
              show: true
            },
            axisLine: {
              show: true
            },
            splitLine: {
              show: false
            }
          }
        ],
        series: [
          {
            data: seriesData,
            type: 'bar',
            barWidth: '26',
            label: {
              show: true,
              position: 'top',
              fontSize: 16
            }
          },
          {
            data: perData,
            type: 'line',
            yAxisIndex: 1,
            label: {
              show: true,
              position: 'top',
              fontSize: 16,
              formatter: (params) => {
                return params.value + '%'
              }
            },
            tooltip: {
              valueFormatter: (value) => {
                return value + '%'
              }
            }
          }
        ]
      }
      this.chart.setOption(option)
    }
  }
}
</script>

<style scoped lang="scss">
</style>
