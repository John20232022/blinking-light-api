<template>
  <div>
    <div ref="chart" :class="className" :style="{ width, height }" />
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
  name: 'BarEcharts',
  props: {
    setData: {
      type: Array,
      default: () => {
        return []
      }
    },
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '150px'
    }
  },
  data() {
    return {
      chart: null
    }
  },
  watch: {
    setData: {
      handler(newValue, oldValue) {
        this.setUp(newValue)
      },
      immediate: true, // 默认是false，watch在首次绑定amount时，是否立即执行handler函数
      deep: true // 默认是false，在监听对象变化时，一般情况下无法监听对象内部属性的变化。deep属性为true时，可以对对象深度监听
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.chart = echarts.init(this.$refs.chart)
    })
  },
  methods: {
    setUp(arr) {
      const data = []
      arr.forEach(item => {
        data.push({
          value: item.NUM,
          name: item.DEFECT_DESC
        })
      })
      setTimeout(() => {
        this.resetOption(data)
      }, 1000)
    },
    resetOption(data) {
      const option = {
        tooltip: {
          trigger: 'item'
        },
        series: [
          {
            name: 'A9-SMT',
            type: 'pie',
            // radius: '30%',
            data: data,
            roseType: 'area',
            label: {
              fontSize: 16,
              color: '#6E7079'
            },
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      }
      this.chart.setOption(option)
    }
  }
}
</script>

<style scoped lang="scss">
</style>
