<template>
  <div style="height:100%;width:100%">
    <el-container style="height:100%">
      <el-header style="padding:0;height:40px">
        <el-select v-model="queryFactory" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectFactory')" @change="getQueryAreaList">
          <el-option
            v-for="item in factoryList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryArea" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectArea')" @change="getQueryteamList">
          <el-option
            v-for="item in areaList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryTeam" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectTeam')" @change="flag=false">
          <el-option
            v-for="item in teamList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-date-picker v-model="queryMonth" size="small" style="width:120px;margin-right:5px" type="month" :placeholder="$t('dpmTeamKPIhis.phdMonth')" @change="flag=false" />
        <el-select v-model="queryShift" placeholder="班別" style="width:100px;margin-right:5px" size="small" @change="flag=false">
          <el-option
            v-for="item in workshiftList"
            :key="item.shift_code"
            :label="item.shift_name"
            :value="item.shift_code"
          />
          <!-- <el-option label="ALL" value="ALL" />
          <el-option :label="$t('common.lblShiftD')" value="D" />
          <el-option :label="$t('common.lblShiftM')" value="M" />
          <el-option :label="$t('common.lblShiftN')" value="N" /> -->
        </el-select>
        <el-select v-model="queryKpi" size="small" class="selectMidSize" placeholder="KPI" @change="flag=false">
          <el-option
            v-for="item in kpiList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-button type="primary" icon="el-icon-search" size="small" @click="queryKPIHisData(true)">{{ $t('common.btnQuery') }}</el-button>
        <el-button type="primary" icon="el-icon-download" size="small" @click="downloadData()">{{ $t('common.btnDownload') }}</el-button>
      </el-header>
      <el-main style="padding:0;height:1px">
        <div id="tableContainer" style="height:100%;">
          <!-- <modupph v-if="queryKpi==='UPPH' && flag" :onedata=sendtooperate></modupph>
            <modeff v-if="queryKpi==='EFF' && flag" :onedata=sendtooperate></modeff>
            <moduph v-if="queryKpi==='UPH' && flag" :onedata=sendtooperate></moduph>
            <moduts v-if="queryKpi==='UTS' && flag" :onedata=sendtooperate></moduts>
            <modndf v-if="queryKpi==='NDF' && flag" :onedata=sendtooperate></modndf>
            <modoatl v-if="queryKpi==='OATL' && flag" :onedata=sendtooperate></modoatl>
            <modoail v-if="queryKpi==='OAIL' && flag" :onedata=sendtooperate></modoail>
            <modlrr v-if="queryKpi==='LRR' && flag" :onedata=sendtooperate></modlrr> -->
          <modupph v-if="getModShowStatus('UPPH')" :onedata="sendtooperate" />
          <modeff v-if="getModShowStatus('EFF')" :onedata="sendtooperate" />
          <moduph v-if="getModShowStatus('UPH')" :onedata="sendtooperate" />
          <moduts v-if="getModShowStatus('UTS')" :onedata="sendtooperate" />
          <modndf v-if="getModShowStatus('NDF')" :onedata="sendtooperate" />
          <modoatl v-if="getModShowStatus('OATL')" :onedata="sendtooperate" />
          <modoail v-if="getModShowStatus('OAIL')" :onedata="sendtooperate" />
          <modlrr v-if="getModShowStatus('LRR')" :onedata="sendtooperate" />
        </div>
      </el-main>
    </el-container>
  </div>
</template>
<script>
// import $ from 'jquery'
import { downloadDPMTeamKPIHistoryData_API } from '@/api/upload_download'
import {
  GetDPMQueryKeyValue, GetWorkshiftList
} from '@/api/midway.js'
import modupph from '@/components/MIDWAY/DPMTeamKPI_UPPHMod.vue'
import modeff from '@/components/MIDWAY/DPMTeamKPI_EFFMod.vue'
import moduph from '@/components/MIDWAY/DPMTeamKPI_UPHMod.vue'
import moduts from '@/components/MIDWAY/DPMTeamKPI_UTSMod.vue'
import modndf from '@/components/MIDWAY/DPMTeamKPI_NDFMod.vue'
import modoatl from '@/components/MIDWAY/DPMTeamKPI_OATLMod.vue'
import modoail from '@/components/MIDWAY/DPMTeamKPI_OAILMod.vue'
import modlrr from '@/components/MIDWAY/DPMTeamKPI_LRRMod.vue'
export default {
  components: {
    modupph,
    modeff,
    moduph,
    moduts,
    modndf,
    modoatl,
    modoail,
    modlrr
  },
  data() {
    return {
      sendtooperate: {
        from: 'history',
        factory: '',
        area: '',
        team: '',
        yearMonth: '',
        shift: '',
        kpi: ''
      },
      loading: false,
      loadingData: null,
      queryFactory: '',
      factoryList: [],
      queryArea: '',
      areaList: [],
      kpiList: [],
      queryTeam: '',
      queryMonth: '',
      queryKpi: '',
      queryShift: 'ALL',
      workshiftList: [],
      teamList: [],
      flag: false
    }
  },
  mounted() {
    this.getDefaultDate()
    this.getQueryFactoryList()
  },
  methods: {
    async getWorkDayWorkshift() {
      this.workshiftList = []
      const data = {
        factory: this.factoryList.filter(x => x.key === this.queryFactory)[0].data,
        hasALL: 'Y'
      }
      const response = await GetWorkshiftList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.workshiftList = response.data.ReturnObject
      } else {
        this.alertMsg(
          this.$utils.ReplacePlaceHolder(
            this.$t('dpmDashboardLineDetail.altMsgCannotGetShift'),
            [queryResult]
          )
        )
      }
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    getDefaultDate() {
      const curDate = new Date()
      this.queryMonth = curDate
    },
    getModShowStatus(kpi) {
      if (this.flag === false) {
        return false
      }
      return this.queryKpi === kpi
    },
    async getQueryFactoryList() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.factoryList = []
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.factoryList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryAreaList() {
      this.getWorkDayWorkshift()
      this.flag = false
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = ''
      const data = {
        type: 'userarea',
        key: this.queryFactory
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject
        this.getKpiList()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getKpiList() {
      this.flag = false
      this.kpiList = []
      this.queryKpi = ''
      const data = {
        type: 'kpi',
        key: this.queryFactory
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.kpiList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryteamList() {
      this.flag = false
      this.teamList = []
      this.queryTeam = ''
      const data = {
        type: 'userteam',
        key: this.queryArea
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        response.data.ReturnObject.forEach(d => {
          this.teamList.push(d)
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    async queryKPIHisData() {
      if (this.queryFactory === '') {
        this.alertMsg(this.$t('dpmTeamKPIhis.altMsgFactoryEmpty'))
        return
      }
      if (this.queryArea === '') {
        this.alertMsg(this.$t('dpmTeamKPIhis.altMsgAreaEmpty'))
        return
      }
      if (this.queryTeam === '') {
        this.alertMsg(this.$t('dpmTeamKPIhis.altMsgTeamEmpty'))
        return
      }
      if (this.queryShift === '') {
        this.alertMsg(this.$t('dpmTeamKPIhis.altMsgShiftEmpty'))
        return
      }
      if (this.queryKpi === '') {
        this.alertMsg(this.$t('dpmTeamKPIhis.altMsgKPIEmpty'))
        return
      }

      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      const yM = this.$utils.GetDateString(this.queryMonth)
      // 移除组件，重新加载渲染，触发查询事件
      this.flag = false
      this.sendtooperate.factory = ''
      this.sendtooperate.area = ''
      this.sendtooperate.team = ''
      this.sendtooperate.yearMonth = ''
      this.sendtooperate.shift = ''
      this.sendtooperate.kpi = ''
      const that = this
      setTimeout(function() {
        that.sendtooperate.factory = factory
        that.sendtooperate.area = area
        that.sendtooperate.team = team
        that.sendtooperate.yearMonth = yM.substr(0, 7)
        that.sendtooperate.shift = that.queryShift
        that.sendtooperate.kpi = that.queryKpi
        that.flag = true
      }, 100)
    },
    downloadData: function() {
      if (this.queryFactory === '') {
        this.alertMsg(this.$t('dpmTeamKPIhis.altMsgFactoryEmpty'))
        return
      }
      if (this.queryArea === '') {
        this.alertMsg(this.$t('dpmTeamKPIhis.altMsgAreaEmpty'))
        return
      }
      if (this.queryTeam === '') {
        this.alertMsg(this.$t('dpmTeamKPIhis.altMsgTeamEmpty'))
        return
      }
      if (this.queryShift === '') {
        this.alertMsg(this.$t('dpmTeamKPIhis.altMsgShiftEmpty'))
        return
      }
      if (this.queryKpi === '') {
        this.alertMsg(this.$t('dpmTeamKPIhis.altMsgKPIEmpty'))
        return
      }

      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      let yM = this.$utils.GetDateString(this.queryMonth)
      yM = yM.substr(0, 7)

      const params = {
        factory: factory,
        area: area,
        team: team,
        yearMonth: encodeURIComponent(yM),
        shift: this.queryShift,
        kpi: encodeURIComponent(this.queryKpi)
      }
      const fileName = factory + '_' + area + '_' + team + '_' + this.queryKpi + '(' + yM + ').xlsx'
      downloadDPMTeamKPIHistoryData_API(params, fileName)

    //   var url = '/midway/downloadDPMTeamKPIHistoryData'
    //   url = url + '?factory=' + encodeURIComponent(factory) + '&area=' + encodeURIComponent(area) +
    // '&team=' + encodeURIComponent(team) + '&yearMonth=' + encodeURIComponent(yM) +
    // '&shift=' + this.queryShift + '&kpi=' + encodeURIComponent(this.queryKpi)
    //   this.$utils.downloadFile(url, fileName)
    }
  }
}
</script>
<style lang="less" scoped>
.selectMidSize{
width:120px;
margin-right:5px;
}
.startDiv{
  position: absolute;
  left:50%;
  top:50%;
  transform: translate(-50%, -50%);
}
.contentDiv{
margin:0 auto;
}
.wizardDailogInfoTitle{
font-size:24px;
color: rgb(0, 122, 204);
display: block;
}
::v-deep section {
padding: 0;
}
::v-deep .el-table .ok-row {
background: rgb(190, 242, 125);
}
::v-deep .el-table .warning-row {
  background: lightyellow;
}
::v-deep .el-table .error-row {
  background: rgb(252, 210, 217);
}
.authdiv{
width:100%;
height:300px;
display: flex;
}
.authTypeDiv{
width: 300px;
height: 100%;
}
.authTreeDiv{
width:500px;
height: 100%;
overflow-y: scroll;
}
.rbCard{
width: 200px;
}
.authTableDiv{
width: 600px;
height: 100%;
}
</style>
