<template>
  <div style="height:100%;width:100%">
    <el-container style="height:100%">
      <el-header style="padding:0">
        <el-select v-model="queryFactory" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectFactory')" @change="getQueryAreaList">
          <el-option
            v-for="item in factoryList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryArea" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectArea')" @change="getQueryLineList">
          <el-option
            v-for="item in areaList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryLine" size="small" class="selectMidSize" style="width:180px" :placeholder="$t('common.phdSelectLine')" multiple collapse-tags>
          <el-option
            v-for="item in lineList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-input
          v-model="queryEmployeeId"
          :placeholder="$t('dpmAuthority.phdKeyinEmpId')"
          prefix-icon="el-icon-search"
          clearable
          size="small"
          style="width:130px;margin-right:5px"
        />
        <el-button type="primary" icon="el-icon-search" size="small" @click="queryUserAuthority(true)">{{ $t('common.btnQuery') }}</el-button>
        <el-button type="success" icon="el-icon-setting" size="small" @click="openWizardDialog">{{ $t('dpmAuthority.btnSetAuth') }}</el-button>
        <el-button type="success" icon="el-icon-setting" size="small" @click="openChangeLevelDialog">{{ $t('dpmAuthority.btnSetLevel') }}</el-button>
        <el-button type="primary" icon="el-icon-document-copy" size="small" @click="openCopyizardDialog">{{ $t('dpmAuthority.btnCopyAuth') }}</el-button>
      </el-header>
      <el-main style="padding:0;height:1px">
        <div id="tableContainer" style="height:100%;">
          <el-table
            v-loading="loading"
            :data="tableData"
            stripe
            size="small"
            :height="tableHeight"
            style="width: 100%;"
          >
            <el-table-column prop="seq" :label="$t('common.colSeq')" width="70" align="center" />
            <el-table-column prop="employee_id" :label="$t('common.colEmpId')" width="100" align="center" />
            <el-table-column prop="name" :label="$t('common.colEmpName')" width="150" align="center" />
            <el-table-column prop="department" :label="$t('common.colDept')" width="160" show-overflow-tooltip header-align="center" />
            <el-table-column prop="factory" :label="$t('common.colFactory')" width="100" align="center" />
            <el-table-column prop="area" :label="$t('common.colArea')" width="120" align="center" />
            <el-table-column prop="line" :label="$t('common.colLine')" width="120" align="center" />
            <el-table-column prop="level" :label="$t('dpmAuthority.colLevel')" width="120" align="center" />
            <div v-if="false">
              <el-table-column prop="line_id" label="lineid" />
            </div>
            <el-table-column :label="$t('common.colOpt')" width="100" align="center">
              <template slot-scope="scope">
                <el-button type="text" size="small" style="color:red" @click="deleteAuth(scope.row)">{{ $t('dpmAuthority.btnDelAuth') }}</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </el-main>
      <el-footer style="margin:0 auto">
        <el-pagination
          :current-page="pageIndex"
          :page-sizes="[100, 200, 300, 400]"
          :page-size="100"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </el-footer>
    </el-container>

    <el-dialog
      :center="true"
      :title="wizardTitle"
      :close-on-press-escape="false"
      :visible.sync="wizardDialogVisible"
      width="1000px"
      :close-on-click-modal="false"
    >
      <div style="height:350px">
        <div v-show="currStep===1" class="startDiv">
          <span class="wizardDailogInfoTitle">{{ $t('dpmAuthority.lblWelcomeWizard') }}</span>
          <el-divider />
          <div style="text-align:center">
            <el-button type="primary" plain icon="el-icon-s-flag" style="font-size:24px;" @click="setupStep(1)">{{ $t('dpmAuthority.btnStart') }}</el-button>
          </div>
        </div>
        <div v-show="currStep===2">
          <el-container style="height:100%">
            <el-aside style="width:150px;height:100%">
              <el-input
                v-model="checkPastePersons"
                type="textarea"
                clearable
                resize="none"
                :placeholder="$t('dpmAuthority.phdCheckPastePersons')"
                rows="13"
              />
              <el-button type="primary" plain icon="el-icon-circle-check" size="small" style="margin-left:15px;margin-top:10px" @click="checkPastePerson">{{ $t('dpmAuthority.btnCheckEmpId') }}</el-button>
            </el-aside>
            <el-main>
              <el-table
                v-loading="loading"
                :data="empList"
                size="small"
                height="300"
                :row-class-name="tableRowClassName"
                style="width: 1000px;"
              >
                <el-table-column prop="employee_id" :label="$t('common.colEmpId')" width="90" align="center" />
                <el-table-column prop="name" :label="$t('common.colEmpName')" width="80" align="center" />
                <el-table-column prop="email" :label="$t('common.colEMail')" width="200" align="center" />
                <el-table-column prop="type_code" :label="$t('common.colEmpTypeCode')" width="50" align="center" />
                <el-table-column prop="dept_code" :label="$t('common.colDeptCode')" width="100" show-overflow-tooltip align="center" />
                <el-table-column prop="department" :label="$t('common.colDept')" width="120" show-overflow-tooltip header-align="center" />
                <el-table-column prop="result" :label="$t('common.colResult')" width="230" show-overflow-tooltip header-align="center" />
                <el-table-column v-if="false" prop="level" label="" width="1" />
              </el-table>
            </el-main>
          </el-container>
        </div>
        <div v-show="currStep===3" class="contentDiv">
          <h2 style="color:rgb(255,64,64)">{{ $t('dpmAuthority.lblWizardWarning') }}</h2>
          <el-table
            v-loading="loading"
            :data="empOKList"
            size="small"
            height="300"
            style="width: 1000px"
          >
            <el-table-column prop="employee_id" :label="$t('common.colEmpId')" width="120" align="center" />
            <el-table-column prop="name" :label="$t('common.colEmpName')" width="120" align="center" />
            <el-table-column prop="email" :label="$t('common.colEMail')" width="250" align="center" />
            <el-table-column prop="type_code" :label="$t('common.colEmpTypeCode')" width="90" align="center" />
            <el-table-column prop="dept_code" :label="$t('common.colDeptCode')" width="130" show-overflow-tooltip align="center" />
            <el-table-column prop="department" :label="$t('common.colDept')" width="180" show-overflow-tooltip header-align="center" />
          </el-table>
        </div>
        <div v-show="currStep===4" class="startDiv">
          <div class="authdiv">
            <div class="authTypeDiv">
              <el-card class="rbCard">
                <el-radio v-model="optType" label="add">{{ $t('dpmAuthority.rbAddAuth') }}</el-radio><br>
                <el-radio v-model="optType" label="delete">{{ $t('dpmAuthority.rbDelAuth') }}</el-radio>
              </el-card>
            </div>
            <div class="authTreeDiv">
              <el-tree
                ref="authTree"
                :data="authorityTable"
                default-expand-all
                node-key="id"
                :props="defaultProps"
                show-checkbox
              />
            </div>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="danger" size="small" @click="closeWizardDialog">{{ $t('common.btnQuit') }}</el-button>
        <el-button v-show="currStep>1" type="primary" size="small" @click="setupStep(-1)">{{ $t('common.btnPrevStep') }}</el-button>
        <el-button v-show="currStep>1 && currStep<4" type="primary" size="small" @click="setupStep(1)">{{ $t('common.btnNextStep') }}</el-button>
        <el-button v-show="currStep===4" type="success" size="small" @click="submitAuthSetting">{{ $t('common.btnSubmit') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="$t('dpmAuthority.lblTitleBatchChange')"
      :close-on-press-escape="false"
      :visible.sync="setLevelDialogVisible"
      width="1000px"
      :close-on-click-modal="false"
    >
      <div style="height:370px">
        <el-container style="height:100%">
          <el-aside style="width:150px;height:100%">
            <el-input
              v-model="checkPasteChangeLevelPersons"
              type="textarea"
              clearable
              resize="none"
              :placeholder="$t('dpmAuthority.phdCheckPastePersons')"
              rows="10"
            />
            <el-button type="primary" plain icon="el-icon-circle-check" size="small" style="margin-left:15px;margin-top:10px" @click="checkPasteChangeLevelPerson">{{ $t('dpmAuthority.btnCheckEmpId') }}</el-button>
            <el-select v-model="newLevel" size="small" style="width:150px;margin-top:15px" :placeholder="$t('dpmAuthority.phdChooseNewLevel')">
              <el-option label="line" value="line" />
              <el-option label="area" value="area" />
              <el-option label="team" value="team" />
              <el-option label="factory" value="factory" />
            </el-select>
          </el-aside>
          <el-main>
            <el-table
              v-loading="loading"
              :data="changeLevelEmpList"
              size="small"
              height="300"
              :row-class-name="tableRowClassName2"
              style="width: 800px;"
            >
              <el-table-column prop="employee_id" :label="$t('common.colEmpId')" width="90" align="center" />
              <el-table-column prop="level" :label="$t('dpmAuthority.colCurrentLevel')" width="160" align="center" />
              <el-table-column prop="result" :label="$t('common.colResult')" show-overflow-tooltip align="center" />
            </el-table>
          </el-main>
        </el-container>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="danger" size="small" @click="closeChangeLevelDialog">{{ $t('common.btnQuit') }}</el-button>
        <el-button type="success" size="small" @click="submitChangeLevel">{{ $t('common.btnSubmit') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="wizardCopyAuthTitle"
      :close-on-press-escape="false"
      :visible.sync="wizardCopyAuthDialogVisible"
      width="1000px"
      :close-on-click-modal="false"
    >
      <div style="height:350px">
        <div v-show="currStep===1" class="startDiv">
          <span class="wizardDailogInfoTitle">{{ $t('dpmAuthority.lblWelcomeWizardCopy') }}</span>
          <el-divider />
          <div style="text-align:center">
            <el-button type="primary" plain icon="el-icon-s-flag" style="font-size:24px;" @click="setupCopyStep(1)">{{ $t('dpmAuthority.btnStart') }}</el-button>
          </div>
        </div>
        <div v-show="currStep===2">
          <el-container style="height:100%">
            <el-aside style="width:150px;height:100%">
              <el-input
                v-model="checkPastePersons"
                type="textarea"
                clearable
                resize="none"
                :placeholder="$t('dpmAuthority.phdCheckPastePersons')"
                rows="13"
              />
              <el-button type="primary" plain icon="el-icon-circle-check" size="small" style="margin-left:15px;margin-top:10px" @click="checkPastePerson">{{ $t('dpmAuthority.btnCheckEmpId') }}</el-button>
            </el-aside>
            <el-main>
              <el-table
                v-loading="loading"
                :data="empList"
                size="small"
                height="300"
                :row-class-name="tableRowClassName"
                style="width: 1000px;"
              >
                <el-table-column prop="employee_id" :label="$t('common.colEmpId')" width="90" align="center" />
                <el-table-column prop="name" :label="$t('common.colEmpName')" width="80" align="center" />
                <el-table-column prop="email" :label="$t('common.colEMail')" width="200" align="center" />
                <el-table-column prop="type_code" :label="$t('common.colEmpTypeCode')" width="50" align="center" />
                <el-table-column prop="dept_code" :label="$t('common.colDeptCode')" width="100" show-overflow-tooltip align="center" />
                <el-table-column prop="department" :label="$t('common.colDept')" width="120" show-overflow-tooltip header-align="center" />
                <el-table-column prop="result" :label="$t('common.colResult')" width="230" show-overflow-tooltip align="center" />
                <el-table-column v-if="false" prop="level" label="" width="1" />
              </el-table>
            </el-main>
          </el-container>
        </div>
        <div v-show="currStep===3" class="contentDiv">
          <h2 style="color:rgb(255,64,64)">{{ $t('dpmAuthority.lblWizardWarningCopy') }}</h2>
          <el-table
            v-loading="loading"
            :data="empOKList"
            size="small"
            height="300"
            style="width: 1000px"
          >
            <el-table-column prop="employee_id" :label="$t('common.colEmpId')" width="120" align="center" />
            <el-table-column prop="name" :label="$t('common.colEmpName')" width="120" align="center" />
            <el-table-column prop="email" :label="$t('common.colEMail')" width="250" align="center" />
            <el-table-column prop="type_code" :label="$t('common.colEmpTypeCode')" width="90" align="center" />
            <el-table-column prop="dept_code" :label="$t('common.colDeptCode')" width="130" show-overflow-tooltip align="center" />
            <el-table-column prop="department" :label="$t('common.colDept')" width="180" show-overflow-tooltip header-align="center" />
          </el-table>
        </div>
        <div v-show="currStep===4" class="startDiv">
          <div class="authdiv">
            <div class="authTypeDiv">
              <el-input v-model="copySourceEmpId" :placeholder="$t('dpmAuthority.iptCopyEmpIdList')" size="small">
                <el-button slot="append" icon="el-icon-search" @click="querySourceAuth" />
              </el-input>
            </div>
            <div class="authTreeDiv">
              <el-tree
                ref="authTreeCopy"
                :data="authorityCopyTable"
                default-expand-all
                node-key="id"
                :props="defaultProps"
                show-checkbox
              />
            </div>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="danger" size="small" @click="closeCopyWizardDialog">{{ $t('common.btnQuit') }}</el-button>
        <el-button v-show="currStep>1" type="primary" size="small" @click="setupCopyStep(-1)">{{ $t('common.btnPrevStep') }}</el-button>
        <el-button v-show="currStep>1 && currStep<4" type="primary" size="small" @click="setupCopyStep(1)">{{ $t('common.btnNextStep') }}</el-button>
        <el-button v-show="currStep===4" type="success" size="small" @click="submitCopyAuthSetting">{{ $t('common.btnSubmit') }}</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import {
  GetDPMQueryKeyValue, CheckEmpStatus, GetMTAuthBaseData, UpdateUserAuthority, CheckChangeEmpLevelStatus, UpdateUserViewLevel,
  GetDPMAuthorityReport, GetMTCopyAuthBaseData
} from '@/api/midway.js'
export default {
  data() {
    return {
      pageSize: 100,
      pageIndex: 1,
      total: 0,
      tableHeight: 1,
      loading: false,
      loadingData: null,
      queryFactory: '',
      factoryList: [],
      queryArea: '',
      areaList: [],
      queryLine: [],
      lineList: [],
      queryEmployeeId: '',
      tableData: [],
      wizardDialogVisible: false,
      checkPastePersons: '',
      empList: [],
      empOKList: [],
      factoryTable: [],
      factorySelectTable: [],
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      authorityTable: [],
      selectAuthTable: [],
      currStep: 1,
      wizardTitle: this.$t('dpmAuthority.lblWizardTitle'),
      optType: 'add',
      newLevel: '',
      setLevelDialogVisible: false,
      checkPasteChangeLevelPersons: '',
      changeLevelEmpList: [],
      wizardCopyAuthTitle: this.$t('dpmAuthority.lblWizardTitleCopy'),
      wizardCopyAuthDialogVisible: false,
      copySourceEmpId: '',
      authorityCopyTable: []
    }
  },
  mounted() {
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
    }
    this.getQueryFactoryList()
  },
  methods: {
    tableRowClassName({ row, rowIndex }) {
      if (row.level === 'NG') {
        return 'error-row'
      } else if (row.level === 'OK') {
        return 'ok-row'
      } else if (row.level === 'WARNING') {
        return 'warning-row'
      } else {
        return ''
      }
    },
    tableRowClassName2({ row, rowIndex }) {
      if (row.result === 'OK') {
        return 'ok-row'
      } else {
        return 'error-row'
      }
    },
    handleSizeChange: function(val) {
      this.pageSize = val
    },
    handleCurrentChange: function(val) {
      this.pageIndex = val
      this.queryUserAuthority(false)
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    async getQueryFactoryList() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.factoryList = []
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.factoryList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryAreaList() {
      this.areaList = []
      this.queryArea = ''
      this.lineList = []
      this.queryLine = []
      const data = {
        type: 'userarea',
        key: this.queryFactory
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryLineList() {
      this.lineList = []
      this.queryLine = []
      const data = {
        type: 'userline2',
        key: this.queryArea
      }
      this.lineList.push({
        key: '0',
        data: 'ALL'
      })
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        response.data.ReturnObject.forEach(d => {
          this.lineList.push(d)
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    async queryUserAuthority(resetIndex) {
      if (resetIndex) {
        this.pageIndex = 1
      }
      if (this.queryFactory === '') {
        this.alertMsg(this.$t('dpmAuthority.altMsgPleaseChooseFactory'))
        return
      }
      if (this.queryArea === '') {
        this.alertMsg(this.$t('dpmAuthority.altMsgPleaseChooseArea'))
        return
      }
      let lineIdList = ''
      if (this.queryLine.length === 0) {
        lineIdList = '0'
      } else {
        this.queryLine.forEach(l => {
          lineIdList = lineIdList + l + ','
        })
      }
      if (lineIdList.length > 1) {
        lineIdList = lineIdList.substr(0, lineIdList.length - 1)
      }
      const data = {
        factoryId: this.queryFactory,
        areaId: this.queryArea,
        lineIdList: lineIdList,
        filter: this.queryEmployeeId,
        pageSize: this.pageSize,
        pageIndex: this.pageIndex
      }
      this.tableData = []
      this.loading = true
      const response = await GetDPMAuthorityReport(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.total = obj.total
        this.tableData = obj.queryData
      } else {
        this.alertMsg(queryResult)
      }
    },
    openWizardDialog() {
      this.currStep = 1
      this.checkPastePersons = ''
      this.empList = []
      this.empOKList = []
      this.getAuthTree()
      this.wizardDialogVisible = true
    },
    async getAuthTree() {
      this.authorityTable = []
      const response = await GetMTAuthBaseData()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.authorityTable = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeWizardDialog() {
      this.wizardDialogVisible = false
    },
    factoryLevelSelectChange(val) {
      this.factorySelectTable = val
    },
    setupStep(step) {
      if (this.currStep === 2) {
        this.empOKList = []
        this.empList.forEach(e => {
          if (e.result === 'OK') {
            this.empOKList.push(e)
          }
        })
        if (this.empOKList.length === 0) {
          this.alertMsg(this.$t('dpmAuthority.altMsgEmpEmpty'))
          return
        }
      }

      const tempStep = this.currStep + step
      if (tempStep < 1) {
        this.currStep = 1
      }
      if (tempStep > 4) {
        this.currStep = 4
      }
      this.currStep = tempStep

      switch (this.currStep) {
        case 1:
          this.wizardTitle = this.$t('dpmAuthority.lblWizardTitle')
          break
        case 2:
          this.wizardTitle = this.$t('dpmAuthority.lblWizardTitle') + '  -- ' + this.$t('dpmAuthority.lblWizardTitleCheckEmp')
          break
        case 3:
          this.wizardTitle = this.$t('dpmAuthority.lblWizardTitle') + '  -- ' + this.$t('dpmAuthority.lblWizardTitleConfirmEmp')
          break
        case 4:
          this.wizardTitle = this.$t('dpmAuthority.lblWizardTitle') + '  -- ' + this.$t('dpmAuthority.lblWizardTitleSubmit')
          break
      }
    },
    async checkPastePerson() {
      if (this.checkPastePersons === '') {
        this.alertMsg(this.$t('dpmAuthority.altMsgMustKeyinEmpId'))
        return
      }
      this.empList = []
      this.empOKList = []
      const data = {
        employeeid: this.checkPastePersons
      }
      this.loading = true
      const response = await CheckEmpStatus(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.empList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async submitAuthSetting() {
      if (this.empOKList.length === 0) {
        this.alertMsg(this.$t('dpmAuthority.altMsgEmpEmpty'))
        return
      }
      const nodes = this.$refs.authTree.getCheckedNodes(true, false)
      if (nodes.length === 0) {
        this.alertMsg(this.$t('dpmAuthority.altMsgAuthEmpty'))
        return
      }
      let ids = ''
      nodes.forEach(n => {
        ids = ids + n.level + ',' + n.id + ';'
      })
      if (ids.length > 1) {
        ids = ids.substr(0, ids.length - 1)
      }
      let emp = ''
      this.empOKList.forEach(e => {
        emp = emp + e.employee_id + ','
      })
      if (emp.length > 1) {
        emp = emp.substr(0, emp.length - 1)
      }
      const optStr = this.optType === 'add' ? this.$t('common.rbAdd') : this.$t('common.rbDel')
      const msg = this.$utils.ReplacePlaceHolder(this.$t('dpmAuthority.altMsgConfirirm'), [optStr])
      if (!confirm(msg)) {
        return
      }
      const data = {
        type: this.optType,
        empList: emp,
        ids: ids
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoadingSubmit'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await UpdateUserAuthority(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeWizardDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async deleteAuth(row) {
      if (!confirm(this.$t('dpmAuthority.altMsgConfirmDel'))) {
        return
      }
      const ids = 'line,' + row.line_id
      const data = {
        type: 'delete',
        empList: row.employee_id,
        ids: ids
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoadingSubmit'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await UpdateUserAuthority(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmAuthority.altMsgDelSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.queryUserAuthority()
      } else {
        this.alertMsg(queryResult)
      }
    },
    resizeTable: function() {
      this.$nextTick(function() {
        const divHeight = $('#tableContainer').height()
        this.tableHeight = divHeight
      })
    },
    async checkPasteChangeLevelPerson() {
      if (this.checkPasteChangeLevelPersons === '') {
        this.alertMsg(this.$t('dpmAuthority.altMsgMustKeyinEmpId'))
        return
      }
      this.changeLevelEmpList = []
      const data = {
        employeeid: this.checkPasteChangeLevelPersons
      }
      this.loading = true
      const response = await CheckChangeEmpLevelStatus(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.changeLevelEmpList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    openChangeLevelDialog() {
      this.checkPasteChangeLevelPersons = ''
      this.changeLevelEmpList = []
      this.setLevelDialogVisible = true
    },
    closeChangeLevelDialog() {
      this.setLevelDialogVisible = false
    },
    submitChangeLevel() {
      if (this.changeLevelEmpList.length === 0) {
        this.alertMsg(this.$t('dpmAuthority.altMsgMustKeyinEmpId'))
        return
      }
      if (this.newLevel === '') {
        this.alertMsg(this.$t('dpmAuthority.altMsgMustChooseNewLevel'))
        return
      }
      const okRow = []
      this.changeLevelEmpList.forEach(c => {
        if (c.result === 'OK') {
          okRow.push(c)
        }
      })
      if (okRow.length === 0) {
        this.alertMsg(this.$t('dpmAuthority.altMsgNoOptRow'))
        return
      }
      if (!confirm(this.$t('dpmAuthority.altMsgConfirmUpdate'))) {
        return
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoadingSubmit'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })

      okRow.forEach(async o => {
        const data = {
          employeeId: o.employee_id,
          level: this.newLevel
        }
        const response = await UpdateUserViewLevel(data)
        o.result = response.data.QueryResult
      })

      this.loadingData.close()
      this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'success'
      })
    },
    openCopyizardDialog() {
      this.currStep = 1
      this.checkPastePersons = ''
      this.empList = []
      this.empOKList = []
      this.copySourceEmpId = ''
      this.authorityCopyTable = []
      this.wizardCopyAuthDialogVisible = true
    },
    setupCopyStep(step) {
      if (this.currStep === 2) {
        this.empList.forEach(e => {
          if (e.result === 'OK') {
            this.empOKList.push(e)
          }
        })
        if (this.empOKList.length === 0) {
          this.alertMsg(this.$t('dpmAuthority.altMsgMustKeyinEmpId'))
          return
        }
      }

      const tempStep = this.currStep + step
      if (tempStep < 1) {
        this.currStep = 1
      }
      if (tempStep > 4) {
        this.currStep = 4
      }
      this.currStep = tempStep

      switch (this.currStep) {
        case 1:
          this.wizardCopyAuthTitle = this.$t('dpmAuthority.lblWizardTitleCopy')
          break
        case 2:
          this.wizardCopyAuthTitle = this.$t('dpmAuthority.lblWizardTitleCopy') + '  -- ' + this.$t('dpmAuthority.lblWizardTitleCheckEmp')
          break
        case 3:
          this.wizardCopyAuthTitle = this.$t('dpmAuthority.lblWizardTitleCopy') + '  -- ' + this.$t('dpmAuthority.lblWizardTitleConfirmEmp')
          break
        case 4:
          this.wizardCopyAuthTitle = this.$t('dpmAuthority.lblWizardTitleCopy') + '  -- ' + this.$t('dpmAuthority.lblWizardTitleSubmit')
          break
      }
    },
    async querySourceAuth() {
      if (this.copySourceEmpId === '') {
        this.alertMsg(this.$t('dpmAuthority.altMsgMustKeyinEmpId'))
      }
      this.authorityCopyTable = []
      const data = {
        sourceId: this.copySourceEmpId
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('dpmAuthority.altMsgLoadingQueryAuth'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await GetMTCopyAuthBaseData(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.authorityCopyTable = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeCopyWizardDialog() {
      this.wizardCopyAuthDialogVisible = false
    },
    async submitCopyAuthSetting() {
      if (this.empOKList.length === 0) {
        this.alertMsg(this.$t('dpmAuthority.altMsgMustKeyinEmpId'))
        return
      }
      const nodes = this.$refs.authTreeCopy.getCheckedNodes(true, false)
      if (nodes.length === 0) {
        this.alertMsg(this.$t('dpmAuthority.altMsgAuthEmpty'))
        return
      }
      let ids = ''
      nodes.forEach(n => {
        ids = ids + n.level + ',' + n.id + ';'
      })
      if (ids.length > 1) {
        ids = ids.substr(0, ids.length - 1)
      }
      let emp = ''
      this.empOKList.forEach(e => {
        emp = emp + e.employee_id + ','
      })
      if (emp.length > 1) {
        emp = emp.substr(0, emp.length - 1)
      }
      if (!confirm(this.$t('dpmAuthority.altMsgConfirmCopy'))) {
        return
      }
      const data = {
        type: 'add',
        empList: emp,
        ids: ids
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoadingSubmit'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await UpdateUserAuthority(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeCopyWizardDialog()
      } else {
        this.alertMsg(queryResult)
      }
    }
  }
}
</script>
<style lang="less" scoped>
.selectMidSize{
  width:120px;
  margin-right:5px;
}
.startDiv{
    position: absolute;
    left:50%;
    top:50%;
    transform: translate(-50%, -50%);
}
.contentDiv{
  margin:0 auto;
}
.wizardDailogInfoTitle{
  font-size:24px;
  color: rgb(0, 122, 204);
  display: block;
}
::v-deep .el-table .ok-row {
  background: rgb(190, 242, 125);
}
 ::v-deep .el-table .warning-row {
    background: lightyellow;
}
::v-deep .el-table .error-row {
    background: rgb(252, 210, 217);
}
.authdiv{
 width:100%;
 height:300px;
 display: flex;
}
.authTypeDiv{
 width: 300px;
 height: 100%;
}
.authTreeDiv{
 width:500px;
 height: 100%;
 overflow-y: scroll;
}
.rbCard{
  width: 200px;
}
.authTableDiv{
 width: 600px;
 height: 100%;
}
</style>
