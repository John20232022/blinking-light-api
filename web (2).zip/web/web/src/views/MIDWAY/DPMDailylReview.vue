<template>
  <div style="height:100%;width:100%;">
    <el-container style="height:100%;">
      <el-header class="header">
        <el-select v-model="queryFactory" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectFactory')" @change="getQueryAreaList">
          <el-option
            v-for="item in factoryList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryArea" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectArea')" @change="getQueryteamList">
          <el-option
            v-for="item in areaList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryTeam" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectTeam')">
          <el-option
            v-for="item in teamList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-date-picker v-model="queryDay" size="small" style="width:140px;margin-right:5px" type="date" :placeholder="$t('common.phdWorkDay')" />
        <!-- <el-select v-model="queryShift" size="small" class="selectMidSize" :placeholder="$t('common.phdShift')">
          <el-option
            v-for="item in shiftList"
            :key="item"
            :label="item"
            :value="item"
          />
        </el-select> -->
        <el-button type="primary" icon="el-icon-search" size="small" @click="queryData('', false)">{{ $t('common.btnQuery') }}</el-button>
        <el-button type="primary" icon="el-icon-download" size="small" @click="downloadData()">{{ $t('common.btnDownload') }}</el-button>
      </el-header>
      <el-main id="tabMain" style="padding:5px;">
        <el-tabs v-model="tabActiveName" @tab-click="tabClick">
          <el-tab-pane :label="$t('dpmDailyReview.lblTabSummary')" name="summary" lazy>
            <div id="kpiMainTableDiv" :style="{'height': getTabDivHeight()}">
              <el-table
                v-loading="loading"
                :data="tableOverall"
                size="small"
                :height="tableHeight"
                :span-method="arraySpanMethod"
                :cell-style="getCellColor"
                :header-cell-style="getHeaderCellColor"
                style="width: 100%;"
              >
                <el-table-column prop="line" label="" width="100" align="center">
                  <template slot-scope="scope">
                    <el-link :underline="false" @click="lineClickHandle(scope.row.line)">{{ scope.row.line }}</el-link>
                  </template>
                </el-table-column>
                <!-- 20230110 Kimi 增加列的显示/不显示判断 -->
                <el-table-column key="1" prop="item" label="" width="70" align="center" />
                <el-table-column v-if="setColVisibleStatus('uts')" key="2" prop="uts" label="UTS" align="center" width="100" />
                <el-table-column v-if="setColVisibleStatus('input')" key="3" prop="input" label="Input" align="center" width="100" />
                <el-table-column v-if="setColVisibleStatus('output')" key="4" prop="output" label="Output" align="center" width="100" />
                <el-table-column v-if="setColVisibleStatus('uph_hit')" key="5" prop="uph_hit" label="UPH Hit" align="center" width="100" />
                <el-table-column v-if="setColVisibleStatus('pph')" key="6" prop="pph" label="PPH" align="center" width="100" />
                <el-table-column v-if="setColVisibleStatus('eff')" key="7" prop="eff" label="Eff" align="center" width="100" />
                <el-table-column v-if="setColVisibleStatus('overall_eff')" key="8" prop="overall_eff" label="OverAll EFF" align="center" width="100" />
                <el-table-column v-if="setColVisibleStatus('rty')" key="9" prop="rty" label="RTY" align="center" width="100" />
                <el-table-column v-if="setColVisibleStatus('oee1')" key="10" prop="oee1" label="OEE1" align="center" width="100" />
                <el-table-column v-if="setColVisibleStatus('oee2')" key="11" prop="oee2" label="OEE2" align="center" width="100" />
                <!-- <el-table-column v-if="setColVisibleStatus('oail')" key="12" prop="oail" label="OAIL" align="center" width="100" /> -->
                <!-- <el-table-column prop="oatl" label="OATL" align="center" width="100" v-if="setColVisibleStatus('oatl')"></el-table-column> -->
              </el-table>
            </div>
          </el-tab-pane>
          <el-tab-pane :label="$t('dpmDailyReview.lblDataByRange')" name="issue">
            <label>{{ $t('common.colShift') }}：</label>
            <el-select v-model="queryShift" size="small" class="selectMidSize" placeholder="班次" @change="selectChange">
              <el-option
                v-for="item in workshiftList"
                :key="item.shift_code"
                :label="item.shift_name"
                :value="item.shift_code"
              />
              <!-- <el-option v-for="item in shiftList" :key="item" :label="item" :value="item" /> -->
            </el-select>
            <label style="margin-left: 20px;">{{ $t('common.colStatus') }}：</label>
            <el-select v-model="queryStatus" placeholder="狀態" style="width:100px;margin:5px 0 5px 0" size="small" @change="selectChange">
              <el-option label="ALL" value="ALL" />
              <el-option :label="$t('dpmIssueReview.selWaitDispatch')" value="waitdispatch" />
              <el-option :label="$t('dpmIssueReview.selWaitSoulation')" value="waitsolution" />
              <el-option :label="$t('dpmIssueReview.selWaitCheck')" value="waitcheck" />
              <el-option :label="$t('dpmDailyReview.phdSelectCompleted')" value="done" />
              <el-option :label="$t('dpmDailyReview.phdSelectUnknown')" value="unknown" />
            </el-select>
            <div id="issueMainTableDiv" class="issueDivTable">
              <el-table
                ref="tableIssueDesc"
                v-loading="loadingIssue"
                :data="tableIssueDesc"
                size="small"
                stripe
                :height="tableHeight"
                :header-cell-style="getHeaderCellColor"
                :span-method="objectSpanMethod"
                :cell-style="getFATPCellColor"
                style="width: 100%;"
              >
                <el-table-column key="1" prop="line" :label="$t('common.colLine')" align="center" width="90" show-overflow-tooltip /><!--20230110 Kimi 设置Fixed-->
                <el-table-column key="2" prop="shift" :label="$t('common.colShift')" align="center" width="60" show-overflow-tooltip /><!--20230110 Kimi 减少宽度 设置Fixed-->
                <el-table-column v-if="setColVisibleStatus2('FATP')" key="3" prop="stage_name" :label="$t('common.colStage')" align="center" width="70" show-overflow-tooltip />
                <el-table-column key="4" prop="work_time" :label="$t('dpmDashboardLineDetail.colTimeRange')" align="center" width="95" show-overflow-tooltip /><!--20230110 Kimi 减少宽度 设置Fixed-->
                <el-table-column key="5" prop="part_no" :label="$t('dpmDashboardLineDetail.colSKU')" align="center" width="145" show-overflow-tooltip /> <!--20230110 Kimi 增加part_no--><!--20230110 Kimi 设置Fixed-->
                <el-table-column key="6" prop="goal" label="GOAL" align="center" width="80" type="number" show-overflow-tooltip />
                <el-table-column key="7" prop="act" label="ACT" align="center" width="80" type="number" show-overflow-tooltip />
                <el-table-column v-if="setColVisibleStatus2('PCBA')" key="8" prop="oee2" label="OEE2" align="center" width="80" show-overflow-tooltip />
                <el-table-column v-if="setColVisibleStatus2('FATP')" key="9" prop="ratio" :label="$t('dpmDashboardLineDetail.colRatio')" align="center" width="80" type="number" show-overflow-tooltip />
                <el-table-column key="10" prop="status" :label="$t('common.colStatus')" align="center" width="70" show-overflow-tooltip />
                <el-table-column key="11" prop="unusual_type" :label="$t('common.colType')" align="center" width="80" show-overflow-tooltip />
                <el-table-column v-if="setColVisibleStatus2('PCBA')" key="12" prop="issue_Stage_name" :label="$t('common.colStage')" align="center" width="70" show-overflow-tooltip />
                <el-table-column key="13" prop="unusual_message" :label="$t('dpmIssueReview.colReasonCode')" align="center" width="140" show-overflow-tooltip />
                <el-table-column v-if="setColVisibleStatus2('PCBA')" key="14" prop="range" :label="$t('dpmIssueReview.colImpactTime')" align="center" width="80" show-overflow-tooltip />
                <el-table-column v-if="setColVisibleStatus2('FATP')" key="15" prop="range" :label="$t('dpmOptMod.lblOccTime')" align="center" width="120" show-overflow-tooltip />
                <el-table-column key="16" prop="message" :label="$t('dpmIssueReview.colReasonDesc')" align="center" width="250" show-overflow-tooltip />
                <el-table-column key="17" prop="solution" :label="$t('dpmOptMod.lblSolution')" align="center" width="220" show-overflow-tooltip />
                <el-table-column key="18" prop="dri_dept" :label="$t('common.colDRIDept')" align="center" width="150" show-overflow-tooltip />
                <!--<el-table-column prop="line" :label="$t('common.colLine')" align="center" width="150" show-overflow-tooltip fixed />--><!--20230110 Kimi 设置Fixed-->
                <!--<el-table-column prop="shift" :label="$t('common.colShift')" align="center" width="70" show-overflow-tooltip fixed />--><!--20230110 Kimi 减少宽度 设置Fixed-->
                <!--<el-table-column prop="work_time" :label="$t('common.colWorkTime')" align="center" width="70" show-overflow-tooltip fixed />--><!--20230110 Kimi 减少宽度 设置Fixed-->
                <!--<el-table-column prop="part_no" :label="$t('common.colPN')" align="center" width="150" show-overflow-tooltip fixed /> --><!--20230110 Kimi 增加part_no--><!--20230110 Kimi 设置Fixed-->
                <!-- <template v-if="queryAreaData !== 'FATP'">
                  <el-table-column
                    v-for="(o, index) in colSetting"
                    :key="index"
                    :label="o.label"
                    align="center"
                  >
                    <el-table-column
                      v-for="(d, index1) in o.detail"
                      :key="index1"
                      :prop="d.prop"
                      :label="d.label"
                      :width="d.width"
                      align="center"
                    />
                  </el-table-column>
                </template>
                <template v-if="queryAreaData === 'FATP'">
                  <el-table-column
                    v-for="(item,index) in colSettingFatp"
                    :key="index"
                    :prop="item.prop"
                    :label="item.label"
                    align="center"
                  />
                </template> -->

              </el-table>
            </div>
          </el-tab-pane>
        </el-tabs>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import $ from 'jquery'
import { DownLoadDPMTeamDailyKpiReviewData_API } from '@/api/upload_download'
import {
  GetDPMQueryKeyValue, GetDPMTeamDailyKpiReviewData, GetDPMTeamDailyKpiReviewIssueData, GetWorkshiftList
} from '@/api/midway.js'

export default {
  components: {
  },
  data() {
    return {
      tabActiveName: 'summary',
      tabDivHeight: 1,
      queryFactory: '',
      factoryList: [],
      queryArea: '',
      queryAreaData: '',
      areaList: [],
      queryTeam: '',
      queryDay: '',
      teamList: [],
      tableHeight: 1,
      loadingData: null,
      keyid: '',
      loading: false,
      loadingIssue: false,
      tableOverall: [],
      tableIssueAll: [],
      kpiLossTableHeight: 1,
      issueTableHeight: 1,
      tableIssueDesc: [],
      spanRows: [],
      lossTableSpanDShiftRowIndex: -1,
      lossTableSpanNShiftRowIndex: -1,
      colSetting: [],
      colSettingFatp: [],
      workshiftList: [],
      // shiftList: [
      //   'D',
      //   'N',
      //   //  'M',
      //   'ALL'
      // ],
      queryShift: 'ALL',
      spanSetting: [],

      queryStatus: 'ALL', // add by liwen at 20230629
      isuessLine: 'OverAll' // add by liwen at 20230703
    }
  },
  computed: {
  },
  mounted() {
    this.resizeTable()
    this.getDefaultDate()
    this.getQueryFactoryList()
    window.onresize = () => {
      this.resizeTable()
    }
  },
  methods: {
    async getWorkDayWorkshift() {
      this.workshiftList = []
      const data = {
        factory: this.factoryList.filter(x => x.key === this.queryFactory)[0].data,
        hasALL: 'Y'
      }
      const response = await GetWorkshiftList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.workshiftList = response.data.ReturnObject
      } else {
        this.alertMsg(
          this.$utils.ReplacePlaceHolder(
            this.$t('dpmDashboardLineDetail.altMsgCannotGetShift'),
            [queryResult]
          )
        )
      }
    },
    // 20230803 Add by kimi，表格走样，重画一次
    tabClick(tab) {
      if (tab.name === 'issue') {
        this.$nextTick(() => {
          this.$refs.tableIssueDesc.doLayout()
        })
      }
    },
    // 狀態下拉框值选择改变事件 add by liwen at 20230629
    selectChange() {
      this.queryByLineData(this.isuessLine)
    },
    downloadData() {
      if (this.queryTeam === '') {
        this.alertMsg(this.$t('common.altMsgChooseCondition'))
        return
      }
      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      const workDay = this.$utils.GetDateString(this.queryDay)
      const params = {
        factory: factory,
        area: area,
        team: team,
        workDay: workDay
      }
      DownLoadDPMTeamDailyKpiReviewData_API(params, this.$t('dpmDailyReview.lblDailyRptName'))
      /* const lang = localStorage.getItem('lang') || 'cn'
      var url = '/midway/DownLoadDPMTeamDailyKpiReviewData'
      url = url + `?factory=${params.factory}&area=${params.area}&team=${params.team}&workDay=${params.workDay}&lang=${lang}`
      this.$utils.downloadFile(url, this.$t('dpmDailyReview.lblDailyRptName')) */
    },

    getTabDivHeight() {
      return this.tabDivHeight + 'px'
    },
    getDefaultDate() {
      const curDate = new Date()
      this.queryDay = new Date(curDate.getTime() - 24 * 60 * 60 * 1000)
    },
    // -----------------------------------------------------------------------
    // 20230110 Kimi 根据Area和KPI来决定列是否显示
    setColVisibleStatus(kpi) {
      let status = true
      let area = ''
      try {
        area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      } catch {
        status = true
      }
      if (area === '') {
        status = true
      } else if (area === 'FATP') {
        switch (kpi.toLowerCase()) {
          case 'oee1':
            status = false
            break
          default:
            status = true
          // case 'oail':
          //   status = false
          //   break
          // default:
          //   status = true
        }
      } else {
        switch (kpi.toLowerCase()) {
          case 'input':
          case 'uts':
          case 'uph_hit':
          case 'pph':
          case 'oatl':
          case 'eff':
            status = false
            break
          default:
            status = true
        }
      }

      return status
    },
    setColVisibleStatus2(kpi) {
      let status = false
      let area = ''
      try {
        area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      } catch {
        status = false
      }
      if (area === kpi) {
        status = true
      } else {
        status = false
      }
      return status
    },
    // -----------------------------------------------------------------------
    arraySpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex % 3 === 0) {
          return [3, 1]
        } else {
          return [0, 0]
        }
      }
    },

    arraySpanMethod02({ columnIndex, rowIndex }) {
      if (this.areaList.filter(x => x.key === this.queryArea)[0].data === 'FATP' ||
      this.areaList.filter(x => x.key === this.queryArea)[0].data === 'PCBA') {
        return [1, 1]
      } else {
        if (
          columnIndex === 0 ||
        columnIndex === 1 ||
        columnIndex === 2 ||
        columnIndex === 3 ||
        columnIndex === 4 ||
        columnIndex === 5 ||
        columnIndex === 6 ||
        columnIndex === 7
        ) {
          const setting = this.spanSetting.filter((x) => x.rowIndex === rowIndex)
          if (setting.length > 0) {
            if (setting[0].rowIndex !== this.tableIssueDesc.length - 1) {
              return [setting[0].rowCount, 1]
            } else {
              return [1, 2]
            }
          } else {
            return [0, 0]
          }
        }
      }
    },
    arraySpanMethodIssue({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0 || columnIndex === 1 || columnIndex === 2 || columnIndex === 3 || columnIndex === 4) {
        const ff = this.spanRows.filter(x => x.rowIndex === rowIndex)
        if (ff.length > 0) {
          return [ff[0].spanQty, 1]
        } else {
          return [0, 0]
        }
      }
    },
    clearTable() {
      this.tableOverall = []
      this.tableIssueDesc = []
      this.tableIssueAll = []
      this.spanRows = []
    },
    async getQueryFactoryList() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.factoryList = []
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.factoryList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryAreaList() {
      this.getWorkDayWorkshift()
      this.clearTable()
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = ''
      this.line = ''
      const data = {
        type: 'userarea',
        key: this.queryFactory
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryteamList() {
      this.clearTable()
      this.teamList = []
      this.queryTeam = ''
      this.line = ''
      const data = {
        type: 'userteam',
        key: this.queryArea
      }
      this.teamList.push({
        key: 'ALL',
        data: 'ALL'
      })
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        response.data.ReturnObject.forEach(d => {
          this.teamList.push(d)
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    getCellColor({ row, column, rowIndex, columnIndex }) {
      if (columnIndex > 1) {
        const label = column.label.toLowerCase()?.replace(' ', '_')
        let gap = row[label]
        let color = 'black'
        if (gap !== undefined) {
          gap = gap?.replace('%', '')
          if (gap !== '') {
            if (parseFloat(gap) < 0) {
              color = 'red'
            }
          }
        }
        if (Math.abs(rowIndex - 4) % 3 === 0) {
          return 'color: black; background: rgb(221, 235, 247);'
        } else if (Math.abs(rowIndex - 5) % 3 === 0) {
          return 'color: ' + color + '; background: rgb(252, 228, 214);'
        } else {
          return 'color: black'
        }
      } else if (columnIndex === 1) {
        if (Math.abs(rowIndex - 4) % 3 === 0) {
          return 'color: black; background: rgb(221, 235, 247);'
        } else if (Math.abs(rowIndex - 5) % 3 === 0) {
          return 'color: black; background: rgb(252, 228, 214);'
        } else {
          return 'color: black'
        }
      } else if (columnIndex === 0) {
        if (rowIndex < 3) {
          return 'color: white; background: rgb(221, 235, 247);' // 20230110 Kimi 背景色调浅，以免Overall看不清
        }
        return 'background: white; color: black;'
      }
    },
    getLossCellColor({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex < this.lossTableSpanDShiftRowIndex) {
          return 'background: rgb(221, 235, 247); color: black;'
        } else {
          return 'background: #d3d3d3; color: black;'
        }
      } else {
        if (rowIndex === this.lossTableSpanDShiftRowIndex - 1) {
          return 'background: rgb(221, 235, 247); color:black'
        } else if (rowIndex === this.lossTableSpanDShiftRowIndex - 2) {
          return 'background: rgb(226, 239, 218); color:black'
        } else if (rowIndex === this.lossTableSpanNShiftRowIndex - 1) {
          return 'background: #d3d3d3; color:black'
        } else if (rowIndex === this.lossTableSpanNShiftRowIndex - 2) {
          return 'background: rgb(226, 239, 218); color:black'
        } else {
          return 'color: black'
        }
      }
    },
    getHeaderCellColor() {
      const style = {
        'background-color': 'rgb(32,55,100)',
        color: 'white'
      }
      return style
    },
    getHeaderCellColorLoss() {
      const style = {
        'background-color': 'rgb(48,84,150)',
        color: 'white'
      }
      return style
    },
    getHeaderCellColorIssue() {
      const style = {
        'background-color': '#d2691e',
        color: 'white'
      }
      return style
    },
    getFATPCellColor({ row, column, rowIndex, columnIndex }) {
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const label = column.label.toLowerCase()?.replace(' ', '_')
      let color = 'black'
      let fontStyle = 'normal'
      if (label === this.$t('common.colStatus')) {
        if (row.status !== '' && row.status !== '--') {
          if (row.status === this.$t('dpmIssueReview.selWaitCheck')) {
            color = 'yellow'
          } else if (row.status !== this.$t('dpmDailyReview.phdSelectCompleted')) {
            color = 'red'
            // add by liwen at 20230706 未知状态，字体加粗
            if (row.status === this.$t('dpmDailyReview.phdSelectUnknown')) {
              fontStyle = 'bold'
            }
          }
        }
      }
      // add by liwen at 20230706 未知行字体红色加粗
      if (label === this.$t('commoncolWorkTime')) {
        if (row.work_time !== '' && row.work_time !== '--') {
          if (row.work_time === 'Unknown') {
            color = 'red'
            fontStyle = 'bold'
          }
        }
      } else if (label === this.$t('dpmIssueReview.colImpactTime')) {
        if (row.work_time !== '' && row.work_time !== '--') {
          if (row.work_time === 'Unknown') {
            color = 'red'
            fontStyle = 'bold'
          }
        }
      }
      //  Kay goal > act 達成率 & oee2 顯示紅色
      if ((label === 'oee2' && area === 'PCBA') || ((label === this.$t('dpmDailyReview.colRatio')) && area === 'FATP')) {
        if (row.act !== '0' && row.act !== '--') {
          const _act = parseInt(row.act)
          const _goal = parseInt(row.goal)
          if (_goal > _act) {
            color = 'red'
          }
        }
      }
      return 'color: ' + color + '; font-weight:' + fontStyle
    },
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      if (columnIndex === 0) {
        if (this.tableIssueDesc[rowIndex].pdline_sort === '1') {
          const n = parseInt(this.tableIssueDesc[rowIndex].pdline_ct)
          return {
            rowspan: n,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
      if (columnIndex === 1) {
        if (this.tableIssueDesc[rowIndex].shift_sort === '1') {
          const n = parseInt(this.tableIssueDesc[rowIndex].shift_ct)
          return {
            rowspan: n,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
      if (columnIndex === 2 && area === 'FATP') {
        if (this.tableIssueDesc[rowIndex].stage_sort === '1') {
          const n = parseInt(this.tableIssueDesc[rowIndex].stage_ct)
          return {
            rowspan: n,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
      if (((columnIndex >= 3 && area === 'FATP' && columnIndex <= 7) || (columnIndex >= 2 && area === 'PCBA' && columnIndex <= 6))) {
        if (this.tableIssueDesc[rowIndex].work_sort === '1') {
          const n = parseInt(this.tableIssueDesc[rowIndex].work_ct)
          return {
            rowspan: n,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    },
    // objectSpanMethod({ row, column, rowIndex, columnIndex }) {
    //   if (columnIndex < 4) {
    //     if (rowIndex % 2 === 0) {
    //       return {
    //         rowspan: 2,
    //         colspan: 1
    //       }
    //     } else {
    //       return {
    //         rowspan: 0,
    //         colspan: 0
    //       }
    //     }
    //   }
    // },
    initialData() {
      this.keyid = this.$route.query.keyid
      // 抓取项目数据显示在看板上
      // this.getDashBoardData()
    },
    lineClickHandle(line) {
      this.queryByLineData(line)
      this.tabActiveName = 'issue'
    },
    async queryData() {
      if (this.queryTeam === '') {
        this.alertMsg(this.$t('common.altMsgChooseCondition'))
        return
      }
      // this.loadingData = this.$loading({
      //   lock: true,
      //   text: '正在加載數據，請耐心等待...',
      //   spinner: 'el-icon-loading',
      //   background: 'rgba(0, 0, 0, 0.7)'
      // })

      this.tableOverall = []
      this.tableIssueDesc = []
      this.tableIssueAll = []
      this.spanRows = []
      this.loading = true
      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      const workDay = this.$utils.GetDateString(this.queryDay)

      const data = {
        factory: factory,
        area: area,
        team: team,
        workDay: workDay
      }
      const response = await GetDPMTeamDailyKpiReviewData(data)
      // this.loadingData.close()
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.tableOverall = obj
        this.queryByLineData('OverAll')
      } else {
        this.alertMsg(queryResult)
      }
    },
    async queryByLineData(line) {
      this.loadingIssue = true
      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      let team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      const workDay = this.$utils.GetDateString(this.queryDay)
      this.colSetting = []
      this.tableIssueDesc = []

      // add by liwen at 20230703,因数据库只接受这六种条件，所以不要做多语言翻译
      var selectStatus = 'ALL'
      if (this.queryStatus === 'waitdispatch') {
        selectStatus = '待分配'
      } else if (this.queryStatus === 'waitsolution') {
        selectStatus = '待填寫'
      } else if (this.queryStatus === 'waitcheck') {
        selectStatus = '待確認'
      } else if (this.queryStatus === 'done') {
        selectStatus = '已完成'
      } else if (this.queryStatus === 'unknown') {
        selectStatus = '未知'
      }
      let clcickTeamByCol = ''
      if (this.teamList.filter(x => x.data.toUpperCase() === line).length > 0) {
        clcickTeamByCol = this.teamList.filter(x => x.data.toUpperCase() === line)[0].data
      }
      if (clcickTeamByCol !== '') {
        team = clcickTeamByCol
        line = ''
      }
      const data = {
        factory: factory,
        area: area,
        team: team,
        workDay: workDay,
        line: line,
        shift: this.queryShift,
        selectStatus: selectStatus
      }
      const response = await GetDPMTeamDailyKpiReviewIssueData(data)
      this.loadingIssue = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject

        // add by liwen at 20230706 未知狀態行，goal和act都改為--
        for (var index = 0; index < obj.length; index++) {
          const work_time = obj[index]['work_time']
          if (work_time === 'Unknown') {
            obj[index]['goal'] = '--'
            obj[index]['act'] = '--'
          }
        }

        this.tableIssueDesc = obj
        for (const key in obj[0]) {
          // 20230110 Kimi 增加key.toLoserCase()===part_no
          if (key.toLowerCase() === 'line' || key.toLowerCase() === 'shift' || key.toLowerCase() === 'work_time' || key.toLowerCase() === 'part_no') {
            continue
          }
          const colString = key.split('_')
          if (colString.length < 2) {
            continue
          }
          const stage = colString[0]
          const kpi = colString[1]
          // 没有stage 的加stage
          if (this.colSetting.filter(x => x.label === stage).length === 0) {
            this.colSetting.push({
              label: stage,
              detail: []
            })
          }
          const oneStage = this.colSetting.filter(x => x.label === stage)[0]
          // 当前的栏位是否存在，不存在则添加
          if (oneStage.detail.filter(x => x.prop === key).length === 0) {
            let label = ''
            let width = 90 // 20230110 Kimi 减少宽度
            switch (kpi.toLowerCase()) {
              case 'act':
                label = 'ACT'
                break
              case 'goal':
                label = 'GOAL'
                break
              case 'ratio':
                label = this.$t('dpmDailyReview.colRatio')
                break
              case 'issue':
                label = this.$t('dpmDailyReview.colReasonCode')
                width = 150
                break
              case 'unusualtype':
                label = this.$t('dpmDailyReview.colReasnCategory')
                width = 150
                break
              case 'unusualmessage':
                label = this.$t('dpmDailyReview.colReasonCode')
                width = 150
                break
              case 'status':
                label = this.$t('common.colStatus')
                width = 80
                break
              case 'range':
                label = area === 'FATP' ? this.$t('dpmDailyReview.colOccTime') : this.$t('dpmDailyReview.colImpactTime') // 20230110 Kimi PCBA Title有变
                width = 80 // 20230110 Kimi 减少宽度
                break
              case 'dridept':
                label = this.$t('common.colDRIDept')
                width = 150
                break
              case 'message':
                label = this.$t('dpmDailyReview.colIssueMsg')
                width = 200
                break
              case 'oee2': // 20230110 Kimi 增加OEE2
                label = 'OEE2'
                width = 80
                break
              case 'solution':
                label = this.$t('common.colSolution')
                width = 200
                break
            }
            oneStage.detail.push({
              prop: key,
              label: label,
              width: width
            })
          }
        }

        // console.log(this.colSetting)
        const queryAreaData = this.areaList.filter(x => x.key === this.queryArea)[0].data
        this.queryAreaData = queryAreaData
        if (area === 'FATP') {
          // this.colSetting.forEach(item=>{
          //   this.colSettingFatp = item.detail;
          // })
          // this.colSettingFatp = this.colSetting[0].detail
        }

        // console.log(this.colSettingFatp,'this.colSettingFatp',this.tableIssueDesc)

        // this.filterTable02();
        this.$nextTick(() => {
          // this.$refs.topTable.doLayout()
          this.$refs.tableIssueDesc.doLayout()
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    filterTable02() {
      // 计算合并单元格的行
      this.spanSetting = []
      let lastRowData = ''
      let lastRowIndex = 0
      // console.log(this.tableIssueDesc)
      for (let i = 0; i < this.tableIssueDesc.length; i++) {
      // console.log('=====================================')
        if (i === 0) {
          lastRowData =
          this.tableIssueDesc[i].line +
          this.tableIssueDesc[i].shift +
          this.tableIssueDesc[i].work_time +
          this.tableIssueDesc[i].part_no +
          this.tableIssueDesc[i]['P-RI_goal'] +
          this.tableIssueDesc[i]['P-RI_act'] +
          this.tableIssueDesc[i]['P-RI_ratio'] +
          this.tableIssueDesc[i]['P-RI_oee2']
          lastRowIndex = 0
        }
        const currentRowData =
        this.tableIssueDesc[i].line +
        this.tableIssueDesc[i].shift +
        this.tableIssueDesc[i].work_time +
        this.tableIssueDesc[i].part_no +
        this.tableIssueDesc[i]['P-RI_goal'] +
        this.tableIssueDesc[i]['P-RI_act'] +
        this.tableIssueDesc[i]['P-RI_ratio'] +
        this.tableIssueDesc[i]['P-RI_oee2']
        // console.log('i: ' + i)
        // console.log('lastRowData: ' + lastRowData)
        // console.log('lastRowIndex: ' + lastRowIndex)
        // console.log('currentRowData: ' + currentRowData)
        if (lastRowData !== currentRowData) {
          this.spanSetting.push({
            rowIndex: lastRowIndex,
            rowCount: i - lastRowIndex
          })
          lastRowIndex = i
          lastRowData = currentRowData
        }
        if (i === this.tableIssueDesc.length - 1) {
          this.spanSetting.push({
            rowIndex: lastRowIndex,
            rowCount: i - lastRowIndex + 1
          })
        }
      }
    },
    getIssueLogData(line, shift, worktime, stage) {
      return this.tableIssueAll.filter(x =>
        x.pdline_name === line &&
        x.shift_code === shift &&
        x.work_time === worktime &&
        x.stage_name === stage
      )
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    resizeTable: function() {
      this.$nextTick(function() {
        const divHeight = $('#tabMain').height()
        this.tabDivHeight = divHeight - 55
      })
      const that = this
      // setTimeout(function () {
      //   const tbHeight = $('#kpiMainTableDiv').height()
      //   that.tableHeight = tbHeight
      // }, 100)
      // setTimeout(function () {
      //   const tbHeight = $('#kpiLossDiv').height()
      //   that.kpiLossTableHeight = tbHeight
      // }, 100)
      setTimeout(function() {
        that.tableHeight = $('#kpiMainTableDiv').height()
        that.issueTableHeight = $('#issueMainTableDiv').height()
        that.kpiLossTableHeight = $('#kpiLossDiv').height()
        that.actionTableHeight = $('#actionMainTableDiv').height()
      }, 100)
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep main.el-main{
  padding: 0
}
::v-deep .el-divider--horizontal{
  margin:0
}
.selectMidSize{
  width:120px;
  margin-right:5px;
}
section{
  padding-bottom: 0;
}
.el-header{
    padding:0 5px
}
.header{
  height:40px !important;
  margin-top:5px;
  /* background-color:#1f4e7c; */
  background-color:rgba(0,0,0,0);
}
.title{
  margin-left: 10px;
  display: inline-block;
  line-height: 40px;
  font-size:20px;
}
.pane{
      height:90%;
      overflow-y:auto;
      overflow-x:hidden;
    }
::v-deep .el-carousel__container{
  height:calc(100% - 55px);
  background-color: rgba(0,0,0,0);
}
.kpiDivMainTop{
  height:calc(65% - 5px);
  margin-bottom: 5px;
  width: 100%;
  display:flex;
}
.kpiDivMainBottom{
  height:35%;
  width: 100%;
  display:flex;
}
.kpiDivMainTopLeft{
  height: 100%;
  width:calc(52% - 5px);
  margin-right: 5px;
}
.kpiDivMainTopRight{
  height: 100%;
  width: 48%;
  background-color: white;
}
.kpiDivMainBottomLeft{
  height: 100%;
  // width:calc(65% - 5px);
  width: 100%;
  margin-right: 5px;
}
.kpiDivMainBottomRight{
  height: 100%;
  width: 35%;
  background-color: white;
}
.kpiDivMainTitle{
  width:100%;
  /* background-color: rgb(52,124,184);
  color:white; */
  color: rgb(32,55,100);
  background-color:white;
  height:35px;
  font-size:21px;
  font-style: italic;
  font-weight: bold;
  padding-top: 7px;
  padding-left:15px;
  /* border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  border-bottom: solid 2px rgb(52,124,184); */
}
.kpiDivRadio{
  width:300px;
  height:35px;
  padding-top:10px;
  padding-right:10px;
  // border-top-right-radius: 5px;
  // border-bottom: solid 2px rgb(52,124,184);
}
.kpiDivSelect{
  width:350px;
  height:35px;
  padding-top:5px;
  padding-right:10px;
}
.kpiDivTable{
  width:100%;
  height: calc(100% - 33px);
}
.chartDiv {
  height:calc(100% - 140px);
  width:100%;
  background-color: white;
}
.lossDiv{
  // height:calc(100% - 75px);
  height:calc(100% - 33px);
  width:100%;
  background-color: white;
}
.kpiDivMainTopSelect {
  width:100%;
  text-align: center;
  // border-bottom: 1px solid rgb(52,124,184);
}
.issueDivTable{
  width:100%;
  height: calc(50% - 35px);
}
.kpiSpan{
  display: inline-block;
  height:30px;
  font-size: 16px;
  font-weight: bold;
  margin:10px 20px 0 0;
}
::v-deep .el-table td div{
  font-size: 16px;
}
::v-deep .el-table .cell {
    white-space: pre-line;
}
.escalateTitleSpan{
  display: block;
  color:rgb(52,124,184);
  border-bottom: 1px solid rgb(52,124,184);
  font-size:16px;
  margin:10px 0 5px 0;
  font-weight: bold;
  font-style: italic;
}
::v-deep .el-table th{
  height: 48px;
  padding:5px 0;
}
::v-deep #txtIssueContent {
  color: blue
}
.actionDivTable{
  width:100%;
  height: 100%;
}
::v-deep .el-table td {
  border:1px solid lightgray;
}
.actionItemSpan {
  color: #8492a6; font-size: 13px;
  display: block;
  width: 600px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
</style>
