<template>
  <div style="height:100%;width:100%;" :style="{'background-image':getBackgroundColor()}">
    <el-container style="height:100%;">
      <el-header class="header">
        <div class="titleDiv">
          <div class="titleLeft">
            <img src="../../../public/static/img/Branding_logo.png" class="titleImg">
            <div class="title">{{ dataEntity.title }}</div>
          </div>
          <div>
            <span class="refreshTime">{{ dataEntity.serverTime }}</span>
            <el-dropdown @command="moreMenuClickHandler">
              <el-button size="mini" plain type="primary" style="margin-left:20px;background-color:rgba(0,0,0,0)">
                {{ $t('common.btnOpt') }}<i class="el-icon-arrow-down el-icon--right" />
              </el-button>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item v-if="showReturnMenu" icon="el-icon-arrow-left" command="return">{{ $t('common.btnToPrevLevel') }}</el-dropdown-item>
                <el-dropdown-item icon="el-icon-menu" command="selectline">{{ $t('dpmDashboardLine.btnChooseLine') }}</el-dropdown-item>
                <el-dropdown-item icon="el-icon-data-analysis" command="max" divided>{{ $t('common.btnDashboardMode') }}</el-dropdown-item>
                <el-dropdown-item icon="el-icon-monitor" command="min">{{ $t('common.btnWindowMode') }}</el-dropdown-item>
                <el-dropdown-item v-if="viewRange==='currentshift'" :icon="autoplay===true?'el-icon-video-pause':'el-icon-video-play'" command="play">{{ autoplay===true?$t('common.btnStopCarousel'):$t('common.btnAutoCarousel') }}</el-dropdown-item>
                <el-dropdown-item :icon="autoRefresh===true?'el-icon-close':'el-icon-refresh'" command="refresh">{{ autoRefresh===true?$t('common.btnStopRefresh'):$t('common.btnAutoRefresh') }}</el-dropdown-item>
                <el-dropdown-item icon="el-icon-view" command="viewrange">{{ viewRange==='currentshift'?$t('common.btnShowPrevShift'):$t('common.btnShowCurrentShift') }}</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </div>
      </el-header>
      <el-main style="padding:0;">
        <el-divider />
        <div class="summaryTitle">
          <div class="mainSummaryDiv mainSummaryDiv1">
            <div class="mainSDivDay">
              <span class="mainSpanCategory">Online DL:</span>
              <span class="mainSSpanValue mainSSpanValue1">
                <span class="prevWord">ACT</span>{{ dataEntity.onlineDLQty }}
                /
                <span class="prevWord">STD</span>{{ dataEntity.onlineDLTargetQty }}
              </span>
            </div>
          </div>
          <!-- 20221213 Kimi 该层级没有数据，屏蔽掉 -->
          <!-- <div class="mainSummaryDiv mainSummaryDiv2">
                  <div class="mainSDivDay">
                      <span class="mainSpanCategory">Offline Var DL:</span>
                      <span class="mainSSpanValue mainSSpanValue2">{{dataEntity.offlineVarDLQty}}</span>
                  </div>
              </div>
              <div class="mainSummaryDiv mainSummaryDiv3">
                  <div class="mainSDivDay">
                      <span class="mainSpanCategory">Offline Fix DL:</span>
                      <span class="mainSSpanValue mainSSpanValue3">{{dataEntity.offlineFixDLQty}}</span>
                  </div>
              </div> -->
          <div class="mainSummaryDiv mainSummaryDiv4" :style="{'border-bottom': setSelectedColor('all')}">
            <div class="mainSDivDay">
              <span class="mainSpanCategory">{{ $t('dpmDashboardLine.lblTotalLineQty') }}:</span>
              <el-link :underline="false" @click="lineShowFilter('all')">
                <span class="mainSSpanValue mainSSpanValue4">{{ dataEntity.totalLineQty }}</span>
              </el-link>
            </div>
          </div>
          <div class="mainSummaryDiv mainSummaryDiv5" :style="{'border-bottom': setSelectedColor('workline')}">
            <div class="mainSDivDay">
              <span class="mainSpanCategory">{{ $t('dpmDashboardLine.lblOpenLineQty') }}:</span>
              <el-link :underline="false" @click="lineShowFilter('workline')">
                <span class="mainSSpanValue mainSSpanValue5">{{ dataEntity.workLineQty }}</span>
              </el-link>
            </div>
          </div>
          <div class="mainSummaryDiv mainSummaryDiv6" :style="{'border-bottom': setSelectedColor('offline')}">
            <div class="mainSDivDay">
              <span class="mainSpanCategory">{{ $t('dpmDashboardLine.lblNotOpenLineQty') }}:</span>
              <el-link :underline="false" @click="lineShowFilter('offline')">
                <span class="mainSSpanValue mainSSpanValue6">{{ dataEntity.offLineQty }}</span>
              </el-link>
            </div>
          </div>
        </div>
        <el-carousel id="carousel" indicator-position="outside" style="height:calc(100% - 55px)" :autoplay="autoplay" :interval="15000">
          <el-carousel-item v-for="item in bigChartData" :key="item.id">
            <div class="lineGroup" :style="{'flex-direction':getOrientation(item)}">
              <div v-for="(onelineData,index) in item.data" :key="index" class="oneLine">
                <lineComp :onedata="onelineData" @showdg="showdg" />
              </div>
            </div>
          </el-carousel-item>
        </el-carousel>
      </el-main>
    </el-container>

    <el-dialog
      :center="true"
      :title="selectFilterTitle"
      :close-on-press-escape="false"
      :visible.sync="selectFilterDialogVisible"
      width="300px"
      :close-on-click-modal="false"
    >
      <el-table
        v-loading="loading"
        :data="tableFilterData"
        size="small"
        height="300"
        style="width: 100%;"
        @selection-change="filterTableChange"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column prop="data" :label="filterColName" width="150" />
        <el-table-column v-if="false" prop="key" />
      </el-table>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="saveSelectedFilter">{{ $t('common.btnSave') }}</el-button>
        <el-button size="small" @click="closeSelectFilterDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <div v-if="showOpt">
      <optComp :onedata="sendtooperate" @closedg="closedg" />
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import {
  GetDPMQueryKeyValue, GetDPMDashboardData, GetDPMDashboardParentId
} from '@/api/midway.js'
import lineComp from '@/components/MIDWAY/DPMDashboardOneLine.vue'
import optComp from '@/components/MIDWAY/DPMDashboardOperateModule.vue'
export default {
  components: {
    lineComp,
    optComp
  },
  data() {
    return {
      showOpt: false,
      sendtooperate: {
        keyword: '',
        index: '',
        level: '',
        id: 0,
        viewrange: ''
      },
      viewRange: 'currentshift',
      showReturnMenu: true,
      parentId: '0',
      selectedCode: [],
      userAllCode: [],
      selectFilterTitle: '',
      tableFilterData: [],
      filterColName: '',
      filterTableSelected: [],
      selectFilterDialogVisible: false,
      origChartData: [],
      dataEntity: {
        title: 'DPM Line',
        shift: '',
        onlineDLQty: '0',
        onlineDLTargetQty: '0',
        offlineVarDLQty: '0',
        offlineFixDLQty: '0',
        totalLineQty: '0',
        workLineQty: '0',
        offLineQty: '0',
        hasError: 'N',
        serverTime: '',
        chartData: []
      },
      loadingData: null,
      onePicLines: 2,
      colQty: 1,
      rowQty: 1,
      level: 'line',
      keyid: '',
      loading: false,
      autoplay: false,
      autoRefresh: false,
      refreshTimer: null,
      bigChartData: [],
      chartData: [],
      mainHeight: 1,
      mainWidth: 1
    }
  },
  computed: {
  },
  mounted() {
    this.initialData()
    window.onresize = () => {
      this.resetDashboard()
    }
  },
  beforeDestroy() {
    clearInterval(this.refreshTimer)
  },
  methods: {
    getBackgroundColor() {
      if (this.viewRange === 'currentshift') {
        return 'radial-gradient(#26589A, #191D50)'
      } else {
        return 'radial-gradient(#60c8d2,#191D50)'
      }
    },
    async initialData() {
      this.keyid = this.$route.query.keyid // 当前的keyid是area的id
      // this.parentId = this.$route.query.factory // line退回去就是area层级，area的parent就是factory的id（退回area层级时，keyid就是factoryid）
      this.parentId = this.$route.query.parent
      const storageKey = 'market_dpm_selectedline_' + this.keyid
      const queryKeyType = 'userline'
      // 抓取本地缓存的选择的项目
      const saveedObj = window.localStorage.getItem(storageKey)
      if (!saveedObj) {
        this.selectedCode = []
      } else {
        this.selectedCode = JSON.parse(saveedObj)
      }
      // 筛选当前用户可以看到的项目
      if (this.keyid === undefined) {
        this.keyid = ''
      }
      const data = {
        type: queryKeyType,
        key: this.keyid
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.userAllCode = obj
      } else {
        this.alertMsg(queryResult)
        return
      }
      // 如果当前用户没有筛选过项目，则显示他能看到的所有项目，否则只显示筛选过的项目
      if (this.selectedCode.length === 0) {
        this.selectedCode = this.userAllCode
      } else {
        for (let i = this.selectedCode.length - 1; i >= 0; i--) {
          const p = this.selectedCode[i].data
          // 只看有权限的想，可能上次看过后原来的权限有被删除，但是缓存了，因此在此比对一下，删除没有的项目权限
          if (this.userAllCode.filter(u => u.data === p).length === 0) {
            this.selectedCode.splice(i, 1)
          }
        }
      }
      // 将新的项目清单缓存起来
      window.localStorage.removeItem(storageKey)
      window.localStorage.setItem(storageKey, JSON.stringify(this.selectedCode))

      // 抓取是看当班还是前已班的数据
      const viewRangeObj = window.localStorage.getItem('market_dpm_viewrange')
      if (!viewRangeObj) {
        this.viewRange = 'currentshift'
      } else {
        this.viewRange = viewRangeObj
      }
      if (this.viewRange !== 'currentshift' && this.viewRange !== 'previousshift') {
        this.viewRange = 'currentshift'
      }
      window.localStorage.setItem('market_dpm_viewrange', this.viewRange)

      // 抓取项目数据显示在看板上
      this.getDashBoardData()
    },
    async showPrevLevel() {
      const data = {
        level: 'team',
        id: this.keyid
      }
      const response = await GetDPMDashboardParentId(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const pId = response.data.ReturnObject
        const query = {
          level: 'team',
          keyid: pId
        }
        this.$router.push({
          path: '/DPMDashboardTeam',
          query: query
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getDashBoardData() {
      let key = ''
      // 将area串联起来
      this.selectedCode.forEach(x => {
        key = key + x.key + ';'
      })
      key = this.keyid + ',' + key

      if (key !== '') {
        key = key.substr(0, key.length - 1)
      }
      const data = {
        level: this.level,
        key: key,
        viewrange: this.viewRange
      }
      // console.log('----clickcode----')
      // console.log(data)
      // console.log('----clickcode----')
      // 查询数据
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoading'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await GetDPMDashboardData(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.dataEntity.title = obj.title
        this.dataEntity.shift = obj.shift
        this.dataEntity.onlineDLQty = obj.online_dl_qty
        this.dataEntity.onlineDLTargetQty = obj.online_dl_target_qty
        this.dataEntity.offlineVarDLQty = obj.offline_var_dl_qty
        this.dataEntity.offlineFixDLQty = obj.offline_fix_dl_qty
        this.origChartData = obj.data // 20221203 Kimi 独立出一个chart的变量，供后面按是否开线筛选线体用
        // ----------------------------------------------------
        // 20221203 Kimi 线层级增加开线数量显示
        this.dataEntity.totalLineQty = obj.total_line_qty
        this.dataEntity.workLineQty = obj.work_line_qty
        this.dataEntity.offLineQty = obj.off_line_qty
        // ----------------------------------------------------
        // this.dataEntity.hasError = obj.has_error
        this.dataEntity.serverTime = obj.server_time
        if (obj.top_level === this.level) {
          this.showReturnMenu = false
        }

        const lineShowObj = window.localStorage.getItem('market_dpm_lineshowfilter')
        if (!lineShowObj) {
          this.lineShowFilter('all')
        } else {
          this.lineShowFilter(lineShowObj)
        }
        // this.dataEntity.chartData = obj.data
        // this.resetDashboard()
        const that = this
        // 第一次渲染比较慢，导致无法获取到DIV的宽度和高度，显示以后刷新一次
        setTimeout(function() {
          that.resetDashboard()
        }, 200)
      } else {
        this.alertMsg(queryResult)
      }
    },
    lineShowFilter(type) {
      window.localStorage.setItem('market_dpm_lineshowfilter', type)
      this.dataEntity.chartData = []
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoadingQuery'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      this.origChartData.forEach(t => {
        if (type === 'all') {
          this.dataEntity.chartData.push(t)
        } else if (type === 'workline') {
          if (t.work_flag === 'Y') {
            this.dataEntity.chartData.push(t)
          }
        } else if (type === 'offline') {
          if (t.work_flag === 'N') {
            this.dataEntity.chartData.push(t)
          }
        }
      })
      this.resetDashboard()
      this.loadingData.close()
    },
    resetDashboard: function() {
      this.$nextTick(function() {
        const divHeight = $('#carousel').height()
        const divWidth = $('#carousel').width()
        this.mainHeight = divHeight - 51 // 刨去底部留白和幻灯片切换条的空间
        this.mainWidth = divWidth
        // console.log('-------------------------')
        // console.log(this.mainHeight)
        // console.log(this.mainWidth)
        // alert(this.mainHeight + ',' + this.mainWidth)
        const oneWidth = $('.oneLineDiv').width() // 900
        const oneHeight = $('.oneLineDiv').height() // 900
        // console.log('onwwidth: ' + oneWidth) // 200
        this.colQty = parseInt(this.mainWidth / (oneWidth + 10)) // 1页显示几列，加上左右margin
        this.rowQty = parseInt(this.mainHeight / (oneHeight + 15)) // 1页显示几行，加上上下margin
        if (this.colQty === 0) {
          this.colQty = 1
        }
        // console.log('col: ' + this.colQty)
        // console.log('row: ' + this.rowQty)
        const lineQty = this.dataEntity.chartData.length
        this.onePicLines = this.colQty * this.rowQty // 计算每个幻灯片可以放几条线
        // const picQty = Math.ceil(lineQty / this.onePicLines) // 计算需要多少个幻灯片
        this.bigChartData = [] // 总数据集合
        let oneGroupCharts = [] // 当前页线体内容集合
        let insertQtyInThisPic = 0 // 当前页塞了几条线
        let currIndex = 1 // 当前页码
        let insertQty = 0 // 一共塞了几条线
        for (let i = 0; i < lineQty; i++) {
          oneGroupCharts.push(this.dataEntity.chartData[i])
          insertQty = insertQty + 1
          insertQtyInThisPic = insertQtyInThisPic + 1
          if ((insertQtyInThisPic % this.onePicLines === 0) || insertQty >= lineQty) {
            this.bigChartData.push({
              id: currIndex,
              data: oneGroupCharts
            })
            oneGroupCharts = []
            insertQtyInThisPic = 0
            currIndex = currIndex + 1
          }
        }
      // console.log('---big---')
      // console.log(this.bigChartData)
      // console.log('---big---')
      })
    },
    filterTableChange(val) {
      this.filterTableSelected = val
    },
    saveSelectedFilter() {
      this.selectedCode = this.filterTableSelected
      const storageKey = 'market_dpm_selectedline_' + this.keyid
      window.localStorage.removeItem(storageKey)
      window.localStorage.setItem(storageKey, JSON.stringify(this.selectedCode))
      this.getDashBoardData()
      this.closeSelectFilterDialog()
    },
    closeSelectFilterDialog() {
      this.selectFilterDialogVisible = false
    },
    showdg: function(param) {
      this.sendtooperate = {
        keyword: param.keyword,
        index: param.type,
        level: this.level,
        id: param.keyid,
        viewrange: this.viewRange
      }
      this.showOpt = true
    },
    closedg() {
      this.showOpt = false
    },
    getOrientation(item) {
    // 如果内容少于1页，就用column方向排列
    // return this.level === 'area' ? 'column' : 'row'
    // console.log(item.data.length)
    // console.log(this.onePicLines)
      const qty = item.data.length
      if (qty < this.onePicLines / 2) {
        return 'column'
      } else {
        return 'row'
      }
    // if (qty === 1) {
    //   return 'row'
    // }
    // if (qty === this.lineQty) {
    //   return 'column'
    // }
    // return this.bigChartData.length < 2 ? 'column' : 'row'
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    moreMenuClickHandler(command) {
      if (command === 'return') {
        if (this.level === undefined || this.level === '' || this.level === 'factory') {
          return
        }
        this.showPrevLevel()
      } else if (command === 'selectline') {
        this.filterColName = this.$t('dpmDashboardLine.btnChooseLine')
        this.selectFilterTitle = this.$t('dpmDashboardLine.lblSelectFilterTitle')
        this.showFilterDailog()
      } else if (command === 'max' || command === 'min') {
      // 调整界面
        const model = {
          type: command
        }
        this.$emit('change-show-model', model)
        const that = this
        setTimeout(function() {
          that.resetDashboard()
          that.fullScreen(command)
        }, 300)
      } else if (command === 'play') {
        this.autoplay = !this.autoplay
      } else if (command === 'refresh') {
        this.autoRefresh = !this.autoRefresh
        const that = this
        if (this.autoRefresh) {
          this.refreshTimer = setInterval(function() {
            if (that.viewRange === 'currentshift') {
              that.initialData(that.level, that.keyid)
            }
          }, 120000)
        } else {
          clearInterval(this.refreshTimer)
        }
      } else if (command === 'viewrange') {
        if (this.viewRange === 'currentshift') {
          this.viewRange = 'previousshift'
        } else {
          this.viewRange = 'currentshift'
        }
        window.localStorage.setItem('market_dpm_viewrange', this.viewRange)
        this.initialData()
      }
    },
    async showFilterDailog() {
      const data = {
        type: 'userline',
        key: this.keyid
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.tableFilterData = obj
        this.filterTableSelected = []
        this.selectFilterDialogVisible = true
      } else {
        this.alertMsg(queryResult)
      }
    },
    fullScreen(type) {
      if (type === 'max') {
        const el = document.documentElement
        const rfs = el.requestFullscreen || el.webkitRequestFullScreen || el.mozRequestFullScreen || el.msRequestFullScreen
        if (typeof rfs !== 'undefined' && rfs) {
          rfs.call(el)
        }
      } else {
        const el = document
        const rfs = el.cancelFullScreen || el.webkitCancelFullScreen || el.mozCancelFullScreen || el.exitFullScreen
        if (typeof rfs !== 'undefined' && rfs) {
          rfs.call(el)
        }
      }
    },
    // 20221203 Kimi 对选择的开线情况加白色下划线提示
    setSelectedColor(type) {
      let currentType = 'all'
      const lineShowObj = window.localStorage.getItem('market_dpm_lineshowfilter')
      if (!lineShowObj) {
        currentType = 'all'
      } else {
        currentType = lineShowObj
      }
      if (currentType === type) {
        return '2px solid white'
      }
      return ''
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep main.el-main{
padding: 0
}
::v-deep .el-divider--horizontal{
margin:0
}
section{
padding-bottom: 0;
}
.el-header{
  padding:0 5px
}
.header{
height:50px !important;
// background-color:#1f4e7c;
background-color:rgba(0,0,0,0);
}
.titleDiv{
display:flex;
justify-content: space-between;
color:white;
}
.title{
line-height: 50px;
font-size:28px;
}
.titleImg{
// padding:5px 20px 5px 20px;
margin-top:8px;
margin-left:10px;
margin-right:20px;
width:160px;
height:35px;
}
.titleLeft{
display: flex;
}
.refreshTime{
display: inline-block;
line-height: 40px;
padding-top:5px;
font-size:20px;
}
.summaryTitle{
display: flex;
justify-content: flex-start;
// align-items: center;
flex-wrap: nowrap;
height: 50px;
// width:100%;
background-color: rgba(0,0,0,0);
}
.mainSDivDay{
  // width: 50%;
  height: 100%;
  float: left;
}
.mainSpanCategory{
  font-size:18px;
  line-height: 50px;
  display: inline-block;
  color: white;
}
.mainSummaryDiv{
  height:50px;
  padding-left:8px;
  margin-bottom: 10px;
  flex: none;
}
.prevWord{
font-size:14px;
display: inline-block;
color:white;
padding-right:10px;
}
.mainSummaryDiv1{
  border-left: 8px solid #359CB6;
}
.mainSummaryDiv2{
  border-left: 8px solid #38c386;
}
.mainSummaryDiv3{
  border-left: 8px solid #f49e12;
}
.mainSummaryDiv4{
border-left: 8px solid #30aecd;
}
.mainSummaryDiv5{
border-left: 8px solid #2c8a20;
}
.mainSummaryDiv6{
  border-left: 8px solid rgb(128,128,128);
}
.mainSummaryDivBottom{
border-bottom: 2px solid red;
}
.mainSSpanValue{
font-size: 30px;
// float: right;
line-height: 50px;
margin-left: 20px;
margin-right: 20px;
}
.mainSSpanValue1{
  color:#359CB6;
}
.mainSSpanValue2{
  color:#38c386;
}
.mainSSpanValue3{
  color:#f49e12;
}
.mainSSpanValue4{
  color:#30aecd;
}
.mainSSpanValue5{
  color:#2c8a20;
}
.mainSSpanValue6{
  color:rgb(128,128,128);
}
.lineGroup{
display: flex;
justify-content: center;
align-items: center;
flex-wrap: wrap;
// height: 800px;
height:calc(100% - 55px)
}
.oneLine{
margin:15px 5px 0 5px;
}
::v-deep .el-carousel__container{
height:calc(100% - 55px);
background-color: rgba(0,0,0,0);
}
</style>
