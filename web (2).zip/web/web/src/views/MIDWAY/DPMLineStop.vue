<template>
  <div style="height:100%;width:100%">
    <el-container style="height:100%;width:100%">
      <el-header style="padding:0;height:40px">
        <el-date-picker
          v-model="pickDates"
          style="width:250px"
          type="daterange"
          align="right"
          unlink-panels
          :picker-options="pickerOptions1"
          :start-placeholder="$t('common.phdStartDate')"
          :end-placeholder="$t('common.phdEndDate')"
          size="small"
        />
        <el-select v-model="queryPlant" :placeholder="$t('common.phdSelectFactory')" size="small" style="width:120px;margin-left:5px" @change="getUserArea">
          <el-option
            v-for="item in plantList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryArea" :placeholder="$t('common.phdSelectArea')" size="small" style="width:100px;margin-left:5px" @change="getUserTeam">
          <el-option
            v-for="item in areaList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryTeam" :placeholder="$t('common.phdSelectTeam')" size="small" multiple collapse-tags style="width:230px;margin-left:5px" @change="getUserLine">
          <el-option
            v-for="item in teamList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryLine" :placeholder="$t('common.phdSelectLine')" size="small" style="width:130px;margin:0 5px">
          <el-option
            v-for="item in lineList"
            :key="item.key"
            :label="item.data"
            :value="item.data"
          />
        </el-select>
        <el-button type="primary" size="small" @click="queryData(true)">{{ $t('common.btnQuery') }}</el-button>
        <el-button type="success" size="small" style="margin-left:20px" @click="addNewSetting">{{ $t('dpmLineStop.btnAddRecord') }}</el-button>
      </el-header>
      <el-main style="padding:0;height:100%">
        <div id="tableContainer" style="height:100%;">
          <el-table
            v-loading="loadingDetail"
            :data="tableData"
            size="mini"
            :height="tableHeight"
            style="width: 100%;"
          >
            <el-table-column prop="status" :label="$t('common.colOpt')" width="70" align="center">
              <template slot-scope="scope">
                <el-button v-show="scope.row.delete_flag==='Y'" type="text" size="small" style="color:red" @click="deleteData(scope.row)">{{ $t('common.btnDel') }}</el-button>
              </template>
            </el-table-column>
            <el-table-column prop="seq" :label="$t('common.colSeq')" width="60" />
            <el-table-column prop="factory" :label="$t('common.colFactory')" width="70" align="center" />
            <el-table-column prop="area" :label="$t('common.colArea')" width="80" align="center" show-overflow-tooltip />
            <el-table-column prop="team" label="Team" width="120" align="center" show-overflow-tooltip />
            <el-table-column prop="line" :label="$t('common.colLine')" width="120" align="center" show-overflow-tooltip />
            <el-table-column prop="work_date" :label="$t('common.colWorkDay')" width="85" align="center" />
            <el-table-column prop="shift" :label="$t('common.colShift')" width="60" align="center" />
            <el-table-column prop="off_time" :label="$t('dpmLineStop.colOffTime')" width="160" align="center" />
            <el-table-column prop="user_name" :label="$t('dpmLineStop.colUpdateUser')" width="100" show-overflow-tooltip />
            <el-table-column prop="update_time" :label="$t('dpmLineStop.colUpdateTime')" width="160" align="center" show-overflow-tooltip />
            <el-table-column prop="memo" :label="$t('dpmLineStop.colOffTimeReason')" width="260" show-overflow-tooltip header-align="center" />
          </el-table>
        </div>
      </el-main>
      <el-footer style="margin:0 auto">
        <el-pagination
          :current-page="pageIndex"
          :page-sizes="[30, 50, 100]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </el-footer>
    </el-container>

    <el-dialog
      :center="true"
      :title="$t('dpmLineStop.lblTitleAddOffTime')"
      :close-on-press-escape="false"
      top="3vh"
      :visible.sync="addSetiingDialogVisible"
      width="1050px"
      :close-on-click-modal="false"
    >
      <div>
        <el-select v-model="queryMTPlant" :placeholder="$t('common.phdSelectFactory')" size="small" style="width:120px;margin-left:5px" @change="getUserMTArea">
          <el-option
            v-for="item in plantMTList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryMTArea" :placeholder="$t('common.phdSelectArea')" size="small" style="width:100px;margin-left:5px" @change="getUserMTTeam">
          <el-option
            v-for="item in areaMTList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryMTTeam" :placeholder="$t('common.phdSelectTeam')" size="small" style="width:230px;margin-left:5px" @change="getUserMTLine">
          <el-option
            v-for="item in teamMTList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
      </div>
      <div>
        <span>{{ $t('dpmLineStop.lblTitleOffTimeWorkDay') }}</span>
        <el-date-picker v-model="pickWorkDay" style="width:140px;margin:5px 5px 0 5px" type="date" align="right" size="small" :picker-options="pickerOptions2" />
        <el-select v-model="offShift" size="small" style="width:90px;margin-right:5px">
          <el-option
            v-for="item in workshiftList"
            :key="item.shift_code"
            :label="item.shift_name"
            :value="item.shift_code"
          />
          <!-- <el-option :label="$t('common.lblShiftD')" value="D" />
          <el-option :label="$t('common.lblShiftM')" value="M" />
          <el-option :label="$t('common.lblShiftN')" value="N" /> -->
        </el-select>
        <el-input v-model="offMemo" size="small" style="width:120px;margin-right:5px" :placeholder="$t('dpmLineStop.phdOffTimeReason')" />
        <el-button type="warning" size="small" @click="useThisMemo">{{ $t('dpmLineStop.lblAllUseThisReason') }}</el-button>
        <el-date-picker v-model="offTime" type="datetime" size="small" style="width:200px;margin:0 5px" :placeholder="$t('dpmLineStop.phdOffTimeTime')" />
        <el-button type="warning" size="small" @click="useThisTime">{{ $t('dpmLineStop.lblAllUseThisTime') }}</el-button>
      </div>
      <div class="selectLineDiv">
        <div class="selectLineLeftDiv">
          <div class="tableTitle">{{ $t('dpmLineStop.lblCanSelectLine') }}</div>
          <el-table
            v-loading="loadingLine"
            :data="tableAllLine"
            size="mini"
            :height="360"
            style="width: 100%;"
            @selection-change="selectTableChange"
          >
            <el-table-column type="selection" width="55" />
            <el-table-column prop="team" label="Team" width="110" align="center" show-overflow-tooltip />
            <el-table-column prop="line" :label="$t('common.colLine')" width="120" align="center" show-overflow-tooltip />
          </el-table>
        </div>
        <div class="selectLineRightDiv">
          <div class="tableTitle">{{ $t('dpmLineStop.lblSelectedLine') }}</div>
          <el-table
            :data="tableSelectedLine"
            size="mini"
            :height="360"
            style="width: 100%;"
          >
            <el-table-column prop="team" label="Team" width="110" align="center" show-overflow-tooltip />
            <el-table-column prop="line" :label="$t('common.colLine')" width="110" align="center" show-overflow-tooltip />
            <el-table-column prop="time" :label="$t('dpmLineStop.colOffTimeTime')" width="200" align="center">
              <template slot-scope="scope">
                <el-date-picker v-model="scope.row.time" type="datetime" style="width:190px" size="mini" />
              </template>
            </el-table-column>
            <el-table-column prop="memo" :label="$t('dpmLineStop.colOffTimeReason')" width="150" header-align="center">
              <template slot-scope="scope">
                <el-input v-model="scope.row.memo" size="mini" />
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="saveSetting">{{ $t('common.btnSave') }}</el-button>
        <el-button size="small" @click="closeSettingDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

  </div>
</template>
<script>
import $ from 'jquery'
import {
  GetDPMLineOffLog, GetDPMQueryKeyValue, SaveDPMLineOffData, DeleteDPMLineOffData, GetWorkshiftList
} from '@/api/midway.js'

export default {
  data() {
    return {
      pickerOptions1: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      pickerOptions2: {
        disabledDate(time) {
          return time.getTime() < Date.now() - 36 * 60 * 60 * 1000
        }
      },
      pickDates: [],
      queryPlant: '',
      queryMTPlant: '',
      queryArea: '',
      queryMTArea: '',
      queryTeam: [],
      queryMTTeam: [],
      queryLine: '',
      plantList: [],
      plantMTList: [],
      areaList: [],
      areaMTList: [],
      teamList: [],
      teamMTList: [],
      lineList: [],
      lineMTList: [],
      queryScope: 'all',
      tableHeight: 1,
      tableData: [],
      loading: false,
      loadingDetail: false,
      filter: '',
      pageIndex: 1,
      pageSize: 50,
      total: 0,
      addSetiingDialogVisible: false,
      loadingData: null,
      tableSelectedLine: [],
      tableAllLine: [],
      loadingLine: false,
      pickWorkDay: null,
      workshiftList: [],
      offShift: 'D',
      offMemo: '',
      offTime: null
    }
  },
  mounted() {
    this.getDefaultDate()
    this.getUserPlant()
    this.getUserMTPlant()
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
    }
  },
  methods: {
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    async deleteData(row) {
      if (!confirm(this.$t('dpmLineStop.altMsgConfirmDel'))) {
        return
      }
      const data = {
        factory: row.factory,
        area: row.area,
        workDay: row.work_date,
        shift: row.shift,
        lineId: row.line_id
      }
      const response = await DeleteDPMLineOffData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.queryData(false)
      } else {
        this.alertMsg(queryResult)
      }
    },
    getDefaultDate() {
      const curDate = new Date()
      this.pickDates.push(new Date(curDate.getTime() - 48 * 60 * 60 * 1000))
      this.pickDates.push(new Date(curDate))
      this.pickWorkDay = curDate
    },
    handleSizeChange: function(val) {
      this.pageSize = val
    },
    handleCurrentChange: function(val) {
      this.pageIndex = val
      this.queryData(false)
    },
    async getUserPlant() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.plantList = []
      this.queryPlant = ''
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = []
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.plantList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getWorkDayWorkshift() {
      this.workshiftList = []
      const data = {
        factory: this.plantList.filter(x => x.key === this.queryPlant)[0].data,
        hasALL: 'N'
      }
      const response = await GetWorkshiftList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.workshiftList = response.data.ReturnObject
      } else {
        this.alertMsg(
          this.$utils.ReplacePlaceHolder(
            this.$t('dpmDashboardLineDetail.altMsgCannotGetShift'),
            [queryResult]
          )
        )
      }
    },
    async getUserArea() {
      this.getWorkDayWorkshift()
      const data = {
        type: 'userarea',
        key: this.queryPlant
      }
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = []
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserTeam() {
      const data = {
        type: 'userteam',
        key: this.queryArea
      }
      this.teamList = []
      this.queryTeam = []
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.teamList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserLine() {
      this.lineList = []
      this.queryLine = ''
      if (this.queryTeam.length === 1) {
        const data = {
          type: 'userline',
          key: this.queryTeam
        }
        const response = await GetDPMQueryKeyValue(data)
        const queryResult = response.data.QueryResult
        if (queryResult === 'OK') {
          this.lineList.push({
            key: 'all',
            data: 'ALL'
          })
          const obj = response.data.ReturnObject
          obj.forEach(x => {
            this.lineList.push(x)
          })
        } else {
          alert(queryResult)
        }
      } else {
        this.lineList.push({
          key: 'all',
          data: 'ALL'
        })
      }
    },
    async getUserMTPlant() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.plantMTList = []
      this.queryMTPlant = ''
      this.areaMTList = []
      this.queryMTArea = ''
      this.teamMTList = []
      this.queryMTTeam = ''
      this.lineMTList = []
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.plantMTList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserMTArea() {
      const data = {
        type: 'userarea',
        key: this.queryMTPlant
      }
      this.tableAllLine = []
      this.tableSelectedLine = []
      this.areaMTList = []
      this.queryMTArea = ''
      this.teamMTList = []
      this.queryMTTeam = ''
      this.lineMTList = []
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaMTList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserMTTeam() {
      const data = {
        type: 'userteam',
        key: this.queryMTArea
      }
      this.tableAllLine = []
      this.tableSelectedLine = []
      this.teamMTList = []
      this.queryMTTeam = ''
      this.lineMTList = []
      this.loadingLine = true
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.teamMTList = response.data.ReturnObject
        for (let i = 0; i < this.teamMTList.length; i++) {
          const dataLine = {
            type: 'userline',
            key: this.teamMTList[i].key
          }
          const team = this.teamMTList[i].data
          const responseLine = await GetDPMQueryKeyValue(dataLine)
          const queryResultLine = responseLine.data.QueryResult
          if (queryResultLine === 'OK') {
            const objLine = responseLine.data.ReturnObject
            objLine.forEach(x => {
              this.tableAllLine.push({
                team: team,
                line: x.data,
                memo: '',
                time: ''
              })
            })
          } else {
            this.loadingLine = false
            alert(queryResultLine)
            return
          }
        }
        this.loadingLine = false
      } else {
        this.loadingLine = false
        alert(queryResult)
      }
    },
    async queryData(resetIndex) {
      if (this.pickDates.length === 0) {
        this.alertMsg(this.$t('dpmLineStop.altMsgWorkDayEmpty'))
        return
      }
      if (this.queryPlant === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgFactoryEmpty'))
        return
      }
      if (this.queryArea === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgAreaEmpty'))
        return
      }
      if (this.queryTeam.length === 0) {
        this.alertMsg(this.$t('dpmLineStop.altMsgTeamEmpty'))
        return
      }
      let teams = ''
      this.queryTeam.forEach(t => {
        teams = teams + this.teamList.filter(x => x.key === t)[0].data + ','
      })
      if (teams.substr(teams.length - 1, 1) === ',') {
        teams = teams.substr(0, teams.length - 1)
      }
      if (resetIndex) {
        this.pageIndex = 1
      }
      const begin = this.$utils.GetDateString(this.pickDates[0])
      const end = this.$utils.GetDateString(this.pickDates[1])
      const factory = this.plantList.filter(x => x.key === this.queryPlant)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const data = {
        factory: factory,
        area: area,
        teams: teams,
        line: this.queryLine,
        begin: begin,
        end: end,
        status: this.queryScope,
        pageIndex: this.pageIndex,
        pageSize: this.pageSize
      }
      this.loadingDetail = true
      const response = await GetDPMLineOffLog(data)
      this.loadingDetail = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.total = response.data.ReturnObject.total
        this.tableData = response.data.ReturnObject.queryData
      } else {
        alert(queryResult)
      }
    },
    async getUserMTLine() {
      this.tableAllLine = []
      this.tableSelectedLine = []
      const data = {
        type: 'userline',
        key: this.queryMTTeam
      }
      this.loadingLine = true
      const team = this.teamMTList.filter(x => x.key === this.queryMTTeam)[0].data
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        obj.forEach(x => {
          this.tableAllLine.push({
            team: team,
            line: x.data,
            memo: '',
            time: ''
          })
        })
        this.loadingLine = false
      } else {
        this.loadingLine = false
        alert(queryResult)
      }
    },
    resizeTable: function() {
      this.$nextTick(function() {
        const divHeight = $('#tableContainer').height()
        this.tableHeight = divHeight
      })
    },
    async saveSetting() {
      if (this.tableSelectedLine.length === 0) {
        return
      }
      if (this.pickWorkDay === null) {
        this.alertMsg(this.$t('dpmLineStop.altMsgWorkDayEmpty'))
        return
      }
      if (this.offShift === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgShiftEmpty'))
        return
      }
      let submitData = ''
      for (let i = 0; i < this.tableSelectedLine.length; i++) {
        if (this.tableSelectedLine[i].time === '' || this.tableSelectedLine[i].time === null) {
          // this.alertMsg(this.tableSelectedLine[i].line + ' 的下班時間沒有填寫')
          this.alertMsg(
            this.$utils.ReplacePlaceHolder(
              this.$t('dpmLineStop.altMsgMissOffTime'),
              [this.tableSelectedLine[i].line])
          )
          return
        }
      }
      for (let i = 0; i < this.tableSelectedLine.length; i++) {
        this.tableSelectedLine[i].memo = this.tableSelectedLine[i].memo.replace(/#/g, '')
        if (this.tableSelectedLine[i].memo === '') {
          // this.alertMsg(this.tableSelectedLine[i].line + ' 的下班理由沒有填寫')
          this.alertMsg(
            this.$utils.ReplacePlaceHolder(
              this.$t('dpmLineStop.altMsgMissOffTimeReason'),
              [this.tableSelectedLine[i].line])
          )
          return
        }
        const time = this.$utils.GetDateTimeString(this.tableSelectedLine[i].time)
        submitData = submitData + this.tableSelectedLine[i].team + '|' + this.tableSelectedLine[i].line +
          '|' + time + '|' + this.tableSelectedLine[i].memo + '#'
      }
      if (!confirm(this.$t('dpmLineStop.altMsgConfirmSubmit'))) {
        return
      }
      submitData = submitData.substr(0, submitData.length - 1)
      const workDay = this.$utils.GetDateString(this.pickWorkDay)
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoadingSubmit'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const data = {
        factory: this.plantMTList.filter(x => x.key === this.queryMTPlant)[0].data,
        area: this.areaMTList.filter(x => x.key === this.queryMTArea)[0].data,
        workDay: workDay,
        shift: this.offShift,
        submitData: submitData
      }
      const response = await SaveDPMLineOffData(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.closeSettingDialog()
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    addNewSetting() {
      this.offMemo = ''
      this.offTime = null
      this.tableAllLine = []
      this.tableSelectedLine = []
      this.addSetiingDialogVisible = true
    },
    closeSettingDialog() {
      this.addSetiingDialogVisible = false
    },
    selectTableChange(val) {
      this.tableSelectedLine = val
    },
    useThisMemo() {
      if (this.tableSelectedLine.length === 0) {
        this.alertMsg(this.$t('dpmLineStop.altMsgNoLineSelect'))
        return
      }
      if (this.offMemo === '') {
        this.alertMsg(this.$t('dpmLineStop.altMsgNoReason'))
        return
      }
      if (!confirm(this.$t('dpmLineStop.altMsgConfirmUseAll'))) {
        return
      }
      this.tableSelectedLine.forEach(x => {
        x.memo = this.offMemo
      })
    },
    useThisTime() {
      // console.log(this.offTime)
      if (this.tableSelectedLine.length === 0) {
        this.alertMsg(this.$t('dpmLineStop.altMsgNoLineSelect'))
        return
      }
      if (this.offTime === null) {
        this.alertMsg(this.$t('dpmLineStop.altMsgNoOffTime'))
        return
      }
      if (!confirm(this.$t('dpmLineStop.altMsgConfirmUseAllTime'))) {
        return
      }
      this.tableSelectedLine.forEach(x => {
        x.time = this.offTime
      })
    }
  }

}
</script>
<style lang="less" scoped>
::v-deep section {
  padding-bottom: 0;
  border: 0;
}

::v-deep .el-table .waitdispatch-row {
  background: rgb(151, 160, 240);
}
::v-deep .el-table .waitsolution-row {
  background: rgb(255, 255, 255);
}
::v-deep .el-table .waitcheck-row {
  background: rgb(252, 252, 173);
}
::v-deep .el-table .ok-row {
  background: rgb(127, 243, 133);
}
::v-deep .el-table .ng-row {
  background: rgb(245, 180, 191);
}
.tb{
    margin:0 auto;
    border:1px solid #cccccc;
    border-collapse:collapse;
    margin-bottom:10px;
    width: 100%;
    table-layout: fixed;
}
.tbTitle{
    width:100%;
    padding:10px 10px;
    font-size:14px;
    font-weight: 600;
    border-bottom:1px solid #cccccc;
    overflow: hidden;
    white-space: nowrap;
    text-overflow:ellipsis;
    word-wrap: break-word;
}
.tbCategory{
    height:30px;
    font-size:12px;
    text-align: center;
    background-color:#f4f4f4;
    border-bottom:1px solid #cccccc;
    border-right:1px solid #cccccc;
}
.tbValue{
    height:30px;
    font-size:12px;
    text-align: center;
    border-bottom:1px solid #cccccc;
    border-right:1px solid #cccccc;
}
.selectLineDiv{
  display: flex;
  width:615px;
  height:405px;
}
.selectLineLeftDiv{
  width:320px;
  height:400px;
  margin-left:5px;
  margin-top:5px;
}
.selectLineRightDiv{
  width:650px;
  height:400px;
  margin-left:20px;
  margin-top:5px;
}
.tableTitle{
  background-color: rgb(51,85,161);
  color:white;
  text-align: center;
}
</style>
