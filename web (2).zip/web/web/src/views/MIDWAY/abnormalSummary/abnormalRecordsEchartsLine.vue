<template>
  <div>
    <div v-show="isShow" class="flex-buttons">
      <el-button v-for="(item, index) in projectList" :key="index" type="primary" plain size="mini" @click="handleItem(item)">{{ item }}</el-button>
    </div>

    <div ref="chart" :style="{ width, height }" />
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
  props: {
    height: {
      type: String,
      default: '200px'
    },
    width: {
      type: String,
      default: '100%'
    }
  },
  data() {
    return {
      isShow: false,
      chart: null,
      dayList: [],
      list: [],
      apGoal: {},
      projectList: ['oee2', 'total', 'loss_time', 'down_time', 'yield_loss', 'unknow', 'idletime', 'average_change_time']
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.chart = echarts.init(this.$refs.chart)
    })
  },
  methods: {
    setUp(dayList, list, apGoal) {
      console.log(list)
      this.$forceUpdate()
      this.isShow = true
      this.dayList = dayList
      this.list = list
      this.apGoal = apGoal
      this.handleItem('oee2')
    },
    handleItem(key) {
      const xData = this.dayList.map((item) => item.label)
      const preTitle = key
      const preData = []
      const goalData = []
      this.list.forEach((item) => {
        const str = String(item[key])
        const val = str.slice(0, str.length - 1)
        preData.push(Number(val))
        goalData.push(this.apGoal[key])
      })
      const params = {
        xData: xData,
        preTitle: preTitle,
        preData: preData,
        goalData: goalData
      }
      this.resetOption(params)
    },
    resetOption(params) {
      const xData = params.xData
      const preTitle = params.preTitle
      const preData = params.preData
      const goalData = params.goalData
      this.chart.setOption({
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        legend: {
          show: true,
          itemGap: 10,
          data: [this.filterpreTitle(preTitle), 'Goal']
        },
        grid: {
          left: '10px',
          top: '40px',
          right: '10px',
          bottom: '10px',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            data: xData,
            axisLine: {
              show: true,
              lineStyle: {
                color: '#DCDFE6',
                width: 1,
                type: 'solid'
              }
            },
            axisTick: {
              show: true
            },
            axisLabel: {
              interval: 0,
              // rotate:50,
              show: true,
              splitNumber: 15,
              textStyle: {
                color: '#606266',
                fontSize: '12'
              }
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            axisLabel: {
              // formatter: '{value} %'
              show: true,
              textStyle: {
                color: '#606266',
                fontSize: '14'
              }
            },
            axisTick: {
              show: false
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: '#DCDFE6',
                width: 1,
                type: 'solid'
              }
            },
            splitLine: {
              show: false,
              lineStyle: {
                color: 'rgba(255,255,255,.1)'
              }
            }
          }
        ],
        series: [
          {
            name: this.filterpreTitle(preTitle),
            type: 'line',
            data: preData,
            itemStyle: {
              normal: {
                opacity: 1,
                barBorderRadius: 2,
                color: '#409EFF'
              }
            },
            label: {
              show: true,
              position: 'top',
              textStyle: {
                color: '#303133'
              },
              formatter: (params) => {
                // return params.value + '%'
                return this.filterpreTitleValue(params.value, preTitle)
              }
            }
          },
          {
            name: 'Goal',
            type: 'line',
            data: goalData,
            itemStyle: {
              normal: {
                opacity: 1,
                barBorderRadius: 2,
                color: '#E6A23C'
              }
            },
            label: {
              show: true,
              position: 'top',
              textStyle: {
                color: '#303133'
              }
            }
          }
        ]
      })
    },
    filterpreTitle(preTitle) {
      if (preTitle === 'average_change_time') {
        return preTitle
      } else {
        return preTitle + '%'
      }
    },
    filterpreTitleValue(val, preTitle) {
      if (preTitle === 'average_change_time') {
        return val
      } else {
        return val + '%'
      }
    }
  }
}
</script>

<style scoped lang="less">
.flex-buttons {
  margin: 20px auto;
  min-width: 1100px;
  button {
    min-width: 120px;
  }
}
</style>
