<template>
  <div v-show="tableData.length > 0" style="margin-top: 10px">
    <el-table :data="tableData" :height="tableHeight" :header-cell-style="getHeaderCellColor" @cell-click="handleRowClick" @header-click="handleHeaderClick">
      <el-table-column v-for="(item, index) in colNameData" :key="index" :prop="item.label" :label="item.label" :width="item.width" align="center" />
    </el-table>

    <DialogAbnormalRecordsIdea ref="DialogAbnormalRecordsIdea" v-model="dialogVisible" />
  </div>
</template>

<script>
import { DownloadLossTimeWithoutWorkOrderInfo_API } from '@/api/kpiSetting'
import DialogAbnormalRecordsIdea from '@/views/components/abnormalSummary/dialogAbnormalRecordsIdea'
export default {
  name: 'Idea',
  components: {
    DialogAbnormalRecordsIdea
  },
  data() {
    return {
      tableData: [],
      colNameData: [],
      dialogVisible: false,
      factory: '',
      team: '',
      tableHeight: '400px'
    }
  },
  methods: {
    handleRowClick(row, column, cell, event) {
      if (column.label !== 'PDLINE_NAME' && column.label !== 'MTD(Hour)') {
        console.log(row, column)
        this.dialogVisible = true
        const params = {
          pdline: row.PDLINE_NAME,
          factory: this.factory,
          team: row.TEAM_NAME,
          work_date: column.label
        }
        this.$nextTick(() => {
          this.$refs['DialogAbnormalRecordsIdea'].setUp(params)
        })
      }
    },
    handleHeaderClick(column) {
      if (column.label !== 'MTD(Hour)') {
        this.$confirm(`是否下载 ${column.property} 数据?`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          const params = {
            factory: this.factory,
            work_date: column.label === 'PDLINE_NAME' ? '' : column.property,
            team: this.team
          }
          const fileName = this.factory + '_' + column.property + '.xlsx'
          DownloadLossTimeWithoutWorkOrderInfo_API(params, fileName)
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消'
          })
        })
      }
    },
    setUp(arr, queryParams) {
      this.factory = queryParams.factory
      this.team = queryParams.team.join(',')
      this.colNameData = []
      this.tableData = arr

      const height = arr.length * 44
      this.tableHeight = height > 400 ? '400px' : height + 'px'

      const obj = arr[0]
      for (const key in obj) {
        if (key !== 'PDLINE_NAME' && key !== 'TEAM_NAME') {
          this.colNameData.push({
            label: key,
            width: 100
          })
        }
      }

      this.colNameData.unshift({
        label: 'PDLINE_NAME',
        width: 120
      })
    },
    getHeaderCellColor({ column }) {
      // console.log(column)
      if (column.label === 'PDLINE_NAME') {
        const style = {
          'background-color': '#409EFF',
          color: '#ffffff',
          cursor: 'pointer'
        }
        return style
      } else if (column.label === 'MTD(Hour)') {
        const style = {
          'background-color': '#f8f8f9',
          color: '#515a6e'
        }
        return style
      } else {
        const style = {
          'background-color': '#154479',
          color: '#ffffff',
          cursor: 'pointer'
        }
        return style
      }
    }
  }
}
</script>

<style scoped lang="less">
</style>
