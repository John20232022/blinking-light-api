<template>
  <div>
    <el-form ref="queryForm" :model="queryParams" :inline="true" size="small">
      <el-form-item prop="factoryType">
        <el-select v-model="queryParams.factory" :placeholder="$t('common.phdSelectFactory')" @change="changeFactory">
          <el-option v-for="item in factoryTypeList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item>
      <el-form-item prop="area">
        <el-select v-model="queryParams.area" disabled :placeholder="$t('common.phdSelectArea')" @change="changeArea">
          <el-option v-for="item in areaList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item>
      <el-form-item prop="team">
        <el-select v-model="queryParams.team" :disabled="!queryParams.area" :placeholder="$t('common.phdSelectTeam')">
          <el-option v-for="item in teamList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" :disabled="!queryParams.factory || !queryParams.area || !queryParams.team" @click="handleQuery">
          {{ $t('common.btnQuery') }}
        </el-button>
        <el-button type="primary" icon="el-icon-plus" plain @click="handleAdd"> {{ $t('common.btnAdd') }} </el-button>
      </el-form-item>
    </el-form>

    <el-table v-loading="loading" :data="tableData" :height="tableHeight">
      <el-table-column prop="factory" label="factory" align="center" />
      <el-table-column prop="area" label="area" align="center" />
      <el-table-column prop="team" label="team" align="center" min-width="100" />
      <el-table-column prop="loss_time_value" label="loss_time" align="center" min-width="140" />
      <el-table-column prop="down_time_value" label="down_time" align="center" min-width="140" />
      <el-table-column prop="yield_loss_value" label="yield_loss" align="center" min-width="140" />
      <el-table-column prop="unknow_value" label="unknow" align="center" min-width="140" />
      <el-table-column prop="oee2_value" label="oee2" align="center" min-width="100" />
      <el-table-column prop="total_value" label="total" align="center" min-width="100" />
      <el-table-column prop="average_change_line_time" label="平均换线时间" align="center" min-width="100" />
      <el-table-column width="150" align="center" :label="$t('common.colOpt')">
        <template slot-scope="scope">
          <el-button icon="el-icon-edit" type="text" @click.stop="handleEdit(scope.row)"> {{ $t('common.btnEdit') }} </el-button>
          <el-button icon="el-icon-delete" type="text" @click="handleDelete(scope.row.id)"> {{ $t('common.btnDel') }} </el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination :total="total" :page.sync="queryParams.pageIndex" :limit.sync="queryParams.pageSize" @pagination="getList" />

    <DialogKpiTeamSetting ref="DialogKpiTeamSetting" v-model="dialogVisible" @closeView="handleQuery" />
  </div>
</template>

<script>
import { GetDPMQueryKeyValue_API, GetKpiTeamSetting_API, DeleteKpiTeamSetting_API } from '@/api/kpiSetting'
// 分页组件
import Pagination from '@/components/Pagination'
import DialogKpiTeamSetting from '@/views/components/abnormalSummary/dialogKpiTeamSetting'
export default {
  name: 'KpiTeamSetting',
  components: {
    Pagination,
    DialogKpiTeamSetting
  },
  data() {
    return {
      loading: false,
      tableData: [],
      factoryTypeList: [],
      areaList: [],
      teamList: [],
      total: 0,
      tableHeight: document.documentElement.scrollHeight - 180 + 'px',
      queryParams: {
        factory: undefined,
        area: undefined,
        team: undefined,
        pageIndex: 1,
        pageSize: 20
      },
      dialogVisible: false,
      dialogTitle: ''
    }
  },
  created() {
    this.getFactoryTypeList()
  },
  methods: {
    getFactoryTypeList() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.factoryTypeList = res.data.ReturnObject
      })
    },
    changeFactory(val) {
      this.queryParams.area = undefined
      this.queryParams.team = undefined
      this.queryParams.pageIndex = 1
      this.queryParams.pageSize = 20

      this.areaList = []
      this.teamList = []

      const obj = this.factoryTypeList.filter((item) => item.data === val)[0]
      const data = {
        type: 'userarea',
        key: obj.key
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        const arr = res.data.ReturnObject
        this.areaList = arr.filter((item) => {
          return item.data === 'PCBA'
        })
        if (this.areaList.length === 0) {
          this.$message({
            message: this.$t('kpiTeamSet.altMsgNotPCBA'),
            type: 'warning'
          })
        } else {
          this.queryParams.area = this.areaList[0].data
          this.changeArea(this.queryParams.area)
        }
      })
    },
    changeArea(val) {
      this.queryParams.team = undefined
      this.queryParams.pageIndex = 1
      this.queryParams.pageSize = 20

      this.teamList = []
      const obj = this.areaList.filter((item) => item.data === val)[0]
      const data = {
        type: 'userteam',
        key: obj.key
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.teamList = res.data.ReturnObject
        this.teamList.unshift({ key: 'ALL', data: 'ALL' })
      })
    },
    handleAdd() {
      this.dialogVisible = true
      this.$nextTick(() => {
        this.$refs['DialogKpiTeamSetting'].init()
      })
    },
    // 弹窗-修改文档
    handleEdit(obj) {
      this.dialogVisible = true
      this.$nextTick(() => {
        this.$refs['DialogKpiTeamSetting'].editTemp({ ...obj }, this.factoryTypeList, this.areaList, this.teamList)
      })
    },
    handleDelete(id) {
      this.$confirm(this.$t('kpiTeamSet.altConfirmDel'), this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        cancelButtonText: this.$t('common.altMsgBtnCancel'),
        type: 'warning'
      }).then(() => {
        const param = {
          id: id
        }
        this.loading = true
        DeleteKpiTeamSetting_API(param).then((res) => {
          if (res.data.QueryResult === 'OK') {
            this.handleQuery()
            this.loading = false
          } else {
            this.$message.error(res.data.QueryResult)
            this.loading = false
          }
        })
      })
    },
    handleQuery() {
      this.queryParams.pageIndex = 1
      this.queryParams.pageSize = 20
      this.getList()
    },
    getList() {
      this.loading = true
      GetKpiTeamSetting_API(this.queryParams).then((res) => {
        if (res.data.QueryResult === 'OK') {
          this.tableData = res.data.ReturnObject.queryData
          this.total = res.data.ReturnObject.total
          this.loading = false
        } else {
          this.$message.error(res.data.QueryResult)
          this.loading = false
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>
</style>
