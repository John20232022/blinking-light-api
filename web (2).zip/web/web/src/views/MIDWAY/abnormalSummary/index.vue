<template>
  <div class="app-container">
    <el-tabs v-model="activeName" type="card">
      <el-tab-pane label="KpiTeamSetting" name="first">
        <KpiTeamSetting />
      </el-tab-pane>
      <el-tab-pane label="KpiReasonSetting" name="second" lazy>
        <KpiReasonSetting />
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import KpiTeamSetting from '@/views/MIDWAY/abnormalSummary/KpiTeamSetting'
import KpiReasonSetting from '@/views/MIDWAY/abnormalSummary/KpiReasonSetting'
export default {
  name: 'AbnormalSummary',
  components: {
    KpiTeamSetting,
    KpiReasonSetting
  },
  data() {
    return {
      activeName: 'first'
    }
  }
}
</script>

<style scoped lang="less">
.app-container {
  padding: 10px;
}
</style>
