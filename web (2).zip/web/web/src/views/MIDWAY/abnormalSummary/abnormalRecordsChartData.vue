<template>
  <div>
    <div ref="chart" :style="{ width, height }" />
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
  name: 'AbnormalRecordsChartData',
  props: {
    height: {
      type: String,
      default: '300px'
    },
    width: {
      type: String,
      default: '100%'
    }
  },
  data() {
    return {
      chart: null,
      tableData: []
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.chart = echarts.init(this.$refs.chart)
    })
  },
  methods: {
    setUp(arr) {
      // console.log(arr)
      this.tableData = arr
      this.tableData.sort((a, b) => {
        return b.per - a.per
      })
      const dataX = this.tableData.map((item) => item.reason_code)
      const dataY = this.tableData.map((item) => item.per)
      const dataY_right = this.tableData.map((item) => item.loss)

      const dataY_new = []
      let oldVal
      dataY.forEach((item, index) => {
        if (index === 0) {
          dataY_new.push(0)
          oldVal = item
        } else {
          oldVal = Number((oldVal - item).toFixed(2))
          dataY_new.push(oldVal)
        }
      })
      const obj01 = {
        name: '',
        type: 'bar',
        stack: 'Total',
        itemStyle: {
          borderColor: 'transparent',
          color: 'transparent'
        },
        emphasis: {
          itemStyle: {
            borderColor: 'transparent',
            color: 'transparent'
          }
        },
        data: dataY_new
      }
      const obj02 = {
        name: 'per',
        type: 'bar',
        stack: 'Total',
        label: {
          show: true,
          position: 'top',
          formatter: (params) => params.value + '%'
        },
        barWidth: '40%',
        data: dataY
      }
      const obj03 = {
        name: '',
        type: 'line',
        yAxisIndex: 1,
        itemStyle: {
          borderColor: 'transparent',
          color: 'transparent'
        },
        data: dataY_right
      }
      const seriesArr = [obj01, obj02, obj03]
      this.resetOption(dataX, seriesArr)
    },
    resetOption(dataX, seriesArr) {
      const option = {
        title: {
          text: 'Loss time waterfall chart'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          },
          formatter: (params) => {
            var tar = params[1]
            return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value + '%<br/>loss:' + params[2].value
          }
        },
        grid: {
          top: '60px',
          left: '10px',
          right: '10px',
          bottom: '10px',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          splitLine: { show: false },
          data: dataX,
          axisLabel: {
            rotate: 45
          }
        },
        yAxis: [
          {
            name: 'per',
            type: 'value',
            axisLabel: {
              formatter: '{value} %'
            }
          },
          {
            type: 'value',
            name: 'loss'
          }
        ],
        series: seriesArr
      }
      this.chart.setOption(option)
    }
  }
}
</script>

<style scoped lang="less">
</style>
