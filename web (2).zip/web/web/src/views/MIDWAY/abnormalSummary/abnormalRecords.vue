<template>
  <div class="app-container">
    <el-form ref="queryForm" :model="queryParams" :inline="true" size="small">
      <el-form-item prop="factoryType">
        <el-select v-model="queryParams.factory" :placeholder="$t('common.phdSelectFactory')" @change="changeFactory">
          <el-option v-for="item in factoryTypeList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item>
      <el-form-item prop="team">
        <el-select v-model="queryParams.team" multiple collapse-tags :disabled="!queryParams.area" :placeholder="$t('common.phdSelectTeam')" @change="changeTeam">
          <el-option v-for="item in teamList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item>
      <el-form-item prop="line">
        <el-select v-model="queryParams.line" multiple collapse-tags :disabled="!queryParams.team" :placeholder="$t('common.phdSelectLine')">
          <el-option v-for="item in lineList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team" @click="handleQuery('YEAR')">
          {{ $t('abnormalRecords.btnByYearQuarter') }}
        </el-button>
        <el-button type="primary" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team" @click="handleQuery('MONTH')">
          {{ $t('abnormalRecords.btnByMonth') }}
        </el-button>
        <el-button type="primary" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team" @click="handleQuery('WEEK')">
          {{ $t('abnormalRecords.btnByWeek') }}
        </el-button>
        <el-button type="primary" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team" @click="handleQuery('DAY')">
          {{ $t('abnormalRecords.btnByDay') }}
        </el-button>

        <el-button type="primary" plain :disabled="dayLilst.length == 0" @click="handleExportExcel()"> downLoad </el-button>
        <el-date-picker v-model="queryParams.date" :editable="false" :clearable="false" style="margin-left: 10px; width: 166px" type="month" placeholder="选择月" value-format="yyyy-MM" />
      </el-form-item>
    </el-form>

    <!--
      colspan 列
      rowspan 行

    -->
    <div class="table-box">
      <table id="out-table01" class="abnormalRecords-table">
        <tr>
          <th colspan="1" rowspan="1" style="min-width: 120px">Work Type</th>
          <th colspan="1" rowspan="1" style="min-width: 120px">{{ $t('abnormalRecords.colRate') }}</th>
          <th colspan="1" rowspan="1" style="min-width: 120px">{{ $t('abnormalRecords.colItem') }}</th>
          <th colspan="1" rowspan="1" style="min-width: 120px">AP Goal({{ $t('abnormalRecords.colMonth') }})</th>
          <th colspan="1" rowspan="1" style="min-width: 120px">MTD</th>
          <th v-for="(item, index) in dayLilst" :key="index" colspan="1" rowspan="1">
            <span>{{ item.label }}</span>
          </th>
        </tr>
        <tr>
          <td colspan="1" rowspan="6">WorkTime(%)</td>
          <td colspan="1" rowspan="6">{{ WorkTime }}%</td>
          <td colspan="1" rowspan="1">OEE2(%)</td>
          <td colspan="1" rowspan="1">{{ apDataPercent.oee2 }}%</td>
          <td colspan="1" rowspan="1">{{ busesNumber.oee2_per }}%</td>
          <td v-for="(item, index) in titleDetai" :key="index" colspan="1" rowspan="1">
            <span :style="colorStyleOee2(apDataPercent.oee2, item)">{{ item.oee2 }}</span>
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">Total(%)</td>
          <td colspan="1" rowspan="1">{{ apDataPercent.total }}%</td>
          <td colspan="1" rowspan="1">{{ busesNumber.total_per }}%</td>
          <td v-for="(item, index) in titleDetai" :key="index" colspan="1" rowspan="1">
            <span :style="colorStyleTotal(apDataPercent.total, item)">{{ item.total }}</span>
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1" class="bg02"><span class="is-link" @click="handleDetail('Loss Time')">Loss Time(%)</span></td>
          <td colspan="1" rowspan="1">{{ apDataPercent.loss_time }}%</td>
          <td colspan="1" rowspan="1">{{ busesNumber.loss_time_per }}%</td>
          <td v-for="(item, index) in titleDetai" :key="index" colspan="1" rowspan="1">
            <span :style="colorStyleLossTime(apDataPercent.loss_time, item)">{{ item.loss_time }}</span>
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1" class="bg02"><span class="is-link" @click="handleDetail('Down Time')">Down Time(%)</span></td>
          <td colspan="1" rowspan="1">{{ apDataPercent.down_time }}%</td>
          <td colspan="1" rowspan="1">{{ busesNumber.down_time_per }}%</td>
          <td v-for="(item, index) in titleDetai" :key="index" colspan="1" rowspan="1">
            <span :style="colorStyleDownTime(apDataPercent.down_time, item)">{{ item.down_time }}</span>
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1" class="bg02"><span class="is-link" @click="handleDetail('Yield Loss')">Yield Loss(%)</span></td>
          <td colspan="1" rowspan="1">{{ apDataPercent.yield_loss }}%</td>
          <td colspan="1" rowspan="1">{{ busesNumber.yield_loss_per }}%</td>
          <td v-for="(item, index) in titleDetai" :key="index" colspan="1" rowspan="1">
            <span :style="colorStyleYieldLoss(apDataPercent.yidle_loss, item)">{{ item.yield_loss }}</span>
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">Unkwn(%)</td>
          <td colspan="1" rowspan="1">{{ apDataPercent.unknow }}%</td>
          <td colspan="1" rowspan="1">{{ busesNumber.unknow_per }}%</td>
          <td v-for="(item, index) in titleDetai" :key="index" colspan="1" rowspan="1">
            <span :style="colorStyleUnknow(apDataPercent.unknow, item)">{{ item.unknow }}</span>
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">IdleTime(%)</td>
          <td colspan="1" rowspan="1">{{ IdleTime }}%</td>
          <td colspan="1" rowspan="1" class="bg02"><span class="is-link" @click="handleDetail('Idle Time')">Idle Time(hr)</span></td>

          <td colspan="1" rowspan="1">-</td>
          <td colspan="1" rowspan="1">{{ busesNumber.idletime }}</td>
          <td v-for="(item, index) in titleDetai" :key="index" colspan="1" rowspan="1">
            {{ item.idletime }}
          </td>
        </tr>
        <tr>
          <td colspan="2" rowspan="4">change over</td>
          <td colspan="1" rowspan="1">{{ $t('abnormalRecords.colTotalChangeLine') }}</td>
          <td colspan="1" rowspan="1">-</td>
          <td colspan="1" rowspan="1">{{ busesNumber.change_line_count }}</td>
          <td v-for="(item, index) in titleDetai" :key="index" colspan="1" rowspan="1">
            {{ item.change_line_count }}
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">{{ $t('abnormalRecords.colNPIChangeLine') }}</td>
          <td colspan="1" rowspan="1">-</td>
          <td colspan="1" rowspan="1">{{ busesNumber.npi_change_count }}</td>
          <td v-for="(item, index) in titleDetai" :key="index" colspan="1" rowspan="1">
            {{ item.npi_change_count }}
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">{{ $t('abnormalRecords.colShiftOpen') }}</td>
          <td colspan="1" rowspan="1">{{ $t('abnormalRecords.colLineOpen') }}</td>
          <td colspan="1" rowspan="1">{{ busesNumber.open_line }}</td>
          <td v-for="(item, index) in titleDetai" :key="index" colspan="1" rowspan="1">
            {{ item.open_line }}
          </td>
        </tr>
        <tr>
          <td colspan="1" rowspan="1">{{ $t('abnormalRecords.colAvgChangeLineTime') }}</td>
          <td colspan="1" rowspan="1">{{ apDataPercent.average_change_line_time }}</td>
          <td colspan="1" rowspan="1">{{ busesNumber.average_change_time }}</td>
          <td v-for="(item, index) in titleDetai" :key="index" colspan="1" rowspan="1">
            {{ item.average_change_time }}
          </td>
        </tr>
      </table>
    </div>

    <AbnormalRecordsDetail ref="AbnormalRecordsDetail" v-model="dialogVisible" />

    <AbnormalRecordsEchartsLine ref="AbnormalRecordsEchartsLine" />

    <AbnormalRecordsIdea ref="AbnormalRecordsIdea" />

    <AbnormalRecordsChartData ref="AbnormalRecordsChartData" />
  </div>
</template>

<script>
import { GetDPMQueryKeyValue_API, GetPcbaIssueHistoryData_API } from '@/api/kpiSetting'
import AbnormalRecordsDetail from '@/views/MIDWAY/abnormalSummary/abnormalRecordsDetail'
import AbnormalRecordsEchartsLine from '@/views/MIDWAY/abnormalSummary/abnormalRecordsEchartsLine'
import AbnormalRecordsIdea from '@/views/MIDWAY/abnormalSummary/abnormalRecordsIdea'
import AbnormalRecordsChartData from '@/views/MIDWAY/abnormalSummary/abnormalRecordsChartData'
import FileSaver from 'file-saver'
import XLSX from 'xlsx'
export default {
  name: 'AbnormalRecords',
  components: {
    AbnormalRecordsDetail,
    AbnormalRecordsEchartsLine,
    AbnormalRecordsIdea,
    AbnormalRecordsChartData
  },
  data() {
    return {
      dialogVisible: false,
      factoryTypeList: [],
      areaList: [],
      teamList: [],
      lineList: [],
      queryParams: {
        factory: undefined,
        area: undefined,
        team: [],
        line: [],
        date: undefined
      },
      busesNumber: {}, // 总线体
      dayLilst: [],
      titleDetai: [],
      detail: [],
      apDataPercent: {},
      apDataHr: {},
      today: new Date().getDate(),
      WorkTime: 0,
      IdleTime: 0,
      type: ''
    }
  },
  created() {
    this.getFactoryTypeList()
    const date = new Date()
    const year_month = date.getFullYear() + '-' + (date.getMonth() + 1).toString().padStart(2, '0')
    this.queryParams.date = year_month
  },
  methods: {
    handleDetail(type) {
      const params = {
        factory: this.queryParams.factory,
        area: this.queryParams.area,
        team: this.queryParams.team,
        line: this.queryParams.line,
        type: type,
        date_type: this.type
      }
      this.dialogVisible = true
      this.$nextTick(() => {
        this.$refs['AbnormalRecordsDetail'].setUp(params, this.factoryTypeList, this.areaList, this.teamList, this.lineList)
      })
    },
    handleQuery(type) {
      this.type = type
      this.getList(type)
    },
    getList(type) {
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      let line
      let team
      if (this.queryParams?.team.findIndex(item => item === 'ALL') > -1) {
        team = 'ALL'
      } else {
        team = this.queryParams.team.join(',')
      }
      if (this.queryParams?.line.findIndex(item => item === 'ALL') > -1) {
        line = 'ALL'
      } else {
        line = this.queryParams.line.join(',')
      }
      const params = {
        factory: this.queryParams.factory,
        area: this.queryParams.area,
        team: team,
        line: line,
        type: type,
        date: this.queryParams.date
      }
      GetPcbaIssueHistoryData_API(params).then((res) => {
        if (res.data.QueryResult === 'OK') {
          const ReturnObject = res.data.ReturnObject
          this.titleDetai = []
          this.dayLilst = ReturnObject.date

          let open_line_all = 0

          ReturnObject.detail.forEach((item) => {
            if (item.date === 'MTD') {
              this.busesNumber = item

              /* this.IdleTime = (this.busesNumber.idletime / (this.today * 12)).toFixed(2);
              this.WorkTime = (100 - this.IdleTime).toFixed(2); */
            } else {
              open_line_all += item.open_line
              this.titleDetai.push({
                open_line: item.open_line,
                type: '%',
                oee2: item.oee2_per + '%',
                total: item.total_per + '%',
                loss_time: item.loss_time_per + '%',
                down_time: item.down_time_per + '%',
                yield_loss: item.yield_loss_per + '%',
                unknow: item.unknow_per + '%',
                idletime: item.idletime_per + '%',
                change_line_count: item.change_line_count,
                npi_change_count: item.npi_change_count,
                average_change_time: item.average_change_time
              })
            }
          })

          this.IdleTime = (this.busesNumber.idletime / open_line_all / 0.12).toFixed(2)
          this.WorkTime = (100 - this.IdleTime).toFixed(2)

          ReturnObject.apData.forEach((item) => {
            if (item.type === 'Percent') {
              this.apDataPercent = item
            }
            if (item.type === 'Hr') {
              this.apDataHr = item
            }
          })
          loading.close()

          this.$nextTick(() => {
            this.$refs['AbnormalRecordsEchartsLine'].setUp(this.dayLilst, this.titleDetai, this.apDataPercent)
            this.$refs['AbnormalRecordsIdea'].setUp(ReturnObject.idleData, this.queryParams)
            this.$refs['AbnormalRecordsChartData'].setUp(ReturnObject.chartData)
          })
        } else {
          loading.close()
        }
      })
    },
    getFactoryTypeList() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.factoryTypeList = res.data.ReturnObject
      })
    },
    changeFactory(val) {
      this.queryParams.area = undefined
      this.queryParams.team = undefined
      this.areaList = []
      this.teamList = []
      const obj = this.factoryTypeList.filter((item) => item.data === val)[0]
      const data = {
        type: 'userarea',
        key: obj.key
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        const arr = res.data.ReturnObject
        this.areaList = arr.filter((item) => {
          return item.data === 'PCBA'
        })
        if (this.areaList.length === 0) {
          this.$message({
            message: this.$t('abnormalRecords.altMsgNotPCBA'),
            type: 'warning'
          })
        } else {
          this.queryParams.area = this.areaList[0].data
          this.changeArea(this.queryParams.area)
        }
      })
    },
    changeArea(val) {
      this.queryParams.team = undefined
      this.teamList = []
      const obj = this.areaList.filter((item) => item.data === val)[0]
      const data = {
        type: 'userteam',
        key: obj.key
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.teamList = res.data.ReturnObject
        this.teamList.unshift({ key: 'ALL', data: 'ALL' })
      })
    },
    changeTeam(arr) {
      // console.log(arr)
      if (arr.length > 1) {
        this.lineList = [{ key: 'ALL', data: 'ALL' }]
        this.queryParams.line = ['ALL']
      } else if (arr.length === 1 && arr[0] !== 'ALL') {
        const obj = this.teamList.filter((item) => item.data === arr[0])[0]
        const data = {
          type: 'userline',
          key: obj.key // obj.key
        }
        GetDPMQueryKeyValue_API(data).then((res) => {
          this.lineList = res.data.ReturnObject
          this.lineList.unshift({ key: 'ALL', data: 'ALL' })
        })
      } else if (arr.length === 1 && arr[0] === 'ALL') {
        this.lineList = [{ key: 'ALL', data: 'ALL' }]
        this.queryParams.line = ['ALL']
      } else {
        this.lineList = []
        this.queryParams.line = []
      }
    },
    colorStyleOee2(apOee2, obj) {
      if (obj.type === '%') {
        const str = obj.oee2
        const val = str.slice(0, str.length - 1)
        if (apOee2 > Number(val)) {
          return 'color:#d54941;font-weight: bold;'
        }
      }
    },
    colorStyleTotal(apTotal, obj) {
      if (obj.type === '%') {
        const str = obj.total
        const val = str.slice(0, str.length - 1)
        if (apTotal < Number(val)) {
          return 'color:#d54941;font-weight: bold;'
        }
      }
    },
    colorStyleLossTime(apLossTime, obj) {
      if (obj.type === '%') {
        const str = obj.loss_time
        const val = str.slice(0, str.length - 1)
        if (apLossTime < Number(val)) {
          return 'color:#d54941;font-weight: bold;'
        }
      }
    },
    colorStyleDownTime(apDownTime, obj) {
      if (obj.type === '%') {
        const str = obj.down_time
        const val = str.slice(0, str.length - 1)
        if (apDownTime < Number(val)) {
          return 'color:#d54941;font-weight: bold;'
        }
      }
    },
    colorStyleYieldLoss(apYieldLoss, obj) {
      if (obj.type === '%') {
        const str = obj.yield_loss
        const val = str.slice(0, str.length - 1)
        if (apYieldLoss < Number(val)) {
          return 'color:#d54941;font-weight: bold;'
        }
      }
    },
    colorStyleUnknow(apUnknow, obj) {
      if (obj.type === '%') {
        const str = obj.unknow
        const val = str.slice(0, str.length - 1)
        if (apUnknow < Number(val)) {
          return 'color:#d54941;font-weight: bold;'
        }
      }
    },
    // 下载
    handleExportExcel() {
      const wb = XLSX.utils.table_to_book(document.querySelector('#out-table01'), {
        raw: true
      })
      const filename = this.type + '.xlsx'
      const wbout = XLSX.write(wb, {
        bookType: 'xlsx',
        bookSST: true,
        type: 'array'
      })
      try {
        FileSaver.saveAs(
          // Blob 对象表示一个不可变、原始数据的类文件对象。
          // Blob 表示的不一定是JavaScript原生格式的数据。
          // File 接口基于Blob，继承了 blob 的功能并将其扩展使其支持用户系统上的文件。
          // 返回一个新创建的 Blob 对象，其内容由参数中给定的数组串联组成。
          new Blob([wbout], { type: 'application/octet-stream' }),
          // 设置导出文件名称
          filename
        )
      } catch (e) {
        if (typeof console !== 'undefined') console.log(e, wbout)
      }
      return wbout
    }
  }
}
</script>

<style scoped lang="less">
::v-deep .el-form-item--small.el-form-item {
  margin-bottom: 10px;
}
.app-container {
  padding: 10px;
  .table-box {
    width: 100%;
    min-height: 430px;
    overflow-x: auto;
    .abnormalRecords-table {
      border-collapse: collapse;
      border: 1px solid #dcdfe6;
      min-width: 1000px;
      tr th {
        height: 30px;
        border: 1px solid #dcdfe6;
        background-color: #154479;
        color: #ffffff;
        min-width: 80px;
        font-size: 14px;
      }
      tr td {
        height: 36px;
        border: 1px solid #dcdfe6;
        min-width: 80px;
        text-align: center;
      }
      tr {
        .bg02 {
          background-color: #7ca6cb;
        }
        .bg03 {
          background-color: #8fcbee;
        }
        .bg04 {
          background-color: #c3e5f7;
        }
        .bg05 {
          background-color: #bdd7ee;
        }
        .bg06 {
          background-color: #ddebf7;
        }
      }
    }
  }
}
.is-link {
  color: #303133;
  cursor: pointer;
  font-size: 16px;
  font-weight: bold;
  transition: all 300ms ease-in-out;
}
.is-link:hover {
  color: #f56c6c;
}
</style>
