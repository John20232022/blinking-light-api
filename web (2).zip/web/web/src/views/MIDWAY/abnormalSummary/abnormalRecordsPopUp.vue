<template>
  <el-dialog :title="dialogTitle" :visible.sync="visible" :before-close="handleCancel" :close-on-click-modal="false" :close-on-press-escape="false" width="1100px" append-to-body>
    <span class="red-text">
      “设备故障” 资讯未来将同步EMS系统，DPM功能将在07/01关闭；
      <br>
      请尽快使用EMS系统进行叫修作业，熟悉操作；避免07/01上线影响绩效对话；
      <br>
      CZOCS MFG和ME单位的无EMS权限；请部门主管统一收集后发送：keven.chen@liteon.com
      <br>
      若需继续使用DPM “设备故障” 请点击 “取消” 按钮。
    </span>
    <div slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import { GetPcbaIssueLossTop5_API } from '@/api/kpiSetting'
export default {
  name: 'AbnormalRecordsReasonCode',
  props: {
    value: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      visible: this.value, // 是否顯示彈出層，
      dialogTitle: '',
      tableData: []
    }
  },
  watch: {
    value(val) {
      this.visible = val
    },
    visible(val) {
      this.$emit('input', val)
    }
  },
  methods: {
    handleCancel() {
      this.visible = false
    },
    setUp(params) {
      this.dialogTitle = params.reason_code
      GetPcbaIssueLossTop5_API(params).then((res) => {
        if (res.data.QueryResult === 'OK') {
          this.tableData = res.data.ReturnObject
        }
      })
    }
  }
}

</script>

<style scoped lang="less">
::v-deep .el-dialog__body {
  padding: 0 20px;
}
.red-text {
  color: red;
  font-size: 24px; /* 设置字体大小为16像素 */
}
</style>
