<template>
  <el-dialog :title="dialogTitle" :visible.sync="visible" :before-close="handleCancel" :close-on-click-modal="false" :close-on-press-escape="false" width="1200px" append-to-body>
    <el-table :data="tableData">
      <el-table-column type="index" width="50" label="序号" align="center" />
      <el-table-column prop="REASON_CODE" label="reason_code" width="180" align="center" />
      <el-table-column prop="PDLINE_NAME" label="线体" width="180" align="center" />
      <el-table-column prop="WORK_DATE" label="工作日" width="120" align="center" />
      <el-table-column prop="REASON_DESC" label="说明" align="center" />
      <el-table-column prop="SOLUTION" label="解决方案" align="center" />
      <el-table-column prop="IMPACT_MINUTES" label="影响时长" width="80" align="center" />
    </el-table>
    <div slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import { GetPcbaIssueLossTop5_API } from '@/api/kpiSetting'
export default {
  name: 'AbnormalRecordsReasonCode',
  props: {
    value: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      visible: this.value, // 是否顯示彈出層，
      dialogTitle: '',
      tableData: []
    }
  },
  watch: {
    value(val) {
      this.visible = val
    },
    visible(val) {
      this.$emit('input', val)
    }
  },
  methods: {
    handleCancel() {
      this.visible = false
    },
    setUp(params) {
      this.dialogTitle = params.reason_code
      GetPcbaIssueLossTop5_API(params).then((res) => {
        if (res.data.QueryResult === 'OK') {
          this.tableData = res.data.ReturnObject
        }
      })
    }
  }
}
</script>

<style scoped lang="less">
::v-deep .el-dialog__body {
  padding: 0 20px;
}
</style>
