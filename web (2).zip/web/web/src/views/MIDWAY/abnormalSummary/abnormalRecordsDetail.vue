<!-- eslint-disable prefer-const -->
<template>
  <el-dialog :title="dialogTitle" :visible.sync="visible" :before-close="handleCancel" :close-on-click-modal="false" :close-on-press-escape="false" :fullscreen="true" append-to-body>
    <el-form ref="queryForm" :model="queryParams" :inline="true" size="small">
      <el-form-item prop="factoryType">
        <el-select v-model="queryParams.factory" :placeholder="$t('common.phdSelectFactory')" style="width: 130px" @change="changeFactory">
          <el-option v-for="item in factoryTypeList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item>
      <!-- <el-form-item prop="area">
        <el-select v-model="queryParams.area" disabled :placeholder="$t('common.phdSelectArea')" @change="changeArea" style="width: 130px">
          <el-option v-for="item in areaList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item> -->
      <el-form-item prop="team">
        <el-select v-model="queryParams.team" multiple collapse-tags :disabled="!queryParams.area" :placeholder="$t('common.phdSelectTeam')" style="width: 130px" @change="changeTeam">
          <el-option v-for="item in teamList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item>
      <el-form-item prop="line">
        <el-select v-model="queryParams.line" multiple collapse-tags :disabled="!queryParams.team" :placeholder="$t('common.phdSelectLine')" style="width: 130px">
          <el-option v-for="item in lineList" :key="item.data" :label="item.data" :value="item.data" />
        </el-select>
      </el-form-item>
      <el-form-item prop="date">
        <el-date-picker v-model="queryParams.date" :clearable="false" :disabled="!queryParams.team" :editable="false" format="yyyy-MM" value-format="yyyy-MM" type="month" placeholder="month" style="width: 130px" />
      </el-form-item>
      <el-form-item prop="type">
        <el-select v-model="queryParams.type" :disabled="!queryParams.date" style="width: 130px">
          <el-option v-for="(item, index) in type_num_list" :key="index" :label="item" :value="item" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button icon="el-icon-search" type="primary" plain :disabled="!queryParams.factory || !queryParams.area || !queryParams.team || !queryParams.line" @click="handleQuery()"> 查询 </el-button>
        <!-- <el-button type="primary" plain :disabled="detail_new_all.length == 0" @click="handleExportExcel()"> downLoad </el-button> -->
      </el-form-item>
    </el-form>
    <!--
      colspan 列
      rowspan 行

    -->
    <div id="out-table02" class="table-box flex">
      <table id="abnormalRecords-table-detail-left" class="abnormalRecords-table-detail abnormalRecords-table-detail-left">
        <tr>
          <th colspan="1" rowspan="3">{{ $t('abnormalRecordsDetail.colProject') }}</th>
          <th colspan="1" rowspan="3">reason_code</th>
          <th colspan="2" rowspan="2">{{ $t('abnormalRecordsDetail.colApGoal') }}</th>
          <th colspan="2" rowspan="1">MTD</th>
        </tr>
        <tr>
          <th colspan="1" rowspan="1">{{ $t('abnormalRecordsDetail.colTotalLoss') }}</th>
          <th colspan="1" rowspan="1">{{ MTD_all_loss }}</th>
        </tr>
        <tr>
          <th colspan="1" rowspan="1">%</th>
          <th colspan="1" rowspan="1">Hr</th>
          <th colspan="1" rowspan="1">ACT vs Goal</th>
          <th colspan="1" rowspan="1">Time(hr)</th>
        </tr>
        <tr v-for="(item, index) in ap_mtd_list" :key="index">
          <td v-if="index == 0" colspan="1" :rowspan="reason_code_len">{{ project_name }}</td>
          <td colspan="1" rowspan="1">
            <span class="is-link" @click="handleReasonCode(item.reason_code)">
              {{ item.reason_code }}
            </span>
          </td>
          <td colspan="1" rowspan="1">{{ item.ap_per }}%</td>
          <td colspan="1" rowspan="1">{{ item.ap_goal }}</td>
          <td colspan="1" rowspan="1">{{ item.mtd_loss_per }}%</td>
          <td colspan="1" rowspan="1">{{ item.mtd_loss }}</td>
        </tr>
      </table>
      <table class="abnormalRecords-table-detail abnormalRecords-table-detail-right">
        <tr>
          <th v-for="(item, index) in data_all_label" :key="index" colspan="1" rowspan="1">{{ item }}</th>
        </tr>
        <tr>
          <th v-for="(item, index) in all_loss_new" :key="index" colspan="1" rowspan="1">
            <div class="th-span flex">
              <span class="span01">{{ project_name }}</span>
              <span>{{ item.all_loss }}</span>
            </div>
          </th>
        </tr>
        <tr>
          <th v-for="(item, index) in data_all_label" :key="index" colspan="1" rowspan="1">
            <div class="th-span">
              <span>%</span>
              <!-- <span>hr</span> -->
            </div>
          </th>
        </tr>
        <tr v-for="(item, index) in detail_new_all" :key="index">
          <td v-for="(item01, index01) in item" :key="index01">
            <div class="th-span">
              <span :style="colorStyle(index, index01)">{{ item01.loss_per }}%</span>
              <!-- <span>{{ item01.loss }}</span> -->
            </div>
          </td>
        </tr>
      </table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">{{ $t('common.btnCancel') }}</el-button>
    </div>

    <AbnormalRecordsReasonCode ref="AbnormalRecordsReasonCode" v-model="dialogVisible" />
  </el-dialog>
</template>

<script>
import { GetDPMQueryKeyValue_API, GetPcbaReasonHistoryData_API } from '@/api/kpiSetting'
import AbnormalRecordsReasonCode from '@/views/MIDWAY/abnormalSummary/abnormalRecordsReasonCode'
import FileSaver from 'file-saver'
import XLSX from 'xlsx'
export default {
  name: 'AbnormalRecordsDetail',
  components: {
    AbnormalRecordsReasonCode
  },
  props: {
    value: {
      type: Boolean,
      default: false
    },
    dialogTitle: {
      type: String,
      default: 'Detail'
    }
  },
  data() {
    return {
      dialogVisible: false,
      visible: this.value, // 是否顯示彈出層，
      factoryTypeList: [],
      areaList: [],
      teamList: [],
      lineList: [],
      queryParams: {
        factory: undefined,
        area: undefined,
        team: [],
        line: [],
        date: undefined,
        type: undefined,
        date_type: undefined
      },
      type_num_list: ['Loss Time', 'Down Time', 'Idle Time', 'Yield Loss'],
      MTD_all_loss: '',
      project_name: '',
      reason_code_len: 0,
      data_all_label: [],
      all_loss_new: [],
      ap_mtd_list: [],
      detail_new_all: []
    }
  },
  watch: {
    value(val) {
      this.visible = val
    },
    visible(val) {
      this.$emit('input', val)
    }
  },
  methods: {
    changeTeam(arr) {
      console.log(arr)
      if (arr.length > 1) {
        this.lineList = [{ key: 'ALL', data: 'ALL' }]
        this.queryParams.line = ['ALL']
      } else if (arr.length === 1 && arr[0] !== 'ALL') {
        const obj = this.teamList.filter((item) => item.data === arr[0])[0]
        const data = {
          type: 'userline',
          key: obj.key // obj.key
        }
        GetDPMQueryKeyValue_API(data).then((res) => {
          this.lineList = res.data.ReturnObject
          this.lineList.unshift({ key: 'ALL', data: 'ALL' })
        })
      } else if (arr.length === 1 && arr[0] === 'ALL') {
        this.lineList = [{ key: 'ALL', data: 'ALL' }]
        this.queryParams.line = ['ALL']
      } else {
        this.lineList = []
        this.queryParams.line = []
      }
    },
    setUp(obj, factoryTypeList, areaList, teamList, lineList) {
      this.factoryTypeList = factoryTypeList
      this.areaList = areaList
      this.teamList = teamList
      this.lineList = lineList
      const month = this.GetDateTimeString()
      this.queryParams.date = month
      this.queryParams.factory = obj.factory
      this.queryParams.area = obj.area
      this.queryParams.team = obj.team
      this.queryParams.line = obj.line
      this.queryParams.type = obj.type
      this.queryParams.date_type = obj.date_type
      if (this.queryParams.factory && this.queryParams.area && this.queryParams.team && this.queryParams.type && this.queryParams.date) {
        this.handleQuery()
      }
    },
    initData(ReturnObject) {
      const apData = ReturnObject.apData
      const reason_code_all = ReturnObject.apData.map((item) => item.reason_code)
      const data_all = ReturnObject.date.map((item) => item.data)
      const data_all_label = ReturnObject.date.map((item) => item.label)
      const allLoss_value = ReturnObject.allLoss
      const allLoss = ReturnObject.allLoss.map((item) => item.date)
      const MTD_all_loss = ReturnObject.allLoss.filter((item) => {
        return item.date === 'MTD'
      })[0]['all_loss']
      let MTDdetail = ReturnObject.detail.filter((item) => {
        return item.date === 'MTD'
      })
      // 如果找不到，手动添加个
      if (MTDdetail.length === 0 && ReturnObject.detail.length > 0) {
        MTDdetail = [
          {
            loss: 0,
            loss_per: 0
          }
        ]
      }
      // console.log(MTDdetail, '------MTDdetail');
      const all_loss_new = []
      data_all.forEach((item) => {
        const index = allLoss.indexOf(item)
        if (index > -1) {
          all_loss_new.push({
            data: allLoss_value[index].date,
            all_loss: allLoss_value[index].all_loss
          })
        } else {
          all_loss_new.push({
            data: item,
            all_loss: 0
          })
        }
      })
      const detail = ReturnObject.detail
      const detail_new = []
      reason_code_all.forEach((reason_code) => {
        data_all.forEach((data) => {
          // console.log(reason_code, data)
          detail_new.push({
            date: data,
            loss: 0,
            loss_per: 0,
            reason_code: reason_code
          })
          for (let i = 0; i < detail.length; i++) {
            // console.log(detail[i])
            if (reason_code === detail[i]['reason_code'] && data === detail[i]['date']) {
              detail_new[detail_new.length - 1] = detail[i]
            }
          }
        })
      })
      // console.log(detail_new);
      const detail_new_all = this.combineArray(detail_new, 'reason_code')

      const ap_mtd_list = []
      reason_code_all.forEach((item, index) => {
        ap_mtd_list.push({
          mtd_loss: 0,
          mtd_loss_per: 0,
          reason_code: item,
          ap_per: apData[index].goal_per,
          ap_goal: apData[index].goal
        })
        for (let i = 0; i < MTDdetail.length; i++) {
          if (item === MTDdetail[i].reason_code) {
            ap_mtd_list[index]['mtd_loss'] = MTDdetail[i].loss
            ap_mtd_list[index]['mtd_loss_per'] = MTDdetail[i].loss_per
          }
        }
        /* for (let i = 0; i < MTDdetail.length; i++) {
          if (item == MTDdetail[i].reason_code) {
            ap_mtd_list.push({
              mtd_loss: MTDdetail[i].loss,
              mtd_loss_per: MTDdetail[i].loss_per,
              reason_code: MTDdetail[i].reason_code,
              ap_per: apData[i].goal_per,
              ap_goal: apData[i].goal
            });
          } else {
            ap_mtd_list.push({
              mtd_loss: 0,
              mtd_loss_per: 0,
              reason_code: item,
              ap_per: apData[i].goal_per,
              ap_goal: apData[i].goal
            });
          }
        } */
      })
      // console.log(ap_mtd_list, '---ap_mtd_list');
      // console.log(detail_new_all, '---detail_new_all');
      // console.log(MTD_all_loss, '---MTD_all_loss');
      // console.log(all_loss_new)
      this.all_loss_new = all_loss_new
      this.reason_code_len = ap_mtd_list.length
      this.ap_mtd_list = ap_mtd_list
      this.detail_new_all = detail_new_all
      this.MTD_all_loss = MTD_all_loss
      this.data_all_label = data_all_label
    },
    handleQuery() {
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      this.project_name = this.queryParams.type

      let team
      let line
      if (this.queryParams?.team.findIndex(item => item === 'ALL') > -1) {
        team = 'ALL'
      } else {
        team = this.queryParams.team.join(',')
      }

      if (this.queryParams?.line.findIndex(item => item === 'ALL') > -1) {
        line = 'ALL'
      } else {
        line = this.queryParams.line.join(',')
      }
      const params = {
        factory: this.queryParams.factory,
        area: this.queryParams.area,
        team: team,
        line: line,
        type: this.queryParams.type,
        date_type: this.queryParams.date_type,
        date: this.queryParams.date
      }

      GetPcbaReasonHistoryData_API(params).then((res) => {
        if (res.data.QueryResult === 'OK') {
          const ReturnObject = res.data.ReturnObject
          this.initData(ReturnObject)
          loading.close()

          const table_box = document.getElementById('out-table02')
          const abnormalRecords_table_detail_left = document.getElementById('abnormalRecords-table-detail-left')
          table_box.onscroll = () => {
            const left = table_box.scrollLeft
            abnormalRecords_table_detail_left.style.transform = `translateX(${left}px)`
          }
        } else {
          loading.close()
        }
      })
    },
    getFactoryTypeList() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.factoryTypeList = res.data.ReturnObject
      })
    },
    changeFactory(val) {
      this.queryParams.area = undefined
      this.queryParams.team = undefined
      this.areaList = []
      this.teamList = []
      const obj = this.factoryTypeList.filter((item) => item.data === val)[0]
      const data = {
        type: 'userarea',
        key: obj.key
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        const arr = res.data.ReturnObject
        this.areaList = arr.filter((item) => {
          return item.data === 'PCBA'
        })
        if (this.areaList.length === 0) {
          this.$message({
            message: this.$t('abnormalRecords.altMsgNotPCBA'),
            type: 'warning'
          })
        } else {
          this.queryParams.area = this.areaList[0].data
          this.changeArea(this.queryParams.area)
        }
      })
    },
    changeArea(val) {
      this.queryParams.team = undefined
      this.teamList = []
      const obj = this.areaList.filter((item) => item.data === val)[0]
      const data = {
        type: 'userteam',
        key: obj.key
      }
      GetDPMQueryKeyValue_API(data).then((res) => {
        this.teamList = res.data.ReturnObject
      })
    },
    handleCancel() {
      this.visible = false
      this.project_name = ''
      this.MTD_all_loss = ''
      this.reason_code_len = 0
      this.detail_new_all = []
      this.data_all_label = []
      this.all_loss_new = []
      this.ap_mtd_list = []
      this.queryParams = {
        factory: undefined,
        area: undefined,
        team: [],
        line: [],
        date: undefined,
        type: undefined,
        date_type: undefined
      }
    },
    combineArray(arr, key) {
      const result = arr.reduce((acc, val) => {
        const lastItem = acc[acc.length - 1]
        if (lastItem && lastItem[0][key] === val[key]) {
          lastItem.push(val)
        } else {
          acc.push([val])
        }
        return acc
      }, [])
      return result
    },
    GetDateTimeString() {
      const date = new Date()
      const year = date.getFullYear()
      let month = (date.getMonth() + 1).toString()
      if (month.length === 1) {
        month = '0' + month
      }
      const YearMonth = year + '-' + month
      return YearMonth
    },
    colorStyle(index, index01) {
      const loss_per = this.detail_new_all[index][index01]['loss_per']
      const ap_per = this.ap_mtd_list[index]['ap_per']
      if (loss_per > ap_per) {
        return 'color:#d54941;font-weight: bold;'
      }
    },
    handleExportExcel() {
      const wb = XLSX.utils.table_to_book(document.querySelector('#out-table02'), {
        raw: true
      })
      const filename = this.queryParams.type + '.xlsx'
      const wbout = XLSX.write(wb, {
        bookType: 'xlsx',
        bookSST: true,
        type: 'array'
      })
      try {
        FileSaver.saveAs(
          // Blob 对象表示一个不可变、原始数据的类文件对象。
          // Blob 表示的不一定是JavaScript原生格式的数据。
          // File 接口基于Blob，继承了 blob 的功能并将其扩展使其支持用户系统上的文件。
          // 返回一个新创建的 Blob 对象，其内容由参数中给定的数组串联组成。
          new Blob([wbout], { type: 'application/octet-stream' }),
          // 设置导出文件名称
          filename
        )
      } catch (e) {
        if (typeof console !== 'undefined') console.log(e, wbout)
      }
      return wbout
    },
    handleReasonCode(reason_code) {
      const params = {
        reason_code: reason_code,
        factory: this.queryParams.factory,
        team: this.queryParams.team,
        date: this.queryParams.date
      }
      this.dialogVisible = true
      this.$nextTick(() => {
        this.$refs['AbnormalRecordsReasonCode'].setUp(params)
      })
    }
  }
}
</script>

<style scoped lang="less">
::v-deep .el-dialog__body {
  padding: 0 20px;
}

.table-box {
  position: relative;
  width: 100%;
  overflow-x: auto;
  padding-left: 599px;
  .abnormalRecords-table-detail {
    border-collapse: collapse;
    border: 1px solid #dcdfe6;
    min-width: 600px;
    tr th {
      border: 1px solid #dcdfe6;
      background-color: #154479;
      color: #ffffff;
      min-width: 80px;
      font-size: 14px;
      height: 36px;
      line-height: 36px;
      padding: 0;
    }
    tr td {
      height: 36px;
      line-height: 36px;
      padding: 0;
      border: 1px solid #dcdfe6;
      min-width: 80px;
      text-align: center;
    }
  }
  .abnormalRecords-table-detail-left {
    position: absolute;
    left: 0;
    z-index: 99;
    background-color: #ffffff;
  }
  .abnormalRecords-table-detail-right {
    tr th {
      min-width: 160px;
      .th-span {
        span {
          width: 50%;
          border-right: 1px solid #dcdfe6;
        }
        span:last-child {
          border-right: 0;
        }
      }
    }
    tr td {
      .th-span {
        span {
          width: 50%;
          border-right: 1px solid #dcdfe6;
        }
        span:last-child {
          border-right: 0;
        }
      }
    }
  }
}
.is-link {
  color: #303133;
  cursor: pointer;
  font-size: 14px;
  font-weight: bold;
  transition: all 300ms ease-in-out;
}
.is-link:hover {
  color: #f56c6c;
}
</style>
