<!-- eslint-disable no-empty -->
<template>
  <div style="height:100%;width:100%;">
    <el-container style="height:100%;">
      <el-header class="header">
        <el-select v-model="queryFactory" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectFactory')" @change="getQueryAreaList">
          <el-option
            v-for="item in factoryList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryArea" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectArea')" @change="getQueryteamList">
          <el-option
            v-for="item in areaList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryTeam" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectTeam')" @change="teamChanged">
          <el-option
            v-for="item in teamList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-date-picker v-model="queryDay" size="small" style="width:140px;margin-right:5px" type="date" :placeholder="$t('common.phdWorkDay')" @chang="selectDateChanged" />
        <el-button type="primary" icon="el-icon-search" size="small" @click="queryData('', false)">{{ $t('common.btnQuery') }}</el-button>
        <el-button type="primary" icon="el-icon-download" size="small" @click="downloadData()">{{ $t('common.btnDownload') }}</el-button>
      </el-header>
      <el-main id="tabMain" style="padding:0;">
        <el-tabs v-model="tabActiveName" @tab-click="tabHandleClick">
          <el-tab-pane label="KPI Review" name="KPIRv" lazy>
            <div :style="{'height': getTabDivHeight()}">
              <div class="kpiDivMainTop">
                <div class="kpiDivMainTopLeft">
                  <div class="kpiDivMainTitle">Overall Performance Dashboard</div>
                  <div id="kpiMainTableDiv" class="kpiDivTable">
                    <el-table
                      ref="tableOverall"
                      :data="tableOverall"
                      size="small"
                      :height="kpiTableHeight"
                      :span-method="arraySpanMethod"
                      :cell-style="getCellColor"
                      :header-cell-style="getHeaderCellColor"
                      style="width: 100%;"
                      @sort-change="kpiSortChangeHandler"
                    >
                      <el-table-column prop="line" label="" align="center">
                        <template slot-scope="scope">
                          <el-link :underline="false" @click="queryDataByLine(scope.row.line) ">{{ scope.row.line }}</el-link>
                        </template>
                      </el-table-column>
                      <el-table-column prop="item" label="" width="70" align="center" />
                      <el-table-column key="1" prop="output" label="Output" align="center" sortable="custom" width="95" />
                      <el-table-column v-if="setColVisibleStatus('eff')" key="2" prop="uph_hit" label="UPH Hit" align="center" sortable="custom" width="95" />
                      <el-table-column v-if="setColVisibleStatus('eff')" key="3" prop="eff" label="Eff" align="center" sortable="custom" width="95" />
                      <!-- 20221117 Kimi 增加毛效率栏位和PPH栏位，取消Online UPPH -->
                      <el-table-column key="4" prop="overall_eff" label="OverAll EFF" align="center" sortable="custom" width="130" />
                      <el-table-column key="5" prop="rty" label="RTY" align="center" sortable="custom" width="95" />
                      <el-table-column v-if="setColVisibleStatus('pph')" key="6" prop="pph" label="PPH" align="center" sortable="custom" width="130" />
                      <!-- <el-table-column prop="online_upph" label="Online UPPH" align="center" sortable="custom" width="130"></el-table-column> -->
                      <el-table-column v-if="setColVisibleStatus('offline_upph')" key="7" prop="offline_upph" label="Offline UPPH" align="center" sortable="custom" width="130" />
                      <el-table-column v-if="setColVisibleStatus('oee1')" key="8" prop="oee1" label="OEE1" align="center" sortable="custom" width="95" />
                      <el-table-column key="9" prop="oee2" label="OEE2" align="center" sortable="custom" width="95" />
                      <el-table-column v-if="setColVisibleStatus('oail')" key="10" prop="oail" label="OAIL" align="center" sortable="custom" width="95" />
                    </el-table>
                  </div>
                </div>
                <div class="kpiDivMainTopRight">
                  <div style="display:flex">
                    <div class="kpiDivMainTitle" style="color:rgb(48,84,150)">{{ lossDivTitle }}</div>
                    <div v-if="index ==='OEE2' || index ===''" class="kpiDivRadio">
                      <el-radio-group v-model="radioLossTypeSelect" @change="changeLoassReasonTable">
                        <el-radio :label="1">By Reason</el-radio>
                        <el-radio :label="2">By Line</el-radio>
                      </el-radio-group>
                    </div>
                    <!-- 20230103 Kimi 因为增加了EFF，所以不能用v-else了，从v-else改成v-if=RTY -->
                    <div v-if="index !== 'UPH' && index !=='' && index !== 'EFF'" class="kpiDivSelect">
                      <el-select v-model="index" style="width:90px;margin-right:5px" size="mini" @change="rtyIndexChangeHandler">
                        <el-option label="RTY" value="RTY" />
                        <!-- <el-option label="NDF" value="NDF" />
                        <el-option label="OATL" value="OATL" />
                        <el-option label="OAIL" value="OAIL" />
                        <el-option label="LRR" value="LRR" /> -->
                      </el-select>
                      <el-select v-model="indexType" style="width:100px;" size="mini" @change="rtyIndexChangeHandler">
                        <el-option label="ByLine" value="line" />
                        <el-option label="ByModel" value="model" />
                      </el-select>
                    </div>
                  </div>
                  <div v-if="index ==='OEE2' || index ==='' || index==='uph_hit'" id="kpiLossDiv" class="lossDiv">
                    <el-table
                      :data="tableLossTop"
                      size="small"
                      :height="kpiLossTableHeight"
                      :span-method="arraySpanMethodLoss"
                      :header-cell-style="getHeaderCellColorLoss"
                      :cell-style="getLossCellColor"
                      style="width: 100%;color: black"
                    >
                      <el-table-column prop="shift" :label="$t('common.colShift')" width="90" align="center" />
                      <el-table-column prop="item" :label="lossTableNameLabel" width="170" align="center" show-overflow-tooltip />
                      <el-table-column prop="loss_pcs" label="Loss Pcs" width="105" align="center" />
                      <el-table-column prop="loss_hours" label="Loss Hours" width="110" align="center" />
                      <el-table-column prop="top5" :label="lossTableTop5Label" header-align="center" show-overflow-tooltip />
                    </el-table>
                  </div>
                  <div v-else id="elChart" class="lossDiv" />
                </div>
              </div>
              <div class="kpiDivMainBottom">
                <div class="kpiDivMainBottomLeft">
                  <div class="kpiDivMainTitle" style="color:#d2691e">{{ issueDivTitle }}</div>
                  <div id="issueMainTableDiv" class="issueDivTable">
                    <el-table
                      v-show="index ==='OEE2' || index ===''"
                      v-loading="loading"
                      :data="tableIssueDesc"
                      size="small"
                      stripe
                      :height="issueTableHeight"
                      :span-method="arraySpanMethodIssue"
                      :header-cell-style="getHeaderCellColorIssue"
                      style="width: 100%;"
                    >
                      <el-table-column prop="line" :label="$t('common.colLine')" width="100" align="center" />
                      <el-table-column prop="shift" :label="$t('common.colShift')" width="100" align="center" />
                      <!-- 20230102 Kimi 修改以下3列的标题 -->
                      <!-- <el-table-column prop="hc_loss_hour" :label="'Over HC\nLoss Hour'" width="85" align="center"></el-table-column>
                            <el-table-column prop="speed_loss_hour" :label="'Speed\nLoss Hour'" width="95" align="center"></el-table-column>
                            <el-table-column prop="mfg_performance" :label="'MFG\nPerf Hour'" width="95" align="center"></el-table-column> -->
                      <el-table-column prop="hc_loss_hour" :label="'Gross Eff\nLoss (Hour)'" width="85" align="center" />
                      <el-table-column prop="speed_loss_hour" :label="'UPH Loss\nHour'" width="95" align="center" />
                      <el-table-column prop="mfg_performance" :label="'MFG Per\nHour'" width="95" align="center" />
                      <el-table-column prop="reason_code" :label="$t('dpmTeamKPI.colReasonCode')" width="120" align="center" show-overflow-tooltip />
                      <el-table-column prop="description" :label="$t('dpmTeamKPI.colIssueDesc')" align="center" show-overflow-tooltip />
                      <el-table-column prop="loss" :label="$t('dpmTeamKPI.colIssueLoss') + '\n(Hour)'" width="100" align="center" />
                      <el-table-column prop="loss_pcs" :label="$t('dpmTeamKPI.colIssueLossPcs')" width="90" align="center" />
                      <el-table-column prop="dri_name" :label="$t('common.colDRI')" width="100" align="center" show-overflow-tooltip />
                      <el-table-column prop="department" :label="$t('common.colDept')" width="120" align="center" show-overflow-tooltip />
                      <el-table-column prop="cost_center" :label="$t('common.colCostCenter')" width="90" align="center" show-overflow-tooltip />
                      <el-table-column prop="solution" :label="$t('common.colSolution')" align="center" show-overflow-tooltip />
                      <!-- <el-table-column prop="speed_loss" :label="'損失時間\nSpeed Loss'" width="100" align="center"></el-table-column> -->
                      <el-table-column :key="12345" :label="$t('common.colOpt')" width="70" align="center">
                        <template slot-scope="scope">
                          <i v-if="scope.row.action_id === ''" class="el-icon-circle-plus-outline" style="cursor:pointer;" @click="addNewAction('UPH', scope.row)" />
                        </template>
                      </el-table-column>
                    </el-table>
                    <el-table
                      v-show="index === 'RTY' && indexType === 'line'"
                      v-loading="loading"
                      :data="tableRTY"
                      size="small"
                      stripe
                      :height="issueTableHeight"
                      :header-cell-style="getHeaderCellColorIssue"
                      style="width: 100%;"
                    >
                      <el-table-column prop="tp" label="" width="100" align="center" />
                      <el-table-column prop="pdline_name" :label="$t('common.colLine')" width="120" align="center" />
                      <el-table-column prop="process_name" :label="$t('common.colProcess')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="part_no" :label="$t('common.colModel')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="rate" label="FPY%" width="100" align="center" />
                      <el-table-column prop="qty" :label="'First Failure Qty\n[PCS]'" width="150" align="center" />
                      <el-table-column label="操作" width="70" align="center">
                        <template slot-scope="scope">
                          <i v-if="scope.row.action_id === ''" class="el-icon-circle-plus-outline" style="cursor:pointer;" @click="addNewAction('RTY', scope.row)" />
                        </template>
                      </el-table-column>
                    </el-table>
                    <el-table
                      v-show="index === 'RTY' && indexType === 'model'"
                      v-loading="loading"
                      :data="tableRTY"
                      size="small"
                      stripe
                      :height="issueTableHeight"
                      :header-cell-style="getHeaderCellColorIssue"
                      style="width: 100%;"
                    >
                      <el-table-column prop="tp" label="" width="100" align="center" />
                      <el-table-column prop="part_no" :label="$t('common.colModel')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="process_name" :label="$t('common.colProcess')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="rate" label="FPY%" width="100" align="center" />
                      <el-table-column prop="qty" :label="'First Failure Qty\n[PCS]'" width="150" align="center" />
                    </el-table>
                    <el-table
                      v-show="index === 'NDF' && indexType === 'line'"
                      v-loading="loading"
                      :data="tableRTY"
                      size="small"
                      stripe
                      :height="issueTableHeight"
                      :header-cell-style="getHeaderCellColorIssue"
                      style="width: 100%;"
                    >
                      <el-table-column prop="tp" label="" width="100" align="center" />
                      <el-table-column prop="pdline_name" :label="$t('common.colLine')" width="120" align="center" />
                      <el-table-column prop="process_name" :label="$t('common.colProcess')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="part_no" :label="$t('common.colModel')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="rate" label="NDF%" width="100" align="center" />
                      <el-table-column prop="qty" :label="'NDF\n[PCS]'" width="150" align="center" />
                      <el-table-column label="操作" width="70" align="center">
                        <template slot-scope="scope">
                          <i v-if="scope.row.action_id === ''" class="el-icon-circle-plus-outline" style="cursor:pointer;" @click="addNewAction('NDF', scope.row)" />
                        </template>
                      </el-table-column>
                    </el-table>
                    <el-table
                      v-show="index === 'NDF' && indexType === 'model'"
                      v-loading="loading"
                      :data="tableRTY"
                      size="small"
                      stripe
                      :height="issueTableHeight"
                      :header-cell-style="getHeaderCellColorIssue"
                      style="width: 100%;"
                    >
                      <el-table-column prop="tp" label="" width="100" align="center" />
                      <el-table-column prop="part_no" :label="$t('common.colModel')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="process_name" :label="$t('common.colProcess')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="rate" label="NDF%" width="100" align="center" />
                      <el-table-column prop="qty" :label="'NDF\n[PCS]'" width="150" align="center" />
                    </el-table>
                    <el-table
                      v-show="index === 'OATL' && indexType ==='line'"
                      v-loading="loading"
                      :data="tableRTY"
                      size="small"
                      stripe
                      :height="issueTableHeight"
                      :header-cell-style="getHeaderCellColorIssue"
                      style="width: 100%;"
                    >
                      <el-table-column prop="tp" label="" width="100" align="center" />
                      <el-table-column prop="pdline_name" :label="$t('common.colLine')" width="120" align="center" />
                      <el-table-column prop="part_no" :label="$t('common.colModel')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="location" :label="$t('dpmTeamKPI.colLocation')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="description" :label="$t('dpmTeamKPI.colDesc')" width="200" align="center" />
                      <el-table-column prop="fail_qty" :label="'Qty\n[PCS]'" width="150" align="center" />
                      <el-table-column :label="$t('common.colOpt')" width="70" align="center">
                        <template slot-scope="scope">
                          <i v-if="scope.row.action_id === ''" class="el-icon-circle-plus-outline" style="cursor:pointer;" @click="addNewAction('OATL', scope.row)" />
                        </template>
                      </el-table-column>
                    </el-table>
                    <el-table
                      v-show="index === 'OATL' && indexType === 'model'"
                      v-loading="loading"
                      :data="tableRTY"
                      size="small"
                      stripe
                      :height="issueTableHeight"
                      :header-cell-style="getHeaderCellColorIssue"
                      style="width: 100%;"
                    >
                      <el-table-column prop="tp" label="" width="100" align="center" />
                      <el-table-column prop="part_no" :label="$t('common.colModel')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="location" :label="$t('dpmTeamKPI.colLocation')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="description" :label="$t('dpmTeamKPI.colDesc')" width="200" align="center" />
                      <el-table-column prop="fail_qty" :label="'Qty\n[PCS]'" width="150" align="center" />
                    </el-table>
                    <el-table
                      v-show="index === 'OAIL' && indexType ==='line'"
                      v-loading="loading"
                      :data="tableRTY"
                      size="small"
                      stripe
                      :height="issueTableHeight"
                      :header-cell-style="getHeaderCellColorIssue"
                      style="width: 100%;"
                    >
                      <el-table-column prop="tp" label="" width="100" align="center" />
                      <el-table-column prop="pdline_name" :label="$t('common.colLine')" width="120" align="center" />
                      <el-table-column prop="part_no" :label="$t('common.colModel')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="location" :label="$t('dpmTeamKPI.colLocation')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="description" :label="$t('dpmTeamKPI.colDesc')" width="200" align="center" />
                      <el-table-column prop="fail_qty" :label="'Qty\n[PCS]'" width="150" align="center" />
                      <el-table-column :label="$t('common.colOpt')" width="70" align="center">
                        <template slot-scope="scope">
                          <i v-if="scope.row.action_id === ''" class="el-icon-circle-plus-outline" style="cursor:pointer;" @click="addNewAction('OAIL', scope.row)" />
                        </template>
                      </el-table-column>
                    </el-table>
                    <el-table
                      v-show="index === 'OAIL' && indexType === 'model'"
                      v-loading="loading"
                      :data="tableRTY"
                      size="small"
                      stripe
                      :height="issueTableHeight"
                      :header-cell-style="getHeaderCellColorIssue"
                      style="width: 100%;"
                    >
                      <el-table-column prop="tp" label="" width="100" align="center" />
                      <el-table-column prop="part_no" :label="$t('common.colModel')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="location" :label="$t('dpmTeamKPI.colLocation')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="description" :label="$t('dpmTeamKPI.colDesc')" width="200" align="center" />
                      <el-table-column prop="fail_qty" :label="'Qty\n[PCS]'" width="150" align="center" />
                    </el-table>
                    <el-table
                      v-show="index === 'LRR'"
                      v-loading="loading"
                      :data="tableRTY"
                      size="small"
                      stripe
                      :height="issueTableHeight"
                      :header-cell-style="getHeaderCellColorIssue"
                      style="width: 100%;"
                    >
                      <el-table-column prop="tp" label="" width="100" align="center" />
                      <el-table-column prop="pdline_name" :label="$t('common.colLine')" width="120" align="center" />
                      <el-table-column prop="part_no" :label="$t('common.colModel')" width="230" align="center" show-overflow-tooltip />
                      <el-table-column prop="oqc_total" :label="$t('dpmTeamKPI.colOQCTotal')" width="110" align="center" show-overflow-tooltip />
                      <el-table-column prop="oqc_ng" :label="$t('dpmTeamKPI.colOQCNG')" width="110" align="center" />
                      <el-table-column prop="oqc_lrr" :label="'LRR\n[Lot%]'" width="110" align="center" />
                      <el-table-column prop="dppm" :label="'LRR\n[DPPM]'" width="110" align="center" />
                      <el-table-column prop="defect_qty" :label="$t('dpmTeamKPI.colNGQty')" width="110" align="center" />
                      <el-table-column prop="description" :label="$t('dpmTeamKPI.colNGDesc')" width="200" align="center" show-overflow-tooltip />
                      <el-table-column :label="$t('common.colOpt')" width="70" align="center">
                        <template slot-scope="scope">
                          <i v-if="scope.row.action_id === ''" class="el-icon-circle-plus-outline" style="cursor:pointer;" @click="addNewAction('LRR', scope.row)" />
                        </template>
                      </el-table-column>
                    </el-table>
                    <!-- 20230103 Kimi 增加EFF KPI Table-->
                    <el-table
                      v-show="index === 'EFF'"
                      v-loading="loading"
                      :data="tableLossData"
                      size="small"
                      stripe
                      :height="issueTableHeight"
                      :header-cell-style="getHeaderCellColorIssue"
                      style="width: 100%;"
                    >
                      <el-table-column prop="line" :label="$t('common.colLine')" width="120" align="center" />
                      <el-table-column prop="shift" :label="$t('common.colShift')" width="80" align="center" />
                      <el-table-column prop="std" :label="$t('dpmTeamKPI.colSTDHour')" width="130" align="center" />
                      <el-table-column prop="act" :label="$t('dpmTeamKPI.colACTHour')" width="130" align="center" />
                      <el-table-column prop="gap" label="Gap" width="130" align="center" />
                      <el-table-column prop="gross" label="Gross Eff" width="120" align="center" />
                    </el-table>
                  </div>
                </div>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="Action Review" name="actionRv" lazy class="pane">
            <div id="actionMainTableDiv" class="actionDivTable">
              <el-table
                v-loading="loadingReview"
                :data="tableAction"
                size="small"
                :height="actionTableHeight"
                :header-cell-style="getHeaderCellColor"
                style="width: 100%;"
                :default-sort="{prop: 'due_date', order: 'descending'}"
              >
                <el-table-column prop="seq" label="#" width="70" align="center" />
                <el-table-column prop="kpi" :label="$t('dpmTeamKPI.colBindKPI')" sortable width="100" align="center" />
                <el-table-column prop="action" label="Action" sortable width="200" align="center" show-overflow-tooltip />
                <el-table-column prop="owner" label="Owner" sortable width="150" align="center" show-overflow-tooltip />
                <el-table-column prop="due_date" label="Due Day" sortable width="120" align="center" />
                <el-table-column prop="status" label="Status" sortable width="110" align="center" show-overflow-tooltip />
                <el-table-column prop="type" label="Priority Of The Day" sortable width="120" align="center" show-overflow-tooltip />
                <!-- <el-table-column prop="history_issue" label="History Issue" sortable align="center" show-overflow-tooltip /> -->

                <el-table-column prop="work_date" label="Work Date" sortable align="center" show-overflow-tooltip />
                <el-table-column prop="pdline_name" label="Pdline" sortable align="center" show-overflow-tooltip />
                <el-table-column prop="PROCESS_NAME" label="Process Name" sortable align="center" show-overflow-tooltip />
                <el-table-column prop="PART_NO" label="PartNo" sortable align="center" show-overflow-tooltip />
                <el-table-column prop="RATE" label="Rate" sortable align="center" show-overflow-tooltip />
                <el-table-column prop="fail_qty" label="QTY" sortable align="center" show-overflow-tooltip />

              </el-table>
            </div>
          </el-tab-pane>
        </el-tabs>
      </el-main>
    </el-container>

    <el-dialog
      :center="true"
      title="Escalate Action"
      :close-on-press-escape="false"
      :visible.sync="escalateDialogVisible"
      width="700px"
      :close-on-click-modal="false"
    >
      <div style="height:370px">
        <span class="escalateTitleSpan">Issue escalate:</span>
        <el-input id="txtIssueContent" v-model="issueContent" type="textarea" :rows="2" readonly />
        <span class="escalateTitleSpan">Action:</span>
        <el-radio-group v-model="radioBindActionType" @change="refreshUnclosedActionList">
          <el-radio :label="1">{{ $t('dpmTeamKPI.rbAddAction') }}</el-radio>
          <el-radio :label="2">{{ $t('dpmTeamKPI.rbBindToArea') }}</el-radio>
          <el-radio :label="3">{{ $t('dpmTeamKPI.rbBindToFactory') }}</el-radio>
        </el-radio-group>
        <br>
        <el-input v-show="radioBindActionType===1" v-model="newActionContent" type="textarea" :rows="2" :placeholder="$t('dpmTeamKPI.phdKeyinNewAction')" />
        <el-select v-show="radioBindActionType!==1" v-model="selectedActionId" :placeholder="$t('dpmTeamKPI.phdSelectAction')" size="small" style="width:100%">
          <el-option
            v-for="item in actionList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          >
            <!-- <span style="float: left">{{ item.key }}</span>
              <span style="float: right; color: #8492a6; font-size: 13px">{{ item.data }}</span> -->
            <el-popover placement="bottom-end" width="500" trigger="hover" :content="item.data">
              <div slot="content">{{ item.data }}</div>
              <span slot="reference" class="actionItemSpan">{{ item.data }}</span>
            </el-popover>
          </el-option>
        </el-select>
        <span class="escalateTitleSpan">Type:</span>
        <el-radio-group v-model="radioActionType" :disabled="radioBindActionType!==1">
          <el-radio :label="1">24H Action</el-radio>
          <el-radio :label="2">Lesson Learnt</el-radio>
          <el-radio :label="3">{{ $t('dpmTeamKPI.rbWave') }}</el-radio>
        </el-radio-group>
        <span class="escalateTitleSpan">Owner:</span>
        <el-input v-model="actionOwner" :placeholder="$t('dpmTeamKPI.phdSelectOwner')" size="small" :disabled="true">
          <el-button slot="append" icon="el-icon-search" :disabled="radioBindActionType!==1" @click="openChooseEmpDialog" />
        </el-input>
        <span class="escalateTitleSpan">Due day:</span>
        <el-date-picker v-model="actionDueDay" type="date" style="width:100%" size="small" :placeholder="$t('dpmTeamKPI.phdSelectDay')" :disabled="radioBindActionType!==1" />
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="success" size="small" @click="saveEscalate">{{ $t('common.btnSave') }}</el-button>
        <el-button type="danger" size="small" @click="closeEscalatelDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="$t('dpmTeamKPI.lblTitleSelectDRI')"
      :close-on-press-escape="false"
      :visible.sync="chooseEmpDialogVisible"
      width="600px"
      :close-on-click-modal="false"
    >
      <div style="height:250px">
        <el-input v-model="queryEmp" :placeholder="$t('dpmTeamKPI.phdKeyinEmpId')" size="small">
          <el-button slot="append" icon="el-icon-search" @click="queryEmpList" />
        </el-input>
        <el-table
          :data="tableEmp"
          size="small"
          :height="200"
          style="width: 100%;"
        >
          <el-table-column prop="employee_id" :label="$t('common.colEmpId')" width="100" align="center" show-overflow-tooltip />
          <el-table-column prop="name" :label="$t('common.colEmpName')" width="100" align="center" show-overflow-tooltip />
          <el-table-column prop="department" :label="$t('common.colDept')" width="150" align="center" show-overflow-tooltip />
          <el-table-column prop="dept_id" :label="$t('common.colCostCenter')" width="120" align="center" show-overflow-tooltip />
          <el-table-column :label="$t('common.colOpt')" width="70" align="center">
            <template slot-scope="scope">
              <el-button type="text" size="small" style="color:blue" @click="selectDRI(scope.row)">{{ $t('common.btnSelect') }}</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="danger" size="small" @click="closeChooseEmpDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import { downLoadDPMEscalateActionReviewData } from '@/api/upload_download'
import {
  GetDPMQueryKeyValue, GetDPMTeamKpiReviewDataGrid, GetEmpInfoList, DPMIssueEscalate, GetDPMUnClosedEscalateActionList, GetDPMEscalateActionReviewData,
  GetDPMTeamKpiReviewKpiChartData, GetDPMTeamKPIReviewKpiLossData
} from '@/api/midway.js'

export default {
  components: {

  },
  data() {
    return {
      tabActiveName: 'KPIRv',
      tabDivHeight: 1,
      radioLossTypeSelect: 1,
      issueDivTitle: 'Issue Description',
      lossDivTitle: 'Loss Reason Top 5',
      lossTableNameLabel: 'Reason Code',
      lossTableTop5Label: this.$t('dpmTeamKPI.lblTop5Line'),
      escalateDialogVisible: false,
      issueKpi: '',
      issueRowId: '',
      issueContent: '',
      radioBindActionType: 1,
      radioActionType: 1,
      actionList: [],
      selectedActionId: '',
      newActionContent: '',
      actionOwner: '',
      actionDueDay: null,
      chooseEmpDialogVisible: false,
      tableEmp: [],
      queryEmp: '',
      queryFactory: '',
      factoryList: [],
      queryArea: '',
      areaList: [],
      queryTeam: '',
      queryDay: '',
      teamList: [],
      tableHeight: 1,
      loadingData: null,
      keyid: '',
      loading: false,
      loadingReview: false,
      tableOverall: [],
      kpiTableHeight: 1,
      kpiLossTableHeight: 1,
      issueTableHeight: 1,
      tableIssueDesc: [],
      spanRows: [],
      tableLossTopReason: [],
      tableLossTopLine: [],
      tableLossTop: [],
      line: '',
      index: '', // UPH or RTY
      indexType: 'line', // line or model
      chart: null,
      tableRTY: [],
      lossTableShift: '',
      driList: [],
      selectedDRI: '',
      actionTableHeight: 1,
      tableAction: [],
      tableLossData: [], // 20230103 Kimi 增加EFF KPI
      lossTableShiftIndex: [],
      pickerOptions: {}
    }
  },
  computed: {
  },
  mounted() {
    this.resizeTable()
    this.getDefaultDate()
    this.getQueryFactoryList()
    // this.initialData()
    window.onresize = () => {
      this.resizeTable()
      if (this.chart !== null) {
        this.chart.resize()
      }
    }
  },
  beforeDestroy() {
  },
  methods: {
    setColVisibleStatus(kpi) {
      let status = true
      let area = ''
      try {
        area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      } catch {
        status = true
      }
      if (area === '') {
        status = true
      } else if (area === 'PCBA') {
        switch (kpi.toLowerCase()) {
          case 'pph':
            status = false
            break
          case 'offline_upph':
            status = false
            break
          case 'eff':
            status = false
            break
          case 'uph_hit':
            status = false
            break
        }
      } else if (area === 'FATP') {
        switch (kpi.toLowerCase()) {
          case 'oee1':
            status = false
            break
          case 'oail':
            status = false
            break
        }
      }

      return status
    },

    tabHandleClick(tab, event) {
    },
    getTabDivHeight() {
      return this.tabDivHeight + 'px'
    },
    getDefaultDate() {
      const curDate = new Date()
      this.queryDay = new Date(curDate.getTime() - 24 * 60 * 60 * 1000)
      // 给日期控件限定只能选当日及以后的数据 add by liwen at 24240423
      const selectTime = this.queryDay.getTime() - 24 * 60 * 60 * 1000
      this.pickerOptions = {
        disabledDate(time) {
          return time.getTime() < selectTime
        }
      }
    },
    selectDateChanged() {
      // 给日期控件限定只能选当日及以后的数据 add by liwen at 24240423
      const selectTime = this.queryDay.getTime()
      this.pickerOptions = {
        disabledDate(time) {
          return time.getTime() < selectTime
        }
      }
    },
    arraySpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex % 2 === 0) {
          return [2, 1]
        } else {
          return [0, 0]
        }
      }
    },
    arraySpanMethodLoss({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        for (let i = 0; i < this.lossTableShiftIndex.length; i++) {
          if (i < this.lossTableShiftIndex.length - 1 && rowIndex === this.lossTableShiftIndex[i]) {
            return [this.lossTableShiftIndex[i + 1] - this.lossTableShiftIndex[i], 1]
          } else if (i === this.lossTableShiftIndex.length - 1 && rowIndex === this.lossTableShiftIndex[i]) {
            return [this.tableLossTop.length - this.lossTableShiftIndex[i], 1]
          } else {
            if (i === this.lossTableShiftIndex.length - 1) {
              return [0, 0]
            }
          }
        }
      }
    },
    arraySpanMethodIssue({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0 || columnIndex === 1 || columnIndex === 2 || columnIndex === 3 || columnIndex === 4) {
        const ff = this.spanRows.filter(x => x.rowIndex === rowIndex)
        if (ff.length > 0) {
          return [ff[0].spanQty, 1]
        } else {
          return [0, 0]
        }
      // if (rowIndex === 0) {
      //   return [2, 1]
      // } else if (rowIndex === 2 || rowIndex === 3) {
      //   return [1, 1]
      // } else {
      //   return [0, 0]
      // }
      }
    },
    changeLoassReasonTable() {
      this.issueDivTitle = 'Issue Description ' + (this.line === '' ? 'OverAll' : this.line)
      if (this.radioLossTypeSelect === 1) {
        this.lossDivTitle = 'Loss Reason Top 5 ' + (this.line === '' ? 'OverAll' : this.line)
        this.lossTableNameLabel = 'Reason Code'
        this.lossTableTop5Label = this.$t('dpmTeamKPI.lblTop5Line')
        this.tableLossTop = this.tableLossTopReason
      } else {
        this.lossDivTitle = 'Line Loss Top 5 ' + (this.line === '' ? 'OverAll' : this.line)
        this.lossTableNameLabel = this.$t('common.lblLine')
        this.lossTableTop5Label = 'Top5 Reason Code'
        this.tableLossTop = this.tableLossTopLine
      }

      if (this.tableLossTop[0]) {
        this.lossTableShift = this.tableLossTop[0].shift_code
      }
      this.lossTableShiftIndex = []
      this.lossTableShiftIndex.push(0)
      for (let i = 0; i < this.tableLossTop.length; i++) {
        if (this.tableLossTop[i].shift_code !== this.lossTableShift) {
          this.lossTableShiftIndex.push(i)
          this.lossTableShift = this.tableLossTop[i].shift_code
        }
      }
    },
    rtyIndexChangeHandler() {
      this.resetDivTitle()
      this.queryData(this.line, false)
    },
    kpiSortChangeHandler(column) {
      try {
        const prop = column.prop.toLowerCase()
        const order = column.order.toLowerCase()
        // ascending, descending
        const newArray = []
        newArray.push(this.tableOverall.filter(x => x.line.toLowerCase() === 'overall' && x.item.toLowerCase() === 'goal')[0])
        newArray.push(this.tableOverall.filter(x => x.line.toLowerCase() === 'overall' && x.item.toLowerCase() === 'act')[0])
        const tempArray = this.tableOverall.filter(x => x.line.toLowerCase() !== 'overall' && x.item.toLowerCase() === 'act')
        tempArray.sort(function(a, b) {
          let valueA
          let valueB
          switch (prop) {
            case 'output':
              valueA = a.output
              valueB = b.output
              break
            case 'uph_hit':
              valueA = a.uph_hit
              valueB = b.uph_hit
              break
            case 'oee2':
              valueA = a.oee2
              valueB = b.oee2
              break
            case 'eff':
              valueA = a.eff
              valueB = b.eff
              break
              // 20221117 Kimi 增加毛效率栏位和PPH栏位，取消Online UPPH
            case 'overall_eff':
              valueA = a.overall_eff
              valueB = b.overall_eff
              break
            case 'pph':
              valueA = a.pph
              valueB = b.pph
              break
              // case 'online_upph':
              //   valueA = a.online_upph
              //   valueB = b.online_upph
              //   break
            case 'rty':
              valueA = a.rty
              valueB = b.rty
              break
            case 'offline_upph':
              valueA = a.offline_upph
              valueB = b.offline_upph
              break
          }
          valueA = valueA.replace('%', '')
          valueB = valueB.replace('%', '')
          if (order === 'ascending') {
            return parseFloat(valueA) - parseFloat(valueB)
          } else {
            return parseFloat(valueB) - parseFloat(valueA)
          }
        })
        tempArray.forEach(x => {
          newArray.push(this.tableOverall.filter(t => t.line === x.line && t.item.toLowerCase() === 'goal')[0])
          newArray.push(this.tableOverall.filter(t => t.line === x.line && t.item.toLowerCase() === 'act')[0])
        })
        this.tableOverall = newArray

        // 如果是UPH或者RTY的，显示对应的内容
        let tempIndex = ''
        if (prop.indexOf('oee2') >= 0) {
          tempIndex = 'OEE2'
        } else if (prop.indexOf('rty') >= 0) {
          tempIndex = 'RTY'
        } else if (prop.indexOf('eff') >= 0) { // 20230103 Kimi 增加EFF KPI
          tempIndex = 'EFF'
        } else if (prop.indexOf('uph_hit') >= 0) {
          tempIndex = 'OEE2'
        }
        if (this.index !== tempIndex && tempIndex !== '') {
          this.index = tempIndex
          this.queryData('', false)
        }
      // eslint-disable-next-line no-empty
      } catch {}
    },
    clearTable() {
      this.tableOverall = []
      this.tableIssueDesc = []
      this.spanRows = []
      this.tableRTY = []
      this.tableLossTop = []
      this.tableLossTopReason = []
      this.tableLossTopLine = []
    },
    async getQueryFactoryList() {
      this.destroyChart()
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.factoryList = []
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.factoryList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryAreaList() {
      this.destroyChart()
      this.clearTable()
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = ''
      this.line = ''
      const data = {
        type: 'userarea',
        key: this.queryFactory
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryteamList() {
      this.destroyChart()
      this.clearTable()
      this.teamList = []
      this.queryTeam = ''
      this.line = ''
      const data = {
        type: 'userteam',
        key: this.queryArea
      }
      this.teamList.push({
        key: 'ALL',
        data: 'ALL'
      })
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        response.data.ReturnObject.forEach(d => {
          this.teamList.push(d)
        })
      } else {
        this.alertMsg(queryResult)
      }
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      if (area === 'FATP') {
        this.index = 'OEE2'
      } else {
        this.index = 'RTY'
      }
      this.resetDivTitle()
    },
    teamChanged() {
      this.line = ''
    },
    resetDivTitle() {
      if (this.index === 'RTY') {
        this.lossDivTitle = 'RTY Review ' + (this.line === '' ? 'OverAll' : this.line)
        this.issueDivTitle = 'RTY Detail ' + (this.line === '' ? 'OverAll' : this.line)
      } else if (this.index === 'NDF') {
        this.lossDivTitle = 'NDF Review ' + (this.line === '' ? 'OverAll' : this.line)
        this.issueDivTitle = 'NDF Detail ' + (this.line === '' ? 'OverAll' : this.line)
      } else if (this.index === 'OATL') {
        this.lossDivTitle = 'OATL Review ' + (this.line === '' ? 'OverAll' : this.line)
        this.issueDivTitle = 'OATL Detail ' + (this.line === '' ? 'OverAll' : this.line)
      } else if (this.index === 'OAIL') {
        this.lossDivTitle = 'OAIL Review ' + (this.line === '' ? 'OverAll' : this.line)
        this.issueDivTitle = 'OAIL Detail ' + (this.line === '' ? 'OverAll' : this.line)
      } else if (this.index === 'LRR') {
        this.lossDivTitle = 'LRR Review ' + (this.line === '' ? 'OverAll' : this.line)
        this.issueDivTitle = 'LRR Detail ' + (this.line === '' ? 'OverAll' : this.line)
      } else if (this.index === 'OEE2') {
        this.changeLoassReasonTable()
      } else if (this.index === 'EFF') { // 20230103 Kimi 增加EFF KPI
        this.lossDivTitle = 'EFF Review ' + (this.line === '' ? 'OverAll' : this.line)
        this.issueDivTitle = 'EFF Detail ' + (this.line === '' ? 'OverAll' : this.line)
      }
    },
    getCellColor({ row, column, rowIndex, columnIndex }) {
      if (columnIndex > 1) {
        if (rowIndex % 2 !== 0) {
          const label = column.label.toLowerCase()?.replace(' ', '_')
          const goal = (this.tableOverall[rowIndex - 1])[label]?.replace('%', '')
          const act = row[label]?.replace('%', '')
          if (goal !== undefined && act !== undefined && goal !== '' && act !== '') {
            if (parseFloat(act) < parseFloat(goal)) {
              if (rowIndex === 1) {
                return 'color: red; background: rgb(217, 217, 217);'
              } else {
                return 'color: red; background: rgb(221, 235, 247);'
              }
            }
            if (rowIndex === 1) {
              return 'color: blue; background: rgb(217, 217, 217);'
            } else {
              return 'color: blue; background: rgb(221, 235, 247);'
            }
          } else {
            return 'color: blue; background: rgb(221, 235, 247);'
          }
        } else {
          return 'color: black'
        }
      } else if (columnIndex === 1) {
        if (rowIndex % 2 !== 0) {
          if (rowIndex === 1) {
            return 'color: black; background: rgb(217, 217, 217);'
          }
          return 'color: black; background: rgb(221, 235, 247);'
        } else {
          return 'color: black'
        }
      } else if (columnIndex === 0) {
        if (rowIndex < 2) {
          return 'color: white; background: rgb(48, 84, 150);'
        }
        return 'background: white; color: black;'
      }
    },
    getLossCellColor({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        for (let i = 0; i < this.lossTableShiftIndex.length; i++) {
          if (i < this.lossTableShiftIndex.length - 1) {
            if (rowIndex >= this.lossTableShiftIndex[i] && rowIndex < this.lossTableShiftIndex[i + 1]) {
              if ((i + 2) % 2 === 1) {
                return 'background: rgb(205,201,201); color: black;'
              } else {
                return 'background: rgb(221, 235, 247); color: black;'
              }
            }
          } else {
            if (i === this.lossTableShiftIndex.length - 1) {
              if ((i + 2) % 2 === 1) {
                return 'background: rgb(205,201,201); color: black;'
              } else {
                return 'background: rgb(221, 235, 247); color: black;'
              }
            }
          }
        }
      } else {
        for (let i = 0; i < this.lossTableShiftIndex.length; i++) {
          if (i < this.lossTableShiftIndex.length - 1) {
            if (rowIndex === this.lossTableShiftIndex[i + 1] - 2) {
              return 'background: rgb(226, 239, 218); color:black'
            }
            if (rowIndex === this.lossTableShiftIndex[i + 1] - 1) {
              if ((i + 2) % 2 === 1) {
                return 'background: rgb(205,201,201); color: black;'
              } else {
                return 'background: rgb(221, 235, 247); color: black;'
              }
            }
          } else {
            if (rowIndex === this.tableLossTop.length - 2) {
              return 'background: rgb(226, 239, 218); color:black'
            }
            if (rowIndex === this.tableLossTop.length - 1) {
              if ((i + 2) % 2 === 1) {
                return 'background: rgb(205,201,201); color: black;'
              } else {
                return 'background: rgb(221, 235, 247); color: black;'
              }
            }
          }
        }
      }
    },
    getHeaderCellColor() {
      const style = {
        'background-color': 'rgb(32,55,100)',
        color: 'white'
      }
      return style
    },
    getHeaderCellColorLoss() {
      const style = {
        'background-color': 'rgb(48,84,150)',
        color: 'white'
      }
      return style
    },
    getHeaderCellColorIssue() {
      const style = {
        'background-color': '#d2691e',
        color: 'white'
      }
      return style
    },
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex < 4) {
        if (rowIndex % 2 === 0) {
          return {
            rowspan: 2,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    },
    getBackgroundColor() {
      if (this.viewRange === 'currentshift') {
        return 'radial-gradient(#26589A, #191D50)'
      } else {
        return 'radial-gradient(#60c8d2,#191D50)'
      }
    },
    addNewAction(kpi, row) {
      this.GetDPMUnClosedEscalateActionList()
      let sToday = this.$utils.GetDateString(this.queryDay)
      sToday = sToday.substr(5, 5).replace('-', '/')
      if (kpi === 'UPH' || kpi === '') {
        this.issueContent = sToday + ' | ' + row.line + ' | ' + row.shift + ' | ' +
        row.reason_code + ' | ' + row.description + ' | ' + (row.solution === '' ? 'N/A' : row.solution) + ' | ' + row.dri_name + ' | ' + row.department
      } else if (kpi === 'RTY' || kpi === 'NDF') {
        this.issueContent = sToday + ' | ' + row.pdline_name + ' | ' + row.process_name + ' | ' +
        row.part_no + ' | ' + row.rate + '% | ' + row.qty
      } else if (kpi === 'OATL' || kpi === 'OAIL') {
        this.issueContent = sToday + ' | ' + row.pdline_name + ' | ' + row.part_no + ' | ' +
        (row.location === '' ? 'N/A' : row.location) + ' | ' + (row.description === '' ? 'N/A' : row.description) + ' | ' + row.fail_qty
      } else if (kpi === 'LRR') {
        this.issueContent = sToday + ' | ' + row.pdline_name + ' | ' + row.part_no + ' | ' +
        row.oqc_total + ' | ' + row.oqc_ng + ' | ' + row.oqc_lrr + '% | ' + row.dppm + ' | ' + row.defect_qty + ' | ' + row.description
      } else {
        this.issueContent = sToday
      }
      this.issueRowId = row.row_id
      this.issueKpi = kpi
      this.radioBindActionType = 1
      this.newActionContent = ''
      this.radioActionType = 1
      this.actionOwner = ''
      this.actionDueDay = null
      this.escalateDialogVisible = true
    },
    async refreshUnclosedActionList() {
      if (this.radioBindActionType === 2 || this.radioBindActionType === 3) {
        this.GetDPMUnClosedEscalateActionList()
      }
    },
    async GetDPMUnClosedEscalateActionList() {
      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const data = {
        factory: factory,
        area: area,
        range: this.radioBindActionType
      }
      const response = await GetDPMUnClosedEscalateActionList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.actionList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeEscalatelDialog() {
      this.escalateDialogVisible = false
    },
    async saveEscalate() {
      if (this.radioBindActionType === 1) {
        if (this.newActionContent === '') {
          this.alertMsg(this.$t('dpmTeamKPI.altMsgActionEmpty'))
          return
        }
      } else {
        if (this.selectedActionId === '') {
          this.alertMsg(this.$t('dpmTeamKPI.altMsgChooseAction'))
          return
        }
      }
      if (this.actionDueDay === null || this.actionDueDay === '') {
        this.alertMsg(this.$t('dpmTeamKPI.altMsgDueDayEmpty'))
        return
      }
      if (this.actionOwner === '') {
        this.alertMsg(this.$t('dpmTeamKPI.altMsgOwnerEmpty'))
        return
      }
      let actionType = ''
      switch (this.radioActionType) {
        case 1:
          actionType = '24H Action'
          break
        case 2:
          actionType = 'Lesson Learnt'
          break
        case 3:
          actionType = 'Wave 舉措'
          break
      }
      if (actionType === '') {
        this.alertMsg(this.$t('dpmTeamKPI.altMsgTypeEmpty'))
        return
      }
      let owner = ''
      owner = this.actionOwner.split('[')[0]
      let dueDay = ''
      dueDay = this.$utils.GetDateString(this.actionDueDay)

      if (!confirm(this.$t('dpmTeamKPI.altConfirmEscalate'))) {
        return
      }
      const data = {
        kpi: this.issueKpi,
        rowId: this.issueRowId,
        issueDesc: this.issueContent,
        actionId: this.selectedActionId,
        action: this.newActionContent,
        escalateType: actionType,
        owner: owner,
        dueDay: dueDay
      }
      const response = await DPMIssueEscalate(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.closeEscalatelDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    openChooseEmpDialog() {
      this.queryEmp = ''
      this.tableEmp = []
      this.chooseEmpDialogVisible = true
    },
    closeChooseEmpDialog() {
      this.tableEmp = []
      this.queryEmp = ''
      this.chooseEmpDialogVisible = false
    },
    async queryEmpList() {
      if (this.queryEmp === null) {
        this.alertMsg(this.$t('dpmTeamKPI.altMsgFilterEmpty'))
        return
      }
      if (this.queryEmp === '') {
        this.alertMsg(this.$t('dpmTeamKPI.altMsgFilterEmpty'))
        return
      }
      this.tableEmp = []
      const data = {
        filter: this.queryEmp
      }
      const response = await GetEmpInfoList(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.tableEmp = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    selectDRI(row) {
      this.actionOwner = row.employee_id + '[' + row.name + ' | ' + row.dept_id + ' | ' + row.department + ']'
      this.closeChooseEmpDialog()
    },
    initialData() {
      this.keyid = this.$route.query.keyid
    // 抓取项目数据显示在看板上
    // this.getDashBoardData()
    },
    queryDataByLine(line) {
    // 20230103 Kimi EFF是ByTeam，因此点击line时，不做查询
      if (this.index === 'EFF') {
        return
      }
      this.line = line
      this.queryData(line, false)
    },
    async queryData(key, onlyIssueTableFlag) {
      if (this.queryTeam === '') {
        this.alertMsg(this.$t('dpmTeamKPI.altMsgFilterEmpty'))
        return
      }
      if (!onlyIssueTableFlag) {
        this.loadingData = this.$loading({
          lock: true,
          text: this.$t('common.altMsgLoading'),
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        })
      } else {
        this.loading = true
      }
      if (!onlyIssueTableFlag) {
        if (this.line === '') {
          this.tableOverall = []
        }
      }
      this.tableRTY = []
      this.tableIssueDesc = []
      this.spanRows = []
      this.tableLossTopReason = []
      this.tableLossTopLine = []
      if (!onlyIssueTableFlag) {
        this.destroyChart()
      }
      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      const workDay = this.$utils.GetDateString(this.queryDay)
      if (this.index === '') {
        if (area === 'FATP') {
          this.index = 'OEE2'
        } else {
          this.index = 'RTY'
        }
      }
      const data = {
        factory: factory,
        area: area,
        team: team,
        workDay: workDay,
        line: this.line,
        index: this.index,
        type: this.indexType,
        key: key
      }
      const response = await GetDPMTeamKpiReviewDataGrid(data)
      if (!onlyIssueTableFlag) {
        this.loadingData.close()
      } else {
        this.loading = false
      }
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        if (this.line === '') {
          this.tableOverall = obj.kpiTable
        }
        if (this.index === 'OEE2') {
          this.tableLossTopReason = obj.top5LossReason
          this.tableLossTopLine = obj.top5LossLine
          this.changeLoassReasonTable()
          // 查看返回的ISSUE表格，看需要合并单元格的行数
          let lastLine = ''
          let lastShift = ''
          let spanQty = 0
          let rowIndex = 0
          for (let i = 0; i < obj.issueLogs.length; i++) {
            const line = obj.issueLogs[i].line
            const shift = obj.issueLogs[i].shift
            if (line !== lastLine || shift !== lastShift) {
              lastLine = line
              lastShift = shift
              if (spanQty > 0) {
                this.spanRows.push({
                  rowIndex: rowIndex,
                  spanQty: spanQty
                })
                rowIndex = i
                spanQty = 0
              }
            }
            spanQty = spanQty + 1
            if (i === obj.issueLogs.length - 1) {
              this.spanRows.push({
                rowIndex: rowIndex,
                spanQty: spanQty
              })
            }
          }
          this.tableIssueDesc = obj.issueLogs
        } else if (this.index === 'EFF') {
        // 20220103 Kimi 增加EFF Index
          this.resetDivTitle()
          if (!onlyIssueTableFlag) {
            this.showEFFIndexChart(factory, area, team, workDay)
          }
        } else {
          this.resetDivTitle()
          if (!onlyIssueTableFlag) {
            this.setChart(obj.chart)
          }
          this.tableRTY = obj.rtyTable
        }
      } else {
        this.alertMsg(queryResult)
      }

      if (key === '') {
        this.queryActionReviewDaa()
      }
    },
    // ------------------------------------------------------------------
    // 20230103 Kimi 增加EFF Index
    async showEFFIndexChart(factory, area, team, workDay) {
      this.destroyChart()
      const kpi = 'EFF'
      const dataq = {
        factory: factory,
        area: area,
        team: team,
        kpi: kpi,
        workDay: workDay
      }
      const response = await GetDPMTeamKpiReviewKpiChartData(dataq)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const data = response.data.ReturnObject
        var chartDom = document.getElementById('elChart')
        this.chart = this.$echarts.init(chartDom)
        this.chart.clear()
        const series = []
        const dataList = []
        data.seriesData.forEach(x => {
          dataList.push({
            value: x.value,
            itemStyle: {
              color: x.itemStyle.color
            }
          })
        })
        if (dataList.length === 0 && team === 'ALL') {
          this.$alert(this.$t('dpmTeamKPI.altMsgEff'), this.$t('common.altMsgTitle'), {
            confirmButtonText: this.$t('common.altMsgBtn'),
            type: 'warning'
          })
        }
        series.push({
          data: dataList,
          type: 'bar',
          label: {
            show: true,
            position: 'inside',
            formatter: '{c}'
          }
        })
        let showZoom = false
        let endValue = 100
        if (dataList.length > 10) {
          showZoom = true
          endValue = (10 / dataList.length * 100)
        // endValue = 10
        }
        var option
        option = {
          title: {
            text: this.$t('dpmTeamKPI.lblEffRate'),
            left: 'center'
          },
          tooltip: {
            trigger: 'axis'
          },
          toolbox: {
            feature: {
              dataView: { show: true, readOnly: false },
              saveAsImage: {}
            }
          },
          xAxis: {
            type: 'category',
            data: data.xAxisData,
            axisLabel: {
              interval: 'auto',
              rotate: -30
            }
          },
          yAxis: {
            type: 'value'
          },
          series: series,
          dataZoom: [
            {
              orient: 'horizontal',
              type: 'slider',
              xAxisIndex: 0,
              yAxixIndex: 0,
              show: showZoom,
              realtime: true,
              height: 24,
              start: 0,
              end: endValue,
              // bottom: '4%',
              zoomLock: false
            }
          ]
        }
        this.chart.setOption(option)
        const that = this
        this.chart.on('click', function(params) {
          that.GetItemIssueDetail(kpi, params.name)
        })
        // 显示完图表以后，再显示点击第一个柱子后带出的table信息
        let queryItem = ''
        if (data.xAxisData.length > 0) {
          queryItem = data.xAxisData[0]
        }
        this.GetItemIssueDetail(kpi, queryItem)
      } else {
        this.alertMsg(queryResult)
      }
    },
    async GetItemIssueDetail(kpi, item) {
      this.tableLossData = []
      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      const workDay = this.$utils.GetDateString(this.queryDay)
      const data = {
        factory: factory,
        area: area,
        team: team,
        kpi: kpi,
        item: item,
        workDay: workDay
      }
      this.loading = true
      const response = await GetDPMTeamKPIReviewKpiLossData(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.tableLossData = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    // ------------------------------------------------------------------
    async queryActionReviewDaa() {
      this.tableAction = []
      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      const workDay = this.$utils.GetDateString(this.queryDay)
      this.loadingReview = true
      const data = {
        factory: factory,
        area: area,
        team: team,
        workDay: workDay
      }
      const response = await GetDPMEscalateActionReviewData(data)
      this.loadingReview = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.tableAction = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    destroyChart() {
      if (this.chart !== null && this.chart !== '' && this.chart !== undefined) {
        this.chart.dispose()
      }
    },
    setChart(obj) {
      let name = 'Value'
      switch (this.index) {
        case 'RTY':
          name = 'RTY%'
          break
        case 'NDF':
          name = 'NDF%'
          break
        case 'OATL':
          name = 'OATL'
          break
        case 'OAIL':
          name = 'OAIL'
          break
        case 'LRR':
          name = 'LRR%'
          break
      }
      const that = this // 20230105 Kimi 将底部的这句提上来
      let rotate = 0
      if (this.line === '' || this.line.toLowerCase() === 'overall') {
        rotate = -30
      }
      let showZoom = false
      let endValue = 100
      if (obj.data.length > 10) {
        showZoom = true
        endValue = (10 / obj.data.length * 100)
      // endValue = 10
      }
      this.destroyChart()
      const option = {
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        tooltip: {
          trigger: 'axis'
        },
        xAxis: {
          type: 'category',
          data: obj.xAxis,
          axisLabel: {
            interval: 'auto',
            rotate: rotate
          }
        },
        yAxis: {
          type: 'value',
          // 20230105 Kimi 针对RTY，因为都很靠近100%，因此柱状图的最小值优化一下
          min: function(value) {
            if (that.index === 'RTY') {
              if (value.min < 10) {
                return 0
              } else {
                const minValue = parseInt(value.min - 10)
                return minValue < 0 ? 0 : minValue
              }
            }
          }
        },
        series: [
          {
            name: name,
            data: obj.data,
            type: 'bar'
          }
        ],
        dataZoom: [
          {
            orient: 'horizontal',
            type: 'slider',
            xAxisIndex: 0,
            yAxixIndex: 0,
            show: showZoom,
            realtime: true,
            height: 24,
            start: 0,
            end: endValue,
            // bottom: '4%',
            zoomLock: false
          }
        ]
      }
      const chartDom = document.getElementById('elChart')
      this.chart = this.$echarts.init(chartDom)
      this.chart.clear()
      this.chart.setOption(option)
      // const that = this // 20230105 Kimi 将这句提到上面去
      this.chart.on('click', function(params) {
        that.queryData(params.name, true)
      })
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    resizeTable: function() {
      this.$nextTick(function() {
        const divHeight = $('#tabMain').height()
        this.tabDivHeight = divHeight - 55
        // 20230110 Kimi 调整Div大小，要不然Detail表格太小
        if (this.tabDivHeight < 1500) {
          this.tabDivHeight = 1500
        }
      })
      const that = this
      // setTimeout(function () {
      //   const tbHeight = $('#kpiMainTableDiv').height()
      //   that.kpiTableHeight = tbHeight
      // }, 100)
      // setTimeout(function () {
      //   const tbHeight = $('#kpiLossDiv').height()
      //   that.kpiLossTableHeight = tbHeight
      // }, 100)
      setTimeout(function() {
        that.kpiTableHeight = $('#kpiMainTableDiv').height()
        that.issueTableHeight = $('#issueMainTableDiv').height()
        // 20230110 Kimi 调整Div大小
        if (that.issueTableHeight < 500) {
          that.issueTableHeight = 500
        }
        that.kpiLossTableHeight = $('#kpiLossDiv').height()
        that.actionTableHeight = $('#actionMainTableDiv').height()
      }, 100)
    },
    downloadData: function() {
      if (this.queryTeam === '') {
        this.alertMsg(this.$t('dpmTeamKPI.altMsgFilterEmpty'))
        return
      }
      const factory = this.factoryList.filter(x => x.key === this.queryFactory)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      const workDay = this.$utils.GetDateString(this.queryDay)
      const params = {
        factory: factory,
        area: area,
        team: team,
        workDay: workDay
      }
      downLoadDPMEscalateActionReviewData(params, this.$t('actionReview.xlsx'))
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep main.el-main{
padding: 0
}
::v-deep .el-divider--horizontal{
margin:0
}
.selectMidSize{
width:120px;
margin-right:5px;
}
section{
padding-bottom: 0;
}
.el-header{
  padding:0 5px
}
.header{
height:40px !important;
// background-color:#1f4e7c;
background-color:rgba(0,0,0,0);
}
.title{
margin-left: 10px;
display: inline-block;
line-height: 40px;
font-size:20px;
}
.pane{
    height:90%;
    overflow-y:auto;
    overflow-x:hidden;
  }
::v-deep .el-carousel__container{
height:calc(100% - 55px);
background-color: rgba(0,0,0,0);
}
.kpiDivMainTop{
height:calc(55% - 5px); // 20230110 Kimi 调整Div大小
margin-bottom: 5px;
width: 100%;
display:flex;
}
.kpiDivMainBottom{
height:45%; // 20230110 Kimi 调整Div大小
width: 100%;
display:flex;
}
.kpiDivMainTopLeft{
height: 100%;
width:calc(52% - 5px);
margin-right: 5px;
}
.kpiDivMainTopRight{
height: 100%;
width: 48%;
background-color: white;
}
.kpiDivMainBottomLeft{
height: 100%;
// width:calc(65% - 5px);
width: 100%;
margin-right: 5px;
}
.kpiDivMainBottomRight{
height: 100%;
width: 35%;
background-color: white;
}
.kpiDivMainTitle{
width:100%;
// background-color: rgb(52,124,184);
// color:white;
color: rgb(32,55,100);
background-color:white;
height:35px;
font-size:21px;
font-style: italic;
font-weight: bold;
padding-top: 7px;
padding-left:15px;
// border-top-left-radius: 5px;
// border-top-right-radius: 5px;
// border-bottom: solid 2px rgb(52,124,184);
}
.kpiDivRadio{
width:435px;
height:35px;
padding-top:10px;
padding-right:10px;
// border-top-right-radius: 5px;
// border-bottom: solid 2px rgb(52,124,184);
}
.kpiDivSelect{
width:350px;
height:35px;
padding-top:5px;
padding-right:10px;
}
.kpiDivTable{
width:100%;
height: calc(100% - 33px);
}
.chartDiv {
height:calc(100% - 140px);
width:100%;
background-color: white;
}
.lossDiv{
// height:calc(100% - 75px);
height:calc(100% - 33px);
width:100%;
background-color: white;
}
.kpiDivMainTopSelect {
width:100%;
text-align: center;
// border-bottom: 1px solid rgb(52,124,184);
}
.issueDivTable{
width:100%;
height: calc(100% - 35px);
}
.kpiSpan{
display: inline-block;
height:30px;
font-size: 16px;
font-weight: bold;
margin:10px 20px 0 0;
}
::v-deep .el-table td div{
font-size: 16px;
}
::v-deep .el-table .cell {
  white-space: pre-line;
}
.escalateTitleSpan{
display: block;
color:rgb(52,124,184);
border-bottom: 1px solid rgb(52,124,184);
font-size:16px;
margin:10px 0 5px 0;
font-weight: bold;
font-style: italic;
}
::v-deep .el-table th{
height: 48px;
padding:5px 0;
}
::v-deep #txtIssueContent {
color: blue
}
.actionDivTable{
width:100%;
height: 100%;
}
::v-deep .el-table td {
border:1px solid lightgray;
}
.actionItemSpan {
color: #8492a6; font-size: 13px;
display: block;
width: 600px;
overflow: hidden;
white-space: nowrap;
text-overflow: ellipsis;
}
</style>
