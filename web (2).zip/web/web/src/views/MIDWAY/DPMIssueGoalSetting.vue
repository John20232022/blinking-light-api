<template>
  <div style="height:100%;width:100%">
    <el-container style="height:100%">
      <el-header style="padding:0;height:40px">
        <el-select v-model="queryPlant" size="small" class="selectMidSize" :placeholder="$t('common.phdSelectFactory')" @change="selectFactoryHandler">
          <el-option
            v-for="item in plantList"
            :key="item.plant"
            :label="item.plant"
            :value="item.plant"
          />
        </el-select>
        <span style="display:inline-block; margin-left:20px; color:blue">{{ $t('dpmIssueGoalSetting.lblSubmitErrorMsg') }}</span>
      </el-header>
      <el-main id="tabMain" style="padding:0;height:1px">
        <el-tabs v-model="tabActiveName">
          <el-tab-pane label="Area Isuue" name="area" lazy>
            <el-date-picker v-model="effDateArea" size="small" style="width:140px;margin:0 5px 5px 5px" type="date" :placeholder="$t('dpmIssueGoalSetting.phdEffDay')" />
            <el-button type="success" size="small" @click="submitChange('area')">{{ $t('dpmIssueGoalSetting.btnDoEff') }}</el-button>
            <div :style="{'height': getTabDivHeight()}">
              <el-table
                ref="tbDataArea"
                v-loading="loading"
                :data="tableDataArea"
                size="small"
                stripe
                :height="tabDivHeight"
                style="width: 100%;"
                @selection-change="areaSelectionChange"
              >
                <el-table-column type="selection" width="55" align="center" />
                <el-table-column prop="data" :label="$t('common.colArea')" width="100" align="center" fixed show-overflow-tooltip />
                <el-table-column
                  v-for="o in colSettingArea"
                  :key="o.label"
                  :label="o.label"
                  :width="o.width"
                  align="center"
                >

                  <template slot-scope="scope">
                    <el-input v-model="scope.row[o.label]" type="text" size="mini" />
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
          <el-tab-pane label="Team Isuue" name="team" lazy>
            <span>{{ $t('dpmIssueGoalSetting.lblChooseArea') }}</span>
            <el-select v-model="queryArea" size="small" class="selectMidSize" style="width:140px; margin:0 5px 5px 5px;" placeholder="Area" @change="selectAreaHandler">
              <el-option
                v-for="item in areaList"
                :key="item.key"
                :label="item.data"
                :value="item.key"
              />
            </el-select>
            <el-date-picker v-model="effDateTeam" size="small" style="width:140px;margin:0 5px 5px 100px" type="date" :placeholder="$t('dpmIssueGoalSetting.phdEffDay')" />
            <el-button type="success" size="small" @click="submitChange('team')">{{ $t('dpmIssueGoalSetting.btnDoEff') }}</el-button>
            <div :style="{'height': getTabDivHeight()}">
              <el-table
                ref="tbDataTeam"
                v-loading="loading"
                :data="tableDataTeam"
                size="small"
                stripe
                :height="tabDivHeight"
                style="width: 100%;"
                @selection-change="teamSelectionChange"
              >
                <el-table-column type="selection" width="55" align="center" />
                <el-table-column prop="data" label="Team" width="100" align="center" fixed show-overflow-tooltip />
                <el-table-column
                  v-for="o in colSettingTeam"
                  :key="o.label"
                  :label="o.label"
                  :width="o.width"
                  align="center"
                >

                  <template slot-scope="scope">
                    <el-input v-model="scope.row[o.label]" type="text" size="mini" />
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
          <el-tab-pane label="Line Isuue" name="line" lazy>
            <span>{{ $t('dpmIssueGoalSetting.lblChooseAreaTeam') }}</span>
            <el-select v-model="queryArea2" size="small" class="selectMidSize" style="width:140px; margin:0 5px 5px 5px;" placeholder="Area" @change="getQueryTeamList">
              <el-option
                v-for="item in areaList"
                :key="item.key"
                :label="item.data"
                :value="item.key"
              />
            </el-select>
            <el-select v-model="queryTeam" size="small" class="selectMidSize" style="width:140px;" placeholder="Team" @change="selectTeamHandler">
              <el-option
                v-for="item in teamList"
                :key="item.key"
                :label="item.data"
                :value="item.key"
              />
            </el-select>
            <el-date-picker v-model="effDateLine" size="small" style="width:140px;margin:0 5px 5px 100px" type="date" :placeholder="$t('dpmIssueGoalSetting.phdEffDay')" />
            <el-button type="success" size="small" @click="submitChange('line')">{{ $t('dpmIssueGoalSetting.btnDoEff') }}</el-button>
            <div :style="{'height': getTabDivHeight()}">
              <el-table
                ref="tbDataLine"
                v-loading="loading"
                :data="tableDataLine"
                size="small"
                stripe
                :height="tabDivHeight"
                style="width: 100%;"
                @selection-change="lineSelectionChange"
              >
                <el-table-column type="selection" width="55" align="center" />
                <el-table-column prop="data" label="Line" width="120" align="center" fixed show-overflow-tooltip />
                <el-table-column
                  v-for="o in colSettingLine"
                  :key="o.label"
                  :label="o.label"
                  :width="o.width"
                  align="center"
                >
                  <template slot-scope="scope">
                    <el-input v-model="scope.row[o.label]" type="text" size="mini" />
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
        </el-tabs>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import $ from 'jquery'
import {
  getUserMenuPlantList,
  GetCurrentBaseData, GetIssueGoalSettingData, UploadIssueGoalSettingData, GetGoalSettingChangeList
} from '@/api/midway.js'
export default {
  data() {
    return {
      effDateArea: '',
      effDateTeam: '',
      effDateLine: '',
      tabActiveName: 'area',
      tabDivHeight: 1,
      tableHeight: 1,
      effDate: '',
      loading: false,
      loadingData: null,
      plantList: [],
      queryPlant: '',
      areaList: [],
      queryArea: '',
      teamList: [],
      queryTeam: '',
      lineList: [],
      colSettingArea: [],
      tableDataArea: [],
      tableDataAreaChange: [],
      tableDataReaonToId: [],
      colSettingTeam: [],
      tableDataTeam: [],
      tableDataTeamChange: [],
      queryArea2: '',
      colSettingLine: [],
      tableDataLine: [],
      tableDataLineChange: [],
      tableDataChangeList: []
    }
  },
  mounted() {
    this.getDefaultDate()
    this.queryPlantList()
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
    }
  },
  methods: {
    getTabDivHeight() {
      return this.tabDivHeight + 'px'
    },
    getDefaultDate() {
      const curDate = new Date()
      // this.effDateArea = new Date(curDate.getTime() + 24 * 60 * 60 * 1000)
      // this.effDateTeam = new Date(curDate.getTime() + 24 * 60 * 60 * 1000)
      // this.effDateLine = new Date(curDate.getTime() + 24 * 60 * 60 * 1000)
      this.effDateArea = new Date(curDate.getTime())
      this.effDateTeam = new Date(curDate.getTime())
      this.effDateLine = new Date(curDate.getTime())
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    async queryPlantList() {
      // start update 20230222 fenglianlong 修改获取menuId来源于主框架值
      // const data = { menu: '', menuId: '79' }
      const data = { menuId: this.$route.query.menuId }
      this.plantList = []
      const response = await getUserMenuPlantList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.plantList = response.data.ReturnObject
        // end update 20230222 fenglianlong ---------------------
      } else {
        this.alertMsg(queryResult)
      }
    },
    // async queryPlantList() {
    //   this.plantList = [
    //     {
    //       'plant': 'A2'
    //     },
    //     {
    //       'plant': 'A6'
    //     },
    //     {
    //       'plant': 'A9'
    //     },
    //     {
    //       'plant': 'A9-TPD'
    //     }
    //   ]
    // },
    selectFactoryHandler() {
      this.getGoalSettingData('area', 0)
      this.getQueryAreaList()
    },
    selectAreaHandler() {
      this.getGoalSettingData('team', this.queryArea)
    },
    selectTeamHandler() {
      this.getGoalSettingData('line', this.queryTeam)
    },
    async getGoalSettingData(level, key) {
      if (this.queryPlant === '') {
        return
      }
      const data = {
        factory: this.queryPlant,
        level: level,
        key: key
      }
      const response = await GetIssueGoalSettingData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.tableDataReaonToId = response.data.ReturnObject[2]
        if (level === 'area') {
          this.tableDataAreaChange = []
          this.colSettingArea = response.data.ReturnObject[0]
          this.tableDataArea = response.data.ReturnObject[1]
          this.$nextTick(() => {
            this.$refs.tbDataArea.doLayout()
          })
        } else if (level === 'team') {
          this.tableDataTeamChange = []
          this.colSettingTeam = response.data.ReturnObject[0]
          this.tableDataTeam = response.data.ReturnObject[1]
          this.$nextTick(() => {
            this.$refs.tbDataTeam.doLayout()
          })
        } else if (level === 'line') {
          this.tableDataLineChange = []
          this.colSettingLine = response.data.ReturnObject[0]
          this.tableDataLine = response.data.ReturnObject[1]
          this.$nextTick(() => {
            this.$refs.tbDataLine.doLayout()
          })
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryAreaList() {
      this.areaList = []
      this.queryArea = ''
      this.queryArea2 = ''
      this.teamList = []
      this.queryTeam = ''
      this.colSettingArea = []
      this.colSettingTeam = []
      this.colSettingLine = []
      this.tableDataArea = []
      this.tableDataReaonToId = []
      this.tableDataAreaChange = []
      this.tableDataTeam = []
      this.tableDataTeamChange = []
      this.tableDataLine = []
      this.tableDataLineChange = []
      const data = {
        type: 'area',
        key: this.queryPlant
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
      //  this.areaList = response.data.ReturnObject[0]
      // 目前只需要PCBA部分数据，后面看是否使用FATP，使用将上段代码放开即可
        this.areaList = [{ data: 'PCBA', key: 7 }]
      } else {
        this.alertMsg(queryResult)
      }
    },
    async getQueryTeamList() {
      this.teamList = []
      this.queryTeam = ''
      this.colSettingLine = []
      this.tableDataLine = []
      this.tableDataReaonToId = []
      this.tableDataLineChange = []
      const data = {
        type: 'team',
        key: this.queryArea2
      }
      const response = await GetCurrentBaseData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.teamList = response.data.ReturnObject[0]
      } else {
        this.alertMsg(queryResult)
      }
    },
    areaSelectionChange(val) {
      this.tableDataAreaChange = val
    },
    teamSelectionChange(val) {
      this.tableDataTeamChange = val
    },
    lineSelectionChange(val) {
      this.tableDataLineChange = val
    },
    async submitChange(type) {
      let tbUpload
      let msg
      const L_tableDataReaonToId = this.tableDataReaonToId
      if (type === 'area') {
        tbUpload = this.tableDataAreaChange
        msg = this.$utils.ReplacePlaceHolder(
          this.$t('dpmIssueGoalSetting.altMsgConfirmSubmitArea'),
          [tbUpload.length])
      } else if (type === 'team') {
        tbUpload = this.tableDataTeamChange
        msg = this.$utils.ReplacePlaceHolder(
          this.$t('dpmIssueGoalSetting.altMsgConfirmSubmitTeam'),
          [tbUpload.length])
      } else if (type === 'line') {
        tbUpload = this.tableDataLineChange
        msg = this.$utils.ReplacePlaceHolder(
          this.$t('dpmIssueGoalSetting.altMsgConfirmSubmitLine'),
          [tbUpload.length])
      } else {
        tbUpload = []
      }
      if (tbUpload.length === 0) {
        this.alertMsg(this.$t('dpmIssueGoalSetting.altMsgNoSelectRow'))
        return
      }
      if (!confirm(msg)) {
        return
      }

      if (!confirm(this.$t('dpmIssueGoalSetting.altMsgConfirmErrorSubmit'))) {
        return
      }

      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoadingSubmit'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })

      const day = this.$utils.GetDateString(this.effDateLine)
      const uploadObject = {
        factory: this.queryPlant,
        effDate: day,
        items: []
      }

      tbUpload.forEach(x => {
        for (var key in x) {
          let index
          // eslint-disable-next-line eqeqeq
          if (key == 'data' || key == 'key' || key == 'level') {
            index = ''
          } else {
            index = key
            const existObject = uploadObject.items.filter(t => t.level === x.level && t.key === x.key && t.index === index)
            if (existObject.length > 0) {
              existObject[0].issue_goal_value = x[key]
            } else {
              uploadObject.items.push({
                level: x.level,
                key: x.key,
                data: x.data,
                index: index,
                reson_id: L_tableDataReaonToId[0][index],
                issue_goal_value: x[key]
              })
            }
          }
        }
      })
      const response = await UploadIssueGoalSettingData(uploadObject)
      this.loadingData.close()

      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('dpmIssueGoalSetting.altMsgSubmitSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
      } else {
        this.alertMsg(queryResult)
      }
    },
    async refreshChangeList() {
      if (this.queryPlantList === '') {
        return
      }
      const data = {
        factory: this.queryPlant
      }
      this.loading = true
      const response = await GetGoalSettingChangeList(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.tableDataChangeList = response.data.ReturnObject
      } else {
        this.alertMsg(queryResult)
      }
    },
    resizeTable: function() {
      this.$nextTick(function() {
        // const divHeight = $('#tableChangeDiv').height()
        // this.tableHeight = divHeight
        const divHeightTab = $('#tabMain').height()
        this.tabDivHeight = divHeightTab - 55 - 40
      })
    }
  }
}
</script>
<style lang="less" scoped>
.mainDiv{
  width:100%;
  height:100%;
  display: flex;
}
.fieldDiv{
  position: relative;
  width:200px;
  height:100%;
  margin-right:5px;
  border:1px solid rgb(23,102,173);
  overflow: auto;
  background-color: white;
}
.fieldTitleDiv{
  width:100%;
  font-size: 16px;
  color:white;
  height:25px;
  line-height: 25px;
  text-align: center;
  background-color: rgb(23,102,173);
}
li {
  list-style-type: none;
}
.liDataSpan{
  font-size:14px;
  color: rgb(23,102,173);
  padding-left:5px;
}
.optIcon{
  // right:20px;
  position:absolute;
  padding-top:5px;
  cursor: pointer;
}
.icon3{
  right:50px;
}
.icon2{
  right:30px;
}
.icon1{
  right:10px;
}
.icon4{
  right:70px;
}
.icon5{
  right:90px;
}
</style>
