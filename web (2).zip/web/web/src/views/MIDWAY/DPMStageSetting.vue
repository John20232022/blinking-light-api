<template>
  <div style="height:100%;width:100%">
    <el-container style="height:100%;width:100%">
      <el-header style="padding:0;height:40px">
        <el-select v-model="queryPlant" :placeholder="$t('common.phdSelectFactory')" size="small" style="width:120px;margin-left:5px" @change="getUserArea">
          <el-option
            v-for="item in plantList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryArea" :placeholder="$t('common.phdSelectArea')" size="small" style="width:100px;margin-left:5px" @change="getUserTeam">
          <el-option
            v-for="item in areaList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryTeam" :placeholder="$t('common.phdSelectTeam')" size="small" style="width:230px;margin-left:5px;" @change="getUserLine">
          <el-option
            v-for="item in teamList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryLine" :placeholder="$t('common.phdSelectLine')" size="small" style="width:130px;margin-left:5px;margin-right: 5px;">
          <el-option
            v-for="item in lineList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-button type="primary" size="small" @click="queryData(true)">{{ $t('common.btnQuery') }}</el-button>
        <el-button type="primary" size="small" @click="downloadData()">{{ $t('common.btnDownload') }}</el-button>
      </el-header>
      <el-main style="padding:0;height:100%">
        <div id="tableContainer" style="height:100%;">
          <el-table :data="tableData" style="width: 100%">
            <el-table-column prop="FACTORY" :label="$t('common.colFactory')" />
            <el-table-column prop="AREA" :label="$t('common.colArea')" />
            <el-table-column prop="TEAM" label="TEAM" />
            <el-table-column prop="LINE" label="LINE" />
            <el-table-column prop="MASTER_STAGE" label="MASTER_STAGE" />
            <el-table-column prop="STAGE_NAME" :label="$t('common.colStage')" />
            <el-table-column prop="IS_INPUT" label="INPUT">
              <template slot-scope="scope">
                <el-checkbox :checked="scope.row.IS_INPUT === 'Y'" disabled />
              </template>
            </el-table-column>
            <el-table-column prop="IS_OUTPUT" label="OUTPUT">
              <template slot-scope="scope">
                <el-checkbox :checked="scope.row.IS_OUTPUT === 'Y'" disabled />
              </template>
            </el-table-column>
            <el-table-column prop="IS_INPUT_MASTER" label="INPUT_MASTER">
              <template slot-scope="scope">
                <el-checkbox :checked="scope.row.IS_INPUT_MASTER === 'Y'" disabled />
              </template>
            </el-table-column>
            <el-table-column prop="IS_OUTPUT_MASTER" label="OUTPUT_MASTER">
              <template slot-scope="scope">
                <el-checkbox :checked="scope.row.IS_OUTPUT_MASTER === 'Y'" disabled />
              </template>
            </el-table-column>
            <el-table-column prop="IS_SHOW_BIND" label="BIND">
              <template slot-scope="scope">
                <el-checkbox :checked="scope.row.IS_SHOW_BIND === 1" disabled />
              </template>
            </el-table-column>
          </el-table>
        </div>
      </el-main>
      <!-- <el-footer style="margin:0 auto">
        <el-pagination
          :current-page="pageIndex"
          :page-sizes="[30, 50, 100]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </el-footer> -->
    </el-container>
  </div>
</template>
<script>
import $ from 'jquery'
import {
  GetDPMQueryKeyValue, GetMasterStageData
} from '@/api/midway.js'
import {
  DownloadDPMMasterStage_API
} from '@/api/upload_download.js'
export default {
  data() {
    return {
      queryPlant: '',
      queryArea: '',
      queryTeam: '',
      queryLine: '',
      plantList: [],
      areaList: [],
      teamList: [],
      lineList: [],
      tableHeight: 1,
      loading: false,
      loadingDetail: false,
      filter: '',
      pageIndex: 1,
      pageSize: 50,
      total: 0,
      loadingData: null,
      tableData: []
    }
  },
  mounted() {
    this.getUserPlant()
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
    }
  },
  methods: {
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    handleSizeChange: function(val) {
      this.pageSize = val
    },
    handleCurrentChange: function(val) {
      this.pageIndex = val
      this.queryData(false)
    },
    async getUserPlant() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.plantList = []
      this.queryPlant = ''
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = ''
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.plantList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserArea() {
      const data = {
        type: 'userarea',
        key: this.queryPlant
      }
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = ''
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserTeam() {
      debugger
      const data = {
        type: 'userteam',
        key: this.queryArea
      }
      this.teamList = []
      this.queryTeam = ''
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      debugger
      if (queryResult === 'OK') {
        this.teamList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserLine() {
      this.lineList = []
      this.queryLine = ''
      // if (this.queryTeam.length === 1) {
      const data = {
        type: 'userline',
        key: this.queryTeam
      }
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.lineList.push({
          key: 'ALL',
          data: 'ALL'
        })
        response.data.ReturnObject.forEach(d => {
          this.lineList.push(d)
        })
      } else {
        alert(queryResult)
      }
      // } else {
      //   this.lineList.push({
      //     key: 'all',
      //     data: 'ALL'
      //   })
      // }
    },
    async queryData(resetIndex) {
      this.tableData = []
      if (this.queryPlant === '') {
        this.alertMsg(this.$t('dpmIssueReview.altMsgFactoryEmpty'))
        return
      }
      if (this.queryArea === '') {
        this.alertMsg(this.$t('dpmIssueReview.altMsgAreaEmpty'))
        return
      }
      // if (resetIndex) {
      //   this.pageIndex = 1
      // }
      const factory = this.plantList.filter(x => x.key === this.queryPlant)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      let team = ''
      let line = ''
      if (this.queryTeam !== '') {
        team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      }
      if (this.queryLine !== '') {
        line = this.lineList.filter(x => x.key === this.queryLine)[0].data
      }
      const data = {
        factory: factory,
        area: area,
        team: team,
        line: line
      }
      this.loadingDetail = true
      const response = await GetMasterStageData(data)
      this.loadingDetail = false
      const queryResult = response.data.QueryResult
      debugger
      if (queryResult === 'OK') {
        this.tableData = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    downloadData: function() {
      if (this.queryPlant === '') {
        this.alertMsg(this.$t('dpmIssueReview.altMsgFactoryEmpty'))
        return
      }
      if (this.queryArea === '') {
        this.alertMsg(this.$t('dpmIssueReview.altMsgAreaEmpty'))
        return
      }
      const factory = this.plantList.filter(x => x.key === this.queryPlant)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      let team = ''
      const line = ''
      if (this.queryTeam !== '') {
        team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      }
      const params = {
        factory: factory,
        area: area,
        team: team,
        line: line
      }
      const fileName = factory + '_' + area + 'MasterStage.xlsx'
      DownloadDPMMasterStage_API(params, fileName)
    },
    resizeTable: function() {
      this.$nextTick(function() {
        const divHeight = $('#tableContainer').height()
        this.tableHeight = divHeight
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    }
  }
}
</script>
<style lang="less">
.el-checkbox__input.is-disabled.is-checked .el-checkbox__inner {
    background-color: #6f7072;
    border-color: #e1e2e3;
}
</style>
