<template>
  <div style="height:100%;width:100%">
    <el-container style="height:100%;width:100%">
      <el-header style="padding:0;height:40px">
        <el-date-picker
          v-model="pickDates"
          style="width:350px"
          type="datetimerange"
          align="right"
          unlink-panels
          :picker-options="pickerOptions1"
          :start-placeholder="$t('common.phdStartDate')"
          :end-placeholder="$t('common.phdEndDate')"
          size="small"
        />
        <el-select v-model="queryPlant" :placeholder="$t('common.phdSelectFactory')" size="small" style="width:120px;margin-left:5px" @change="getUserArea">
          <el-option
            v-for="item in plantList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryArea" :placeholder="$t('common.phdSelectArea')" size="small" style="width:100px;margin-left:5px" @change="getUserTeam">
          <el-option
            v-for="item in areaList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryTeam" :placeholder="$t('common.phdSelectTeam')" size="small" multiple collapse-tags style="width:230px;margin-left:5px" @change="getUserLine">
          <el-option
            v-for="item in teamList"
            :key="item.key"
            :label="item.data"
            :value="item.key"
          />
        </el-select>
        <el-select v-model="queryLine" :placeholder="$t('common.phdSelectLine')" size="small" style="width:130px;margin-left:5px">
          <el-option
            v-for="item in lineList"
            :key="item.key"
            :label="item.data"
            :value="item.data"
          />
        </el-select>
        <el-select v-model="queryScope" :placeholder="$t('common.phdStatus')" style="width:100px;margin-left:5px" size="small">
          <el-option :label="$t('dpmIssueReview.selAll')" value="all" />
          <el-option :label="$t('dpmIssueReview.selWaitDispatch')" value="waitdispatch" />
          <el-option :label="$t('dpmIssueReview.selWaitSoulation')" value="waitsolution" />
          <el-option :label="$t('dpmIssueReview.selWaitCheck')" value="waitcheck" />
          <el-option :label="$t('dpmIssueReview.lblReturned')" value="returned" />
          <el-option :label="$t('dpmIssueReview.selClosed')" value="closed" />
        </el-select>
        <el-select v-model="data_from" :placeholder="$t('dpmIssueReview.phdSource')" style="width:100px;margin:0 5px" size="small">
          <el-option :label="$t('dpmIssueReview.selAll')" value="all" />
          <el-option :label="$t('dpmIssueReview.selFromIssueLog')" value="1" />
          <el-option label="EMS" value="2" />
        </el-select>
        <el-button type="primary" size="small" @click="queryData(true)">{{ $t('common.btnQuery') }}</el-button>
        <el-button type="primary" size="small" @click="downloadData()">{{ $t('common.btnDownload') }}</el-button>
      </el-header>
      <el-main style="padding:0;height:100%">
        <div id="tableContainer" style="height:100%;">
          <el-table
            v-loading="loadingDetail"
            :data="tableData"
            size="mini"
            :row-class-name="tableRowClassName"
            :height="tableHeight"
            style="width: 100%;"
          >
            <el-table-column prop="seq" :label="$t('common.colSeq')" width="60" align="center" />
            <el-table-column prop="status" :label="$t('common.colStatus')" width="70" align="center">
              <template slot-scope="scope">
                <!-- 20230102 Kimi 取消此页面的确认功能，改到我的异常中去 -->
                <!-- <span v-if="scope.row.status!=='待填寫' && scope.row.status!=='待分配' && scope.row.status!=='待確認'" style="cursor: pointer;" @click="showDg(scope.row)">{{ scope.row.status }}</span> -->
                <span v-if="scope.row.status === 'toBeFillIn'" style="cursor: pointer">{{ $t('dpmMyIssue.selWaitSoulation') }}</span>
                <span v-else-if="scope.row.status === 'toBeConfirmed'" style="cursor: pointer">{{ $t('dpmIssueReview.selWaitCheck') }}</span>
                <span v-else-if="scope.row.status === 'ok'" style="cursor: pointer" @click="showDg(scope.row)">{{ $t('dpmMyIssue.lblPass') }}</span>
                <span v-else-if="scope.row.status === 'ng'" style="cursor: pointer" @click="showDg(scope.row)">{{ $t('dpmMyIssue.lblReject') }}</span>
                <span v-else-if="scope.row.status === 'returned'" style="cursor: pointer" @click="showDg(scope.row)">{{ $t('dpmMyIssue.lblReturned') }}</span>
                <span v-else-if="scope.row.status === 'toBeDistributed'" style="cursor: pointer">{{ $t('dpmMyIssue.lblToBeDistributed') }}</span>
                <span v-else>{{ scope.row.status }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="factory_code" :label="$t('common.colFactory')" width="70" align="center" />
            <el-table-column prop="work_date" :label="$t('common.colWorkDay')" width="85" align="center" />
            <el-table-column prop="shift_code" :label="$t('common.colShift')" width="60" align="center" />
            <el-table-column prop="area" :label="$t('common.colArea')" width="70" show-overflow-tooltip align="center" />
            <el-table-column prop="team" label="Team" width="70" show-overflow-tooltip align="center" />
            <el-table-column prop="pdline_name" :label="$t('common.colLine')" width="90" show-overflow-tooltip align="center" />
            <el-table-column prop="stage_name" :label="$t('common.colStage')" width="70" show-overflow-tooltip align="center" />
            <!-- <el-table-column prop="start_time" :label="$t('dpmIssueReview.colRangeStart')" width="150" align="center" />
            <el-table-column prop="end_time" :label="$t('dpmIssueReview.colRangeEnd')" width="150" align="center" /> -->
            <el-table-column prop="issue_start_time" :label="$t('dpmIssueReview.colIssueStart')" width="150" align="center" />
            <el-table-column prop="issue_end_time" :label="$t('dpmIssueReview.colIssueEnd')" width="150" align="center" />
            <el-table-column prop="actual" :label="$t('common.colAct')" width="60" show-overflow-tooltip align="center" />
            <el-table-column prop="goal" :label="$t('common.colGoal')" width="60" show-overflow-tooltip align="center" />
            <el-table-column prop="gap" :label="$t('common.colLoss')" width="60" show-overflow-tooltip align="center" />
            <el-table-column prop="loss_time" :label="$t('dpmIssueReview.colLossTime')" width="150" align="center" />
            <el-table-column prop="impact_minutes" :label="$t('dpmIssueReview.colImpactTime')" width="80" align="center" />
            <el-table-column prop="impact_persons" :label="$t('dpmIssueReview.colImpactPersons')" width="110" header-align="center" />
            <el-table-column :label="$t('dpmIssueReview.colIssueKeyinUser')" width="140" show-overflow-tooltip align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.issue_log_user }}</span>
                <span>{{ scope.row.issue_log_user_name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="type" :label="$t('common.colType')" width="70" show-overflow-tooltip align="center" />
            <el-table-column prop="reason_code" :label="$t('dpmIssueReview.colReasonCode')" width="120" show-overflow-tooltip align="center" />
            <el-table-column prop="reason_desc" :label="$t('dpmIssueReview.colReasonDesc')" width="180" show-overflow-tooltip header-align="center" />
            <el-table-column :label="$t('common.colDRI')" width="140" show-overflow-tooltip header-align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.dri }}</span>
                <span>{{ scope.row.dri_name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="dri_deptid" :label="$t('common.colCostCenter')" width="90" show-overflow-tooltip header-align="center" />
            <el-table-column prop="dri_dept" :label="$t('common.colDRIDept')" width="120" show-overflow-tooltip header-align="center" />
            <el-table-column prop="solution" :label="$t('common.colSolution')" width="200" show-overflow-tooltip header-align="center" />
            <el-table-column prop="keyin_solution_time" :label="$t('dpmIssueReview.colKeyinTime')" width="150" align="center" />
            <el-table-column prop="memo" :label="$t('common.colMemo')" width="180" show-overflow-tooltip header-align="center" />
            <el-table-column :label="$t('dpmIssueReview.colDispatchUser')" width="140" show-overflow-tooltip align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.dispatch_user }}</span>
                <span>{{ scope.row.dispatch_user_name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="dispatch_time" :label="$t('dpmIssueReview.colDispatchTime')" width="150" align="center" />
            <el-table-column prop="check_result" :label="$t('dpmIssueReview.colCheckResult')" width="100" align="center" />
            <el-table-column :label="$t('dpmIssueReview.colCheckUser')" width="140" show-overflow-tooltip align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.check_user }}</span>
                <span>{{ scope.row.check_user_name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="check_time" :label="$t('dpmIssueReview.colCheckTime')" width="150" align="center" />
            <el-table-column v-if="false" prop="row_id" label="ROWID" width="120" align="center" />
            <el-table-column v-if="false" prop="site" label="SITE" width="120" align="center" />

            <el-table-column :label="$t('dpmIssueReview.lblCallNo')" width="180" align="center">
              <template slot-scope="scope">
                <el-link type="primary" :underline="true" @click="getDataByCallNo(scope.row.call_no)"><span>{{ scope.row.call_no }}</span></el-link>
              </template>
            </el-table-column>
            <el-table-column prop="equipment_id" :label="$t('dpmIssueReview.lblEquipmentId')" width="160" align="center" />

            <el-table-column :label="$t('dpmIssueReview.colDataSource')" width="100" align="center">
              <template slot-scope="scope">
                <span v-if="scope.row.data_from == 1">{{ $t('dpmIssueReview.selFromIssueLog') }}</span>
                <span v-if="scope.row.data_from == 2">EMS</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </el-main>
      <el-footer style="margin:0 auto">
        <el-pagination
          :current-page="pageIndex"
          :page-sizes="[30, 50, 100]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </el-footer>
    </el-container>

    <el-dialog
      :center="true"
      :title="$t('dpmIssueReview.lblTitleCheckSolution')"
      :close-on-press-escape="false"
      top="3vh"
      :visible.sync="evalDialogVisible"
      width="560px"
      :close-on-click-modal="false"
    >
      <table class="tb" style="width:510px">
        <tr>
          <td class="tbCategory">{{ $t('common.colLine') }}</td>
          <td class="tbCategory">{{ $t('common.colStage') }}</td>
          <td class="tbCategory">{{ $t('common.colWorkDay') }}</td>
          <td class="tbCategory">{{ $t('common.colShift') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.pdline_name }}</td>
          <td class="tbValue">{{ selectedRow.stage_name }}</td>
          <td class="tbValue">{{ selectedRow.work_date }}</td>
          <td class="tbValue">{{ selectedRow.shift_code }}</td>
        </tr>
        <tr>
          <td class="tbCategory">{{ $t('dpmIssueReview.colRangeStart') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colRangeEnd') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colIssueStart') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colIssueEnd') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.start_time }}</td>
          <td class="tbValue">{{ selectedRow.end_time }}</td>
          <td class="tbValue">{{ selectedRow.issue_start_time }}</td>
          <td class="tbValue">{{ selectedRow.issue_end_time }}</td>
        </tr>
        <tr>
          <td class="tbCategory">{{ $t('dpmIssueReview.colCategory') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colReasonCode') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colImpactTime') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colImpactOutput') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.type }}</td>
          <td class="tbValue">{{ selectedRow.reason_code }}</td>
          <td class="tbValue">{{ selectedRow.impact_minutes }}{{ $t('dpmIssueReview.colMinutes') }}</td>
          <td class="tbValue">{{ selectedRow.gap }}</td>
        </tr>
      </table>
      <el-divider />
      <table class="tb" style="width:510px">
        <tr>
          <td class="tbCategory">{{ $t('common.colDRI') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colKeyinTime') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.dri }}{{ selectedRow.dri_name }}</td>
          <td class="tbValue">{{ selectedRow.keyin_solution_time }}</td>
        </tr>
      </table>
      <el-input v-model="selectedRow.solution" style="margin-top:5px" type="textarea" :rows="4" :readonly="true" />
      <el-divider />
      <div style="text-align:center">
        <el-radio v-model="evalResult" label="OK">{{ $t('dpmIssueReview.lblPass') }}</el-radio>
        <el-radio v-model="evalResult" label="NG">{{ $t('dpmIssueReview.lblReject') }}</el-radio>
      </div>
      <el-input v-model="memo" style="margin-top:5px" :placeholder="$t('common.colMemo')" size="small" />
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="saveEval">{{ $t('common.btnQuery') }}</el-button>
        <el-button size="small" @click="closeEvalDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="$t('dpmIssueReview.lblTitleEval')"
      :close-on-press-escape="false"
      top="3vh"
      :visible.sync="resultDialogVisible"
      width="560px"
      :close-on-click-modal="false"
    >
      <table class="tb" style="width:510px">
        <tr>
          <td class="tbCategory">{{ $t('common.colLine') }}</td>
          <td class="tbCategory">{{ $t('common.colStage') }}</td>
          <td class="tbCategory">{{ $t('common.colWorkDay') }}</td>
          <td class="tbCategory">{{ $t('common.colShift') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.pdline_name }}</td>
          <td class="tbValue">{{ selectedRow.stage_name }}</td>
          <td class="tbValue">{{ selectedRow.work_date }}</td>
          <td class="tbValue">{{ selectedRow.shift_code }}</td>
        </tr>
        <tr>
          <td class="tbCategory">{{ $t('dpmIssueReview.colRangeStart') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colRangeEnd') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colIssueStart') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colIssueEnd') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.start_time }}</td>
          <td class="tbValue">{{ selectedRow.end_time }}</td>
          <td class="tbValue">{{ selectedRow.issue_start_time }}</td>
          <td class="tbValue">{{ selectedRow.issue_end_time }}</td>
        </tr>
        <tr>
          <td class="tbCategory">{{ $t('dpmIssueReview.colCategory') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colReasonCode') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colImpactTime') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colImpactOutput') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.type }}</td>
          <td class="tbValue">{{ selectedRow.reason_code }}</td>
          <td class="tbValue">{{ selectedRow.impact_minutes }}{{ $t('dpmIssueReview.colMinutes') }}</td>
          <td class="tbValue">{{ selectedRow.gap }}</td>
        </tr>
      </table>
      <el-divider />
      <table class="tb" style="width:510px">
        <tr>
          <td class="tbCategory">{{ $t('common.colDRI') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.colKeyinTime') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.dri }}{{ selectedRow.dri_name }}</td>
          <td class="tbValue">{{ selectedRow.keyin_solution_time }}</td>
        </tr>
      </table>
      <el-input v-model="selectedRow.solution" style="margin-top:5px" type="textarea" :rows="4" :readonly="true" />
      <el-divider />
      <table class="tb" style="width:510px">
        <tr>
          <td class="tbCategory">{{ $t('dpmIssueReview.lblEvalResult') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.lblEvalTime') }}</td>
          <td class="tbCategory">{{ $t('dpmIssueReview.lblEvalUser') }}</td>
        </tr>
        <tr>
          <td class="tbValue">{{ selectedRow.check_result }}</td>
          <td class="tbValue">{{ selectedRow.check_time }}</td>
          <td class="tbValue">{{ selectedRow.check_user }}{{ selectedRow.check_user_name }}</td>
        </tr>
      </table>
      <el-input v-model="selectedRow.memo" style="margin-top:5px" :placeholder="$t('common.colMemo')" :readonly="true" size="small" />
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="closeResultDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <DialogEmsMaintenance ref="DialogEmsMaintenance" :detail-dialog="detailDialog" :ems-data="emsData" :dialog-title="$t('dpmIssueReview.lblEmsRepairNo')" @detail-close="closeDetaildlg" />

  </div>

</template>
<script>
import $ from 'jquery'
import { DownloadDPMIssueReview_API } from '@/api/upload_download'
import DialogEmsMaintenance from '@/views/components/DPMIssueReview/dialogEmsMaintenance'
import {
  DPMQueryIssueToReview, GetDPMQueryKeyValue, SaveEvalSolution, GetMaintenanceDataByCallNo
} from '@/api/midway.js'

export default {
  components: {
    DialogEmsMaintenance
  },
  data() {
    return {
      detailDialog: false,
      emsData: {},
      pickerOptions1: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      pickDates: [],
      queryPlant: '',
      queryArea: '',
      queryTeam: [],
      queryLine: '',
      plantList: [],
      areaList: [],
      teamList: [],
      lineList: [],
      queryScope: 'all',
      data_from: 'all',
      tableHeight: 1,
      tableData: [],
      loading: false,
      loadingDetail: false,
      filter: '',
      pageIndex: 1,
      pageSize: 50,
      total: 0,
      evalDialogVisible: false,
      resultDialogVisible: false,
      selectedRow: '',
      loadingData: null,
      evalResult: '',
      memo: ''
    }
  },
  mounted() {
    this.getDefaultDate()
    this.getUserPlant()
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
    }
  },
  methods: {
    async getDataByCallNo(param) {
      const data = {
        callNo: param
      }
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      await GetMaintenanceDataByCallNo(data).then((res) => {
        if (res.data.QueryResult === 'OK') {
          if (res.data.ReturnObject.length > 0) {
            this.emsData = res.data.ReturnObject[0]
          } else {
            this.emsData = {}
          }
        } else {
          this.emsData = {}
          this.alertMsg(res.data.QueryResult)
        }
      })
      loading.close()
      this.detailDialog = true
    },
    closeDetaildlg(data) {
      this.emsData = {}
      this.detailDialog = data
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    tableRowClassName({ row, rowIndex }) {
      if (row.status === 'toBeFillIn') {
        return 'waitsolution-row'
      } else if (row.status === 'toBeDistributed') {
        if (row.data_from === 2) {
          return 'waitdispatch-EMS-row'
        } else {
          return 'waitdispatch-row'
        }
      } else if (row.status === 'toBeConfirmed') {
        return 'waitcheck-row'
      } else if (row.status === 'ok') {
        return 'ok-row'
      } else if (row.status === 'ng') {
        return 'ng-row'
      } else if (row.status === 'returned') {
        return 'returned-row'
      }
      return ''
    },
    getDefaultDate() {
      const curDate = new Date()
      this.pickDates.push(new Date(curDate.getTime() - 48 * 60 * 60 * 1000))
      this.pickDates.push(new Date(curDate))
    },
    handleSizeChange: function(val) {
      this.pageSize = val
    },
    handleCurrentChange: function(val) {
      this.pageIndex = val
      this.queryData(false)
    },
    async getUserPlant() {
      const data = {
        type: 'userfactory',
        key: ''
      }
      this.plantList = []
      this.queryPlant = ''
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = []
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.plantList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserArea() {
      const data = {
        type: 'userarea',
        key: this.queryPlant
      }
      this.areaList = []
      this.queryArea = ''
      this.teamList = []
      this.queryTeam = []
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.areaList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserTeam() {
      const data = {
        type: 'userteam',
        key: this.queryArea
      }
      this.teamList = []
      this.queryTeam = []
      this.lineList = []
      this.queryLine = ''
      const response = await GetDPMQueryKeyValue(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.teamList = response.data.ReturnObject
      } else {
        alert(queryResult)
      }
    },
    async getUserLine() {
      this.lineList = []
      this.queryLine = ''
      if (this.queryTeam.length === 1) {
        const data = {
          type: 'userline',
          key: this.queryTeam
        }
        const response = await GetDPMQueryKeyValue(data)
        const queryResult = response.data.QueryResult
        if (queryResult === 'OK') {
          this.lineList.push({
            key: 'all',
            data: 'ALL'
          })
          const obj = response.data.ReturnObject
          obj.forEach(x => {
            this.lineList.push(x)
          })
        } else {
          alert(queryResult)
        }
      } else {
        this.lineList.push({
          key: 'all',
          data: 'ALL'
        })
      }
    },
    async queryData(resetIndex) {
      if (this.pickDates.length === 0) {
        this.alertMsg(this.$t('dpmIssueReview.altMsgWorkDayEmpty'))
        return
      }
      if (this.queryPlant === '') {
        this.alertMsg(this.$t('dpmIssueReview.altMsgFactoryEmpty'))
        return
      }
      if (this.queryArea === '') {
        this.alertMsg(this.$t('dpmIssueReview.altMsgAreaEmpty'))
        return
      }
      if (this.queryTeam.length === 0) {
        this.alertMsg(this.$t('dpmIssueReview.altMsgTeamEmpty'))
        return
      }
      let teams = ''
      this.queryTeam.forEach(t => {
        teams = teams + this.teamList.filter(x => x.key === t)[0].data + ','
      })
      if (teams.substr(teams.length - 1, 1) === ',') {
        teams = teams.substr(0, teams.length - 1)
      }
      if (resetIndex) {
        this.pageIndex = 1
      }
      const begin = this.$utils.GetDateTimeString(this.pickDates[0])
      const end = this.$utils.GetDateTimeString(this.pickDates[1])
      const factory = this.plantList.filter(x => x.key === this.queryPlant)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = teams // this.teamList.filter(x => x.key === this.queryTeam)[0].data
      const data = {
        factory: factory,
        area: area,
        team: team,
        line: this.queryLine,
        begin: begin,
        end: end,
        status: this.queryScope,
        data_from: this.data_from,
        pageIndex: this.pageIndex,
        pageSize: this.pageSize
      }
      this.loadingDetail = true
      const response = await DPMQueryIssueToReview(data)
      this.loadingDetail = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.total = response.data.ReturnObject.total
        this.tableData = response.data.ReturnObject.queryData
      } else {
        alert(queryResult)
      }
    },
    downloadData: function() {
      if (this.pickDates.length === 0) {
        this.alertMsg(this.$t('dpmIssueReview.altMsgWorkDayEmpty'))
        return
      }
      if (this.queryPlant === '') {
        this.alertMsg(this.$t('dpmIssueReview.altMsgFactoryEmpty'))
        return
      }
      if (this.queryArea === '') {
        this.alertMsg(this.$t('dpmIssueReview.altMsgAreaEmpty'))
        return
      }
      if (this.queryTeam.length === 0) {
        this.alertMsg(this.$t('dpmIssueReview.altMsgTeamEmpty'))
        return
      }
      let teams = ''
      this.queryTeam.forEach(t => {
        teams = teams + this.teamList.filter(x => x.key === t)[0].data + ','
      })
      if (teams.substr(teams.length - 1, 1) === ',') {
        teams = teams.substr(0, teams.length - 1)
      }

      const begin = this.$utils.GetDateTimeString(this.pickDates[0])
      const end = this.$utils.GetDateTimeString(this.pickDates[1])
      const factory = this.plantList.filter(x => x.key === this.queryPlant)[0].data
      const area = this.areaList.filter(x => x.key === this.queryArea)[0].data
      const team = teams
      const line = encodeURIComponent(this.queryLine)
      const status = encodeURIComponent(this.queryScope)
      const params = {
        factory: factory,
        area: area,
        team: team,
        line: line,
        status: status,
        begin: begin,
        end: end
      }
      // const team = this.teamList.filter(x => x.key === this.queryTeam)[0].data
      // var url = '/midway/downloadDPMIssueReview'
      // url = url + '?factory=' + encodeURIComponent(factory) + '&area=' + encodeURIComponent(area) +
      //  '&team=' + encodeURIComponent(teams) + '&line=' + encodeURIComponent(this.queryLine) +
      // '&begin=' + begin + '&end=' + end + '&status=' + encodeURIComponent(this.queryScope) + '&lang=' + this.$route.query.lang
      // this.$utils.downloadFile(url, this.$t('dpmIssueReview.lblFile'))

      DownloadDPMIssueReview_API(params, this.$t('dpmIssueReview.lblFile'))
    },
    resizeTable: function() {
      this.$nextTick(function() {
        const divHeight = $('#tableContainer').height()
        this.tableHeight = divHeight
      })
    },
    showDg(row) {
      if (row.status === 'toBeConfirmed') {
        this.showEvalDailog(row)
      } else {
        this.showResultDailog(row)
      }
    },
    showEvalDailog(row) {
      this.evalResult = ''
      this.memo = ''
      this.selectedRow = row
      this.evalDialogVisible = true
    },
    showResultDailog(row) {
      this.selectedRow = row
      this.resultDialogVisible = true
    },
    async saveEval() {
      if (this.evalResult === '') {
        this.alertMsg(this.$t('dpmIssueReview.altMsgCheckEmpty'))
        return
      }
      if (!confirm(this.$t('dpmIssueReview.altMsgConfirmCheck'))) {
        return
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoadingSubmit'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const data = {
        rowId: this.selectedRow.row_id,
        result: this.evalResult,
        memo: this.memo
      }
      const response = await SaveEvalSolution(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.closeEvalDialog()
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.queryData(false)
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeEvalDialog() {
      this.evalDialogVisible = false
    },
    closeResultDialog() {
      this.resultDialogVisible = false
    }
  }

}
</script>
<style lang="less" scoped>
::v-deep section {
padding-bottom: 0;
border: 0;
}

::v-deep .el-table .waitdispatch-row {
background: rgb(151, 160, 240);
}
::v-deep .el-table .waitsolution-row {
background: rgb(255, 255, 255);
}
::v-deep .el-table .waitcheck-row {
background: rgb(252, 252, 173);
}
::v-deep .el-table .ok-row {
background: rgb(127, 243, 133);
}
::v-deep .el-table .ng-row {
background: rgb(245, 180, 191);
}
::v-deep .el-table .returned-row {
  background: rgb(255, 103, 254);
}
::v-deep .el-table .waitdispatch-EMS-row {
background: linear-gradient(to right,rgb(200, 215, 224),rgb(100, 215, 224)) ;
}

.tb{
  margin:0 auto;
  border:1px solid #cccccc;
  border-collapse:collapse;
  margin-bottom:10px;
  width: 100%;
  table-layout: fixed;
}
.tbTitle{
  width:100%;
  padding:10px 10px;
  font-size:14px;
  font-weight: 600;
  border-bottom:1px solid #cccccc;
  overflow: hidden;
  white-space: nowrap;
  text-overflow:ellipsis;
  word-wrap: break-word;
}
.tbCategory{
  height:30px;
  font-size:12px;
  text-align: center;
  background-color:#f4f4f4;
  border-bottom:1px solid #cccccc;
  border-right:1px solid #cccccc;
}
.tbValue{
  height:30px;
  font-size:12px;
  text-align: center;
  border-bottom:1px solid #cccccc;
  border-right:1px solid #cccccc;
}
</style>
