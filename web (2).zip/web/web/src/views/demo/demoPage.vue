<template>
  <div>
    <H4>Device Type(desktop,mobile)
      <el-input v-model="device" placeholder="device input" />
    </H4>
    <H4>Menu ID</H4>
    <el-input v-model="menu_id" placeholder="Menu ID input" />
    <H4>Privilege Level
      <el-input v-model="privilege_level" placeholder="Please input" />
    </H4>
    <H4>Site</H4>
    <el-input v-model="site" placeholder="site input" />
    <H4>username</H4>
    <el-input v-model="username" placeholder="username input" />
    <H4>Language (tw,cn,en)
      <el-input v-model="lang" placeholder="lang input" />
    </H4>{{ lang }}
    <h2>Gen Token</h2>
    <el-button type="info" @click.native="GenToken">GenToken</el-button>
    <el-button type="info" @click.native="getToken">deCode</el-button>
    <el-button type="primary" @click.native="DownloadI18n">Download i18n</el-button>
    <H4>Site ID:{{ site_id }}</H4>
    <H4>User ID:{{ sys_userid }}</H4>
    <el-input v-model="token" placeholder="token input" />
    <h5>{{ token }}</h5>
    <el-divider />
    <H4>URL
      <el-select v-model="Route" placeholder="select" @change="RouteChanged">
        <el-option v-for="r in RouteList" :key="r.name" :label="r.name" :value="r.name" />
      </el-select>
      <el-input v-model="url" placeholder="url input" />
    </H4>
    <el-button type="info" @click.native="onSubmit">go URL</el-button>
    <el-button v-show="false" type="info" @click.native="onDecode">decode</el-button>

  </div>
</template>
<script>
import cache from '@/plugins/cache'
import axios from 'axios'
import { getI18nFile } from '@/api/demo.js'
// 調整jsonwebtoken的引用
import jwt from 'jsonwebtoken'
export default {
  data() {
    return {
      //  Jason:  目前無法無條件獲取smfg的user id 與 site id 所以拿我自己的ID當工具用於查詢要登入的工號的sys_userId與 Site ID
      // 登入的SMFG API https://smfg.liteon.com/dfap_api_ent/HttpUtility/Post?controller=main&action=GetUserListByIds
      admin_sys_userid: '33f6ca7ee4bf4a838cf50cbbde536c60',
      admin_site_id: '7c4b04aeb2ba4d049f9030792f1abb14',
      device: '',
      privilege_level: '',
      menu_id: '',
      token: '',
      url: '',
      lang: '',
      site: parent.baseConfig.baseSite,
      dispatcher: '',
      username: '',
      RouteList: [],
      Route: '',
      site_id: '',
      sys_userid: ''
    }
  },
  created() {
    this.$router.options.routes.forEach(route => {
      if (route.path.length > 1 && route.path.length !== '/demoPage') {
        this.RouteList.push({ name: route.path })
      }
    })
  },
  methods: {
    DownloadI18n() {
      getI18nFile({ appName: 'DPM' }, 'i18n.zip')
    },
    onDecode() {
      const decoded = jwt.verify(this.token, 'GQDsjcKsx0NHjPOuXOYg5MbeG1XT0uFiwDVvVHrk')
      console.log(decoded)
    },
    onSubmit() {
      if (this.token.startsWith('Bearer', 0) === false) {
        this.token = this.token + 'Bearer '
      }
      console.debug(this.token)
      cache.local.set('lang', this.lang)
      cache.session.set('site', this.site)
      cache.session.set('Dfap-Token', this.token)
      const routeData = this.$router.resolve({
        path: this.url,
        query: { lang: this.lang, token: this.token, site: this.site, menuId: this.menu_id, device: this.device, pLevel: this.privilege_level }
      })
      window.open(routeData.href, '_blank')
    },
    RouteChanged() {
      this.url = this.Route
    },
    ormatDate(date) {
      const year = date.getFullYear()
      const month = ('0' + (date.getMonth() + 1)).slice(-2)
      const day = ('0' + date.getDate()).slice(-2)
      const hours = ('0' + date.getHours()).slice(-2)
      const minutes = ('0' + date.getMinutes()).slice(-2)
      const seconds = ('0' + date.getSeconds()).slice(-2)
      const milliseconds = ('00' + date.getMilliseconds()).slice(-3)
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${milliseconds}`
    },
    GenToken() {
      var JsonRequest = {
        ids: this.username
      }
      const self = this
      const nowDatetime = new Date()
      var beforDatetime = new Date()
      beforDatetime.setDate(beforDatetime.getDate() + 10)
      let payload = { username: self.username, site: self.site, expireTime: self.ormatDate(beforDatetime), genTime: self.ormatDate(nowDatetime), site_id: this.admin_site_id, sys_userid: this.admin_sys_userid }
      this.generateToken(payload)
      axios({
        method: 'post',
        url: 'https://smfg.liteon.com/dfap_api_ent/HttpUtility/Post?controller=main&action=GetUserListByIds',
        data: JsonRequest,
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          Authorization: this.token,
          Site: this.site,
          SystemName: 'dfap_portal'
        }
      }).then((response) => {
        const { data } = response
        const toJSON = JSON.parse(data)
        console.debug(toJSON)
        if (toJSON.ReturnObject.length > 0) {
          self.sys_userid = toJSON.ReturnObject[0].sys_user_id
          self.site_id = toJSON.ReturnObject[0].site_id
          payload = { username: self.username, site: self.site, expireTime: self.ormatDate(beforDatetime), genTime: self.ormatDate(nowDatetime), site_id: toJSON.ReturnObject[0].site_id, sys_userid: toJSON.ReturnObject[0].sys_user_id, lang: self.lang }
          self.generateToken(payload)
        }
      })
    },
    generateToken(payload) {
      this.token = 'Bearer ' + jwt.sign(payload, 'GQDsjcKsx0NHjPOuXOYg5MbeG1XT0uFiwDVvVHrk')
    },
    getToken() {
      var decoded = jwt.verify(this.token, 'GQDsjcKsx0NHjPOuXOYg5MbeG1XT0uFiwDVvVHrk')
      alert(JSON.stringify(decoded))
    }
  }
}
</script>
<style lang="less" scoped>
</style>
