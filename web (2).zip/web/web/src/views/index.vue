<template>
  <div>首页</div>
</template>

<script>
export default {
  name: 'Index',
  created() {
    // console.log(baseConfig,'-----1')
  }
}
</script>

<style scoped lang="scss">
</style>
