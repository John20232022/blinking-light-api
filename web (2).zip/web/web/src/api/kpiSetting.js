
import { get, post, downloadFile } from '@/api/request.js'

// 分長別
export function GetDPMQueryKeyValue_API(params) {
  return get('/MIDWAY/GetDPMQueryKeyValue', params)
}

// 列表-team
export function GetKpiTeamSetting_API(params) {
  return get('/MIDWAY/GetKpiTeamSetting', params)
}

// 更新-team
export function ModifyKpiTeamSetting_API(params) {
  return post('/MIDWAY/ModifyKpiTeamSetting', params)
}

// 新增-team
export function AddKpiTeamSetting_API(params) {
  return post('/MIDWAY/AddKpiTeamSetting', params)
}

// 新增-team
export function DeleteKpiTeamSetting_API(params) {
  return post('/MIDWAY/DeleteKpiTeamSetting', params)
}

// 列表-Reason
export function GetKpiReasonSetting_API(params) {
  return get('/MIDWAY/GetKpiReasonSetting', params)
}

// 更新-Reason
export function ModifyKpiReasonSetting_API(params) {
  return post('/MIDWAY/ModifyKpiReasonSetting', params)
}

// 新增-Reason
export function AddKpiReasonSetting_API(params) {
  return post('/MIDWAY/AddKpiReasonSetting', params)
}

// 新增-Reason
export function DeleteKpiReasonSetting_API(params) {
  return post('/MIDWAY/DeleteKpiReasonSetting', params)
}

export function GetDPMPCBAReasonCode_API(params) {
  return get('/MIDWAY/GetDPMPCBAReasonCode', params)
}

export function GetPcbaIssueHistoryData_API(params) {
  return get('/MIDWAY/GetPcbaIssueHistoryData', params)
}

// factory-area-team-type-date
export function GetPcbaReasonHistoryData_API(params) {
  return get('/MIDWAY/GetPcbaReasonHistoryData', params)
}

export function GetPcbaIssueLossTop5_API(params) {
  return get('/MIDWAY/GetPcbaIssueLossTop5', params)
}

export function GetReasonCodeAndTimeData_API(params) {
  return get('/MIDWAY/GetReasonCodeAndTimeData', params)
}

// 保存
export function SaveLossTimeWithoutWorkOrderInfo_API(params) {
  return post('/MIDWAY/SaveLossTimeWithoutWorkOrderInfo', params)
}

// 下载
export function DownloadLossTimeWithoutWorkOrderInfo_API(data, fileName) {
  return downloadFile('/midway/DownloadLossTimeWithoutWorkOrderInfo', data, fileName)
}
