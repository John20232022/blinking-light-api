import { get, post, downloadFile } from '@/api/request.js'

export function getDemoMessage() {
  return 'This is a demo message'
}
// Get API Function
export function getConnectType() {
  return get('/apiController/apiAction')
}
// Post API Function
export function doPost(data) {
  return post('/apiController/apiAction', data)
}
export function getI18nFile(data, fileName) {
  return downloadFile('/main/getI18nFile', data, fileName)
}

