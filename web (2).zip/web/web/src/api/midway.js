
import { get, post } from '@/api/request.js'
export function getUserMenuPlantList(data) {
  // start update 20230222 fenglianlong  api的地址发生变化
  // return get('/Home/GetUserMenuPlantList', data)
  return post('/Main/GetUserMenuPlantList', data)
  // end update 20230222 fenglianlong ---------------------
}

/* DPM */
// add 20240424 dannyLeong  查詢所有線體類型
export function GetLineTypeData(data) {
  return get('/MIDWAY/GetLineTypeData', data)
}
// add 20240424 dannyLeong  新增線體類型
export function AddNewLineType(data) {
  return get('/MIDWAY/AddNewLineType', data)
}
// add 20230210 fenglianlong  三班制修改
export function GetWorkshiftList(data) {
  return get('/MIDWAY/GetWorkShift', data)
}

export function GetDPMQueryKeyValue(data) {
  return get('/MIDWAY/GetDPMQueryKeyValue', data)
}
export function GetDashboardInitialLevel() {
  return get('/MIDWAY/GetDashboardInitialLevel')
}
export function GetDPMDashboardParentId(data) {
  return get('/MIDWAY/GetDPMDashboardParentId', data)
}
export function GetDPMDashboardData(data) {
  return get('/MIDWAY/GetDPMDashboardData', data)
}
export function GetDashboardTrendChartData(data) {
  return get('/MIDWAY/GetDashboardTrendChartData', data)
}
export function GetDashboardIssueList(data) {
  return get('/MIDWAY/GetDashboardIssueList', data)
}
export function GetEmpInfo(data) {
  return get('/MIDWAY/GetEmpInfo', data)
}
export function GetEmpInfoList(data) {
  return get('/MIDWAY/GetEmpInfoList', data)
}
export function GetCommonDRIList() {
  return get('/MIDWAY/GetCommonDRIList')
}
export function RemoveCommonDRIList(data) {
  return post('/MIDWAY/RemoveCommonDRIList', data)
}
export function SaveDispatchUser(data) {
  return post('/MIDWAY/SaveDispatchUser', data)
}
export function GetDPMDashboardLineDetailData(data) {
  return get('/MIDWAY/GetDPMDashboardLineDetailData', data)
}
export function GetDPMDashboardLineIndexData(data) {
  return get('/MIDWAY/GetDPMDashboardLineIndexData', data)
}
export function GetDPMDashboardLineIndexDataRTY(data) {
  return get('/MIDWAY/GetDPMDashboardLineIndexDataRTY', data)
}
export function GetIssueTrackingTrace(data) {
  return get('/MIDWAY/GetIssueTrackingTrace', data)
}
export function SaveIssueOwner(data) {
  return post('/MIDWAY/SaveIssueOwner', data)
}
export function GetErrorCodeList() {
  return get('/MIDWAY/GetErrorCodeList')
}
export function SaveIssueSolution(data) {
  return post('/MIDWAY/SaveIssueSolution', data)
}
export function SaveEvalSolution(data) {
  return post('/MIDWAY/SaveEvalSolution', data)
}
export function CheckEmpStatus(data) {
  return post('/MIDWAY/CheckEmpStatus', data)
}
export function GetMTAuthBaseData() {
  return get('/MIDWAY/GetMTAuthBaseData')
}
export function UpdateUserAuthority(data) {
  return post('/MIDWAY/UpdateUserAuthority', data)
}
export function CheckChangeEmpLevelStatus(data) {
  return post('/MIDWAY/CheckChangeEmpLevelStatus', data)
}
export function UpdateUserViewLevel(data) {
  return post('/MIDWAY/UpdateUserViewLevel', data)
}
export function GetDPMAuthorityReport(data) {
  return get('/MIDWAY/GetDPMAuthorityReport', data)
}
export function GetMTCopyAuthBaseData(data) {
  return get('/MIDWAY/GetMTCopyAuthBaseData', data)
}
export function GetDPMReasonCodeLevel1() {
  return get('/MIDWAY/GetDPMReasonCodeLevel1')
}
export function GetDPMReasonCodeLevel2(data) {
  return get('/MIDWAY/GetDPMReasonCodeLevel2', data)
}
export function GetDPMReasonCodeDRI(data) {
  return get('/MIDWAY/GetDPMReasonCodeDRI', data)
}
export function SaveIssueTrackingDRIByReasonCode(data) {
  return post('/MIDWAY/SaveIssueTrackingDRIByReasonCode', data)
}
export function GetReasonCodeDescription(data) {
  return get('/MIDWAY/GetReasonCodeDescription', data)
}
export function GetSolutionList(data) {
  return get('/MIDWAY/GetSolutionList', data)
}
export function GetIssueDetailData(data) {
  return get('/MIDWAY/GetDPMIssueDetailData', data)
}
export function GetDPMReasonCode(data) {
  return get('/MIDWAY/GetDPMReasonCode', data)
}
export function GetDPMLogDymaticItems(data) {
  return get('/MIDWAY/GetDPMLogDymaticItems', data)
}
export function GetDPMIssueLogData(data) {
  return get('/MIDWAY/GetDPMIssueLogData', data)
}
export function UpdateEmsIssueLogByLine(data) {
  return get('/MIDWAY/UpdateEmsIssueLogByLine', data)
}
export function GetEmsStructuredDataByLine(data) {
  return get('/MIDWAY/GetEmsStructuredDataByLine', data)
}
export function SaveIssueLog(data) {
  return post('/MIDWAY/SaveIssueLog', data)
}
export function DeleteIssueLog(data) {
  return post('/MIDWAY/DeleteIssueLog', data)
}
export function GetDPMCanMatchLogData(data) {
  return get('/MIDWAY/GetDPMCanMatchLogData', data)
}
export function GetDPMRangeIssueData(data) {
  return get('/MIDWAY/GetDPMRangeIssueData', data)
}
export function GetReasonFromSystem(data) {
  return get('/MIDWAY/GetReasonFromSystem', data)
}
export function GetDPMStatisticChartData(data) {
  return get('/MIDWAY/GetDPMStatisticChartData', data)
}
export function DPMQueryMyIssue(data) {
  return get('/MIDWAY/DPMQueryMyIssue', data)
}
export function GetMaintenanceDataByCallNo(data) {
  return get('/MIDWAY/GetMaintenanceDataByCallNo', data)
}
export function DPMQueryIssueToReview(data) {
  return get('/MIDWAY/DPMQueryIssueToReview', data)
}
export function GetDPMTeamKpiReviewDataGrid(data) {
  return get('/MIDWAY/GetDPMTeamKpiReviewDataGrid', data)
}
export function DPMIssueEscalate(data) {
  return post('/MIDWAY/DPMIssueEscalate', data)
}
export function GetDPMUnClosedEscalateActionList(data) {
  return get('/MIDWAY/GetDPMUnClosedEscalateActionList', data)
}
export function GetDPMTeamKpiReviewKpiChartData(data) {
  return get('/MIDWAY/GetDPMTeamKpiReviewKpiChartData', data)
}
export function GetDPMTeamKPIReviewKpiLossData(data) {
  return get('/MIDWAY/GetDPMTeamKPIReviewKpiLossData', data)
}
export function GetDPMEscalateActionReviewData(data) {
  return get('/MIDWAY/GetDPMEscalateActionReviewData', data)
}
export function GetDPMTeamKPIHistoryData(data) {
  return get('/MIDWAY/GetDPMTeamKPIHistoryData', data)
}
export function GetDPMOutputReviewRptKeyValue(data) {
  return get('/MIDWAY/GetDPMOutputReviewRptKeyValue', data)
}
export function GetDPMOutputReviewRptData(data) {
  return get('/MIDWAY/GetDPMOutputReviewRptData', data)
}
export function GetCurrentBaseData(data) {
  return get('/MIDWAY/GetCurrentBaseData', data)
}
export function GetDPMLineOffLog(data) {
  return get('/MIDWAY/GetDPMLineOffLog', data)
}
export function SaveDPMLineOffData(data) {
  return post('/MIDWAY/SaveDPMLineOffData', data)
}
export function DeleteDPMLineOffData(data) {
  return post('/MIDWAY/DeleteDPMLineOffData', data)
}
export function GetDPMTeamKPIReviewMainData(data) {
  return get('/MIDWAY/GetDPMTeamKPIReviewMainData', data)
}
export function GetDPMTeamKPIReviewYOYData(data) {
  return get('/MIDWAY/GetDPMTeamKPIReviewYOYData', data)
}
export function GetDPMPCBAReasonCode(data) {
  return get('/MIDWAY/GetDPMPCBAReasonCode', data)
}
export function GetMESStageList(data) {
  return get('/MIDWAY/GetMESStageList', data)
}
export function GetMESProcessList(data) {
  return get('/MIDWAY/GetMESProcessList', data)
}
export function GetWorkShiftCode() {
  return get('/MIDWAY/GetWorkShiftCode')
}
export function GetWorkTimeList(data) {
  return get('/MIDWAY/GetWorkTimeList', data)
}
export function GetMAX3IN1EndTime(data) {
  return get('/MIDWAY/GetMAX3IN1EndTime', data)
}
export function GetDPM3IN1WOList(data) {
  return get('/MIDWAY/GetDPM3IN1WOList', data)
}
export function Get3IN1WOBaseData(data) {
  return get('/MIDWAY/Get3IN1WOBaseData', data)
}
export function GetDPMPCBAReasonCodeDefaultValue(data) {
  return get('/MIDWAY/GetDPMPCBAReasonCodeDefaultValue', data)
}
export function Check3IN1SavePrivilege(data) {
  return post('/MIDWAY/Check3IN1SavePrivilege', data)
}
export function submit3IN1Data(data) {
  return post('/MIDWAY/Submit3IN1Data', data)
}
export function Query3IN1Report(data) {
  return get('/MIDWAY/Query3IN1Report', data)
}
export function GetSTDInputOutputGoalData(data) {
  return get('/MIDWAY/GetSTDInputOutputGoalData', data)
}
export function GetDPMTeamDailyKpiReviewData(data) {
  return get('/MIDWAY/GetDPMTeamDailyKpiReviewData', data)
}
export function GetDPMTeamDailyKpiReviewIssueData(data) {
  return get('/MIDWAY/GetDPMTeamDailyKpiReviewIssueData', data)
}
export function AddNewBaseData(data) {
  return post('/MIDWAY/AddNewBaseData', data)
}
export function AddBaseDataChangeRequest(data) {
  return post('/MIDWAY/AddBaseDataChangeRequest', data)
}
export function GetBaseDataChangeList(data) {
  return get('/MIDWAY/GetBaseDataChangeList', data)
}
export function CancelBaseDataChangeListItem(data) {
  return post('/MIDWAY/CancelBaseDataChangeListItem', data)
}
export function GetGoalSettingData(data) {
  return get('/MIDWAY/GetGoalSettingData', data)
}
export function UploadGoalSettingData(data) {
  return post('/MIDWAY/UploadGoalSettingData', data)
}
export function GetGoalSettingChangeList(data) {
  return get('/MIDWAY/GetGoalSettingChangeList', data)
}
export function CancelGoalSettingChangeListItem(data) {
  return post('/MIDWAY/CancelGoalSettingChangeListItem', data)
}
// start add fenglianlong 20230228   PCAB 彙整by Area/Team/Line 異常原因彙整////////////////
export function GetIssueGoalSettingData(data) {
  return get('/MIDWAY/GetIssueGoalSettingData', data)
}
export function UploadIssueGoalSettingData(data) {
  return post('/MIDWAY/UploadIssueGoalSettingData', data)
}
export function GetDPMSummaryOfIssuesData(data) {
  return get('/MIDWAY/GetDPMSummaryOfIssuesData', data)
}
// end add fenglianlong 20230228////////////////---------------------------------------

/* 以下应该用不到 */
/* ======================================================== */
/* Manpower */
export function GetMTSTDLineType(data) {
  return get('/MIDWAY/GetMTSTDLineType', data)
}
export function GetMTSTDStage(data) {
  return get('/MIDWAY/GetMTSTDStage', data)
}
export function GetMTSTDPosList(data) {
  return get('/MIDWAY/GetMTSTDPosList', data)
}
export function SaveMTSTDData(data) {
  return post('/MIDWAY/SaveMTSTDData', data)
}
export function GetMTSTDModelData(data) {
  return get('/MIDWAY/GetMTSTDModelData', data)
}
export function GetSTDManpowerData(data) {
  return get('/MIDWAY/GetSTDManpowerData', data)
}
export function DeleteMTSTDData(data) {
  return post('/MIDWAY/DeleteMTSTDData', data)
}
export function GetMTDetailColumns(data) {
  return get('/MIDWAY/GetMTDetailColumns', data)
}
export function GetLineEmployeeDetail(data) {
  return get('/MIDWAY/GetLineEmployeeDetail', data)
}
export function GetNeedSpecialPosNameList(data) {
  return get('/MIDWAY/GetNeedSpecialPosNameList', data)
}
export function GetFreeSpecialPosEmpList(data) {
  return get('/MIDWAY/GetFreeSpecialPosEmpList', data)
}
export function GetFreeNormalEmpArea(data) {
  return get('/MIDWAY/GetFreeNormalEmpArea', data)
}
export function GetFreeNormalEmpLine(data) {
  return get('/MIDWAY/GetFreeNormalEmpLine', data)
}
export function GetFreeNormalEmpList(data) {
  return get('/MIDWAY/GetFreeNormalEmpList', data)
}
export function GetMTSiteFormData(data) {
  return get('/MIDWAY/GetMTSiteFormData', data)
}
export function GetMTFactoryFormData(data) {
  return get('/MIDWAY/GetMTFactoryFormData', data)
}
export function GetMTFactoryOfflineDetail(data) {
  return get('/MIDWAY/GetMTFactoryOfflineDetail', data)
}
export function GetMTAreaFormData(data) {
  return get('/MIDWAY/GetMTAreaFormData', data)
}
export function GetMTLineFormData(data) {
  return get('/MIDWAY/GetMTLineFormData', data)
}
export function ReleaseEmployee(data) {
  return post('/MIDWAY/ReleaseEmployee', data)
}
export function SaveRequest(data) {
  return post('/MIDWAY/SaveRequest', data)
}
export function MTGetManpowerPool(data) {
  return get('/MIDWAY/MTGetManpowerPool', data)
}
export function DoEmpOperate(data) {
  return post('/MIDWAY/DoEmpOperate', data)
}
export function MTCancelRequest(data) {
  return post('/MIDWAY/MTCancelRequest', data)
}
export function MTCancelRelease(data) {
  return post('/MIDWAY/MTCancelRelease', data)
}
export function GetMTStageList(data) {
  return get('/MIDWAY/GetMTStageList', data)
}
export function GetMTAbsenceEmpList(data) {
  return get('/MIDWAY/GetMTAbsenceEmpList', data)
}
export function SaveMTAbsenceClockIn(data) {
  return post('/MIDWAY/SaveMTAbsenceClockIn', data)
}
export function QueryMTAutoConfirmData(data) {
  return get('/MIDWAY/QueryMTAutoConfirmData', data)
}
export function MTMoveOfflineEmp(data) {
  return post('/MIDWAY/MTMoveOfflineEmp', data)
}
export function MTGetOfflineEmpDetail(data) {
  return get('/MIDWAY/MTGetOfflineEmpDetail', data)
}
export function GetSTDWIPMachineQty(data) {
  return get('/MIDWAY/GetSTDWIPMachineQty', data)
}
export function QueryMTAutoConfirmDPMEffData(data) {
  return get('/MIDWAY/QueryMTAutoConfirmDPMEffData', data)
}
export function MTAutoConfirmApprove(data) {
  return post('/MIDWAY/MTAutoConfirmApprove', data)
}
export function QueryMTHCHistory(data) {
  return get('/MIDWAY/QueryMTHCHistory', data)
}
export function GetWorkStartAndEndTime(data) {
  return get('/MIDWAY/GetWorkStartAndEndTime', data)
}
export function GetOfflineSTDManpowerData(data) {
  return get('/MIDWAY/GetOfflineSTDManpowerData', data)
}
export function DeleteMTOfflineSTDData(data) {
  return post('/MIDWAY/DeleteMTOfflineSTDData', data)
}
export function GetMTLineType(data) {
  return get('/MIDWAY/GetMTLineType', data)
}
export function GetMTAutoConfirmTypeList() {
  return get('/MIDWAY/GetMTAutoConfirmTypeList')
}
export function GetMTAutoConfirmSetting(data) {
  return get('/MIDWAY/GetMTAutoConfirmSetting', data)
}
export function CheckMTAutoConfirmExistAnotherSetting(data) {
  return get('/MIDWAY/CheckMTAutoConfirmExistAnotherSetting', data)
}
export function SaveMTAutoConfirmSetting(data) {
  return post('/MIDWAY/SaveMTAutoConfirmSetting', data)
}
export function GetMTAutoConfirmReasonCode(data) {
  return get('/MIDWAY/GetMTAutoConfirmReasonCode', data)
}
export function GetMTAutoConfirmUnMappingReasonCode(data) {
  return get('/MIDWAY/GetMTAutoConfirmUnMappingReasonCode', data)
}
export function MTAutoConfirmSaveReasonCode(data) {
  return post('/MIDWAY/MTAutoConfirmSaveReasonCode', data)
}
export function MTAutoConfirmDeleteReasonCode(data) {
  return post('/MIDWAY/MTAutoConfirmDeleteReasonCode', data)
}
export function QueryMTHCDetailData(data) {
  return get('/MIDWAY/QueryMTHCDetailData', data)
}
export function GetDashboardLineStageDetailData(data) {
  return post('/MIDWAY/GetDashboardLineStageDetailData', data)
}

export function GetPcbaEmsData_API(data) {
  return get('/MIDWAY/GetPcbaEmsData', data)
}

// 退回log by zhujunjie 2023-07-13  传rowId
export function UnassignIssueLog_API(data) {
  return post('/MIDWAY/UnassignIssueLog', data)
}

// 重新指派 by zhujunjie 2023-07-13  传rowId，dri
export function SaveRedistributionLog_API(data) {
  return post('/MIDWAY/SaveRedistributionLog', data)
}

// 获取issue信息
export function QueryIssueData_API(data) {
  return get('/MIDWAY/QueryIssueData', data)
}

// add by liwen at 20230907 fatp历史汇总
export function GetFatpHistoricalSummaryData(data) {
  return get('/MIDWAY/GetFatpHistoricalSummaryData', data)
}

export function GetMasterStageData(data) {
  return get('/MIDWAY/GetMasterStageData', data)
}

export function SaveNoLossDispatchUser_API(data) {
  return post('/MIDWAY/SaveNoLossDispatchUser', data)
}

// ADD BY zhujunjie 2023-11-08 常州厂需要的接口
export function GetOATLLossKeyInfo_API(data) {
  return get('/MIDWAY/GetOATLLossKeyInfo', data)
}
// ADD BY Liwen at 20240108 KPI历史绩效汇总V2
export function GetDPMTeamKPIHistoryDataV2(data) {
  return get('/MIDWAY/GetDPMTeamKPIHistoryDataV2', data)
}
// Issuecheck add by ZhangjingChang 2024-01-10
export function GetIssueCheckSearchingComBox(data) {
  return post('/MIDWAY/GetIssueCheckSearchingComBox', data)
}
export function GetIssueCheckSearchingInfo(data) {
  return post('/MIDWAY/GetIssueCheckSearchingInfo', data)
}
// ReasonCodeSetting add by ZhangjingChang 2024-05-23
export function SaveSelectedResonCode(data) {
  return post('/MIDWAY/SaveSelectedResonCode', data)
}
export function GetResonCodeListData(data) {
  return post('/MIDWAY/GetResonCodeListData', data)
}
export function GetResoncodedetailSetting(data) {
  return post('/MIDWAY/GetResoncodedetailSetting', data)
}
export function SaveResoncodedetailSetting(data) {
  return post('/MIDWAY/SaveResoncodedetailSetting', data)
}
export function GetConfigList(data) {
  return get('/MIDWAY/GetConfigList', data)
}
export function GetStageOperationOption(data) {
  return get('/MIDWAY/GetStageOperationOption', data)
}
export function SaveLineStageData(data) {
  return post('/MIDWAY/SaveLineStageData', data)
}
export function GetLineStageData(data) {
  return get('/MIDWAY/GetLineStageData', data)
}

// by zhujunjie 2024-04-15------start
export function GetWorkOrderAndPartData_API(data) {
  return get('/midway/GetWorkOrderAndPartData', data)
}

export function GetLineQuality_API(data) {
  return get('/midway/GetLineQuality', data)
}

export function GetLossByPart_API(data) {
  return get('/midway/GetLossByPart', data)
}

export function GetDashBoardByPart_API(data) {
  return get('/midway/GetDashBoardByPart', data)
}

export function GetEmsRepaireData_API(data) {
  return get('/midway/GetEmsRepaireData', data)
}

export function GetPCBAQRADashboard_API(data) {
  return get('/midway/GetPCBAQRADashboard', data)
}

export function GetDashBoardDetail_API(data) {
  return get('/midway/GetDashBoardDetail', data)
}

export function GetDqmDetail_API(data) {
  return get('/midway/GetDqmDetail', data)
}

// by zhujunjie 2024-04-15------end

// by zhujunjie 2024-08-13------start
export function GetMyissueStandardReason_API(data) {
  return get('/midway/GetMyissueStandardReason', data)
}
// by zhujunjie 2024-08-13------end

export function CheckLast3N1Time(data) {
  return get('/midway/CheckLast3N1Time', data)
}
