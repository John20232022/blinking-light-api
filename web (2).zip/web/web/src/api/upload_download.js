import { uploadFile, downloadFile } from '@/api/request.js'

export function DownLoadDPMTeamDailyKpiReviewData_API(data, fileName) {
  return downloadFile('/midway/DownLoadDPMTeamDailyKpiReviewData', data, fileName)
}
export function DownloadDPMIssueReview_API(data, fileName) {
  return downloadFile('/midway/downloadDPMIssueReview', data, fileName)
}
export function DownloadDPMMyIssue_API(data, fileName) {
  return downloadFile('/midway/downloadDPMMyIssue', data, fileName)
}
export function download3IN1Report_API(data, fileName) {
  return downloadFile('/midway/download3IN1Report', data, fileName)
}
export function downloadSTDInputOutputGoal_API(data, fileName) {
  return downloadFile('/midway/downloadSTDInputOutputGoal', data, fileName)
}
export function downloadDPMTeamKPIHistoryData_API(data, fileName) {
  return downloadFile('/midway/downloadDPMTeamKPIHistoryData', data, fileName)
}
export function UploadSTDDataFromExcel_API(data) {
  return uploadFile('/midway/UploadSTDInputOutputFromExcel', data)
}
export function DownloadDPMMasterStage_API(data, fileName) {
  return downloadFile('/MIDWAY/downloadDPMMasterStage', data, fileName)
}
export function downloadDPMTeamKPIHistoryDataV2_API(data, fileName) {
  return downloadFile('/MIDWAY/downloadDPMTeamKPIHistoryDataV2', data, fileName)
}
export function downLoadDPMEscalateActionReviewData(data, fileName) {
  return downloadFile('/MIDWAY/DownLoadDPMEscalateActionReviewData', data, fileName)
}
