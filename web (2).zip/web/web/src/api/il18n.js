
import { get, post } from '@/api/request.js'
export function getUserMenuPlantList(data) {
  // start update 20230222 fenglianlong  api的地址发生变化
  // return get('/Home/GetUserMenuPlantList', data)
  return post('/Main/GetUserMenuPlantList', data)
  // end update 20230222 fenglianlong ---------------------
}

/* DPM */
// add 20230210 fenglianlong  三班制修改
export function getI18nAPI(data) {
  return get('/main/getI18n', data)
}
export function I18nGuid(data) {
  return get('/main/I18nGuid', data)
}
