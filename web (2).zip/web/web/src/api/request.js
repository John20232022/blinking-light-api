// /*
//     備注：
//     process.env.NODE_ENV
//     在開發階段是 development
//     生產發佈是   production
// */

// import request from '@/utils/request'

// export function get(url, query, method = 'Get') {
//   const lang = localStorage.getItem('lang') || 'cn'
//   const obj = { ...query, lang: lang }
//   if (process.env.NODE_ENV === 'production') {
//     const newUrl = handleUrl(url, query, method)
//     return request({
//       url: newUrl,
//       method: 'get',
//       params: obj
//     })
//   } else {
//     return request({
//       url: url,
//       method: 'get',
//       params: obj
//     })
//   }
// }

// export function post(url, query = {}, method = 'Post') {
//   const lang = localStorage.getItem('lang') || 'cn'
//   const obj = { ...query, lang: lang }
//   if (process.env.NODE_ENV === 'production') {
//     const newUrl = handleUrl(url, query, method)
//     return request({
//       url: newUrl,
//       method: 'post',
//       data: obj
//     })
//   } else {
//     return request({
//       url: url,
//       method: 'post',
//       data: obj
//     })
//   }
// }

// function handleUrl(url, query, method) {
//   const tempArray = url.split('/')
//   let newUrl
//   if (tempArray.length < 3) {
//     newUrl = query?.isApiRedirect === 'N' ? `/HttpUtility/${method}?controller=&action=&isApiRedirect=N` : `/HttpUtility/${method}?controller=&action=`
//   } else {
//     newUrl = query?.isApiRedirect === 'N' ? `/HttpUtility/${method}?controller=${tempArray[1]}&action=${tempArray[2]}&isApiRedirect=N` : `/HttpUtility/${method}?controller=${tempArray[1]}&action=${tempArray[2]}`
//   }
//   return newUrl
// }

// // function handleUrl(url, method) {
// //     const tempArray = url.split('/');
// //     let obj = {
// //         newUrl: undefined,
// //         data: null
// //     }
// //     if (tempArray.length < 3) {
// //         obj = {
// //             newUrl: `/HttpUtility/${method}`,
// //             data: {
// //                 controller: "",
// //                 action: ""
// //             }
// //         }
// //     } else {
// //         obj = {
// //             newUrl: `/HttpUtility/${method}`,
// //             data: {
// //                 controller: tempArray[1],
// //                 action: tempArray[2]
// //             }
// //         }
// //     }
// //     return obj
// // }

// // 测试阶段用到的 请求----start
// // export function get(url, params) {
// //     let lang = localStorage.getItem('lang') || 'cn'
// //     let obj = { ...params, lang: lang }
// //     return request({
// //         url: url,
// //         method: 'get',
// //         obj
// //     })
// // }

// // export function post(url, params) {
// //     let lang = localStorage.getItem('lang') || 'cn'
// //     let obj = { ...params, lang: lang }
// //     return request({
// //         url: url,
// //         method: 'post',
// //         data: obj
// //     })
// // }
// // 测试阶段用到的 请求----end

/*
    備注：
    process.env.NODE_ENV
    在開發階段是 development
    生產發佈是   production
*/

import request from '@/utils/request'

export function get(url, query, method = 'Get') {
  const lang = localStorage.getItem('lang') || 'cn'
  const obj = { ...query, lang: lang }
  if (process.env.NODE_ENV === 'production') {
    const newUrl = handleUrl(url, query, method)
    return request({
      url: newUrl,
      method: 'get',
      params: obj
    })
  } else {
    return request({
      url: url,
      method: 'get',
      params: obj
    })
  }
}

export function post(url, query = {}, method = 'Post') {
  const lang = localStorage.getItem('lang') || 'cn'
  const obj = { ...query, lang: lang }
  if (process.env.NODE_ENV === 'production') {
    const newUrl = handleUrl(url, query, method)
    return request({
      url: newUrl,
      method: 'post',
      data: obj
    })
  } else {
    return request({
      url: url,
      method: 'post',
      data: obj
    })
  }
}

function handleUrl(url, query, method) {
  const tempArray = url.split('/')
  let newUrl
  if (tempArray.length < 3) {
    newUrl = query?.isApiRedirect === 'N' ? `/HttpUtility/${method}?controller=&action=&isApiRedirect=N` : `/HttpUtility/${method}?controller=&action=`
  } else {
    newUrl = query?.isApiRedirect === 'N' ? `/HttpUtility/${method}?controller=${tempArray[1]}&action=${tempArray[2]}&isApiRedirect=N` : `/HttpUtility/${method}?controller=${tempArray[1]}&action=${tempArray[2]}`
  }
  return newUrl
}

export function downloadFile(url, query = {}, fileName, method = 'Get') {
  const lang = localStorage.getItem('lang') || 'cn'
  const obj = { ...query, lang: lang }
  var newUrl = url
  if (process.env.NODE_ENV === 'production') {
    newUrl = handleUrl(url, query, 'Download')
  }
  request({
    method: 'get',
    url: newUrl, // url,
    responseType: 'blob',
    params: obj
  })
    .then((res) => {
      const content = res.data
      const blob = new Blob([content])
      if ('download' in document.createElement('a')) { // 非IE下载
        const elink = document.createElement('a')
        elink.download = fileName
        elink.style.display = 'none'
        elink.href = URL.createObjectURL(blob)
        document.body.appendChild(elink)
        elink.click()
        URL.revokeObjectURL(elink.href) // 释放URL 对象
        document.body.removeChild(elink)
      } else { // IE10+下载
        navigator.msSaveBlob(blob, fileName)
      }
    })
    .catch(function(response) {
      alert('Error:' + response)
    })
}

export function uploadFile(url, formData, method = 'Post') {
  const lang = localStorage.getItem('lang') || 'cn'
  formData.append('lang', lang)
  if (process.env.NODE_ENV === 'production') {
    const newUrl = handleUrl(url, {}, 'Upload')
    return request({
      url: newUrl,
      method: 'post',
      data: formData,
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  } else {
    return request({
      url: url,
      method: 'post',
      data: formData
    })
  }
}

// function handleUrl(url, method) {
//     const tempArray = url.split('/');
//     let obj = {
//         newUrl: undefined,
//         data: null
//     }
//     if (tempArray.length < 3) {
//         obj = {
//             newUrl: `/HttpUtility/${method}`,
//             data: {
//                 controller: "",
//                 action: ""
//             }
//         }
//     } else {
//         obj = {
//             newUrl: `/HttpUtility/${method}`,
//             data: {
//                 controller: tempArray[1],
//                 action: tempArray[2]
//             }
//         }
//     }
//     return obj
// }

// 测试阶段用到的 请求----start
// export function get(url, params) {
//   const lang = localStorage.getItem('lang') || 'cn'
//   const obj = { ...params, lang: lang }
//   return request({
//     url: url,
//     method: 'get',
//     obj
//   })
// }

// export function post(url, params) {
//   const lang = localStorage.getItem('lang') || 'cn'
//   const obj = { ...params, lang: lang }
//   return request({
//     url: url,
//     method: 'post',
//     data: obj
//   })
// }
// 测试阶段用到的 请求----end

