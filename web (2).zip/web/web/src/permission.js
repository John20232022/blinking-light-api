import { Loading } from 'element-ui'
import router from './router'

import cache from '@/plugins/cache'

let pageLoading

router.beforeEach((to, from, next) => {
  pageLoading = Loading.service({
    lock: true,
    text: 'Loading',
    spinner: 'el-icon-loading',
    background: 'rgba(0, 0, 0, 0.7)'
  })

  // 存入语言
  if (to.query.lang) {
    // 存到localstorage 裏面
    cache.local.set('lang', to.query.lang) // 把 lang 存到 localstorage
  }

  // 存入Site
  if (to.query.site) {
    // 存到localstorage 裏面
    cache.session.set('site', to.query.site)
  }

  // 如果token 存在，那么我们就存入token
  if (to.query.token) {
    // 存到localstorage 裏面
    cache.session.set('Dfap-Token', to.query.token) // 把 token 存到 sessionStorage
  }
  next()
})

router.afterEach(() => {
  // 加载动画去除
  setTimeout(() => {
    pageLoading.close()
  }, 300)
})
