<template>
  <div id="app">
    <router-view
      @do-redirect-url="actionJumper"
      @change-show-model="changeShowModel"
    />
  </div>
</template>

<script>
import { getI18nAPI, I18nGuid } from '@/api/il18n'
import elementCNLocale from 'element-ui/lib/locale/lang/zh-CN'
import elementEnLocale from 'element-ui/lib/locale/lang/en'
import elementTWLocale from 'element-ui/lib/locale/lang/zh-TW'
import elementESLocale from 'element-ui/lib/locale/lang/es'
import elementVILocale from 'element-ui/lib/locale/lang/vi'
import elementTHLocale from 'element-ui/lib/locale/lang/th'
export default {
  name: 'App',
  mounted: function() {
    this.getI18n()
  },
  methods: {
    actionJumper(routeData) {
      this.$router.push({
        path: routeData.url,
        query: routeData.param
      })
    },

    async  getI18n() {
      let MessageLocalObject = {}
      const LocMsg = localStorage.getItem('DPMi18n')
      if (LocMsg) {
        try {
          const returnObject = JSON.parse(LocMsg)
          const response = await I18nGuid({ appName: 'DPM' })
          const i18nCurrentGuid = response.data.ReturnObject

          if (i18nCurrentGuid === returnObject.guid) {
            MessageLocalObject = returnObject.il18n
          } else {
            MessageLocalObject = {}
          }
        } catch (e) {
          MessageLocalObject = {}
        }
      }
      console.debug(JSON.stringify(MessageLocalObject))
      if (JSON.stringify(MessageLocalObject) === '{}') {
        const response = await getI18nAPI({ appName: 'DPM' })
        const retunrObject = response.data.ReturnObject
        MessageLocalObject = response.data.ReturnObject.il18n
        localStorage.setItem('DPMi18n', JSON.stringify(retunrObject))
      }
      if (JSON.stringify(MessageLocalObject) !== '{}') {
        this.$i18n.setLocaleMessage('cn', {
          ...MessageLocalObject.cn,
          ...elementCNLocale
        })

        this.$i18n.setLocaleMessage('tw', {
          ...MessageLocalObject.tw,
          ...elementTWLocale
        })

        this.$i18n.setLocaleMessage('en', {
          ...MessageLocalObject.en,
          ...elementEnLocale
        })

        this.$i18n.setLocaleMessage('vi', {
          ...MessageLocalObject.vi,
          ...elementVILocale
        })

        this.$i18n.setLocaleMessage('es', {
          ...MessageLocalObject.es,
          ...elementESLocale
        })
        this.$i18n.setLocaleMessage('th', {
          ...MessageLocalObject.th,
          ...elementTHLocale
        })
        this.$i18n.locale = localStorage.getItem('lang') || 'cn'
      }
    },
    // 这个函数不起作用
    changeShowModel(model) {}
  }
}
</script>
<style>
/* #app {
  padding: 5px 5px 0px 5px;
} */
</style>
