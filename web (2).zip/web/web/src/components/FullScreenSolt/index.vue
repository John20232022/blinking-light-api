<template>
  <div id="app-container"><slot /></div>
</template>

<script>
export default {
  mounted() {
    this.changeScale()
    window.addEventListener('resize', () => {
      this.changeScale()
    })
  },
  methods: {
    changeScale() {
      const app_container = document.getElementById('app-container')
      const clientWidth = document.documentElement.clientWidth
      const clientHeight = document.documentElement.clientHeight
      if (clientWidth < 1920) {
        const num = (clientHeight / 1080).toFixed(6)
        app_container.style.transform = `scale(${num})`
      }
      if (clientWidth / clientHeight < 1920 / 1080) {
        // 通常這種情況 我們不考慮
        const num = (clientWidth / 1920).toFixed(6)
        setTimeout(() => {
          app_container.style.transform = `scale(${num})`
          const top = ((clientHeight - (1080 * num)) / 2).toFixed(0)
          app_container.style.top = top + 'px'
        }, 100)
      } else {
        const num = (clientHeight / 1080).toFixed(6)
        setTimeout(() => {
          app_container.style.transform = `scale(${num})`
          const left = ((clientWidth - (1920 * num)) / 2).toFixed(0)
          app_container.style.left = left + 'px'
        }, 10)
      }
    }
    /* changeScale() {
      const app_container = document.getElementById('app-container')
      const clientWidth = document.documentElement.clientWidth
      const num = (clientWidth / 1920).toFixed(6)
      // console.log(num);
      setTimeout(() => {
        app_container.style.transform = `scale(${num})`
      }, 100)
    } */
  }
}
</script>

<style scoped lang="scss">
#app-container {
  position: fixed;
  top: 0px;
  left: 0px;
  width: 1920px;
  overflow: hidden;
  -webkit-transform-origin: left top;
  transform-origin: left top;
  z-index: 999;
}
</style>
