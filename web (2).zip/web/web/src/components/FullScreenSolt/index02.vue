<template>
  <div id="app-container"><slot /></div>
</template>

<script>
export default {
  mounted() {
    const loading = this.$loading({
      lock: true,
      text: 'Loading',
      spinner: 'el-icon-loading',
      background: 'rgba(0, 0, 0, 0.7)'
    })
    setTimeout(() => {
      loading.close()
    }, 300)
    this.changeScale()
    window.addEventListener('resize', () => {
      this.changeScale()
    })
  },
  methods: {
    changeScale() {
      const app_container = document.getElementById('app-container')
      const clientWidth = document.documentElement.clientWidth
      const clientHeight = document.documentElement.clientHeight

      if (clientWidth / clientHeight < 1920 / 1080) {
        // 通常這種情況 我們不考慮
        const num = (clientWidth / 1920).toFixed(6)
        setTimeout(() => {
          app_container.style.transform = `scale(${num})`
          const top = ((clientHeight - 1080 * num) / 2).toFixed(0)
          // app_container.style.top = top + 'px'
        }, 100)
      } else {
        const num = (clientHeight / 1080).toFixed(6)
        setTimeout(() => {
          app_container.style.transform = `scale(${num})`
          const width = ((1080 * clientWidth) / clientHeight).toFixed(0)
          app_container.style.width = width + 'px'
        }, 10)
      }
    }
  }
}
</script>

<style scoped lang="scss">
#app-container {
  position: fixed;
  top: 0px;
  left: 0px;
// width: 2395px;
  overflow: hidden;
  -webkit-transform-origin: left top;
  transform-origin: left top;
  z-index: 1;
}
</style>
