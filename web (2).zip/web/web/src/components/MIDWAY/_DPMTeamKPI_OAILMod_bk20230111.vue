<template>
    <div style="height:100%;width:100%;" id="containerDiv">
      <div class="chartDiv" id="divChart">
        <div class="chart" id="elChart">
        </div>
         <div class="chartLoss" id="elChartLoss">
        </div>
      </div>
      <div class="detailDiv" id="tableDetailContainer">
        <el-table :data="tableData" :height="190" size="mini"
          style="width: 100%" :header-cell-style="getHeaderCellColor">
          <el-table-column prop="type" label="" width="70" align="center" fixed></el-table-column>
          <el-table-column prop="mtd" label="MTD" width="70" align="center" fixed></el-table-column>
          <el-table-column prop="d1" label="01" width="70" align="center"></el-table-column>
          <el-table-column prop="d2" label="02" width="70" align="center"></el-table-column>
          <el-table-column prop="d3" label="03" width="70" align="center"></el-table-column>
          <el-table-column prop="d4" label="04" width="70" align="center"></el-table-column>
          <el-table-column prop="d5" label="05" width="70" align="center"></el-table-column>
          <el-table-column prop="d6" label="06" width="70" align="center"></el-table-column>
          <el-table-column prop="d7" label="07" width="70" align="center"></el-table-column>
          <el-table-column prop="d8" label="08" width="70" align="center"></el-table-column>
          <el-table-column prop="d9" label="09" width="70" align="center"></el-table-column>
          <el-table-column prop="d10" label="10" width="70" align="center"></el-table-column>
          <el-table-column prop="d11" label="11" width="70" align="center"></el-table-column>
          <el-table-column prop="d12" label="12" width="70" align="center"></el-table-column>
          <el-table-column prop="d13" label="13" width="70" align="center"></el-table-column>
          <el-table-column prop="d14" label="14" width="70" align="center"></el-table-column>
          <el-table-column prop="d15" label="15" width="70" align="center"></el-table-column>
          <el-table-column prop="d16" label="16" width="70" align="center"></el-table-column>
          <el-table-column prop="d17" label="17" width="70" align="center"></el-table-column>
          <el-table-column prop="d18" label="18" width="70" align="center"></el-table-column>
          <el-table-column prop="d19" label="19" width="70" align="center"></el-table-column>
          <el-table-column prop="d20" label="20" width="70" align="center"></el-table-column>
          <el-table-column prop="d21" label="21" width="70" align="center"></el-table-column>
          <el-table-column prop="d22" label="22" width="70" align="center"></el-table-column>
          <el-table-column prop="d23" label="23" width="70" align="center"></el-table-column>
          <el-table-column prop="d24" label="24" width="70" align="center"></el-table-column>
          <el-table-column prop="d25" label="25" width="70" align="center"></el-table-column>
          <el-table-column prop="d26" label="26" width="70" align="center"></el-table-column>
          <el-table-column prop="d27" label="27" width="70" align="center"></el-table-column>
          <el-table-column prop="d28" label="28" width="70" align="center"></el-table-column>
          <el-table-column prop="d29" label="29" width="70" align="center"></el-table-column>
          <el-table-column prop="d30" label="30" width="70" align="center"></el-table-column>
          <el-table-column prop="d31" label="31" width="70" align="center"></el-table-column>
        </el-table>
      </div>
      <div class="middleDiv" id="tableMiddleContainer">
        <el-table :data="tableMiddleData" :height="190" size="mini"
          style="width: 100%" :header-cell-style="getHeaderCellColor">
          <el-table-column prop="type" label="" width="70" align="center" fixed></el-table-column>
          <el-table-column prop="mtd" label="MTD" width="70" align="center" fixed></el-table-column>
          <el-table-column prop="d1" label="01" width="70" align="center"></el-table-column>
          <el-table-column prop="d2" label="02" width="70" align="center"></el-table-column>
          <el-table-column prop="d3" label="03" width="70" align="center"></el-table-column>
          <el-table-column prop="d4" label="04" width="70" align="center"></el-table-column>
          <el-table-column prop="d5" label="05" width="70" align="center"></el-table-column>
          <el-table-column prop="d6" label="06" width="70" align="center"></el-table-column>
          <el-table-column prop="d7" label="07" width="70" align="center"></el-table-column>
          <el-table-column prop="d8" label="08" width="70" align="center"></el-table-column>
          <el-table-column prop="d9" label="09" width="70" align="center"></el-table-column>
          <el-table-column prop="d10" label="10" width="70" align="center"></el-table-column>
          <el-table-column prop="d11" label="11" width="70" align="center"></el-table-column>
          <el-table-column prop="d12" label="12" width="70" align="center"></el-table-column>
          <el-table-column prop="d13" label="13" width="70" align="center"></el-table-column>
          <el-table-column prop="d14" label="14" width="70" align="center"></el-table-column>
          <el-table-column prop="d15" label="15" width="70" align="center"></el-table-column>
          <el-table-column prop="d16" label="16" width="70" align="center"></el-table-column>
          <el-table-column prop="d17" label="17" width="70" align="center"></el-table-column>
          <el-table-column prop="d18" label="18" width="70" align="center"></el-table-column>
          <el-table-column prop="d19" label="19" width="70" align="center"></el-table-column>
          <el-table-column prop="d20" label="20" width="70" align="center"></el-table-column>
          <el-table-column prop="d21" label="21" width="70" align="center"></el-table-column>
          <el-table-column prop="d22" label="22" width="70" align="center"></el-table-column>
          <el-table-column prop="d23" label="23" width="70" align="center"></el-table-column>
          <el-table-column prop="d24" label="24" width="70" align="center"></el-table-column>
          <el-table-column prop="d25" label="25" width="70" align="center"></el-table-column>
          <el-table-column prop="d26" label="26" width="70" align="center"></el-table-column>
          <el-table-column prop="d27" label="27" width="70" align="center"></el-table-column>
          <el-table-column prop="d28" label="28" width="70" align="center"></el-table-column>
          <el-table-column prop="d29" label="29" width="70" align="center"></el-table-column>
          <el-table-column prop="d30" label="30" width="70" align="center"></el-table-column>
          <el-table-column prop="d31" label="31" width="70" align="center"></el-table-column>
        </el-table>
      </div>
      <div class="lineDiv" id="tableLinelContainer">
        <el-table :data="tableLineData" :height="190" size="mini"
          style="width: 100%" :header-cell-style="getHeaderCellColor">
          <el-table-column prop="line" label="線體" width="70" align="center" fixed show-overflow-tooltip></el-table-column>
          <el-table-column prop="mtd" label="MTD" width="70" align="center" fixed></el-table-column>
          <el-table-column prop="d1" label="01" width="70" align="center"></el-table-column>
          <el-table-column prop="d2" label="02" width="70" align="center"></el-table-column>
          <el-table-column prop="d3" label="03" width="70" align="center"></el-table-column>
          <el-table-column prop="d4" label="04" width="70" align="center"></el-table-column>
          <el-table-column prop="d5" label="05" width="70" align="center"></el-table-column>
          <el-table-column prop="d6" label="06" width="70" align="center"></el-table-column>
          <el-table-column prop="d7" label="07" width="70" align="center"></el-table-column>
          <el-table-column prop="d8" label="08" width="70" align="center"></el-table-column>
          <el-table-column prop="d9" label="09" width="70" align="center"></el-table-column>
          <el-table-column prop="d10" label="10" width="70" align="center"></el-table-column>
          <el-table-column prop="d11" label="11" width="70" align="center"></el-table-column>
          <el-table-column prop="d12" label="12" width="70" align="center"></el-table-column>
          <el-table-column prop="d13" label="13" width="70" align="center"></el-table-column>
          <el-table-column prop="d14" label="14" width="70" align="center"></el-table-column>
          <el-table-column prop="d15" label="15" width="70" align="center"></el-table-column>
          <el-table-column prop="d16" label="16" width="70" align="center"></el-table-column>
          <el-table-column prop="d17" label="17" width="70" align="center"></el-table-column>
          <el-table-column prop="d18" label="18" width="70" align="center"></el-table-column>
          <el-table-column prop="d19" label="19" width="70" align="center"></el-table-column>
          <el-table-column prop="d20" label="20" width="70" align="center"></el-table-column>
          <el-table-column prop="d21" label="21" width="70" align="center"></el-table-column>
          <el-table-column prop="d22" label="22" width="70" align="center"></el-table-column>
          <el-table-column prop="d23" label="23" width="70" align="center"></el-table-column>
          <el-table-column prop="d24" label="24" width="70" align="center"></el-table-column>
          <el-table-column prop="d25" label="25" width="70" align="center"></el-table-column>
          <el-table-column prop="d26" label="26" width="70" align="center"></el-table-column>
          <el-table-column prop="d27" label="27" width="70" align="center"></el-table-column>
          <el-table-column prop="d28" label="28" width="70" align="center"></el-table-column>
          <el-table-column prop="d29" label="29" width="70" align="center"></el-table-column>
          <el-table-column prop="d30" label="30" width="70" align="center"></el-table-column>
          <el-table-column prop="d31" label="31" width="70" align="center"></el-table-column>
        </el-table>
      </div>
    </div>
</template>
<script>
// import $ from 'jquery'
import {
// GetDPMQueryKeyValue, GetDPMDashboardData
} from '@/api/midway.js'
export default {
  props: [
    'onedata'
  ],
  components: {
    // lineComp,
    // optComp
  },
  computed: {
  },
  mounted () {
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
      // this.resetDashboard()
      if (this.chart !== null) {
        this.chart.resize()
      }
      if (this.chartLoss !== null) {
        this.chartLoss.resize()
      }
    }
    this.$nextTick(function () {
      this.initialData()
    })
  },
  watch: {
    onedata (n, o) {
      this.mydata = n
    }
  },
  data () {
    return {
      mydata: this.onedata,
      activeNames: ['1', '2', '3'],
      tableData: [{
        type: 'Input',
        mtd: '31500',
        d1: '8000',
        d2: '8000'
      }, {
        type: '不良',
        mtd: '31500',
        d1: '8000',
        d2: '8000'
      }, {
        type: 'PT',
        mtd: '7',
        d1: '0',
        d2: '5'
      }, {
        type: 'BI',
        mtd: '7',
        d1: '0',
        d2: '5'
      }, {
        type: 'HI-POT',
        mtd: '8',
        d1: '0',
        d2: '5'
      }, {
        type: 'ATE',
        mtd: '7',
        d1: '0',
        d2: '5'
      }, {
        type: 'OATL',
        mtd: '1333',
        d1: '1000',
        d2: '1125'
      }],
      tableMiddleData: [{
        type: 'D',
        mtd: '0.6%',
        d1: '0.3%',
        d2: '0.6%'
      }, {
        type: 'M',
        mtd: '7',
        d1: '0',
        d2: '5'
      }, {
        type: 'W',
        mtd: '7',
        d1: '0',
        d2: '5'
      }, {
        type: 'E',
        mtd: '8',
        d1: '0',
        d2: '5'
      }, {
        type: 'T',
        mtd: '7',
        d1: '0',
        d2: '5'
      }, {
        type: 'O',
        mtd: '7',
        d1: '0',
        d2: '5'
      }, {
        type: 'A',
        mtd: '7',
        d1: '0',
        d2: '5'
      }, {
        type: 'S',
        mtd: '7',
        d1: '0',
        d2: '5'
      }],
      tableLineData: [{
        line: 'P501',
        mtd: '333',
        d1: '123',
        d2: '456'
      }, {
        line: 'P502',
        mtd: '333',
        d1: '123',
        d2: '456'
      }, {
        line: 'P503',
        mtd: '79.9%',
        d1: '65.3%',
        d2: '46.3%'
      }],
      loadingData: null,
      onePicLines: 2,
      colQty: 1,
      rowQty: 1,
      level: 'team',
      keyid: '',
      loading: false,
      autoRefresh: false,
      refreshTimer: null,
      bigChartData: [],
      chartData: [],
      mainHeight: 1,
      mainWidth: 1,
      chart: null,
      chartLoss: null
    }
  },
  beforeDestroy () {
    clearInterval(this.refreshTimer)
  },
  methods: {
    getHeaderCellColor () {
      const style = {
        'background-color': 'rgb(23,102,173)',
        color: 'white'
      }
      return style
    },
    initialData () {
      this.keyid = this.$route.query.keyid
      // 抓取项目数据显示在看板上
      // this.getDashBoardData()
      this.GetMainData()
    },
    destoryChart (chart) {
      if (chart !== null && chart !== '' && chart !== undefined) {
        chart.dispose()
      }
    },
    async GetMainData () {
      const option = {
        xAxis: {
          type: 'category',
          data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            data: [150, 230, 224, 218, 135, 147, 260],
            type: 'line'
          }
        ]
      }
      this.destoryChart(this.chart)
      const chartDom = document.getElementById('elChart')
      this.chart = this.$echarts.init(chartDom)
      this.chart.clear()
      this.chart.setOption(option)

      const option2 = {
        title: {
          text: 'Referer of a Website',
          subtext: 'Fake Data',
          left: 'center'
        },
        tooltip: {
          trigger: 'item'
        },
        legend: {
          orient: 'vertical',
          left: 'left'
        },
        series: [
          {
            name: 'Access From',
            type: 'pie',
            radius: '50%',
            data: [
              { value: 1048, name: 'Search Engine' },
              { value: 735, name: 'Direct' },
              { value: 580, name: 'Email' },
              { value: 484, name: 'Union Ads' },
              { value: 300, name: 'Video Ads' }
            ],
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      }
      this.destoryChart(this.chartLoss)
      const chartDom2 = document.getElementById('elChartLoss')
      this.chartLoss = this.$echarts.init(chartDom2)
      this.chartLoss.clear()
      this.chartLoss.setOption(option2)
    },
    alertMsg (msg) {
      this.$alert(msg, '提示', {
        confirmButtonText: '確定',
        type: 'error'
      })
    },
    resizeTable: function () {
      this.$nextTick(function () {
        let dailogBodyHeight = $(window).height() - 700// $('#containerDiv').height()
        if (dailogBodyHeight < 250) {
          dailogBodyHeight = 250
        }
        $('#divChart').height(dailogBodyHeight)
      })
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep main.el-main{
  padding: 0
}
::v-deep .el-divider--horizontal{
  margin:0
}
// ::v-deep .el-dialog__body{
//   padding-bottom: 0px;
// }
section{
  padding-bottom: 0;
}
.el-header{
    padding:0 5px
}
.header{
  height:50px !important;
  // background-color:#1f4e7c;
  background-color:rgba(0,0,0,0);
}
.chartDiv {
  height:calc(100% - 430px);
  width:100%;
  background-color: white;
  display: flex;
}
.chart{
  height: 100%;
  width:70%;
}
.chartLoss{
  height: 100%;
  width:30%;
}
.detailDiv{
  margin-top:5px;
  width:100%;
}
.middleDiv{
  margin-top:5px;
  width:100%;
}
.lineDiv{
  margin-top:5px;
  width:100%;
}
</style>
