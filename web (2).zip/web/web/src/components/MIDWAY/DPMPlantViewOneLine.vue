<template>
  <div class="oneLineDiv">
    <div class="lineTitle">{{ mydata.line }}</div>
    <div class="chartMainDiv">
      <div :id="rtyChartId" class="chartDiv" />
      <div :id="uphChartId" class="chartDiv" />
      <div :id="upphChartId" class="chartDiv" />
      <div :id="utsChartId" class="chartDiv" />
    </div>
  </div>
</template>
<script>
export default {
  // eslint-disable-next-line vue/require-prop-types
  props: ['onedata'],
  data() {
    return {
      mydata: this.onedata,
      rtyChartId: 'rty',
      uphChartId: 'uph',
      upphChartId: 'upph',
      utsChartId: 'uts',
      chartRTY: null,
      chartUPH: null,
      chartUPPH: null,
      chartUTS: null
    }
  },
  computed: {
    // getColor: function (value) {
    //   if (value >= 90) {
    //     return 'limegreen'
    //   } else if (value >= 60 && value < 90) {
    //     return 'yellow'
    //   } else {
    //     return 'red'
    //   }
    // }
  },
  watch: {
    onedata(n, o) {
      this.mydata = n
    }
  },
  mounted() {
    this.$nextTick(() => {
      if (this.mydata === undefined) {
        return
      }
      this.rtyChartId = this.mydata.line + 'rty'
      this.uphChartId = this.mydata.line + 'uph'
      this.upphChartId = this.mydata.line + 'upph'
      this.utsChartId = this.mydata.line + 'uts'
      this.showChart('RTY')
      this.showChart('UPH')
      this.showChart('UPPH')
      this.showChart('UTS')
    })
  },
  methods: {
    getColor: function(value) {
      if (value >= 90) {
        return 'limegreen'
      } else if (value >= 60 && value < 90) {
        return 'yellow'
      } else {
        return 'red'
      }
    },
    showChart(type) {
      if (this.mydata === undefined || this.mydata.data.length === 0) {
        return
      }

      const one = this.mydata.data.find(x => x.type === type)
      if (one !== null) {
        const gaugeData = [
          {
            value: one.value,
            name: one.name,
            title: {
              offsetCenter: ['0%', '-20%']
            },
            detail: {
              valueAnimation: true,
              offsetCenter: ['0%', '20%']
            }
          }
        ]
        const color = this.getColor(one.value)
        var option = {
          series: [
            {
              type: 'gauge',
              startAngle: 90,
              endAngle: -270,
              pointer: {
                show: false
              },
              progress: {
                show: true,
                overlap: false,
                roundCap: true,
                clip: false,
                itemStyle: {
                  borderWidth: 1,
                  borderColor: '#464646',
                  color: color
                }
              },
              axisLine: {
                lineStyle: {
                  width: 10,
                  color: [[1, '#E6EBF8']]
                }
              },
              splitLine: {
                show: false,
                distance: 0,
                length: 10
              },
              axisTick: {
                show: false
              },
              axisLabel: {
                show: false,
                distance: 50
              },
              data: gaugeData,
              title: {
                fontSize: 14
              },
              detail: {
                width: 45,
                height: 13,
                fontSize: 13,
                color: 'auto',
                borderColor: 'auto',
                borderRadius: 15,
                borderWidth: 1,
                formatter: '{value}%'
              }
            }
          ]
        }
        var id = ''
        var chartDom
        if (type === 'RTY') {
          id = this.rtyChartId
          this.$nextTick(() => {
            chartDom = document.getElementById(id)
            this.chartRTY = this.$echarts.init(chartDom)
            this.chartRTY.setOption(option)
          })
        } else if (type === 'UPH') {
          id = this.uphChartId
          this.$nextTick(() => {
            chartDom = document.getElementById(id)
            this.chartUPH = this.$echarts.init(chartDom)
            this.chartUPH.setOption(option)
          })
        } else if (type === 'UPPH') {
          id = this.upphChartId
          this.$nextTick(() => {
            chartDom = document.getElementById(id)
            this.chartUPPH = this.$echarts.init(chartDom)
            this.chartUPPH.setOption(option)
          })
        } else if (type === 'UTS') {
          id = this.utsChartId
          this.$nextTick(() => {
            chartDom = document.getElementById(id)
            this.chartUTS = this.$echarts.init(chartDom)
            this.chartUTS.setOption(option)
          })
        }
      }
    }

  }
}
</script>
<style lang="less" scoped>
.oneLineDiv{
  width:600px;
  box-shadow: 0 0 10px rgb(205,205,205) ;
}
.lineTitle{
  text-align: center;
  background-color: slategrey;
  color: white;
  font-size: 28px;
  height:40px;
  line-height: 40px;
  // border-top-right-radius: 10px;
  // border-top-left-radius: 10px;
}
.chartMainDiv{
  height: 162px;
  display:flex;
  // border: 1px solid red;
  flex-wrap: nowrap;
  justify-content: center;
  align-items: center;
  // border-left:2px solid slategrey;
  // border-right:2px solid slategrey;
  // border-bottom:2px solid slategrey;
  // border-bottom-right-radius: 10px;
  // border-bottom-left-radius: 10px;
  background-color: rgb(250,251,253);
}
.chartDiv{
  width:150px;
  height:150px;
  flex:none;
}
</style>
