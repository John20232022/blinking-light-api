<template>
  <div>
    <el-dialog
      :center="true"
      :title="chartDetailDialogTitle"
      :close-on-press-escape="false"
      :visible.sync="chartDetailDialogVisible"
      width="1250px"
      :close-on-click-modal="false"
      @close="closeChartDetailDialog"
    >
      <el-tabs v-model="activeDetailTabName" @tab-click="tabClick">
        <el-tab-pane label="$t('dpmOptMod.lblTitleIssueSummary')" name="statusDetailTab">
          <div style="width: 1200px;height:450px">
            <el-table
              :data="tableData"
              size="small"
              height="450"
              style="width: 100%;"
              @row-click="getIssueTrace"
            >
              <el-table-column v-if="showOptColumn" label="" width="90" fixed>
                <template slot-scope="scope">
                  <el-button type="text" size="small" @click="showTrackingDialog(scope.row)">{{ $t('dpmOptMod.btnView') }}</el-button>
                  <el-button type="text" size="small" @click="showIssueChartDialog(scope.row)">{{ $t('dpmOptMod.btnChart') }}</el-button>
                </template>
              </el-table-column>
              <el-table-column prop="start_time" :label="$t('dpmOptMod.colRangeStart')" width="100" />
              <el-table-column prop="end_time" :label="$t('dpmOptMod.colRangeEnd')" width="100" />
              <el-table-column prop="factory" :label="$t('common.colFactory')" width="70" />
              <el-table-column prop="area" :label="$t('common.colArea')" width="70" />
              <el-table-column prop="line" :label="$t('common.colLine')" width="80" />
              <el-table-column prop="stage" :label="$t('common.colStage')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="output" :label="$t('common.colOutput')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="pass_oqc" :label="$t('dpmOptMod.colPassOQC')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="actual" :label="$t('dpmOptMod.colStock')" width="80" />
              <el-table-column prop="actual" :label="$t('common.colAct')" width="80" />
              <el-table-column prop="goal" :label="$t('common.colGoal')" width="80" />
              <el-table-column prop="reason_codes" :label="$t('dpmOptMod.colReaconCode')" width="120" show-overflow-tooltip />
              <el-table-column prop="owner_names" :label="$t('common.colDRI')" width="120" show-overflow-tooltip />
              <el-table-column prop="process_name" :label="$t('common.colStatus')" width="90" />
              <el-table-column prop="result" :label="$t('dpmOptMod.colResult')" width="90" />
              <el-table-column v-if="false" prop="row_id" />
              <el-table-column v-if="false" prop="index" />
            </el-table>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmOptMod.lblTitleWaitForDispatch')" name="waitForDispatchTab">
          <div style="width: 1200px;height:450px">
            <el-table
              :data="tableDataDispatch"
              size="small"
              height="450"
              style="width: 100%;"
              @row-click="getIssueTrace"
            >
              <el-table-column v-if="showOptColumn" label="" width="90" fixed>
                <template slot-scope="scope">
                  <el-button type="text" size="small" @click="showDetailDataForEachRange(scope.row)">{{ $t('dpmOptMod.btnExpand') }}</el-button>
                  <el-button type="text" size="small" @click="showIssueChartDialog(scope.row)">{{ $t('dpmOptMod.btnChart') }}</el-button>
                </template>
              </el-table-column>
              <el-table-column prop="start_time" :label="$t('dpmOptMod.colRangeStart')" width="100" />
              <el-table-column prop="end_time" :label="$t('dpmOptMod.colRangeEnd')" width="100" />
              <el-table-column prop="factory" :label="$t('common.colFactory')" width="70" />
              <el-table-column prop="area" :llabel="$t('common.colArea')" width="70" />
              <el-table-column prop="line" :label="$t('common.colLine')" width="80" />
              <el-table-column prop="stage" :label="$t('common.colStage')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="output" :label="$t('common.colOutput')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="pass_oqc" :label="$t('dpmOptMod.colPassOQC')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="actual" :label="$t('dpmOptMod.colStock')" width="80" />
              <el-table-column prop="actual" :label="$t('common.colAct')" width="80" />
              <el-table-column prop="goal" :label="$t('common.colGoal')" width="80" />
              <el-table-column prop="reason_codes" :label="$t('dpmOptMod.colReaconCode')" width="120" show-overflow-tooltip />
              <el-table-column prop="owner_names" :label="$t('common.colDRI')" width="120" show-overflow-tooltip />
              <el-table-column prop="process_name" :label="$t('common.colStatus')" width="90" />
              <el-table-column prop="result" :label="$t('dpmOptMod.colResult')" width="90" />
              <el-table-column v-if="false" prop="row_id" />
              <el-table-column v-if="false" prop="index" />
            </el-table>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmOptMod.lblTitleWaitForEval')" name="waitForEvalTab">
          <div style="width: 1200px;height:450px">
            <el-table
              :data="tableDataEval"
              size="small"
              height="450"
              style="width: 100%;"
              @row-click="getIssueTrace"
            >
              <el-table-column v-if="showOptColumn" label="" width="70" fixed>
                <template slot-scope="scope">
                  <el-button type="text" size="small" @click="showTrackingDialog(scope.row)">{{ $t('dpmOptMod.btnEval') }}</el-button>
                </template>
              </el-table-column>
              <el-table-column prop="start_time" :label="$t('dpmOptMod.colRangeStart')" width="100" />
              <el-table-column prop="end_time" :label="$t('dpmOptMod.colRangeEnd')" width="100" />
              <el-table-column prop="factory" :label="$t('common.colFactory')" width="70" />
              <el-table-column prop="area" :llabel="$t('common.colArea')" width="70" />
              <el-table-column prop="line" :label="$t('common.colLine')" width="80" />
              <el-table-column prop="stage" :label="$t('common.colStage')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="output" :label="$t('common.colOutput')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="pass_oqc" :label="$t('dpmOptMod.colPassOQC')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="actual" :label="$t('dpmOptMod.colStock')" width="80" />
              <el-table-column prop="actual" :label="$t('common.colAct')" width="80" />
              <el-table-column prop="goal" :label="$t('common.colGoal')" width="80" />
              <el-table-column prop="reason_codes" :label="$t('dpmOptMod.colReaconCode')" width="120" show-overflow-tooltip />
              <el-table-column prop="owner_names" :label="$t('common.colDRI')" width="120" show-overflow-tooltip />
              <el-table-column prop="process_name" :label="$t('common.colStatus')" width="90" />
              <el-table-column prop="result" :label="$t('dpmOptMod.colResult')" width="90" />
              <el-table-column v-if="false" prop="row_id" />
              <el-table-column v-if="false" prop="index" />
            </el-table>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmOptMod.lblTitleClosed')" name="waitForCloseTab">
          <div style="width: 1200px;height:450px">
            <el-table
              :data="tableDataClose"
              size="small"
              height="450"
              style="width: 100%;"
              @row-click="getIssueTrace"
            >
              <el-table-column prop="start_time" :label="$t('dpmOptMod.colRangeStart')" width="100" />
              <el-table-column prop="end_time" :label="$t('dpmOptMod.colRangeEnd')" width="100" />
              <el-table-column prop="factory" :label="$t('common.colFactory')" width="70" />
              <el-table-column prop="area" :llabel="$t('common.colArea')" width="70" />
              <el-table-column prop="line" :label="$t('common.colLine')" width="80" />
              <el-table-column prop="stage" :label="$t('common.colStage')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="output" :label="$t('common.colOutput')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="pass_oqc" :label="$t('dpmOptMod.colPassOQC')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="actual" :label="$t('dpmOptMod.colStock')" width="80" />
              <el-table-column prop="actual" :label="$t('common.colAct')" width="80" />
              <el-table-column prop="goal" :label="$t('common.colGoal')" width="80" />
              <el-table-column prop="reason_codes" :label="$t('dpmOptMod.colReaconCode')" width="120" show-overflow-tooltip />
              <el-table-column prop="owner_names" :label="$t('common.colDRI')" width="120" show-overflow-tooltip />
              <el-table-column prop="process_name" :label="$t('common.colStatus')" width="90" />
              <el-table-column prop="result" :label="$t('dpmOptMod.colResult')" width="90" />
              <el-table-column v-if="false" prop="row_id" />
              <el-table-column v-if="false" prop="index" />
            </el-table>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmOptMod.lblMyIssue')" name="myIssueTab">
          <div style="width: 1200px;height:450px">
            <el-table
              :data="tableDataMy"
              size="small"
              height="450"
              style="width: 100%;"
              @row-click="getIssueTrace"
            >
              <el-table-column v-if="showOptColumn" label="" width="70" fixed>
                <template slot-scope="scope">
                  <el-button v-if="checkOptButtonStatus(scope.row)" type="text" size="small" @click="showTrackingDialog(scope.row)">{{ $t('dpmOptMod.btnKeyin') }}</el-button>
                </template>
              </el-table-column>
              <el-table-column prop="start_time" :label="$t('dpmOptMod.colRangeStart')" width="100" />
              <el-table-column prop="end_time" :label="$t('dpmOptMod.colRangeEnd')" width="100" />
              <el-table-column prop="factory" :label="$t('common.colFactory')" width="70" />
              <el-table-column prop="area" :llabel="$t('common.colArea')" width="70" />
              <el-table-column prop="line" :label="$t('common.colLine')" width="80" />
              <el-table-column prop="stage" :label="$t('common.colStage')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="output" :label="$t('common.colOutput')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="pass_oqc" :label="$t('dpmOptMod.colPassOQC')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="actual" :label="$t('dpmOptMod.colStock')" width="80" />
              <el-table-column prop="actual" :label="$t('common.colAct')" width="80" />
              <el-table-column prop="goal" :label="$t('common.colGoal')" width="80" />
              <el-table-column prop="reason_codes" :label="$t('dpmOptMod.colReaconCode')" width="120" show-overflow-tooltip />
              <el-table-column prop="owner_names" :label="$t('common.colDRI')" width="120" show-overflow-tooltip />
              <el-table-column prop="process_name" :label="$t('common.colStatus')" width="90" />
              <el-table-column prop="result" :label="$t('dpmOptMod.colResult')" width="90" />
              <el-table-column v-if="false" prop="row_id" />
              <el-table-column v-if="false" prop="index" />
            </el-table>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmOptMod.lblMyIssueWaitForKeyin')" name="myIssueWaitTab">
          <div style="width: 1200px;height:450px">
            <el-table
              :data="tableDataMyWait"
              size="small"
              height="450"
              style="width: 100%;"
              @row-click="getIssueTrace"
            >
              <el-table-column v-if="showOptColumn" label="" width="70" fixed>
                <template slot-scope="scope">
                  <el-button type="text" size="small" @click="showTrackingDialog(scope.row)">{{ $t('dpmOptMod.btnKeyin') }}</el-button>
                </template>
              </el-table-column>
              <el-table-column prop="start_time" :label="$t('dpmOptMod.colRangeStart')" width="100" />
              <el-table-column prop="end_time" :label="$t('dpmOptMod.colRangeEnd')" width="100" />
              <el-table-column prop="factory" :label="$t('common.colFactory')" width="70" />
              <el-table-column prop="area" :llabel="$t('common.colArea')" width="70" />
              <el-table-column prop="line" :label="$t('common.colLine')" width="80" />
              <el-table-column prop="stage" :label="$t('common.colStage')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="output" :label="$t('common.colOutput')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="pass_oqc" :label="$t('dpmOptMod.colPassOQC')" width="80" />
              <el-table-column v-if="inputData.index==='UTS'" prop="actual" :label="$t('dpmOptMod.colStock')" width="80" />
              <el-table-column prop="actual" :label="$t('common.colAct')" width="80" />
              <el-table-column prop="goal" :label="$t('common.colGoal')" width="80" />
              <el-table-column prop="reason_codes" :label="$t('dpmOptMod.colReaconCode')" width="120" show-overflow-tooltip />
              <el-table-column prop="owner_names" :label="$t('common.colDRI')" width="120" show-overflow-tooltip />
              <el-table-column prop="process_name" :label="$t('common.colStatus')" width="90" />
              <el-table-column prop="result" :label="$t('dpmOptMod.colResult')" width="90" />
              <el-table-column v-if="false" prop="row_id" />
              <el-table-column v-if="false" prop="index" />
            </el-table>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="$t('dpmOptMod.lblChart')" name="hisChartTab">
          <div style="height:40px">
            <el-select v-model="queryRange" :placeholder="$t('dpmOptMod.phdSelectRange')" size="small" style="width:450px;margin-bottom:5px">
              <el-option :label="$t('dpmOptMod.rbShift')" value="shift" />
              <el-option :label="$t('dpmOptMod.rbToday')" value="day" />
              <el-option :label="$t('dpmOptMod.rbWeek')" value="week" />
              <el-option :label="$t('dpmOptMod.rbMonth')" value="month" />
            </el-select>
            <el-button size="small" plain type="primary" style="margin-left:5px;" @click="queryTrendChartData">{{ $t('common.btnQuery') }}</el-button>
          </div>
          <div id="elTrend" style="height:360px;width:950px" />
        </el-tab-pane>
      </el-tabs>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="closeChartDetailDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="$t('dpmOptMod.lblIssueDetail')"
      :close-on-press-escape="false"
      :visible.sync="detailRangeDailogVisible"
      width="1250px"
      :close-on-click-modal="false"
    >
      <div class="issueDetailMainDiv">
        <div style="width:400px;height:520px;flex:none">
          <div class="tableTitle">{{ $t('dpmOptMod.lblTimeRangeIssue') }}</div>
          <el-table
            ref="rangeTable"
            :data="tableDataIssueRangeDetail"
            size="small"
            height="500"
            highlight-current-row
            style="width: 100%;"
            @current-change="handleCurrentChange"
          >
            <el-table-column prop="start_time" :label="$t('common.colStart')" width="70" />
            <el-table-column prop="end_time" :label="$t('common.colEnd')" width="70" />
            <el-table-column prop="actual" :label="$t('common.colAct')" width="80" />
            <el-table-column prop="goal" :label="$t('common.colGoal')" width="80" />
            <el-table-column prop="loss" :label="$t('common.colLoss')" width="80" />
            <el-table-column v-if="false" prop="row_id" />
            <el-table-column v-if="false" prop="full_start_time" />
            <el-table-column v-if="false" prop="full_end_time" />
          </el-table>
        </div>
        <div style="height:520px;width:760px;margin-left:10px;flex:none">
          <div class="tableTitle">{{ $t('dpmOptMod.lblTitleLossReason') }}</div>
          <el-table
            :data="tableDataIssueAction"
            size="small"
            height="500"
            style="width: 100%;"
          >
            <el-table-column label="" width="90">
              <template slot-scope="scope">
                <el-button type="text" size="small" style="color:red" @click="removeReason(scope.$index)">{{ $t('common.btnDel') }}</el-button>
                <el-button v-if="scope.row.from_sys==='Y'" type="text" size="small" @click="showChooseSysDRI(scope.row)">{{ $t('dpmOptMod.btnDispatch') }}</el-button>
              </template>
            </el-table-column>
            <el-table-column prop="level1" label="Level 1" width="70" />
            <el-table-column prop="level2" label="Level 2" width="80" show-overflow-tooltip />
            <el-table-column prop="start_time" :label="$t('common.colStart')" width="70" />
            <el-table-column prop="end_time" :label="$t('common.colEnd')" width="70" />
            <el-table-column prop="loss" :label="$t('common.colLoss')" width="70" />
            <el-table-column prop="dri" :label="$t('common.colDRI')" width="90" />
            <el-table-column prop="dri_name" :label="$t('dpmOptMod.colName')" width="80" />
            <el-table-column prop="memo" :label="$t('common.colMemo')" width="100" show-overflow-tooltip />
            <el-table-column v-if="false" prop="from_sys" />
            <el-table-column v-if="false" prop="full_start_time" />
            <el-table-column v-if="false" prop="full_end_time" />
            <el-table-column v-if="false" prop="id" />
          </el-table>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" @click="showSetReasonCodeDialog">{{ $t('dpmOptMod.btnCreateIssue') }}</el-button>
        <el-button type="success" size="small" style="margin:0 20px" @click="saveReasonCode">{{ $t('dpmOptMod.btnSaveIssue') }}</el-button>
        <el-button size="small" @click="closeDetailRangeDailog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="$t('dpmOptMod.lblTitleIssueRate')"
      :close-on-press-escape="false"
      :visible.sync="issueChartDialogVisible"
      width="1000px"
      :close-on-click-modal="false"
    >
      <div id="elWaterFall" style="height:505px;width:900px;margin-left:10px;flex:none" />
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="closeIssueChartDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      title="設定問題原因和責任人"
      :close-on-press-escape="false"
      :visible.sync="setReasonCodeDialogVisible"
      width="1250px"
      :close-on-click-modal="false"
      size="small"
    >
      <div style="width:100%;text-align:center">
        <span style="margin-right:5px">{{ $t('dpmOptMod.lblIssueStart') }}</span>
        <el-tooltip class="item" effect="dark" :content="$t('dpmOptMod.lblContent1')" placement="top-end">
          <el-date-picker v-model="setReasonCodeForm.start_time" size="small" type="datetime" style="width:275px" />
        </el-tooltip>
        <span style="margin:0 5px">{{ $t('dpmOptMod.lblIssueEnd') }}</span>
        <el-tooltip class="item" effect="dark" :content="$t('dpmOptMod.lblContent2')" placement="top-end">
          <el-date-picker v-model="setReasonCodeForm.end_time" size="small" type="datetime" style="width:275px" />
        </el-tooltip>
        <span style="margin:0 5px">LOSS</span>
        <el-input v-model.number="setReasonCodeForm.loss" :placeholder="$t('dpmOptMod.phdLoss')" size="small" style="width:100px" />
      </div>
      <div class="typeContainer">
        <div v-for="(type,index) in reasonCodeList" :key="index" class="code codeSection">
          <span class="codeType">{{ type.type }}</span>
          <div class="tagStyle">
            <el-tag v-for="code in type.codes" :key="code.id" type="danger" style="cursor:pointer;font-size:14px;margin:5px" @click="reasoncodeSelected(type,code)">
              {{ code.reason_code }}
            </el-tag>
          </div>
        </div>
      </div>
      <div style="width:100%;text-align:center">
        <span style="margin-right:5px">{{ $t('dpmOptMod.lblChoosedReason') }}</span>
        <el-input v-model="selectReasonCodeString" :readonly="true" style="width:200px;" size="small" />
        <span style="margin:0 5px">{{ $t('dpmOptMod.lblDRI') }}</span>
        <el-input v-model="setReasonCodeForm.dri" :readonly="true" style="width:200px;" size="small">
          <el-button slot="append" icon="el-icon-search" @click="showKeyinOwnerDailog" />
        </el-input>
        <span style="margin:0 5px">{{ $t('dpmOptMod.lblDRIName') }}</span>
        <el-input v-model="setReasonCodeForm.dri_name" :readonly="true" style="width:150px;" size="small" />
      </div>
      <div style="width:100%;text-align:center">
        <el-input v-model="setReasonCodeForm.memo" maxlength="50" show-word-limit :placeholder="$t('dpmOptMod.phdMemoOption')" style="width:100%;margin-top:10px" size="small" />
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="saveSetReasonCodeData">{{ $t('common.btnSave') }}</el-button>
        <el-button size="small" @click="closeSetReasonCodeDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="$t('dpmOptMod.lblTitleChooseDRI')"
      :close-on-press-escape="false"
      :visible.sync="chooseDRIDialogVisible"
      width="500px"
      :close-on-click-modal="false"
    >
      <el-table
        :data="reasonCodeDRIs"
        size="small"
        height="400"
        style="width: 100%;"
      >
        <el-table-column :label="$t('common.colOpt')" width="80">
          <template slot-scope="scope">
            <el-button type="text" size="small" @click="chooseThisDRI(scope.row)">{{ $t('common.btnSelect') }}</el-button>
          </template>
        </el-table-column>
        <el-table-column prop="area" :label="$t('common.colArea')" width="90" />
        <el-table-column prop="line" :label="$t('common.colLine')" width="100" show-overflow-tooltip />
        <el-table-column prop="dri" :label="$t('common.colDRI')" width="90" />
        <el-table-column prop="dri_name" :label="$t('dpmOptMod.lblDRIName')" width="100" />
      </el-table>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="closeChooseDRIDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="$t('dpmOptMod.lblTitleDispatchDRI')"
      :close-on-press-escape="false"
      :visible.sync="dispatchOwnerDialogVisible"
      width="300px"
      :close-on-click-modal="false"
    >
      <el-input v-model="dispatchOwnerID" :placeholder="$t('dpmOptMod.phdKeyInEmpId')" size="small">
        <el-button slot="append" icon="el-icon-search" @click="checkEmployee" />
      </el-input>
      <span>{{ dispatchOwnerInfo }}</span>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="chooseThisDRIByEmpId">{{ $t('dpmOptMod.btnOK') }}</el-button>
        <el-button size="small" @click="closeDispatchOwnerDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="$t('dpmOptMod.lblTitleSystemCheck')"
      :close-on-press-escape="false"
      :visible.sync="dispatchSysDataOwnerDialogVisible"
      width="300px"
      :close-on-click-modal="false"
    >
      <el-input v-model="dispatchOwnerID" :placeholder="$t('dpmOptMod.phdKeyInEmpId')" size="small">
        <el-button slot="append" icon="el-icon-search" @click="checkEmployee" />
      </el-input>
      <span>{{ dispatchOwnerInfo }}</span>
      <el-input v-model="tempMemo" maxlength="50" show-word-limit :placeholder="$t('dpmOptMod.phdMemoOption')" style="width:100%;margin-top:10px" size="small" />
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="chooseThisSysDRIByEmpId">{{ $t('dpmOptMod.btnOK') }}</el-button>
        <el-button size="small" @click="closeDispatchSysOwnerDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="$t('dpmOptMod.lblOtherReason')"
      :close-on-press-escape="false"
      :visible.sync="otherReasonDialogVisible"
      width="300px"
      :close-on-click-modal="false"
    >
      <el-input v-model="keyInOtherReason" :placeholder="$t('dpmOptMod.phdKeyInOther')" size="small" />
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="setOtherReason">{{ $t('dpmOptMod.btnOK') }}</el-button>
        <el-button size="small" @click="closeOtherReasonDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="$t('dpmOptMod.lblKeyinSolution')"
      :close-on-press-escape="false"
      :visible.sync="solutionDialogVisible"
      width="560px"
      :close-on-click-modal="false"
    >
      <h2 style="margin-bottom:10px">{{ $t('dpmOptMod.lblReasonGroup') }}：{{ solutionDialogData.type }}</h2>
      <el-divider />
      <h2 style="margin-top:10px;margin-bottom:10px">{{ $t('dpmOptMod.lblLevel2') }}：{{ solutionDialogData.reason_code }}</h2>
      <h2 style="margin-top:10px;margin-bottom:10px">{{ $t('dpmOptMod.lblDesc') }}：{{ solutionDialogData.description }}</h2>
      <!-- <h2 style="margin-top:10px;margin-bottom:10px">一級代碼：{{solutionDialogData.level1_reasoncode}}</h2>
          <h3 style="margin-bottom:10px;margin-left:30px">{{solutionDialogData.level1_desc}}</h3>
          <h2 style="margin-bottom:10px;">二級代碼：{{solutionDialogData.level2_reasoncode}}</h2>
          <h3 style="margin-bottom:10px;margin-left:30px">{{solutionDialogData.level2_desc}}</h3> -->
      <el-divider />
      <el-input v-model="solutionContent" style="margin-top:10px" type="textarea" :rows="4" :placeholder="$t('dpmOptMod.phdKeyInSolution')" />
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="saveSolution">{{ $t('common.btnSave') }}</el-button>
        <el-button size="small" @click="closeSolutionDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="$t('dpmOptMod.lblTitleEval')"
      :close-on-press-escape="false"
      :visible.sync="evalDialogVisible"
      width="560px"
      :close-on-click-modal="false"
    >
      <el-carousel id="carousel1" indicator-position="outside" style="height:500px" :autoplay="false">
        <el-carousel-item v-for="(so, index) in solutionList" :key="index">
          <table class="tb">
            <tr>
              <td class="tbCategory">{{ $t('dpmOptMod.lblReasonGroup') }}</td><td class="tbValue">{{ so.type }}</td>
            </tr>
            <tr>
              <td class="tbCategory">{{ $t('dpmOptMod.lblLevel2') }}</td><td class="tbValue">{{ so.reason_code }}</td>
            </tr>
            <tr>
              <td class="tbCategory">{{ $t('dpmOptMod.lblDesc') }}</td><td class="tbValue">{{ so.description }}</td>
            </tr>
            <tr>
              <td class="tbCategory">{{ $t('dpmOptMod.lblKeyInUser') }}</td><td class="tbValue">[{{ so.dri }}]{{ so.dri_name }}</td>
            </tr>
          </table>
          <el-input v-model="so.solution" type="textarea" :rows="4" :readonly="true" />
          <div style="width:100%;text-align:center;margin-top:10px">
            <el-radio v-model="so.result" label="OK">{{ $t('dpmOptMod.rbGood') }}</el-radio>
            <el-radio v-model="so.result" label="NG">{{ $t('dpmOptMod.rbNG') }}</el-radio>
            <el-input v-model="so.memo" type="textarea" :rows="2" :placeholder="$t('dpmOptMod.phdMemoOption')" />
            <el-button size="small" type="primary" :disabled="so.disable" style="width:300px;margin-top:10px" @click="saveEvalResult(so)">{{ $t('common.btnSave') }}</el-button>
          </div>
        </el-carousel-item>
      </el-carousel>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="closeEvalSolutionDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :center="true"
      :title="$t('dpmOptMod.lblTitleDetail')"
      :close-on-press-escape="false"
      :visible.sync="detailDialogVisible"
      width="850px"
      :close-on-click-modal="false"
    >
      <table class="tb">
        <tr>
          <td class="tbCategory">{{ $t('dpmOptMod.lblOccTime') }}</td><td class="tbValue">{{ issueDetail.calc_time }}</td>
          <td class="tbCategory">{{ $t('dpmOptMod.lblDealResult') }}</td><td class="tbValue">{{ issueDetail.result }}</td>
        </tr>
      </table>
      <h3 v-if="issueDetail.solutions.length===0" style="color:red;margin-top:5px">{{ $t('dpmOptMod.lblNoSultuion') }}</h3>
      <div class="detailIssueDiv">
        <table v-for="(so, index) in issueDetail.solutions" :key="index" class="tb">
          <tr>
            <td class="tbCategory">{{ $t('dpmOptMod.lblReasonGroup') }}</td><td class="tbValue" colspan="3">{{ so.type }}</td>
          </tr>
          <tr>
            <td class="tbCategory">{{ $t('dpmOptMod.lblLevel2') }}</td><td class="tbValue">{{ so.reason_code }}</td>
            <td class="tbCategory">{{ $t('dpmOptMod.lblDesc') }}</td><td class="tbValue">{{ so.description }}</td>
          </tr>
          <tr>
            <td class="tbCategory">{{ $t('dpmOptMod.lblKeyInUser') }}</td><td class="tbValue">[{{ so.dri }}]{{ so.dri_name }}</td>
            <td class="tbCategory">{{ $t('dpmOptMod.lblKeyInTime') }}</td><td class="tbValue">{{ so.update_time }}</td>
          </tr>
          <tr>
            <td class="tbCategory">{{ $t('dpmOptMod.lblSolution') }}</td><td class="tbValue" colspan="3">{{ so.solution }}</td>
          </tr>
          <tr>
            <td class="tbCategory">{{ $t('dpmOptMod.colResult') }}</td><td class="tbValue">{{ so.check_result }}</td>
            <td class="tbCategory">{{ $t('dpmOptMod.lblEvalTime') }}</td><td class="tbValue">{{ so.check_time }}</td>
          </tr>
          <tr>
            <td class="tbCategory">{{ $t('common.colMemo') }}</td><td class="tbValue" colspan="3">{{ so.memo }}</td>
          </tr>
        </table>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="closeDetailDialog">{{ $t('common.btnClose') }}</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import {
  GetDashboardTrendChartData, GetDashboardIssueList, GetEmpInfo,
  GetIssueTrackingTrace, GetErrorCodeList, SaveIssueSolution, SaveEvalSolution, GetDPMReasonCodeDRI,
  GetReasonCodeDescription, GetSolutionList, GetIssueDetailData, GetDPMReasonCode, GetDPMRangeIssueData,
  GetReasonFromSystem, SaveIssueTrackingDRIByReasonCode, GetDPMStatisticChartData
} from '@/api/midway.js'
// import { GetDateTimeString } from '@/assets/js/utils.js'
export default {
  // eslint-disable-next-line vue/require-prop-types
  props: ['onedata'],
  data() {
    return {
      parentRow: null,
      loadingSub: false,
      inputData: this.onedata,
      filterMode: 0,
      showProcessColumn: true,
      showResultColumn: true,
      showOptColumn: false,
      viewRange: 'currentshift',
      selectedCode: [],
      loadingData: null,
      level: 'line',
      loading: false,
      dispatchOwnerDialogVisible: false,
      dispatchSysDataOwnerDialogVisible: false,
      tempMemo: '',
      dispatchOwnerID: '',
      dispatchOwnerInfo: '',
      solutionDialogData: {
        type: '',
        reason_code: '',
        description: ''
        // level1_reasoncode: '',
        // level1_desc: '',
        // level2_reasoncode: '',
        // level2_desc: ''
      },
      solutionList: [],
      errorCodeList: [],
      selectedErrorCode: '',
      evalDialogVisible: false,
      evalSolution: 'OK',
      currentRow: null,
      activeDetailTabName: 'statusDetailTab',
      chartDetailDialogTitle: '',
      chartDetailDialogVisible: false,
      tableData: [],
      tableDataDispatch: [],
      tableDataEval: [],
      tableDataClose: [],
      tableDataMy: [],
      tableDataMyWait: [],
      tableDataIssueRangeDetail: [],
      tableDataIssueAction: [],
      optTrace: [],
      solutionDialogVisible: false,
      solutionContent: '',
      queryRange: '',
      trendChart: null,
      waterFallChart: null,
      setReasonCodeDialogVisible: false,
      level1ReasonCodes: [],
      level2ReasonCodes: [],
      setReasonCodeForm: {
        type: '',
        reason_code: '',
        id: '',
        loss: 0,
        dri: '',
        dir_name: '',
        start_time: '',
        end_time: '',
        memo: ''
      },
      reasonCodeDRIs: [],
      selectedReasonCodes: [],
      chooseDRIDialogVisible: false,
      detailDialogVisible: false,
      issueDetail: {
        calc_time: '',
        result: '',
        solutions: []
      },
      selectReasonCodeString: '',
      detailRangeDailogVisible: false,
      issueChartDialogVisible: false,
      otherReasonDialogVisible: false,
      keyInOtherReason: '',
      reasonCodeList: []
    }
  },
  computed: {
  },
  mounted() {
    this.showdg()
  },
  methods: {
    showdg: function() {
      this.chartDetailDialogTitle = this.inputData.keyword + ' ' + this.inputData.index + ' ' + this.$t('dpmOptMod.lblDetailMsg')
      this.chartDetailDialogVisible = true
      this.$nextTick(() => {
        this.showChart()
      })
      this.getIssueList()
    },
    tabClick() {
      switch (this.activeDetailTabName) {
        case 'statusDetailTab':
          this.filterMode = 0
          break
        case 'waitForDispatchTab':
          this.filterMode = 1
          break
        case 'waitForEvalTab':
          this.filterMode = 2
          break
        case 'waitForCloseTab':
          this.filterMode = 3
          break
        case 'myIssueTab':
          this.filterMode = 4
          break
        case 'myIssueWaitTab':
          this.filterMode = 5
          break
      }
      this.getIssueList()
    },
    async getIssueList() {
      let mode = 'all'
      this.showProcessColumn = true
      this.showResultColumn = true
      switch (this.filterMode) {
        case 0:
          mode = 'all'
          this.showOptColumn = true
          break
        case 1:
          mode = 'waitfordispatch'
          this.showOptColumn = true
          this.showProcessColumn = false
          this.showResultColumn = false
          break
        case 2:
          mode = 'waitforcheck'
          this.showOptColumn = true
          this.showResultColumn = false
          break
        case 3:
          mode = 'closed'
          this.showProcessColumn = false
          this.showOptColumn = false
          break
        case 4:
          mode = 'tomeall'
          this.showOptColumn = true
          break
        case 5:
          mode = 'tome'
          this.showOptColumn = true
          this.showProcessColumn = false
          this.showResultColumn = false
          break
      }
      const data = {
        level: this.inputData.level,
        index: this.inputData.index,
        id: this.inputData.id,
        viewrange: this.inputData.viewrange,
        filtermode: mode
      }
      this.tableData = []
      this.loading = true
      const response = await GetDashboardIssueList(data)
      const queryResult = response.data.QueryResult
      this.loading = false
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        switch (this.filterMode) {
          case 0:
            this.tableData = obj
            break
          case 1:
            this.tableDataDispatch = obj
            break
          case 2:
            this.tableDataEval = obj
            break
          case 3:
            this.tableDataClose = obj
            break
          case 4:
            this.tableDataMy = obj
            break
          case 5:
            this.tableDataMyWait = obj
            break
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    checkOptButtonStatus(row) {
      if (this.filterMode === 3) {
        return false
      } else if (this.filterMode === 4) {
        return row.result === '' && row.process_name === '待填寫'
      } else if (this.filterMode === 5 || this.filterMode === 2 || this.filterMode === 1 || this.filterMode === 0) {
        return true
      }
    },
    async getIssueTrace(row) {
      const data = {
        rowId: row.row_id,
        index: row.index
      }
      this.optTrace = []
      const response = await GetIssueTrackingTrace(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.optTrace = obj
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeChartDetailDialog() {
      this.chartDetailDialogVisible = false
      this.$emit('closedg')
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    showDetailDataForEachRange(row) {
      this.getRangeDetailData(row)
      this.detailRangeDailogVisible = true
    },
    async getRangeDetailData(row) {
      this.parentRow = row
      const data = {
        pid: row.row_id,
        index: row.index
      }
      const response = await GetDPMRangeIssueData(data)
      this.tableDataIssueRangeDetail = []
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.tableDataIssueRangeDetail = obj
        if (this.detailRangeDailogVisible === true && this.tableDataIssueRangeDetail.length === 0) {
          this.closeDetailRangeDailog()
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeDetailRangeDailog() {
      this.currentRow = null
      this.tableDataIssueRangeDetail = []
      this.tableDataIssueAction = []
      this.getIssueList()
      this.detailRangeDailogVisible = false
    },
    async GetReasonCodes() {
      const data = {
        level: this.inputData.level,
        id: this.inputData.id
      }
      const response = await GetDPMReasonCode(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.reasonCodeList = obj
      } else {
        this.alertMsg(queryResult)
      }
    },
    handleCurrentChange(current, oldCurrent) {
      if (this.currentRow !== null && this.currentRow !== current) {
        if (this.tableDataIssueAction.length > 0) {
          if (!confirm(this.$t('dpmOptMod.altConfirmSwitch'))) {
            this.$refs.rangeTable.setCurrentRow(oldCurrent)
            this.currentRow = oldCurrent
          } else {
            this.tableDataIssueAction = []
            this.getSysReasonData(current)
          }
        } else {
          this.tableDataIssueAction = []
          this.getSysReasonData(current)
        }
      } else {
        this.getSysReasonData(current)
      }
    },
    async getSysReasonData(row) {
      if (row !== this.currentRow && row !== null) {
        this.currentRow = row
        const data = {
          factory: row.factory,
          begin: row.full_start_time,
          end: row.full_end_time,
          line: row.line,
          area: row.area
        }
        const response = await GetReasonFromSystem(data)
        const queryResult = response.data.QueryResult
        if (queryResult === 'OK') {
          const obj = response.data.ReturnObject
          this.tableDataIssueAction = obj
        } else {
          this.alertMsg(queryResult)
        }
      }
    },
    showTrackingDialog(row) {
      this.currentRow = row
      if (this.filterMode === 0) {
        this.showDetailDialog(row)
      } else {
        if (row.process_name === '待分配') {
          this.showSetReasonCodeDialog(row)
        } else if (row.process_name === '待填寫') {
          this.showKeyinSolutionDailog(row)
        } else if (row.process_name === '待評判') {
          this.showKeyinEvalDialog()
        }
      }
    },
    async showDetailDialog(row) {
      const data = {
        rowId: row.row_id,
        index: row.index
      }
      const response = await GetIssueDetailData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.issueDetail = obj
        this.detailDialogVisible = true
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeDetailDialog() {
      this.detailDialogVisible = false
    },
    showKeyinOwnerDailog() {
      this.dispatchOwnerInfo = ''
      this.dispatchOwnerID = ''
      this.dispatchOwnerDialogVisible = true
    },
    closeDispatchOwnerDialog() {
      this.dispatchOwnerInfo = ''
      this.dispatchOwnerID = ''
      this.dispatchOwnerDialogVisible = false
    },
    async checkEmployee() {
      this.dispatchOwnerInfo = ''
      if (this.dispatchOwnerID === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgEmpIdEmpty'))
        return
      }
      const data = {
        employeeId: this.dispatchOwnerID
      }
      const response = await GetEmpInfo(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.dispatchOwnerInfo = obj.name
      } else {
        this.alertMsg(queryResult)
      }
    },
    showChooseSysDRI(row) {
      this.dispatchOwnerID = row.dri
      this.dispatchOwnerInfo = row.dri_name
      this.tempMemo = row.memo
      this.dispatchSysDataOwnerDialogVisible = true
    },
    closeDispatchSysOwnerDialog() {
      this.dispatchOwnerInfo = ''
      this.dispatchOwnerID = ''
      this.tempMemo = ''
      this.dispatchSysDataOwnerDialogVisible = false
    },
    chooseThisSysDRIByEmpId(row) {
      if (this.dispatchOwnerID === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgDRIEmpty'))
        return
      }
      if (this.dispatchOwnerInfo === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgDRIConfirm'))
        return
      }
      if (!confirm(
        this.$utils.ReplacePlaceHolder(
          this.$t('dpmOptMod.altMsgConfirmDRI'),
          [this.dispatchOwnerInfo])
      )) {
        return
      }
      row.dri = this.dispatchOwnerID
      row.dri_name = this.dispatchOwnerInfo
      row.memo = this.tempMemo
      this.closeDispatchSysOwnerDialog()
    },
    removeReason(index) {
      if (!confirm(this.$t('dpmOptMod.altMsgConfirmRemove'))) {
        return
      }
      this.tableDataIssueAction.splice(index, 1)
    },
    async showKeyinSolutionDailog(row) {
      this.solutionContent = ''
      const data = {
        rowId: row.row_id,
        index: row.index
      }
      const response = await GetReasonCodeDescription(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.solutionDialogData = response.data.ReturnObject
        this.solutionDialogVisible = true
      } else {
        this.alertMsg(queryResult)
      }
    },
    async GetErrorCodeList() {
      const response = await GetErrorCodeList()
      const queryResult = response.data.QueryResult
      this.loading = false
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.errorCodeList = obj
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeSolutionDialog() {
      this.selectedErrorCode = ''
      this.solutionContent = ''
      this.solutionDialogVisible = false
    },
    async saveSolution() {
      if (this.solutionContent === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgSolutionEmpty'))
        return
      }
      if (!confirm(this.$t('dpmOptMod.altMsgConfirmSubmitSolution'))) {
        return
      }
      const data = {
        rowId: this.currentRow.row_id,
        index: this.currentRow.index,
        solution: this.solutionContent,
        reasoncode: this.currentRow.reason_codes
      }
      const response = await SaveIssueSolution(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.getIssueList()
        this.closeSolutionDialog()
      } else {
        this.alertMsg(queryResult)
      }
    },
    async showKeyinEvalDialog(id) {
      this.evalSolution = 'OK'
      const data = {
        rowId: this.currentRow.row_id,
        index: this.currentRow.index
      }
      const response = await GetSolutionList(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.solutionList = response.data.ReturnObject
        this.evalDialogVisible = true
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeEvalSolutionDialog() {
      this.evalSolution = 'OK'
      this.evalDialogVisible = false
    },
    async saveEvalResult(so) {
      if (so.result === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgEvalEmpty'))
        return
      }
      if (!confirm(this.$t('common.altMsgConfirmSubmit'))) {
        return
      }
      const data = {
        rowId: this.currentRow.row_id,
        index: this.currentRow.index,
        reasoncode: so.reason_code,
        result: so.result,
        memo: so.memo
      }
      const response = await SaveEvalSolution(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        if (this.solutionList.length === 1) {
          this.getIssueList()
          this.closeEvalSolutionDialog()
        } else {
          for (let i = this.solutionList.length - 1; i >= 0; i--) {
            if (this.solutionList[i].level2_reasoncode === so.level2_reasoncode) {
              this.solutionList.splice(i, 1)
            }
          }
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    async queryTrendChartData() {
      if (this.queryRange === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgRangeEmpty'))
        return
      }
      const data = {
        index: this.inputData.index,
        level: this.inputData.level,
        id: this.inputData.id,
        range: this.queryRange,
        viewrange: this.inputData.viewrange
      }
      this.trendChart = null
      const response = await GetDashboardTrendChartData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        const series = []
        obj.series.forEach(s => {
          series.push({
            name: s.name,
            type: s.type,
            data: s.data
          })
        })
        var chartDom = document.getElementById('elTrend')
        this.trendChart = this.$echarts.init(chartDom)
        this.trendChart.clear()
        var option
        option = {
          title: {
            text: this.inputData.index + this.$t('dpmOptMod.lblChart'),
            subtext: ''
          },
          tooltip: {
            trigger: 'axis'
          },
          toolbox: {
            feature: {
              dataView: { show: true, readOnly: false },
              saveAsImage: {}
            }
          },
          legend: {
            data: obj.legendData
          },
          xAxis: {
            type: 'category',
            data: obj.xAxisData
          },
          yAxis: {
            type: 'value'
          },
          series: series
        }
        this.trendChart.setOption(option)
      } else {
        this.alertMsg(queryResult)
      }
    },
    showChart: function() {
      if (this.trendChart !== null) {
        this.trendChart.dispose()
      }
      var chartDom = document.getElementById('elTrend')
      this.trendChart = this.$echarts.init(chartDom)
      this.trendChart.clear()
      var option
      option = {
        title: {
          text: '',
          subtext: ''
        },
        tooltip: {
          trigger: 'axis'
        },
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: {}
          }
        },
        legend: {
          data: ['']
        },
        xAxis: {
          type: 'category',
          data: []
        },
        yAxis: {
          type: 'value'
        },
        series: []
      }
      this.trendChart.setOption(option)
    },
    showSetReasonCodeDialog() {
      if (this.currentRow === null) {
        this.alertMsg(this.$t('dpmOptMod.altMsgSelectLeftRow'))
        return
      }
      this.clearReasonCodeDialogFormData()
      this.GetReasonCodes()
      this.setReasonCodeForm.start_time = new Date(this.currentRow.full_start_time)
      this.setReasonCodeForm.end_time = new Date(this.currentRow.full_end_time)
      this.setReasonCodeForm.loss = this.currentRow.loss
      this.setReasonCodeDialogVisible = true
    },
    reasoncodeSelected(type, code) {
      if (type.type !== '其他') {
        this.setReasonCodeForm.type = type.type
        this.setReasonCodeForm.reason_code = code.reason_code
        this.setReasonCodeForm.id = code.id
        this.selectReasonCodeString = '[' + this.setReasonCodeForm.type + ']' + this.setReasonCodeForm.reason_code
        this.getDRIList(code.id)
      } else {
        this.showAddOtherReasonDialog()
      }
    },
    async getDRIList(key) {
      this.setReasonCodeForm.dri = ''
      this.setReasonCodeForm.dri_name = ''
      const data = {
        level: this.inputData.level,
        id: this.inputData.id,
        reasoncodeid: key
      }
      this.reasonCodeDRIs = []
      const response = await GetDPMReasonCodeDRI(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.reasonCodeDRIs = response.data.ReturnObject
        if (this.reasonCodeDRIs.length === 1) {
          this.setReasonCodeForm.dri = this.reasonCodeDRIs[0].dri
          this.setReasonCodeForm.dri_name = this.reasonCodeDRIs[0].dri_name
        } else if (this.reasonCodeDRIs.length === 0) {
          this.alertMsg(this.$t('dpmOptMod.altMsgNoDRIFound'))
        } else if (this.reasonCodeDRIs.length > 1) {
          this.chooseDRIDialogVisible = true
        }
      } else {
        this.alertMsg(queryResult)
      }
    },
    chooseThisDRI(row) {
      this.setReasonCodeForm.dri = row.dri
      this.setReasonCodeForm.dri_name = row.dri_name
      this.closeChooseDRIDialog()
    },
    chooseThisDRIByEmpId() {
      if (this.dispatchOwnerID === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgDRIEmpty'))
        return
      }
      if (this.dispatchOwnerInfo === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgDRIConfirm'))
        return
      }
      if (!confirm(
        this.$utils.ReplacePlaceHolder(
          this.$t('dpmOptMod.altMsgConfirmDRI'),
          [this.dispatchOwnerInfo])
      )) {
        return
      }
      this.setReasonCodeForm.dri = this.dispatchOwnerID
      this.setReasonCodeForm.dri_name = this.dispatchOwnerInfo
      this.closeDispatchOwnerDialog()
    },
    closeChooseDRIDialog() {
      this.chooseDRIDialogVisible = false
    },
    showAddOtherReasonDialog() {
      this.keyInOtherReason = ''
      this.otherReasonDialogVisible = true
    },
    closeOtherReasonDialog() {
      this.otherReasonDialogVisible = false
    },
    setOtherReason() {
      if (this.keyInOtherReason === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgOtherReasonEmpty'))
        return
      }
      this.setReasonCodeForm.type = '其他'
      this.setReasonCodeForm.reason_code = this.keyInOtherReason
      this.setReasonCodeForm.id = '0'
      this.selectReasonCodeString = '[' + this.setReasonCodeForm.type + ']' + this.setReasonCodeForm.reason_code
      this.closeOtherReasonDialog()
    },
    addThisReason() {
      if (this.setReasonCodeForm.start_time === null) {
        this.setReasonCodeForm.start_time = new Date(this.currentRow.full_start_time)
      }
      if (this.setReasonCodeForm.end_time === null) {
        this.setReasonCodeForm.end_time = new Date(this.currentRow.full_end_time)
      }
      if (this.setReasonCodeForm.start_time >= this.setReasonCodeForm.end_time) {
        this.alertMsg(this.$t('dpmOptMod.altMsgEndTimeError'))
        return
      }
      if (this.setReasonCodeForm.start_time < new Date(this.currentRow.full_start_time)) {
        this.alertMsg(this.$t('dpmOptMod.altMsgStartTimeError'))
        return
      }
      if (this.setReasonCodeForm.end_time > new Date(this.currentRow.full_end_time)) {
        this.alertMsg(this.$t('dpmOptMod.altMsgEndTimeError2'))
        return
      }
      this.$refs.fromReasonCode.validate(async(valid) => {
        if (valid) {
          if (this.selectedReasonCodes.filter(x => x.level2_code === this.setReasonCodeForm.level2_reasoncode).length > 0) {
            this.alertMsg(this.$t('dpmOptMod.altMsgLevel2Exist'))
          } else {
            this.selectedReasonCodes.push({
              level1_code: this.setReasonCodeForm.level1_reasoncode,
              level1_description: this.setReasonCodeForm.level1_description,
              level2_code: this.setReasonCodeForm.level2_reasoncode,
              level2_description: this.setReasonCodeForm.level2_description,
              dri: this.setReasonCodeForm.dri,
              dri_name: this.setReasonCodeForm.dri_name,
              start_time: this.$utils.GetDateTimeString(this.setReasonCodeForm.start_time),
              end_time: this.$utils.GetDateTimeString(this.setReasonCodeForm.end_time)
            })
          }
        } else {
          console.log('')
        }
      })
    },
    clearReasonCodeDialogFormData() {
      this.setReasonCodeForm.type = ''
      this.setReasonCodeForm.reason_code = ''
      this.setReasonCodeForm.id = ''
      this.setReasonCodeForm.loss = 0
      this.setReasonCodeForm.dri = ''
      this.setReasonCodeForm.dir_name = ''
      this.setReasonCodeForm.start_time = ''
      this.setReasonCodeForm.end_time = ''
      this.setReasonCodeForm.memo = ''
    },
    closeSetReasonCodeDialog() {
      this.clearReasonCodeDialogFormData()
      this.setReasonCodeDialogVisible = false
    },
    removeReasonCode(index, row) {
      this.selectedReasonCodes.splice(index, 1)
    },
    saveSetReasonCodeData() {
      if (this.setReasonCodeForm.id === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgReasonCodeEmpty'))
        return
      }
      if (this.dri === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgDRINotSet'))
        return
      }
      if (this.setReasonCodeForm.start_time === null || this.setReasonCodeForm.start_time === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgStartTimeEmpty'))
        return
      }
      if (this.setReasonCodeForm.end_time === null || this.setReasonCodeForm.end_time === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgEndTimeEmpty'))
        return
      }
      if (this.setReasonCodeForm.start_time > this.setReasonCodeForm.end_time) {
        this.alertMsg(this.$t('dpmOptMod.altMsgEndTimeError'))
        return
      }
      if (this.setReasonCodeForm.loss === null || this.setReasonCodeForm.loss === undefined || this.setReasonCodeForm.loss === '') {
        this.alertMsg(this.$t('dpmOptMod.altMsgLossEmpty'))
        return
      }
      if (isNaN(this.setReasonCodeForm.loss)) {
        this.alertMsg(this.$t('dpmOptMod.altMsgLossNotNumber'))
        return
      }
      if (this.setReasonCodeForm.loss <= 0) {
        this.alertMsg(this.$t('dpmOptMod.altMsgLossLargeThenZero'))
        return
      }
      const st = this.$utils.GetDateTimeString(this.setReasonCodeForm.start_time)
      const et = this.$utils.GetDateTimeString(this.setReasonCodeForm.end_time)
      this.tableDataIssueAction.push({
        level1: this.setReasonCodeForm.type,
        level2: this.setReasonCodeForm.reason_code,
        start_time: st.substr(11, 5),
        end_time: et.substr(11, 5),
        loss: this.setReasonCodeForm.loss,
        from_sys: 'N',
        full_start_time: st,
        full_end_time: et,
        dri: this.setReasonCodeForm.dri,
        dri_name: this.setReasonCodeForm.dri_name,
        id: this.setReasonCodeForm.id,
        memo: this.setReasonCodeForm.memo
      })
      this.closeSetReasonCodeDialog()
    },
    async saveReasonCode() {
      if (this.currentRow === null) {
        this.alertMsg(this.$t('dpmOptMod.altMsgSelectOneRow'))
        return
      }
      if (this.tableDataIssueAction.length === 0) {
        this.alertMsg(this.$t('dpmOptMod.altMsgReasonCodeEmpty'))
        return
      }
      if (!confirm(this.$t('common.altMsgConfirmSubmit'))) {
        return
      }
      let totalLoss = 0
      let ownerStr = ''
      this.tableDataIssueAction.forEach(x => {
        ownerStr = ownerStr + x.level1 + ',' + x.level2 + ',' + x.dri + ',' + x.full_start_time + ',' + x.full_end_time + ',' + x.loss + ',' + x.memo + ';'
        totalLoss = totalLoss + x.loss
      })
      if (totalLoss > this.currentRow.loss) {
        this.alertMsg(this.$t('dpmOptMod.altMsgLossCheck'))
        return
      }
      ownerStr = ownerStr.substr(0, ownerStr.length - 1)
      const data = {
        prowId: this.currentRow.p_row_id,
        rowId: this.currentRow.row_id,
        index: this.currentRow.index,
        owner: ownerStr
      }
      this.loadingData = this.$loading({
        lock: true,
        text: this.$t('common.altMsgLoadingSubmit'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const response = await SaveIssueTrackingDRIByReasonCode(data)
      this.loadingData.close()
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        this.$alert(this.$t('common.altMsgOptSuccess'), this.$t('common.altMsgTitle'), {
          confirmButtonText: this.$t('common.altMsgBtn'),
          type: 'success'
        })
        this.tableDataIssueAction = []
        this.getRangeDetailData(this.parentRow)
      } else {
        this.alertMsg(queryResult)
      }
    },
    async showIssueChartDialog(row) {
      this.issueChartDialogVisible = true
      if (this.waterFallChart !== null) {
        this.waterFallChart.dispose()
      }
      const data = {
        rowId: row.row_id
      }
      const response = await GetDPMStatisticChartData(data)
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        const series = []
        obj.series.forEach(s => {
          series.push({
            name: s.name,
            type: s.type,
            data: s.data,
            label: s.label,
            itemStyle: s.itemStyle,
            emphasis: s.emphasis,
            stack: 'Total'
          })
        })
        var chartDom = document.getElementById('elWaterFall')
        this.waterFallChart = this.$echarts.init(chartDom)
        this.waterFallChart.clear()
        var option
        option = {
          tooltip: {
            trigger: 'axis',
            formatter: function(params) {
              var tar = params[1]
              return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value
            }
          },
          toolbox: {
            feature: {
              dataView: { show: true, readOnly: false },
              saveAsImage: {}
            }
          },
          xAxis: {
            type: 'category',
            data: obj.xAxis
          },
          yAxis: {
            type: 'value'
          },
          series: series
        }
        this.waterFallChart.setOption(option)
      } else {
        this.alertMsg(queryResult)
      }
    },
    closeIssueChartDialog() {
      this.issueChartDialogVisible = false
    },
    showWFChart: function() {
      if (this.waterFallChart !== null) {
        this.waterFallChart.dispose()
      }
      var chartDom = document.getElementById('elWaterFall')
      this.waterFallChart = this.$echarts.init(chartDom)
      this.waterFallChart.clear()
      var option
      option = {
        title: {
          text: this.$t('dpmOptMod.lblChartReason'),
          subtext: ''
        },
        tooltip: {
          trigger: 'axis'
        },
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: {}
          }
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          splitLine: { show: false },
          data: []
        },
        yAxis: {
          type: 'value'
        },
        series: [{
          name: 'Placeholder',
          type: 'bar',
          stack: 'Total',
          itemStyle: {
            borderColor: 'transparent',
            color: 'transparent'
          },
          emphasis: {
            itemStyle: {
              borderColor: 'transparent',
              color: 'transparent'
            }
          },
          data: []
        },
        {
          name: '問題Loss數量',
          type: 'bar',
          stack: 'Total',
          label: {
            show: true,
            position: 'inside'
          },
          data: []
        }
        ]
      }
      this.waterFallChart.setOption(option)
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep main.el-main{
  padding: 0
}
// ::v-deep .el-divider--horizontal{
//   margin:0
// }
section{
  padding-bottom: 0;
}
.el-header{
    padding:0 5px
}
.header{
  height:50px !important;
  // background-color:#1f4e7c;
  background-color:rgba(0,0,0,0);
}
.tb{
    margin:0 auto;font-size:14px;border:1px solid #cccccc;border-collapse:collapse;margin-bottom:10px;
}
.tbCategory{
    width:120px;
    height:30px;
    font-size:12px;
    text-align: center;
    background-color:#f4f4f4;
    border-bottom:1px solid #cccccc;
    border-right:1px solid #cccccc;
}
.tbValue{
    width:330px;
    height:30px;
    font-size:12px;
    text-align: center;
    border-bottom:1px solid #cccccc;
    border-right:1px solid #cccccc;
}
.detailIssueDiv{
  overflow-y: auto;
  width:800px;
  height:500px;
}
.issueDetailMainDiv{
  display: flex;
  width:100%;
  height: 520px;
}
.typeContainer{
  display: flex;
  flex-wrap: wrap;
  width: 100%;
  margin:30px auto;
  justify-content: center;
}
.tableTitle{
  background-color: rgb(51,85,161);
  color:white;
  text-align: center;
}
.codeType{
  display: block;
  width:100%;
  color:white;
  background-color: rgb(51,85,161);
  height: 30px;
  padding-top:5px;
  font-size: 20px;
}
.code{
    flex:none;
    margin-right:10px;
    width:190px;
    height:130px;
    box-shadow: 0 0 10px rgb(205,205,205);
    margin-bottom: 10px;
}
.codeSection{
  width:190px;
  border:1px solid  rgb(51,85,161);
  text-align: center;
  color:rgb(51,85,161);
}
.tagStyle{
  width:190px;
  height: 100px;
  text-align: center;
  display: table-cell;
  vertical-align: middle;
}
</style>
