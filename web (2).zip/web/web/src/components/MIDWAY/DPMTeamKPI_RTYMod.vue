<template>
  <div id="containerDivRTY" style="height:100%;width:100%;">
    <div id="elChartRTY" class="chartDiv" />
    <div id="tableDetailContainerRTY" class="detailDiv">
      <el-table
        v-loading="loading"
        :data="tableData"
        :height="180"
        size="mini"
        style="width: 100%"
        :header-cell-style="getHeaderCellColor"
      >
        <el-table-column prop="type" label="" width="110" align="center" fixed show-overflow-tooltip />
        <el-table-column prop="mtd" label="MTD" width="100" align="center" fixed />
        <el-table-column prop="01" label="01" width="100" align="center" />
        <el-table-column prop="02" label="02" width="100" align="center" />
        <el-table-column prop="03" label="03" width="100" align="center" />
        <el-table-column prop="04" label="04" width="100" align="center" />
        <el-table-column prop="05" label="05" width="100" align="center" />
        <el-table-column prop="06" label="06" width="100" align="center" />
        <el-table-column prop="07" label="07" width="100" align="center" />
        <el-table-column prop="08" label="08" width="100" align="center" />
        <el-table-column prop="09" label="09" width="100" align="center" />
        <el-table-column prop="10" label="10" width="100" align="center" />
        <el-table-column prop="11" label="11" width="100" align="center" />
        <el-table-column prop="12" label="12" width="100" align="center" />
        <el-table-column prop="13" label="13" width="100" align="center" />
        <el-table-column prop="14" label="14" width="100" align="center" />
        <el-table-column prop="15" label="15" width="100" align="center" />
        <el-table-column prop="16" label="16" width="100" align="center" />
        <el-table-column prop="17" label="17" width="100" align="center" />
        <el-table-column prop="18" label="18" width="100" align="center" />
        <el-table-column prop="19" label="19" width="100" align="center" />
        <el-table-column prop="20" label="20" width="100" align="center" />
        <el-table-column prop="21" label="21" width="100" align="center" />
        <el-table-column prop="22" label="22" width="100" align="center" />
        <el-table-column prop="23" label="23" width="100" align="center" />
        <el-table-column prop="24" label="24" width="100" align="center" />
        <el-table-column prop="25" label="25" width="100" align="center" />
        <el-table-column prop="26" label="26" width="100" align="center" />
        <el-table-column prop="27" label="27" width="100" align="center" />
        <el-table-column prop="28" label="28" width="100" align="center" />
        <el-table-column prop="29" label="29" width="100" align="center" />
        <el-table-column prop="30" label="30" width="100" align="center" />
        <el-table-column prop="31" label="31" width="100" align="center" />
      </el-table>
    </div>
    <div id="tableLinelContainer" class="lineDiv">
      <el-table
        v-loading="loading"
        :data="tableLineData"
        :height="270"
        size="mini"
        style="width: 100%"
        :header-cell-style="getHeaderCellColor"
      >
        <el-table-column prop="line" :label="$t('common.colLine') + '[%]'" width="110" align="center" fixed show-overflow-tooltip />
        <el-table-column prop="mtd" label="MTD" width="100" align="center" fixed />
        <el-table-column prop="01" label="01" width="100" align="center" />
        <el-table-column prop="02" label="02" width="100" align="center" />
        <el-table-column prop="03" label="03" width="100" align="center" />
        <el-table-column prop="04" label="04" width="100" align="center" />
        <el-table-column prop="05" label="05" width="100" align="center" />
        <el-table-column prop="06" label="06" width="100" align="center" />
        <el-table-column prop="07" label="07" width="100" align="center" />
        <el-table-column prop="08" label="08" width="100" align="center" />
        <el-table-column prop="09" label="09" width="100" align="center" />
        <el-table-column prop="10" label="10" width="100" align="center" />
        <el-table-column prop="11" label="11" width="100" align="center" />
        <el-table-column prop="12" label="12" width="100" align="center" />
        <el-table-column prop="13" label="13" width="100" align="center" />
        <el-table-column prop="14" label="14" width="100" align="center" />
        <el-table-column prop="15" label="15" width="100" align="center" />
        <el-table-column prop="16" label="16" width="100" align="center" />
        <el-table-column prop="17" label="17" width="100" align="center" />
        <el-table-column prop="18" label="18" width="100" align="center" />
        <el-table-column prop="19" label="19" width="100" align="center" />
        <el-table-column prop="20" label="20" width="100" align="center" />
        <el-table-column prop="21" label="21" width="100" align="center" />
        <el-table-column prop="22" label="22" width="100" align="center" />
        <el-table-column prop="23" label="23" width="100" align="center" />
        <el-table-column prop="24" label="24" width="100" align="center" />
        <el-table-column prop="25" label="25" width="100" align="center" />
        <el-table-column prop="26" label="26" width="100" align="center" />
        <el-table-column prop="27" label="27" width="100" align="center" />
        <el-table-column prop="28" label="28" width="100" align="center" />
        <el-table-column prop="29" label="29" width="100" align="center" />
        <el-table-column prop="30" label="30" width="100" align="center" />
        <el-table-column prop="31" label="31" width="100" align="center" />
      </el-table>
    </div>
  </div>
</template>
<script>
// import $ from 'jquery'
import {
  GetDPMTeamKPIHistoryData
} from '@/api/midway.js'
export default {
  components: {
    // lineComp,
    // optComp
  },
  // eslint-disable-next-line vue/require-prop-types
  props: ['onedata'],
  data() {
    return {
      mydata: this.onedata,
      tableData: [],
      tableLineData: [],
      loadingData: null,
      loading: false,
      chart: null
    }
  },
  computed: {
  },
  watch: {
    // onedata: {
    //   immediate: true,
    //   handler (n) {
    //     console.log('update')
    //     this.mydata = n
    //   }
    // }
    onedata(n, o) {
      this.mydata = n
    }
  },
  mounted() {
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
      if (this.chart !== null) {
        this.chart.resize()
      }
    }
    // this.$nextTick(function () {
    //   this.initialData()
    // })
  },
  beforeDestroy() {
  },
  methods: {
    getHeaderCellColor() {
      const style = {
        'background-color': 'rgb(23,102,173)',
        color: 'white'
      }
      return style
    },
    initialData() {
      this.GetMainData()
    },
    destoryChart(chart) {
      if (chart !== null && chart !== '' && chart !== undefined) {
        chart.dispose()
      }
    },
    async GetMainData() {
      const data = {
        factory: this.mydata.factory,
        area: this.mydata.area,
        team: this.mydata.team,
        yearMonth: this.mydata.yearMonth,
        shift: this.mydata.shift,
        kpi: this.mydata.kpi
      }
      this.loading = true
      const response = await GetDPMTeamKPIHistoryData(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.setChart(obj.chartData[0])
        this.tableData = obj.tableData[0]
        this.tableLineData = obj.tableData[1]
      } else {
        this.alertMsg(queryResult)
      }
    },
    setChart(obj) {
      const series = []
      obj.series.forEach(s => {
        series.push(s)
      })
      const option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          }
        },
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        legend: {
          data: ['Goal', 'RTY']
        },
        xAxis: [
          {
            type: 'category',
            data: obj.xAxisData,
            axisPointer: {
              type: 'shadow'
            }
          }
        ],
        yAxis: [
          {
            type: 'value'
            // name: obj.yAxisName
          },
          {
            type: 'value',
            // name: '效率',
            axisLabel: {
              formatter: '{value} %'
            }
          }
        ],
        series: series
      }
      this.destoryChart(this.chart)
      const chartDom = document.getElementById('elChartRTY')
      this.chart = this.$echarts.init(chartDom)
      this.chart.clear()
      this.chart.setOption(option)
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    resizeTable: function() {
      this.$nextTick(function() {
        // let dailogBodyHeight = $(window).height() - 540// $('#containerDivRTY').height()
        // if (dailogBodyHeight < 400) {
        //   dailogBodyHeight = 400
        // }
        // $('#elChartRTY').height(dailogBodyHeight)
      })
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep main.el-main{
  padding: 0
}
::v-deep .el-divider--horizontal{
  margin:0
}
section{
  padding-bottom: 0;
}
.el-header{
    padding:0 5px
}
.header{
  height:50px !important;
  // background-color:#1f4e7c;
  background-color:rgba(0,0,0,0);
}
.chartDiv {
  height:350px;
  width:100%;
  background-color: white;
}
.detailDiv{
  margin-top:10px;
  width:100%;
}
.lineDiv{
  margin-top:10px;
  width:100%;
}
</style>
