<template>
  <div class="oneLineDiv">
    <div class="lineTitle">
      <!-- <span class="lineTitleValue" :style="{'font-size':getFontSize(mydata.code)}" @click="titleClick()">{{mydata.code}}</span> -->
      <span class="lineTitleValue" :style="{'color': getCodeColor(mydata.work_flag)}" @click="titleClick()">{{ mydata.code }}</span>
    </div>
    <div class="chartMainDiv">
      <div v-show="getShowStatus('UTS')" class="chartPanel">
        <div class="chartTitle">UTS</div>
        <div :id="utsChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('UTS')" />
        <div class="actualAndTarget">{{ getInfoString('UTS') }}</div>
        <div v-if="getErrorStatus('UTS')" class="warningDiv" />
      </div>
      <div v-show="getShowStatus('Output')" class="chartPanel">
        <div class="chartTitle">Output</div>
        <div :id="outputChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('Output')" />
        <div class="actualAndTarget">{{ getInfoString('Output') }}</div>
        <div v-if="getErrorStatus('Output')" class="warningDiv" />
      </div>
      <div v-show="getShowStatus('UPH')" class="chartPanel">
        <div class="chartTitle">UPH</div>
        <div :id="uphChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('UPH')" />
        <div class="actualAndTarget">{{ getInfoString('UPH') }}</div>
        <div v-if="getErrorStatus('UPH')" class="warningDiv" />
      </div>
      <div v-show="getShowStatus('Online DL UPPH')" class="chartPanel">
        <div class="chartTitle">Online DL UPPH</div>
        <div :id="upphOnlineDLChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('Online DL UPPH')" />
        <div class="actualAndTarget">{{ getInfoString('Online DL UPPH') }}</div>
        <div v-if="getErrorStatus('Online DL UPPH')" class="warningDiv" />
      </div>
      <!-- 20230102 Kimi 增加Online PPH，替换Online DL UPPH -->
      <div v-show="getShowStatus('Online DL PPH')" class="chartPanel">
        <div class="chartTitle">Online DL PPH</div>
        <div :id="pphOnlineDLChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('Online DL PPH')" />
        <div class="actualAndTarget">{{ getInfoString('Online DL PPH') }}</div>
        <div v-if="getErrorStatus('Online DL PPH')" class="warningDiv" />
      </div>
      <div v-show="getShowStatus('Offline DL UPPH')" class="chartPanel">
        <div class="chartTitle">Offline DL UPPH</div>
        <div :id="upphOfflineDLChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('Offline DL UPPH')" />
        <div class="actualAndTarget">{{ getInfoString('Offline DL UPPH') }}</div>
        <div v-if="getErrorStatus('Offline DL UPPH')" class="warningDiv" />
      </div>
      <div v-show="getShowStatus('EFFCIENCY')" class="chartPanel">
        <div class="chartTitle">EFFCIENCY</div>
        <div :id="effciencyChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('EFFCIENCY')" />
        <div class="actualAndTarget">{{ getInfoString('EFFCIENCY') }}</div>
        <div v-if="getErrorStatus('EFFCIENCY')" class="warningDiv" />
      </div>
      <div v-show="getShowStatus('RTY')" class="chartPanel">
        <div class="chartTitle">RTY</div>
        <div :id="rtyChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('RTY')" />
        <div class="actualAndTarget">{{ getInfoString('RTY') }}</div>
        <div v-if="getErrorStatus('RTY')" class="warningDiv" />
      </div>
      <!-- 20240111 Byron 增加RTY(FY) -->
      <div v-show="getShowStatus('RTY(FY)')" class="chartPanel">
        <div class="chartTitle">RTY(FY)</div>
        <div :id="RTYFYChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('RTY(FY)')" />
        <div class="actualAndTarget">{{ getInfoString('RTY(FY)') }}</div>
        <div v-if="getErrorStatus('RTY(FY)')" class="warningDiv" />
      </div>
      <!-- 20230110 Kimi 增加OAIL -->
      <div v-show="getShowStatus('OAIL')" class="chartPanel">
        <div class="chartTitle">OAIL</div>
        <div :id="oailChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('OAIL')" />
        <div class="actualAndTarget">{{ getInfoString('OAIL') }}</div>
        <div v-if="getErrorStatus('OAIL')" class="warningDiv" />
      </div>
      <div v-show="getShowStatus('OEE1')" class="chartPanel">
        <div class="chartTitle">OEE1</div>
        <div :id="oee1ChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('OEE1')" />
        <div class="actualAndTarget">{{ getInfoString('OEE1') }}</div>
        <div v-if="getErrorStatus('OEE1')" class="warningDiv" />
      </div>
      <div v-show="getShowStatus('OEE2')" class="chartPanel">
        <div class="chartTitle">OEE2</div>
        <div :id="oee2ChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('OEE2')" />
        <div class="actualAndTarget">{{ getInfoString('OEE2') }}</div>
        <div v-if="getErrorStatus('OEE2')" class="warningDiv" />
      </div>
      <div v-show="getShowStatus('WIP')" class="chartPanel">
        <div class="chartTitle">WIP</div>
        <div :id="wipChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('WIP')" />
        <div class="actualAndTarget">{{ getInfoString('WIP') }}</div>
        <div v-if="getErrorStatus('WIP')" class="warningDiv" />
      </div>
      <!-- 20230111 Kimi 增加毛效率 -->
      <div v-show="getShowStatus('Overall Eff')" class="chartPanel">
        <div class="chartTitle">Overall Eff</div>
        <div :id="overAllEffChartId" class="chartDiv" style="width:150px;height:150px" @click="chartClick('Overall Eff')" />
        <div class="actualAndTarget">{{ getInfoString('Overall Eff') }}</div>
        <div v-if="getErrorStatus('Overall Eff')" class="warningDiv" />
      </div>
    </div>
  </div>
</template>
<script>
export default {
  // eslint-disable-next-line vue/require-prop-types
  props: ['onedata'],
  data() {
    return {
      mydata: this.onedata,
      level: '',
      effciencyChartId: 'effciency',
      rtyChartId: 'rty',
      uphChartId: 'uph',
      upphOnlineDLChartId: 'upphonlinedl',
      upphOfflineDLChartId: 'upphofflinedl',
      oailChartId: 'oail', // 20230110 Kimi Add
      oee1ChartId: 'oee1',
      oee2ChartId: 'oee2',
      utsChartId: 'uts',
      wipChartId: 'wip',
      outputChartId: 'output',
      pphOnlineDLChartId: 'pphonlinedl', // 20230102 Kimi Add
      overAllEffChartId: 'overalleff', // 20230111 Kimi Add
      RTYFYChartId: 'RTY(FY)', // 20230111 Kimi Add
      chartEffciency: null,
      chartRTY: null,
      chartUPH: null,
      chartUPPHOnlineDL: null,
      chartUPPHOfflineDL: null,
      chartOAIL: null, // 20230110 Kimi Add
      chartOEE1: null,
      chartOEE2: null,
      chartUTS: null,
      chartWIP: null,
      chartOutput: null,
      chartPPHOnlineDL: null, // 20230102 Kimi Add
      chartOverallEff: null, // 20230111 Kimi Add
      chartRTYFY: null // 20240815 Byron Add
    }
  },
  computed: {
  // getColor: function (value) {
  //   if (value >= 90) {
  //     return 'limegreen'
  //   } else if (value >= 60 && value < 90) {
  //     return 'yellow'
  //   } else {
  //     return 'red'
  //   }
  // }
  },
  watch: {
    onedata(n, o) {
      this.mydata = n
      this.initialForm()
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.initialForm()
    })
  },
  methods: {
    initialForm() {
      if (this.mydata === undefined) {
        return
      }
      this.level = this.mydata.level
      this.effciencyChartId = this.mydata.code + 'effciency'
      this.rtyChartId = this.mydata.code + 'rty'
      this.uphChartId = this.mydata.code + 'uph'
      this.upphOnlineDLChartId = this.mydata.code + 'upphonlinedl'
      this.upphOfflineDLChartId = this.mydata.code + 'upphofflinedl'
      this.oailChartId = this.mydata.code + 'oail' // 20230110 Kimi Add
      this.oee1ChartId = this.mydata.code + 'oee1'
      this.oee2ChartId = this.mydata.code + 'oee2'
      this.utsChartId = this.mydata.code + 'uts'
      this.wipChartId = this.mydata.code + 'wip'
      this.outputChartId = this.mydata.code + 'output'
      this.pphOnlineDLChartId = this.mydata.code + 'pphonlinedl'
      this.overAllEffChartId = this.mydata.code + 'overalleff' // 20230111 Kimi Add
      this.RTYFYChartId = this.mydata.code + 'RTY(FY)' // 20240815 Byron Add
      this.showChart('EFFCIENCY')
      this.showChart('RTY')
      this.showChart('UPH')
      this.showChart('Online DL UPPH')
      this.showChart('Offline DL UPPH')
      this.showChart('OAIL') // 20230110 Kimi Add
      this.showChart('OEE1')
      this.showChart('OEE2')
      this.showChart('UTS')
      this.showChart('WIP')
      this.showChart('Output')
      this.showChart('Online DL PPH')
      this.showChart('Overall Eff') // 20230111 Kimi Add
      this.showChart('RTY(FY)') // 20240815 Byron Add
    },
    getCodeColor(workFlag) {
      if (workFlag === 'N') {
        return 'rgb(128,128,128)'
      }
    },
    getFontSize(content) {
      if (content.length < 5) {
        return '50px'
      } else if (content.length > 5 && content.length < 8) {
        return '40px'
      } else if (content.length >= 8 && content.length < 12) {
        return '30px'
      } else {
        return '25px'
      }
    },
    getColor: function(value, actual, goal, color) {
    // if (parseInt(value) === 0) {
    //   return '#FF5151'
    // }
    // if (parseFloat(actual) < parseFloat(goal)) {
    //   if (value >= 90) {
    //     return '#FFA700'
    //   }
    //   return '#FF5151'
    // } else {
    //   return '#1AD300'
    // }
      return color
    },
    getBKColor(type) {
      if (this.mydata === undefined || this.mydata.data.length === 0) {
        return ''
      }
      try {
        const one = this.mydata.data.find(x => x.type === type)

        if (one.has_error === 'Y') {
          return 'tomato'
        }
      } catch {
        return ''
      }
    },
    getInfoString(type) {
      if (this.mydata === undefined || this.mydata.data.length === 0) {
        return ''
      }
      try {
        const one = this.mydata.data.find(x => x.type === type)
        return one.actual + ' / ' + one.goal
      } catch {
        return ''
      }
    },
    getErrorStatus(type) {
      if (this.mydata === undefined || this.mydata.data.length === 0) {
        return ''
      }
      try {
        const one = this.mydata.data.find(x => x.type === type)
        return one.has_error === 'Y'
      } catch {
        return false
      }
    },
    getShowStatus(type) {
      if (this.mydata === undefined || this.mydata.data.length === 0) {
        return ''
      }
      try {
        const one = this.mydata.data.find(x => x.type === type)
        return one.show === 'Y'
      } catch {
        return false
      }
    },
    titleClick() {
      this.GoToNext()
    },
    showChart(type) {
      if (this.mydata === undefined || this.mydata.data.length === 0) {
        return
      }

      const one = this.mydata.data.find(x => x.type === type)
      try {
        if (one.value === null || one.value === undefined) {
          return
        }
      } catch {
        return
      }
      let formatter = '{value}%'
      if (type === 'Output') {
        formatter = one.value + '%' // 20221026 Kimi 将output的显示用实际值来显示
      } else if (type === 'Online DL PPH') {
        formatter = one.value + '%' // 20230102 Kimi PPH直接显示数值
      } else if (type === 'OAIL') {
        formatter = one.value // 2023011 Kimi OAIL直接显示DPPM
      } else if (type === 'Overall Eff') {
        formatter = one.value // 2023011 Kimi
      }
      // if (type === 'RTY') {
      //   formatter = '{value}%'
      // }
      if (one !== null) {
      // 20221026 Kimi 将图的value在展示output的时候用百分比来显示，原来直接显示了value，不对
        let seriesValue = one.value
        if (type === 'Output' || type === 'Online DL PPH' || type === 'OAIL' || type === 'Overall Eff') { // 20230102 Kimi PPH也按实际百分比计算圈圈进度 // 20230110 Kimi Add OAIL // 20230111 Kimi Add OVERALL_EFF
          seriesValue = parseFloat(one.goal) === 0 ? 0 : 100 * parseFloat(one.actual) / parseFloat(one.goal)
          // console.log(seriesValue)
          seriesValue = seriesValue.toFixed(2)
        }
        // ---------------------------------------------------------------------------------
        const gaugeData = [
          {
            value: seriesValue, // one.value,
            // name: one.name,
            title: {
              offsetCenter: ['0%', '-20%']
            },
            detail: {
              valueAnimation: true,
              fontSize: 20,
              borderColor: 'transparent',
              offsetCenter: ['0%', '5%']
            }
          }
        ]
        const color = this.getColor(one.value, one.actual, one.goal, one.color)
        var option = {
          backgroundColor: 'rgba(0,0,0,0)',
          // tooltip: {
          //   trigger: 'item'
          // },
          series: [
            {
              type: 'gauge',
              startAngle: 90,
              endAngle: -270,
              pointer: {
                show: false
              },
              progress: {
                show: true,
                overlap: false,
                roundCap: true,
                clip: false,
                itemStyle: {
                  borderWidth: 1,
                  borderColor: '#464646',
                  color: color
                }
              },
              axisLine: {
                lineStyle: {
                  width: 10,
                  color: [[1, '#203C81']]
                }
              },
              splitLine: {
                show: false,
                distance: 0,
                length: 10
              },
              axisTick: {
                show: false
              },
              axisLabel: {
                show: false,
                distance: 50
              },
              data: gaugeData,
              title: {
                fontSize: 14
              },
              detail: {
                width: 45,
                height: 13,
                fontSize: 13,
                color: color,
                borderColor: 'auto',
                borderRadius: 15,
                borderWidth: 1,
                formatter: formatter
              }
            }
          ]
        }
        var id = ''
        var chartDom
        if (this.getShowStatus(type)) {
          if (type === 'RTY') {
            id = this.rtyChartId
            this.$nextTick(() => {
              if (this.chartRTY !== null && this.chartRTY !== '' && this.chartRTY !== undefined) {
                this.chartRTY.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartRTY = this.$echarts.init(chartDom)
              this.chartRTY.clear()
              this.chartRTY.setOption(option)
            })
          } else if (type === 'EFFCIENCY') {
            id = this.effciencyChartId
            this.$nextTick(() => {
              if (this.chartEffciency !== null && this.chartEffciency !== '' && this.chartEffciency !== undefined) {
                this.chartEffciency.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartEffciency = this.$echarts.init(chartDom)
              this.chartEffciency.clear()
              this.chartEffciency.setOption(option)
            })
          } else if (type === 'UPH') {
            id = this.uphChartId
            this.$nextTick(() => {
              if (this.chartUPH !== null && this.chartUPH !== '' && this.chartUPH !== undefined) {
                this.chartUPH.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartUPH = this.$echarts.init(chartDom)
              this.chartUPH.clear()
              this.chartUPH.setOption(option)
            })
          } else if (type === 'Online DL UPPH') {
            id = this.upphOnlineDLChartId
            this.$nextTick(() => {
              if (this.chartUPPHOnlineDL !== null && this.chartUPPHOnlineDL !== '' && this.chartUPPHOnlineDL !== undefined) {
                this.chartUPPHOnlineDL.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartUPPHOnlineDL = this.$echarts.init(chartDom)
              this.chartUPPHOnlineDL.clear()
              this.chartUPPHOnlineDL.setOption(option)
            })
          } else if (type === 'Offline DL UPPH') {
            id = this.upphOfflineDLChartId
            this.$nextTick(() => {
              if (this.chartUPPHOfflineDL !== null && this.chartUPPHOfflineDL !== '' && this.chartUPPHOfflineDL !== undefined) {
                this.chartUPPHOfflineDL.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartUPPHOfflineDL = this.$echarts.init(chartDom)
              this.chartUPPHOfflineDL.clear()
              this.chartUPPHOfflineDL.setOption(option)
            })
          } else if (type === 'OAIL') {
          // 20230110 Kimi Add
            id = this.oailChartId
            this.$nextTick(() => {
              if (this.chartOAIL !== null && this.chartOAIL !== '' && this.chartOAIL !== undefined) {
                this.chartOAIL.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartOAIL = this.$echarts.init(chartDom)
              this.chartOAIL.clear()
              this.chartOAIL.setOption(option)
            })
          } else if (type === 'OEE1') {
            id = this.oee1ChartId
            this.$nextTick(() => {
              if (this.chartOEE1 !== null && this.chartOEE1 !== '' && this.chartOEE1 !== undefined) {
                this.chartOEE1.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartOEE1 = this.$echarts.init(chartDom)
              this.chartOEE1.clear()
              this.chartOEE1.setOption(option)
            })
          } else if (type === 'OEE2') {
            id = this.oee2ChartId
            this.$nextTick(() => {
              if (this.chartOEE2 !== null && this.chartOEE2 !== '' && this.chartOEE2 !== undefined) {
                this.chartOEE2.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartOEE2 = this.$echarts.init(chartDom)
              this.chartOEE2.clear()
              this.chartOEE2.setOption(option)
            })
          } else if (type === 'UTS') {
            id = this.utsChartId
            this.$nextTick(() => {
              if (this.chartUTS !== null && this.chartUTS !== '' && this.chartUTS !== undefined) {
                this.chartUTS.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartUTS = this.$echarts.init(chartDom)
              this.chartUTS.clear()
              this.chartUTS.setOption(option)
            })
          } else if (type === 'WIP') {
            id = this.wipChartId
            this.$nextTick(() => {
              if (this.chartWIP !== null && this.chartWIP !== '' && this.chartWIP !== undefined) {
                this.chartWIP.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartWIP = this.$echarts.init(chartDom)
              this.chartWIP.clear()
              this.chartWIP.setOption(option)
            })
          } else if (type === 'Output') {
            id = this.outputChartId
            this.$nextTick(() => {
              if (this.chartOutput !== null && this.chartOutput !== '' && this.chartOutput !== undefined) {
                this.chartOutput.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartOutput = this.$echarts.init(chartDom)
              this.chartOutput.clear()
              this.chartOutput.setOption(option)
            })
          } else if (type === 'Online DL PPH') {
          // 20220102 Kimi add
            id = this.pphOnlineDLChartId
            this.$nextTick(() => {
              if (this.chartPPHOnlineDL !== null && this.chartPPHOnlineDL !== '' && this.chartPPHOnlineDL !== undefined) {
                this.chartPPHOnlineDL.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartPPHOnlineDL = this.$echarts.init(chartDom)
              this.chartPPHOnlineDL.clear()
              this.chartPPHOnlineDL.setOption(option)
            })
          } else if (type === 'Overall Eff') {
          // 20220111 Kimi add
            id = this.overAllEffChartId
            this.$nextTick(() => {
              if (this.chartOverallEff !== null && this.chartOverallEff !== '' && this.chartOverallEff !== undefined) {
                this.chartOverallEff.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartOverallEff = this.$echarts.init(chartDom)
              this.chartOverallEff.clear()
              this.chartOverallEff.setOption(option)
            })
          } else if (type === 'RTY(FY)') {
          // 20220111 Kimi add
            id = this.RTYFYChartId
            this.$nextTick(() => {
              if (this.chartRTYFY !== null && this.chartRTYFY !== '' && this.chartRTYFY !== undefined) {
                this.chartRTYFY.dispose()
              }
              chartDom = document.getElementById(id)
              this.chartRTYFY = this.$echarts.init(chartDom)
              this.chartRTYFY.clear()
              this.chartRTYFY.setOption(option)
            })
          }
        }
      }
    },
    GoToNext: function() {
      let url = ''
      let nextLevel = ''
      const currLevel = this.mydata.level.toLowerCase()
      switch (currLevel) {
        case 'factory':
          url = '/DPMDashboardArea'
          nextLevel = 'area'
          break
        case 'area':
          url = '/DPMDashboardTeam'
          nextLevel = 'team'
          break
        // url = '/DPMDashboardLine'
        // nextLevel = 'line'
        // break
        case 'team':
          url = '/DPMDashboardLine'
          nextLevel = 'line'
          break
        case 'line':
          url = '/DPMDashboardLineDetail'
          nextLevel = 'linedetail'
          break
        default:
          url = '/DPMDashboard'
          nextLevel = 'factory'
          break
      }
      const query = {
        level: nextLevel,
        keyid: this.mydata.id
      // parent: this.mydata.parent
      // factory: this.mydata.factory,
      // area: this.mydata.area,
      // line: this.mydata.line
      }
      this.$router.push({
        path: url,
        query: query
      })
    },
    chartClick(type) {
    // const data = {
    //   level: this.mydata.level,
    //   keyword: this.mydata.code,
    //   keyid: this.mydata.id,
    //   type: type
    // }
    // this.$emit('showdg', data)
    }
  }
}
</script>
<style lang="less" scoped>
.oneLineDiv{
width:100%;
height: 200px;
display:flex;
border-radius: 15px;
background-image: linear-gradient(to right, rgb(28,49,106), rgb(25,27,74));
box-shadow: 0 0 10px rgb(205,205,205) ;
}
.lineTitle{
text-align: center;
// background-color: rgb(31,78,124);
background-color: rgba(0,0,0,0);
color: white;
font-size: 40px;
height:100%;
// width: 200px;
min-width: 200px;
line-height: 200px;
padding-left:10px;
// position: relative;
// top:50%;
// transform:translateY(-50%);
// border-top-right-radius: 10px;
// border-top-left-radius: 10px;
}
.lineTitleValue{
color:white;
cursor: pointer;
font-size: 40px;
}
.chartMainDiv{
height: 100%;
display:flex;
// border: 1px solid red;
flex-wrap: nowrap;
justify-content: center;
align-items: center;
// background-color: rgb(250,251,253);
background-color: rgba(0,0,0,0);
}
.chartDiv{
// cursor: pointer;
// width:150px;
// height:150px;
flex:none;
}
.chartPanel{
flex:1;
position: relative;
}
.chartTitle{
flex:1;
text-align: center;
height: 30px;
line-height:30px;
font-size: 15px;
// background-color: rgb(31,78,124);
background-color: rgba(0,0,0,0);
color:white;
}
.chartInfo{
width:150px;
height: 20px;
display:flex;
justify-content: space-between;
}
.statusIcon{
background-color: tomato;
height: 20px;
width: 20px;
margin-left:20px;
border-radius: 10px;
}
.actualAndTarget{
color:white;
font-size:14px;
line-height: 20px;
width:150px;
height:20px;
text-align: center;
}
.warningDiv{
position: absolute;
width:10px;
height:10px;
background: tomato;
bottom:40px;
left:115px;
border-radius: 5px;
}
</style>
