<template>
  <div id="containerDivOEE2" style="height:100%;width:100%;">
    <div id="elChartOEE2" class="chartDiv" />
    <div id="tableDetailContainerOEE2" class="detailDiv">
      <el-table
        v-loading="loading"
        :data="tableData"
        :height="180"
        size="mini"
        style="width: 100%"
        :header-cell-style="getHeaderCellColor"
      >
        <el-table-column prop="type" label="" width="110" align="center" fixed show-overflow-tooltip />
        <el-table-column prop="mtd" label="MTD" width="100" align="center" fixed />
        <el-table-column label="01" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('01',scope.row['01'])}">{{ scope.row['01'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="02" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('02',scope.row['02'])}">{{ scope.row['02'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="03" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('03',scope.row['03'])}">{{ scope.row['03'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="04" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('04',scope.row['04'])}">{{ scope.row['04'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="05" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('05',scope.row['05'])}">{{ scope.row['05'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="06" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('06',scope.row['06'])}">{{ scope.row['06'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="07" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('07',scope.row['07'])}">{{ scope.row['07'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="08" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('08',scope.row['08'])}">{{ scope.row['08'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="09" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('09',scope.row['09'])}">{{ scope.row['09'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="10" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('10',scope.row['10'])}">{{ scope.row['10'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="11" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('11',scope.row['11'])}">{{ scope.row['11'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="12" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('12',scope.row['12'])}">{{ scope.row['12'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="13" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('13',scope.row['13'])}">{{ scope.row['13'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="14" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('14',scope.row['14'])}">{{ scope.row['14'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="15" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('15',scope.row['15'])}">{{ scope.row['15'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="16" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('16',scope.row['16'])}">{{ scope.row['16'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="17" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('17',scope.row['17'])}">{{ scope.row['17'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="18" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('18',scope.row['18'])}">{{ scope.row['18'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="19" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('19',scope.row['19'])}">{{ scope.row['19'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="20" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('20',scope.row['20'])}">{{ scope.row['20'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="21" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('21',scope.row['21'])}">{{ scope.row['21'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="22" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('22',scope.row['22'])}">{{ scope.row['22'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="23" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('23',scope.row['23'])}">{{ scope.row['23'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="24" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('24',scope.row['24'])}">{{ scope.row['24'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="25" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('25',scope.row['25'])}">{{ scope.row['25'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="26" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('26',scope.row['26'])}">{{ scope.row['26'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="27" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('27',scope.row['27'])}">{{ scope.row['27'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="28" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('28',scope.row['28'])}">{{ scope.row['28'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="29" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('29',scope.row['29'])}">{{ scope.row['29'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="30" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('30',scope.row['30'])}">{{ scope.row['30'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="31" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('31',scope.row['31'])}">{{ scope.row['31'] }}</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div id="tableLinelContainer" class="lineDiv">
      <el-table
        v-loading="loading"
        :data="tableLineData"
        :height="270"
        size="mini"
        style="width: 100%"
        :header-cell-style="getHeaderCellColor"
      >
        <el-table-column prop="line" :label="$t('common.colLine') + '[%]'" width="110" align="center" fixed show-overflow-tooltip />

        <el-table-column prop="mtd" label="MTD" width="100" align="center" fixed />
        <el-table-column label="01" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('01',scope.row['01'])}">{{ scope.row['01'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="02" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('02',scope.row['02'])}">{{ scope.row['02'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="03" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('03',scope.row['03'])}">{{ scope.row['03'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="04" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('04',scope.row['04'])}">{{ scope.row['04'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="05" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('05',scope.row['05'])}">{{ scope.row['05'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="06" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('06',scope.row['06'])}">{{ scope.row['06'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="07" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('07',scope.row['07'])}">{{ scope.row['07'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="08" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('08',scope.row['08'])}">{{ scope.row['08'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="09" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('09',scope.row['09'])}">{{ scope.row['09'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="10" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('10',scope.row['10'])}">{{ scope.row['10'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="11" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('11',scope.row['11'])}">{{ scope.row['11'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="12" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('12',scope.row['12'])}">{{ scope.row['12'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="13" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('13',scope.row['13'])}">{{ scope.row['13'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="14" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('14',scope.row['14'])}">{{ scope.row['14'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="15" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('15',scope.row['15'])}">{{ scope.row['15'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="16" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('16',scope.row['16'])}">{{ scope.row['16'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="17" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('17',scope.row['17'])}">{{ scope.row['17'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="18" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('18',scope.row['18'])}">{{ scope.row['18'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="19" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('19',scope.row['19'])}">{{ scope.row['19'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="20" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('20',scope.row['20'])}">{{ scope.row['20'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="21" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('21',scope.row['21'])}">{{ scope.row['21'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="22" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('22',scope.row['22'])}">{{ scope.row['22'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="23" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('23',scope.row['23'])}">{{ scope.row['23'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="24" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('24',scope.row['24'])}">{{ scope.row['24'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="25" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('25',scope.row['25'])}">{{ scope.row['25'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="26" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('26',scope.row['26'])}">{{ scope.row['26'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="27" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('27',scope.row['27'])}">{{ scope.row['27'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="28" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('28',scope.row['28'])}">{{ scope.row['28'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="29" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('29',scope.row['29'])}">{{ scope.row['29'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="30" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('30',scope.row['30'])}">{{ scope.row['30'] }}</span>
          </template>
        </el-table-column>
        <el-table-column label="31" width="100" align="center">
          <template slot-scope="scope">
            <span :class="{'isRed':setUpColor('31',scope.row['31'])}">{{ scope.row['31'] }}</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
// import $ from 'jquery'
import {
  GetDPMTeamKPIHistoryData
} from '@/api/midway.js'
export default {
  components: {
    // lineComp,
    // optComp
  },
  // eslint-disable-next-line vue/require-prop-types
  props: ['onedata'],
  data() {
    return {
      mydata: this.onedata,
      tableData: [],
      tableLineData: [],
      loadingData: null,
      loading: false,
      chart: null
    }
  },
  computed: {
  },
  watch: {
    // onedata: {
    //   immediate: true,
    //   handler (n) {
    //     console.log('update')
    //     this.mydata = n
    //   }
    // }
    onedata(n, o) {
      this.mydata = n
    }
  },
  mounted() {
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
      if (this.chart !== null) {
        this.chart.resize()
      }
    }
    // this.$nextTick(function () {
    //   this.initialData()
    // })
  },
  beforeDestroy() {
  },
  methods: {
    setUpColor(key, value) {
      // scope.row['01']
      const val = value
      const GoalValue = this.tableData[0][key]
      if (val < GoalValue) {
        return true
      } else {
        return false
      }
    },

    getHeaderCellColor() {
      const style = {
        'background-color': 'rgb(23,102,173)',
        color: 'white'
      }
      return style
    },
    initialData() {
      this.GetMainData()
    },
    destoryChart(chart) {
      if (chart !== null && chart !== '' && chart !== undefined) {
        chart.dispose()
      }
    },
    async GetMainData() {
      const data = {
        factory: this.mydata.factory,
        area: this.mydata.area,
        team: this.mydata.team,
        yearMonth: this.mydata.yearMonth,
        shift: this.mydata.shift,
        kpi: this.mydata.kpi
      }
      this.loading = true
      const response = await GetDPMTeamKPIHistoryData(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.setChart(obj.chartData[0])
        this.tableData = obj.tableData[0]
        this.tableLineData = obj.tableData[1]
      } else {
        this.alertMsg(queryResult)
      }
    },
    setChart(obj) {
      const series = []
      obj.series.forEach(s => {
        series.push(s)
      })
      const option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          }
        },
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        legend: {
          data: ['Goal', 'OEE2']
        },
        xAxis: [
          {
            type: 'category',
            data: obj.xAxisData,
            axisPointer: {
              type: 'shadow'
            }
          }
        ],
        yAxis: [
          {
            type: 'value'
            // name: obj.yAxisName
          },
          {
            type: 'value',
            // name: '效率',
            axisLabel: {
              formatter: '{value} %'
            }
          }
        ],
        series: series
      }
      this.destoryChart(this.chart)
      const chartDom = document.getElementById('elChartOEE2')
      this.chart = this.$echarts.init(chartDom)
      this.chart.clear()
      this.chart.setOption(option)
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    resizeTable: function() {
      this.$nextTick(function() {
        // let dailogBodyHeight = $(window).height() - 540// $('#containerDivOEE2').height()
        // if (dailogBodyHeight < 400) {
        //   dailogBodyHeight = 400
        // }
        // $('#elChartOEE2').height(dailogBodyHeight)
      })
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep main.el-main{
  padding: 0
}
::v-deep .el-divider--horizontal{
  margin:0
}
section{
  padding-bottom: 0;
}
.el-header{
    padding:0 5px
}
.header{
  height:50px !important;
  // background-color:#1f4e7c;
  background-color:rgba(0,0,0,0);
}
.chartDiv {
  height:350px;
  width:100%;
  background-color: white;
}
.detailDiv{
  margin-top:10px;
  width:100%;
}
.lineDiv{
  margin-top:10px;
  width:100%;
}
.isRed{
  color:red
}
</style>
