<template>
  <div id="containerDivOAIL" style="height:100%;width:100%;">
    <div id="divChartOAIL" class="chartDiv">
      <div id="elChartOAIL" class="chart" />
      <div id="elChartOAILProcess" class="chartProcess" />
    </div>
    <div id="tableDetailContainerOAIL" class="detailDiv">
      <el-table
        :data="tableData"
        :height="240"
        size="mini"
        style="width: 100%"
        :header-cell-style="getHeaderCellColor"
      >
        <el-table-column prop="type" label="" width="150" align="center" show-overflow-tooltip fixed />
        <el-table-column prop="mtd" label="MTD" width="90" align="center" fixed />
        <el-table-column prop="01" label="01" width="90" align="center" />
        <el-table-column prop="02" label="02" width="90" align="center" />
        <el-table-column prop="03" label="03" width="90" align="center" />
        <el-table-column prop="04" label="04" width="90" align="center" />
        <el-table-column prop="05" label="05" width="90" align="center" />
        <el-table-column prop="06" label="06" width="90" align="center" />
        <el-table-column prop="07" label="07" width="90" align="center" />
        <el-table-column prop="08" label="08" width="90" align="center" />
        <el-table-column prop="09" label="09" width="90" align="center" />
        <el-table-column prop="10" label="10" width="90" align="center" />
        <el-table-column prop="11" label="11" width="90" align="center" />
        <el-table-column prop="12" label="12" width="90" align="center" />
        <el-table-column prop="13" label="13" width="90" align="center" />
        <el-table-column prop="14" label="14" width="90" align="center" />
        <el-table-column prop="15" label="15" width="90" align="center" />
        <el-table-column prop="16" label="16" width="90" align="center" />
        <el-table-column prop="17" label="17" width="90" align="center" />
        <el-table-column prop="18" label="18" width="90" align="center" />
        <el-table-column prop="19" label="19" width="90" align="center" />
        <el-table-column prop="20" label="20" width="90" align="center" />
        <el-table-column prop="21" label="21" width="90" align="center" />
        <el-table-column prop="22" label="22" width="90" align="center" />
        <el-table-column prop="23" label="23" width="90" align="center" />
        <el-table-column prop="24" label="24" width="90" align="center" />
        <el-table-column prop="25" label="25" width="90" align="center" />
        <el-table-column prop="26" label="26" width="90" align="center" />
        <el-table-column prop="27" label="27" width="90" align="center" />
        <el-table-column prop="28" label="28" width="90" align="center" />
        <el-table-column prop="29" label="29" width="90" align="center" />
        <el-table-column prop="30" label="30" width="90" align="center" />
        <el-table-column prop="31" label="31" width="90" align="center" />
      </el-table>
    </div>
    <div id="tableMiddleContainer" class="middleDiv">
      <el-table
        :data="tableMiddleData"
        :height="240"
        size="mini"
        style="width: 100%"
        :header-cell-style="getHeaderCellColor"
      >
        <el-table-column prop="category" label="Category[PCS]" width="150" align="center" show-overflow-tooltip fixed />
        <el-table-column prop="mtd" label="MTD" width="90" align="center" fixed />
        <el-table-column prop="01" label="01" width="90" align="center" />
        <el-table-column prop="02" label="02" width="90" align="center" />
        <el-table-column prop="03" label="03" width="90" align="center" />
        <el-table-column prop="04" label="04" width="90" align="center" />
        <el-table-column prop="05" label="05" width="90" align="center" />
        <el-table-column prop="06" label="06" width="90" align="center" />
        <el-table-column prop="07" label="07" width="90" align="center" />
        <el-table-column prop="08" label="08" width="90" align="center" />
        <el-table-column prop="09" label="09" width="90" align="center" />
        <el-table-column prop="10" label="10" width="90" align="center" />
        <el-table-column prop="11" label="11" width="90" align="center" />
        <el-table-column prop="12" label="12" width="90" align="center" />
        <el-table-column prop="13" label="13" width="90" align="center" />
        <el-table-column prop="14" label="14" width="90" align="center" />
        <el-table-column prop="15" label="15" width="90" align="center" />
        <el-table-column prop="16" label="16" width="90" align="center" />
        <el-table-column prop="17" label="17" width="90" align="center" />
        <el-table-column prop="18" label="18" width="90" align="center" />
        <el-table-column prop="19" label="19" width="90" align="center" />
        <el-table-column prop="20" label="20" width="90" align="center" />
        <el-table-column prop="21" label="21" width="90" align="center" />
        <el-table-column prop="22" label="22" width="90" align="center" />
        <el-table-column prop="23" label="23" width="90" align="center" />
        <el-table-column prop="24" label="24" width="90" align="center" />
        <el-table-column prop="25" label="25" width="90" align="center" />
        <el-table-column prop="26" label="26" width="90" align="center" />
        <el-table-column prop="27" label="27" width="90" align="center" />
        <el-table-column prop="28" label="28" width="90" align="center" />
        <el-table-column prop="29" label="29" width="90" align="center" />
        <el-table-column prop="30" label="30" width="90" align="center" />
        <el-table-column prop="d31" label="31" width="90" align="center" />
      </el-table>
    </div>
    <div id="tableLinelContainer" class="lineDiv">
      <el-table
        :data="tableLineData"
        :height="240"
        size="mini"
        style="width: 100%"
        :header-cell-style="getHeaderCellColor"
      >
        <el-table-column prop="line" :label="$t('common.colLine') + '[DPPM]'" width="150" align="center" fixed show-overflow-tooltip />
        <el-table-column prop="mtd" label="MTD" width="90" align="center" fixed />
        <el-table-column prop="01" label="01" width="90" align="center" />
        <el-table-column prop="02" label="02" width="90" align="center" />
        <el-table-column prop="03" label="03" width="90" align="center" />
        <el-table-column prop="04" label="04" width="90" align="center" />
        <el-table-column prop="05" label="05" width="90" align="center" />
        <el-table-column prop="06" label="06" width="90" align="center" />
        <el-table-column prop="07" label="07" width="90" align="center" />
        <el-table-column prop="08" label="08" width="90" align="center" />
        <el-table-column prop="09" label="09" width="90" align="center" />
        <el-table-column prop="10" label="10" width="90" align="center" />
        <el-table-column prop="11" label="11" width="90" align="center" />
        <el-table-column prop="12" label="12" width="90" align="center" />
        <el-table-column prop="13" label="13" width="90" align="center" />
        <el-table-column prop="14" label="14" width="90" align="center" />
        <el-table-column prop="15" label="15" width="90" align="center" />
        <el-table-column prop="16" label="16" width="90" align="center" />
        <el-table-column prop="17" label="17" width="90" align="center" />
        <el-table-column prop="18" label="18" width="90" align="center" />
        <el-table-column prop="19" label="19" width="90" align="center" />
        <el-table-column prop="20" label="20" width="90" align="center" />
        <el-table-column prop="21" label="21" width="90" align="center" />
        <el-table-column prop="22" label="22" width="90" align="center" />
        <el-table-column prop="23" label="23" width="90" align="center" />
        <el-table-column prop="24" label="24" width="90" align="center" />
        <el-table-column prop="25" label="25" width="90" align="center" />
        <el-table-column prop="26" label="26" width="90" align="center" />
        <el-table-column prop="27" label="27" width="90" align="center" />
        <el-table-column prop="28" label="28" width="90" align="center" />
        <el-table-column prop="29" label="29" width="90" align="center" />
        <el-table-column prop="30" label="30" width="90" align="center" />
        <el-table-column prop="31" label="31" width="90" align="center" />
      </el-table>
    </div>
  </div>
</template>
<script>
// import $ from 'jquery'
import {
  GetDPMTeamKPIHistoryData
} from '@/api/midway.js'
export default {
  components: {
    // lineComp,
    // optComp
  },
  // eslint-disable-next-line vue/require-prop-types
  props: ['onedata'],
  data() {
    return {
      mydata: this.onedata,
      tableData: [],
      tableMiddleData: [],
      tableLineData: [],
      loadingData: null,
      loading: false,
      chart: null,
      chartProcess: null
    }
  },
  computed: {
  },
  watch: {
    onedata(n, o) {
      this.mydata = n
    }
  },
  mounted() {
    this.resizeTable()
    window.onresize = () => {
      this.resizeTable()
      // this.resetDashboard()
      if (this.chart !== null) {
        this.chart.resize()
      }
      if (this.chartProcess !== null) {
        this.chartProcess.resize()
      }
    }
    // this.$nextTick(function () {
    //   this.initialData()
    // })
  },
  beforeDestroy() {
    clearInterval(this.refreshTimer)
  },
  methods: {
    getHeaderCellColor() {
      const style = {
        'background-color': 'rgb(23,102,173)',
        color: 'white'
      }
      return style
    },
    initialData() {
      this.keyid = this.$route.query.keyid
      // 抓取项目数据显示在看板上
      // this.getDashBoardData()
      this.GetMainData()
    },
    destoryChart(chart) {
      if (chart !== null && chart !== '' && chart !== undefined) {
        chart.dispose()
      }
    },
    async GetMainData() {
      const data = {
        factory: this.mydata.factory,
        area: this.mydata.area,
        team: this.mydata.team,
        yearMonth: this.mydata.yearMonth,
        shift: this.mydata.shift,
        kpi: this.mydata.kpi
      }
      this.loading = true
      const response = await GetDPMTeamKPIHistoryData(data)
      this.loading = false
      const queryResult = response.data.QueryResult
      if (queryResult === 'OK') {
        const obj = response.data.ReturnObject
        this.setOAILChart(obj.chartData[0])
        this.setProcessChart(obj.chartData[1])
        this.tableData = obj.tableData[0]
        this.tableLineData = obj.tableData[1]
        this.tableMiddleData = obj.tableData[2]
      } else {
        this.alertMsg(queryResult)
      }
    },
    setOAILChart(obj) {
      const option = {
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: ['OAIL']
        },
        xAxis: {
          type: 'category',
          data: obj.xAxisData,
          axisLabel: {
            interval: 'auto',
            rotate: -30
          }
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: obj.series[0].name,
            data: obj.series[0].data,
            type: 'line'
          }
        ]
      }
      this.destoryChart(this.chart)
      const chartDom = document.getElementById('elChartOAIL')
      this.chart = this.$echarts.init(chartDom)
      this.chart.clear()
      this.chart.setOption(option)
    },
    setProcessChart(obj) {
      const option = {
        toolbox: {
          feature: {
            dataView: { show: true, readOnly: false },
            saveAsImage: { show: true }
          }
        },
        tooltip: {
          trigger: 'axis'
        },
        xAxis: {
          type: 'category',
          data: obj.xAxisData,
          axisLabel: {
            interval: 'auto',
            rotate: -30
          }
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            data: obj.series[0].data,
            type: 'bar'
          }
        ]
      }
      this.destoryChart(this.chartProcess)
      const chartDom = document.getElementById('elChartOAILProcess')
      this.chartProcess = this.$echarts.init(chartDom)
      this.chartProcess.clear()
      this.chartProcess.setOption(option)
    },
    alertMsg(msg) {
      this.$alert(msg, this.$t('common.altMsgTitle'), {
        confirmButtonText: this.$t('common.altMsgBtn'),
        type: 'error'
      })
    },
    resizeTable: function() {
      this.$nextTick(function() {
        // let dailogBodyHeight = $(window).height() - 900// $('#containerDiv').height()
        // if (dailogBodyHeight < 250) {
        //   dailogBodyHeight = 250
        // }
        // $('#divChartOAIL').height(dailogBodyHeight)
      })
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep main.el-main{
  padding: 0
}
::v-deep .el-divider--horizontal{
  margin:0
}
// ::v-deep .el-dialog__body{
//   padding-bottom: 0px;
// }
section{
  padding-bottom: 0;
}
.el-header{
    padding:0 5px
}
.header{
  height:50px !important;
  // background-color:#1f4e7c;
  background-color:rgba(0,0,0,0);
}
.chartDiv {
  height:350px;
  width:100%;
  background-color: white;
  display: flex;
}
.chart{
  height: 100%;
  width:90%;
}
.chartProcess{
  height: 100%;
  width:30%;
}
.detailDiv{
  margin-top:5px;
  width:100%;
}
.middleDiv{
  margin-top:5px;
  width:100%;
}
.lineDiv{
  margin-top:5px;
  width:100%;
}
</style>
