// eslint-disable-next-line no-unused-vars
var baseConfig = {
  apiUrl: 'https://amfg-cz.liteon.com/dfap_api_ent',
 //devApiUrl: 'https://amfg-cz.liteon.com/dfap_api_ent',
  devApiUrl: 'http://localhost:61871/api',
  basSite: 'TH-THAILAND'
}
